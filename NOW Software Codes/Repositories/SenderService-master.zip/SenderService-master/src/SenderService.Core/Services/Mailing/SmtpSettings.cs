﻿using System.Text.Json.Serialization;

namespace SenderService.Core.Services.Mailing;

public class SmtpSettings
{
    public const string SectionName = nameof(SmtpSettings);
    public static SmtpSettings Bind { get; set; } = new SmtpSettings();

    [JsonPropertyName("PrimaryServer")]
    public ServerSetting PrimaryServer { get; set; } = new ServerSetting();
    [JsonPropertyName("SecondaryServer")]
    public ServerSetting SecondaryServer { get; set; } = new ServerSetting();
    [JsonPropertyName("DefaultSender")]
    public DefaultSender DefaultSender { get; set; } = new DefaultSender();

}

public class ServerSetting
{
    //public EmailFrom From { get; set; } = new EmailFrom();
    public string? FromEmail { get; set; }
    public string Host { get; set; } = null!;
    public string AlternateHost { get; set; } = null!;
    public int Port { get; set; }
    public string? UserName { get; set; }
    public string? Password { get; set; }
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; }
}

public class DefaultSender
{
    public bool Mailkit { get; set; }
    public bool BuiltIn { get; set; }
}
