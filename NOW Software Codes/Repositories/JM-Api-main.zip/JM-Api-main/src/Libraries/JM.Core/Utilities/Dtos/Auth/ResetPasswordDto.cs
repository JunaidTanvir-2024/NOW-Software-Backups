namespace JM.Core.Utilities.Dtos.Auth;

public abstract class ResetPasswordDto
{
    public sealed record Request
    {
        public required string Email { get; set; }
        public required string Password { get; set; }
    }
    public sealed record Response
    {
        public bool IsSuccess { get; set; }
    }
}
