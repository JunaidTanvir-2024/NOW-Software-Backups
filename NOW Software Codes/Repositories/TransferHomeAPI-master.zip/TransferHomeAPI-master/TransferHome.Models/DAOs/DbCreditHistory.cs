﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.DAOs
{
    public class DbCreditHistory
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string PaymentType { get; set; }
        public string Amount { get; set; }
        public string Currency { get; set; }
        public DateTime TransactionDate { get; set; }
    }
}
