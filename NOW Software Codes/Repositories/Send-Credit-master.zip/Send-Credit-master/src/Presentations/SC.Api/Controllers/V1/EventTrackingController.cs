﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SC.Api.Model.EventTracking;
using SC.Core.Features.Countries.Requests;
using SC.Core.Features.Notification.Request;

namespace SC.Api.Controllers.V1;

[ApiVersion(1.0)]
public class EventTrackingController : BaseApiController
{
    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> GetCountries(EventTrackingModel model)
    {
        var result = await Mediator.Send(model.Map());

        if (!result)
            return Ok();
        return NotFound(result);

    }
}

