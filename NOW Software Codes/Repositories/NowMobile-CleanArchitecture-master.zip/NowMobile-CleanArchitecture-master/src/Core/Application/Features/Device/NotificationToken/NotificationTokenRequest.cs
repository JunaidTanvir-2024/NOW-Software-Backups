﻿namespace Application.Features.Device.NotificationToken;

public class NotificationTokenRequest : IRequest<Result<object>>
{
    public string DeviceId { get; set; } = default!;
    public string DeviceToken { get; set; } = default!;
}
