﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PayPalInApp.Configurations;
using PayPalInApp.Interfaces;
using PayPalInApp.Models;
using PayPalInApp.Models.Paypal;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace TalkHome.Services
{
    public class PayPalService : IPayPalService
    {
        private readonly string PayPalApiEndpoint;
        private readonly string Pay360PayPalApiEndpoint;

        private readonly IOptions<AppConfig> AppConfig;

        public PayPalService(IOptions<AppConfig> appConfig)
        {
            AppConfig = appConfig;
            PayPalApiEndpoint = appConfig.Value.PaypalApiEndpoint;
            Pay360PayPalApiEndpoint = appConfig.Value.Pay360PayPalApiEndpoint;
        }

        private PayPalCreateSalePaymentRequest MapPayload(PayPalCreateSalePaymentRequest request, PaypalStartPaymentModel model)
        {
            try
            {
                List<ProductBasket> basket = new List<ProductBasket>();
                string msisdn = "";

                basket.Add(new ProductBasket
                {
                    Amount = model.amount,
                    BundleRef = "",
                    ProductItemCode = "THAATA",
                    ProductRef = request.CustomerMsisdn
                });
                msisdn = request.CustomerMsisdn;

                request.Basket = basket;

                request.CustomerMsisdn = msisdn;
                request.CustomerUniqueRef = msisdn;
                request.CustomerEmail = "";

                request.ProductCode = "THA";
                request.Transaction = new Transactions { Amount = new Amounts() };

                request.Transaction.Amount.Currency = model.currency;
                request.Transaction.Amount.Total = model.amount;
                request.Transaction.Description = "PayPal Transaction for Customer Unique Reference: " + request.CustomerUniqueRef;


                return request;
            }
            catch ( Exception)
            {
                throw;
            }

        }

        private async Task<string> Post(string address, string json)
        {
            var Content = new StringContent(json, Encoding.UTF8, "application/json");
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(address), Timeout = TimeSpan.FromSeconds(60) })
                {
                    HttpResponseMessage response = await client.PostAsync("", Content);
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    if (!response.IsSuccessStatusCode || response.Content == null)
                    {
                        throw new WebException();
                    }

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public string GetResumeUrl(string path, string baseUrl)
        {
            string Domain = "";

            if (Debugger.IsAttached)
            {
                Domain = baseUrl + "/" + path;
            }
            else
            {
                Domain = new Uri(baseUrl).ToString();
                Domain = Domain.Replace("http", "https");
                Domain = Domain + path;
            }

            return Domain;

        }
        
        public async Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request, PaypalStartPaymentModel model)
        {
            try
            {

                var fullRequest = MapPayload(request, model);

                GenericPayPalApiResponse<PayPalCreateSalePaymentResponse> ret;

                string endpoint = "";
                string Json = "";
                string Result = "";
                endpoint = PayPalApiEndpoint + "Paypal/CreateSalePayment";
                Json = JsonConvert.SerializeObject(fullRequest);
                Result = await Post(endpoint, Json);
                if (Result == null)
                {
                    return null;
                }
                ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>>(Result);
                return ret;
            }
            catch (Exception)
            {
                throw;
            }

        }


        public async Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request)
        {
            try
            {
                request.ProductCode = "THA";

                GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse> ret;

                string endpoint = "";
                string Json = "";
                string Result = "";
                endpoint = PayPalApiEndpoint + "Paypal/ExecuteSalePayment";
                Json = JsonConvert.SerializeObject(request);
                Result = await Post(endpoint, Json);
                if (Result == null)
                {
                    return null;
                }
                ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>>(Result);
                return ret;
            }
            catch (Exception)
            {
                throw;
            }
        }


        // Pay360-PayPal 

        public async Task<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>> Pay360PayPalCreateSalePayment(PaypalStartPaymentModel model,string baseUrl,string ipAddress,string FirstUseDate)
        {
            try
            {

                var fullRequest = Pay360PayPalMapPayload(model,baseUrl, ipAddress,FirstUseDate);

                GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse> ret;

                string endpoint = "";
                string Json = "";
                string Result = "";
                endpoint = Pay360PayPalApiEndpoint + "Paypal/Payment";
                Json = JsonConvert.SerializeObject(fullRequest);
                Result = await Post(endpoint, Json);
                if (Result == null)
                {
                    return null;
                }
                ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<Pay360PayPalCreateSalePaymentResponse>>(Result);
                return ret;
            }
            catch (Exception)
            {
                throw;
            }

        }



        public async Task<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>> Pay360ResumePayment(Pay360PayPalResumePaymentRequest request)
        {
            try
            {
                GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse> ret;

                string endpoint = "";
                string Json = "";
                string Result = "";
                endpoint = Pay360PayPalApiEndpoint + "Paypal/Resume";
                Json = JsonConvert.SerializeObject(request);
                Result = await Post(endpoint, Json);
                if (Result == null)
                {
                    return null;
                }
                ret = JsonConvert.DeserializeObject<GenericPayPalApiResponse<Pay360PayPalCreateResumePaymentResponse>>(Result);
                return ret;
            }
            catch (Exception)
            {
                throw;
            }
        }



        private Pay360PayPalCreateSalePaymentRequest Pay360PayPalMapPayload(PaypalStartPaymentModel model,string baseUrl,string ipAddress,string FirstUseDate)
        {

            try
            {

                Pay360PayPalCreateSalePaymentRequest request = new Pay360PayPalCreateSalePaymentRequest();
                List<ProductBasket> basket = new List<ProductBasket>();
                string msisdn = "";

                basket.Add(new ProductBasket
                {
                    Amount = model.amount,
                    BundleRef = "",
                    ProductItemCode = "THAATA",
                    ProductRef = model.msisdn
                });
                msisdn = model.msisdn;

                request.Basket = basket;

                request.CustomerMsisdn = msisdn;
                request.CustomerUniqueRef = msisdn;
                request.CustomerEmail = "";

                request.ProductCode = "THA";
                paymentMethod paymentMethod = new paymentMethod();
                paymentMethod.paypal = new paypal
                {
                    returnUrl = GetResumeUrl("app/pay360topUpSuccessReturn?reference=" + model.msisdn + "&amount=" + model.amount + "&currency=" + model.currency + "&utm_source=" + model.utm_source + "&utm_medium=" + model.utm_medium + "&utm_campaign=" + model.utm_campaign, baseUrl),
                    cancelUrl = GetResumeUrl("app/cancelReturn", baseUrl)
                };
                request.paymentMethod = paymentMethod;
                request.CustomerName = "Guest";
                request.transactionCurrency = model.currency;
                request.transactionAmount = model.amount;
                request.isDirectFullfilment = true;
                request.ipAddress = ipAddress;
                customField customFields = new customField();
                List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = "THA", transient = false },
                    new fieldstate() { name = "ProductItemCode", value = "THAATA", transient = false },
                    new fieldstate() { name = "FirstUseDate", value = FirstUseDate, transient = false },
                };
                customFields.fieldState = _fieldState;
                request.customFields = customFields;
                return request;
            }
            catch (Exception)
            {
                throw;
            }

        }

     
    }
}

