﻿namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface IInternationalTopupServiceFeeCalculator
    {
        (decimal totalServiceFee, decimal serviceFee, decimal serviceFeeDiscount) Calculate(string origination, string destination, string currency, decimal productPrice);
    }
}
