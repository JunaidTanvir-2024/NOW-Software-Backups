﻿using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using THM.Infrastructure.DAL;
using THM.Infrastructure.Services;
using THM.Models.Enums;

namespace THM.Infrastructure.BLL
{
    public class SimOrderEmails_BL : ISimOrderEmails_BL
    {
        private readonly ISimOrderEmails_DL _simOrderEmails_DL;
        private readonly IEmail_BL _email_BL;
        private readonly ILogger<SimOrderEmails_BL> _logger;

        public SimOrderEmails_BL(
            ISimOrderEmails_DL simOrderEmails_DL,
            IEmail_BL email_BL,
            ILogger<SimOrderEmails_BL> logger)
        {
            _simOrderEmails_DL = simOrderEmails_DL;
            _email_BL = email_BL;
            _logger = logger;
        }

        public async Task SendNotActivatedSimEmail(SimOrderType simOrderType)
        {
            var simOrders = await _simOrderEmails_DL.GetNotActivatedSimOrders(simOrderType);
            foreach (var item in simOrders)
            {
                var itemDetails = await _simOrderEmails_DL.GetSentEmailsDetail(item.id, simOrderType, EmailsType.NotActivatedSim);

                if (itemDetails.Count() == 0
                    || (itemDetails.Count() > 0 && itemDetails.Where(x => x.IsEmailSent == false).Count() < 3))
                {

                    //send email
                    var emailResponse = await _email_BL.SendNotActivatedSimEmail(item.email, simOrderType);


                    //Update user email status
                    await _simOrderEmails_DL.LogEmail(item.id, simOrderType, EmailsType.NotActivatedSim,
                                                                    emailResponse, emailResponse ? null : "unable to send email");

                    _logger.LogInformation($"SendNotActivatedSimEmail: {item.email}, time: {DateTimeOffset.Now}");
                }
            }
        }
        public async Task SendNotToppedUpEmail(SimOrderType simOrderType)
        {
            var simOrders = await _simOrderEmails_DL.GetNotToppedUpSimOrders(simOrderType);
            foreach (var item in simOrders)
            {
                var itemDetails = await _simOrderEmails_DL.GetSentEmailsDetail(item.id, simOrderType, EmailsType.NotToppedUp);

                if (itemDetails.Count() == 0
                    || (itemDetails.Count() > 0 && itemDetails.Where(x => x.IsEmailSent == false).Count() < 3))
                {


                    //send email
                    var emailResponse = await _email_BL.SendNotToppedUpEmail(item.email, simOrderType);

                    //Update user email status
                    await _simOrderEmails_DL.LogEmail(item.id, simOrderType, EmailsType.NotToppedUp,
                                                                    emailResponse, emailResponse ? null : "unable to send email");

                    _logger.LogInformation($"SendNotToppedUpEmail: {item.email}, time: {DateTimeOffset.Now}");
                }
            }
        }
        public async Task SendOtherServicesEmail(SimOrderType simOrderType)
        {
            var simOrders = await _simOrderEmails_DL.GetOrdersForOtherServicesEmail(simOrderType);
            foreach (var item in simOrders)
            {
                var itemDetails = await _simOrderEmails_DL.GetSentEmailsDetail(item.id, simOrderType, EmailsType.OtherServicesEmail);

                if (itemDetails.Count() == 0
                    || (itemDetails.Count() > 0 && itemDetails.Where(x => x.IsEmailSent == false).Count() < 3))
                {
                    //send email
                    var emailResponse = await _email_BL.SendOtherServicesEmail(item.email, simOrderType);

                    //Update user email status
                    await _simOrderEmails_DL.LogEmail(item.id, simOrderType, EmailsType.OtherServicesEmail,
                                                                    emailResponse, emailResponse ? null : "unable to send email");

                    _logger.LogInformation($"SendOtherServicesEmail: {item.email}, time: {DateTimeOffset.Now}");
                }
            }
        }
        public async Task SendSocialMediaEmails(SimOrderType simOrderType)
        {
            var simOrders = await _simOrderEmails_DL.GetOrdersForSocialMediaEmails(simOrderType);
            foreach (var item in simOrders)
            {
                var itemDetails = await _simOrderEmails_DL.GetSentEmailsDetail(item.id, simOrderType, EmailsType.SocialMediaEmails);

                if (itemDetails.Count() == 0
                    || (itemDetails.Count() > 0 && itemDetails.Where(x => x.IsEmailSent == false).Count() < 3))
                {
                    //send email
                    var emailResponse = await _email_BL.SendSocialMediaEmails(item.email, simOrderType);

                    //Update user email status
                    await _simOrderEmails_DL.LogEmail(item.id, simOrderType, EmailsType.SocialMediaEmails,
                                                                    emailResponse, emailResponse ? null : "unable to send email");

                    _logger.LogInformation($"SendSocialMediaEmails: {item.email}, time: {DateTimeOffset.Now}");
                }
            }
        }
        public async Task SendWhyAndBenefitsEmail(SimOrderType simOrderType)
        {
            var simOrders = await _simOrderEmails_DL.GetWhyAndBenefitsEmails(simOrderType);

            foreach (var item in simOrders)
            {
                var itemDetails = await _simOrderEmails_DL.GetSentEmailsDetail(item.id, simOrderType, EmailsType.WhyAndBenefits);

                if (itemDetails.Count() == 0
                    || (itemDetails.Count() > 0 && itemDetails.Where(x => x.IsEmailSent == false).Count() < 3))
                {
                    //send email
                    var emailResponse = await _email_BL.SendWhyAndBenefitsEmail(item.email, simOrderType);

                    //Update user email status
                    await _simOrderEmails_DL.LogEmail(item.id, simOrderType, EmailsType.WhyAndBenefits,
                                                    emailResponse, emailResponse ? null : "unable to send email");

                    _logger.LogInformation($"SendWhyAndBenefitsEmail: {item.email}, time: {DateTimeOffset.Now}");
                }
            }
        }
    }
}
