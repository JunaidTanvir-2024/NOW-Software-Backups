﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkHomeContactSyncApi.Contracts;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Request;
using TalkHomeContactSyncApi.Contracts.ContactSync.RequestAndResponse.Response;

namespace TalkHomeContactSyncApi.Infrastructure.ContactSync
{
    public interface IContactSyncPost
    {
        Task<GenericApiResponse<IList<ContactSyncResponse>>> GetFilteredTalkHomeContacts(ContactSyncRequest contacts);
    }
}
