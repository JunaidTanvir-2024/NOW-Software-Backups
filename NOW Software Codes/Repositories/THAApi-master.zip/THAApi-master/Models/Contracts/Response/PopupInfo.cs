﻿namespace Models.Contracts.Response
{
    public class PopupInfo
    {
        public string Heading { get; set; }
        public string Description { get; set; }
    }
}
