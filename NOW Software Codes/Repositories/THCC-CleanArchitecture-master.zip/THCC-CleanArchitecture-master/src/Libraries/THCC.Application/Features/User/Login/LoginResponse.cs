﻿using THCC.Application.Models.Dtos;

namespace THCC.Application.Features.User.Login;

public class LoginResponse
{
    public string Token { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;
    public UserDto User { get; set; } = default!;
}