﻿$(document).ready(function () {

    //Get User Details
    GetUserData_AccDet();

    $('#btnUpdateMailStatus').click(function () {

        $.ajax({
            url: "/Account/UpdateMailSubscription",
            type: "POST",
            data: { Status: $('#chk_MailingList_Ad').prop('checked') ? true : false },
            beforeSend: function (xhr) {

                $('#UpdateMailStatusSuccessMsg,#UpdateMailStatusErrorMsg').slideUp();

                $('#btnUpdateMailStatus').attr('disabled', true);
                $('#chk_MailingList_Ad').attr('disabled', true);
                $('#btnUpdateMailStatusSpinner').fadeIn();
            },
            success: function (response) {
                if (response != null) {
                    if (response.errorCode == 0) {
                        if (response.data == true) {
                            $('#UpdateMailStatusSuccessMsg').slideDown().delay(5000).slideUp();
                        }
                        else {
                            $('#UpdateMailStatusErrorlbl').text(response.message);
                            $('#UpdateMailStatusErrorMsg').slideDown().delay(5000).slideUp();
                        }
                    }
                    else {
                        $('#UpdateMailStatusErrorlbl').text(response.message);
                        $('#UpdateMailStatusErrorMsg').slideDown().delay(5000).slideUp();
                    }
                }
                else {
                    $('#UpdateMailStatusErrorlbl').text('Something went wrong on server.');
                    $('#UpdateMailStatusErrorMsg').slideDown().delay(5000).slideUp();
                }
            },
            error: function (xhr, status, error) {

                if ($('#chk_MailingList_Ad').prop('checked')) {
                    $('#chk_MailingList_Ad').prop('checked', false);
                }
                else {
                    $('#chk_MailingList_Ad').prop('checked', true);
                }

                $('#UpdateMailStatusErrorlbl').text('Something went wrong on server.');
                $('#UpdateMailStatusErrorMsg').slideDown().delay(5000).slideUp();
            },
            complete: function (xhr, status) {
                $('#btnUpdateMailStatus').attr('disabled', false);
                $('#chk_MailingList_Ad').attr('disabled', false);
                $('#btnUpdateMailStatusSpinner').fadeOut();
            }
        });


    })

    $('#BtnChangePassword_Ad').click(function () {

        if (!$('#PasswordChangeForm').valid()) {
            return false;
        }
        else {
            var model = {
                NewPassword: $('#NewPassword').val(),
                ConfirmNewPassword: $('#ConfirmNewPassword').val(),
                OldPassword: $('#OldPassword').val()
            }

            $.ajax({
                url: "/Account/ChangeAccountPasword",
                type: "POST",
                data: model,
                beforeSend: function (xhr) {
                    $('#ChangePasswordSuccessMsg_Ad,#ChangePasswordErrorMsg_Ad').slideUp();
                    $('#BtnChangePassword_Ad').attr('disabled', true);
                    $('#BtnChangePasswordSpinner_Ad').fadeIn();
                },
                success: function (response) {
                    if (response != null) {
                        if (response.errorCode == 0) {
                            if (response.data == true) {
                                ResetForm('PasswordChangeForm');
                                $('#ChangePasswordErrorMsg_Ad').slideUp();
                                $('#ChangePasswordSuccessMsg_Ad').slideDown().delay(5000).slideUp();
                            }
                            else {
                                $('#ChangePasswordErrorlbl_Ad').text(response.message);
                                $('#ChangePasswordErrorMsg_Ad').slideDown().delay(5000).slideUp();
                            }
                        }
                        else {
                            $('#ChangePasswordErrorlbl_Ad').text(response.message);
                            $('#ChangePasswordErrorMsg_Ad').slideDown().delay(5000).slideUp();
                        }
                    }
                    else {
                        $('#ChangePasswordErrorlbl_Ad').text('Something went wrong on server.');
                        $('#ChangePasswordErrorMsg_Ad').slideDown().delay(5000).slideUp();;
                    }
                },
                error: function (xhr, status, error) {
                    $('#ChangePasswordErrorlbl_Ad').text('Something went wrong on server.');
                    $('#ChangePasswordErrorMsg_Ad').slideDown().delay(5000).slideUp();
                },
                complete: function (xhr, status) {
                    $('#BtnChangePassword_Ad').attr('disabled', false);
                    $('#BtnChangePasswordSpinner_Ad').fadeOut();
                }
            });
        }

    })

});

function GetUserData_AccDet() {

    $.ajax({
        url: "/Account/GetUserDetails",
        type: "GET",
        beforeSend: function (xhr) {


        },
        success: function (response) {
            if (response != null) {
                if (response.errorCode == 0) {

                    $('#txtFirstName_Ad').val(response.data.firstName);
                    $('#txtLastName_Ad').val(response.data.lastName);
                    $('#txtEmail_Ad').val(response.data.email);

                    if (response.data.mailSubscription) {
                        $('#chk_MailingList_Ad').prop('checked', true)
                    }
                    else {
                        $('#chk_MailingList_Ad').prop('checked', false);
                    }
                }
                else {

                }
            }
            else {

            }
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

        }
    });

}