﻿namespace Application.Common.Settings;
public class BasicAuthSetting
{
    public const string SectionName = "BasicAuthSetting";
    public static BasicAuthSetting Bind = new BasicAuthSetting();
    public string? UserName { get; set; }
    public string? Password { get; set; }
}
