﻿using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
   
    public class TopupPaymentHistory
    {
        public DateTime TransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Reference { get; set; }
    }

    public class LastTopup
    {
        public DateTime TransDate { get; set; }
        public string Amount { get; set; }
        public string Method { get; set; }
        public string Reference { get; set; }
        public Pay360GetAutoTopUpResponse AutoTopUp { get; set; }
    }
}
