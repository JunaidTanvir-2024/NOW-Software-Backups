﻿using Infrastructure.DAL;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL
{
    public class Auth_BL : IAuth_BL
    {

        private IAuth_DL Db;
        private readonly ILogger Logger;
        private readonly IConfiguration Config;


        public Auth_BL(ILogger logger, IAuth_DL db, IConfiguration Conf)
        {
            Db = db;
            Logger = logger;
            Config = Conf;
        }

        public async Task<GenericApiResponse<bool>> VerifyPreAuth(VerifyPreAuthRequest request)
        {

            GenericApiResponse<bool> response = new GenericApiResponse<bool>();

            try
            {

                bool dbResult = await Db.VerifyPreAuth(request.AuthTx, request.ProductCode, request.ProductItemCode);
                if (dbResult == true)
                {
                    response.errorCode = 0;
                    response.message = "Success";
                    response.status = "Success";
                    response.payload = true;
                }
                else
                {
                    response.errorCode = 1;
                    response.message = "Failure";
                    response.status = "Failure";
                    response.payload = false;
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_BL, Method: VerifyPreAuth, Parameters =>  {JsonConvert.SerializeObject(request)}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
                response.errorCode = 2;
                response.message = "Failure:Excep";
                response.status = "Failure";
                response.payload = false;
            }
            return response;

        }
        public async Task<GenericApiResponse<PreAuthResponse>> PreAuth(PreAuthRequest request, string remoteIp)
        {

            GenericApiResponse<PreAuthResponse> response = new GenericApiResponse<PreAuthResponse>();

            try
            {

                string[] delimeters = Config["Settings:Delimeters"].Split(',');

                Random rand = new Random();
                int index = rand.Next(0, delimeters.Length - 1);

                string enc_d = delimeters[index];

                Guid guid = Guid.NewGuid();
                string enc_g = guid.ToString("N");

                Guid key = Guid.NewGuid();
                string enc_k = key.ToString("N");

                int enc_a = (int)Algo.HMACSHA256;

                EType selectedEType = EType.DeviceUUID;

                int enc_ty = (int)selectedEType;

                string eTypeValue = GetETypeValue(request, selectedEType);

                string text = enc_g + enc_d + eTypeValue;

                string enc_tx = GetHMACSHA256(text, enc_k);
                //int dd = enc_tx.Length;
                int dbResult = await Db.AddPreAuth(request, enc_g, enc_k, enc_tx, enc_a, enc_d, enc_ty, remoteIp);
                if (dbResult > 0)
                {
                    // Guid-Delimeter-EType-EAlgo-EKey
                    string responseText = enc_g + "-" + enc_d + "-" + enc_ty + "-" + enc_a + "-" + enc_k;
                    response.errorCode = 0;
                    response.message = "Success";
                    response.status = "Success";
                    response.payload = new PreAuthResponse() { token_tx = responseText };
                }
                else
                {
                    response.errorCode = 1;
                    response.message = "Failure";
                    response.status = "Failure";
                    response.payload = new PreAuthResponse() { token_tx = "" };
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_BL, Method: PreAuth, Parameters => remoteIp: {remoteIp}, {JsonConvert.SerializeObject(request)}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
                response.errorCode = 2;
                response.message = "Failure:Excep";
                response.status = "Failure";
                response.payload = new PreAuthResponse() { token_tx = "" };
            }
            return response;

        }

        public string GetETypeValue(PreAuthRequest request, EType eType)
        {

            string eTypeText = "";

            try
            {
                if (eType == EType.DeviceUUID)
                {
                    eTypeText = request.DeviceUuid;
                }
                else if (eType == EType.Msisdn)
                {
                    eTypeText = request.Msisdn;
                }
                else if (eType == EType.Email)
                {
                    eTypeText = request.Email;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_BL, Method: GetETypeValue, Parameters => eType: {eType}, {JsonConvert.SerializeObject(request)}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
            }
            return eTypeText;

        }
        public string GetHMACSHA256(string text, string privatekey)
        {

            string hashString = string.Empty;
            try
            {
                byte[] key = Encoding.UTF8.GetBytes(privatekey);
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                HMACSHA256 hashstring = new HMACSHA256(key);
                byte[] hash = hashstring.ComputeHash(bytes);
                foreach (byte x in hash)
                {
                    hashString += String.Format("{0:x2}", x);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_BL, Method: GetHMACSHA256, text: {text}, privatekey: {privatekey}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return hashString;
        }

        public async Task<string> GetRemoteIPAddress(HttpContext context, bool allowForwarded = true)
        {
            if (allowForwarded)
            {
                string header = (context.Request.Headers["CF-Connecting-IP"].FirstOrDefault() ?? context.Request.Headers["X-Forwarded-For"].FirstOrDefault());
                if (IPAddress.TryParse(header, out IPAddress ip))
                {
                    return ip.ToString();
                }
            }
            return context.Connection.RemoteIpAddress.ToString().Replace("::ffff:", "");
        }


    }
}
