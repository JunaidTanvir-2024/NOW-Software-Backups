﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class AddEmailChannelRequest
    {
        [Required]
        public string productCode { get; set; }

        [JsonProperty("commercial_opted_in")]
        public DateTime? commercialOptedIn { get; set; }

        [JsonProperty("commercial_opted_out")]
        public DateTime? commercialOptedOut { get; set; }

        [JsonProperty("transactional_opted_in")]
        public DateTime? transactionalOptedIn { get; set; }

        [JsonProperty("transactional_opted_out")]
        public DateTime? transactionalOptedOut { get; set; }

        [Required]
        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("timezone")]
        public string TimeZone { get; set; }

        [JsonProperty("locale_country")]
        public string LocaleCountry { get; set; }

        [JsonProperty("locale_language")]
        public string LocaleLanguage { get; set; }
    }
}
