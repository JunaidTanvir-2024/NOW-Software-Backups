﻿namespace Application.Features.AutoTopup.GetAutoTopup;

public class GetAutoTopupRequestValidator : AbstractValidator<GetAutoTopupRequest>
{
    public GetAutoTopupRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");
    }
}