﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using TransferHomeAPI.JwtHelpers;
using TransferHome.Models.Contracts.Request;
using TransferHome.Models.Contracts.Response;
using TrasnferHome.Infrastructure.BLL.Interfaces;
using TrasnferHome.Models.Contracts;
using TrasnferHome.Models.Utility;

namespace TransferHomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IBL_User Bl;
        private readonly ILogger Logger;
        private readonly IConfiguration Configuration;

        public AccountController(IBL_User bl, ILogger logger, IConfiguration configuration)
        {
            Bl = bl;
            Logger = logger;
            Configuration = configuration;
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("LoginSignUpByEmail")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> LoginSignUpByEmail([FromBody]LoginSignUpEmailRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.LoginSignUpByEmail(model);

                if (response.errorCode == 0)
                {
                    //response.payload.GenerateToken(Configuration);
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: LoginSignUpByEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("IsEmailAlreadyExist")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> IsEmailAlreadyExist([FromBody]IsEmailAlreadyExistRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.IsEmailAlreadyExist(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: IsEmailAlreadyExist, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("VerifyEmail")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> VerifyEmail([FromBody]VerifyEmailRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.VerifyEmailbyToken(model, UserTokenTypes.EmailVerificationToken);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("ReSendEmailToken")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> ReSendEmailToken([FromBody]ReSendTokenRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.ReSendEmailVerificationToken(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ReSendEmailToken, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("LoginSignUpByPhoneNumber")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> LoginSignUpByPhoneNumber([FromBody]LoginSignUpPhoneNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.LoginSignUpByPhoneNumber(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: LoginSignUpByPhoneNumber, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("IsPhoneNumberAlreadyExist")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> IsPhoneNumberAlreadyExist([FromBody]IsPhoneNumberAlreadyExistRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.IsPhoneNumberAlreadyExist(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: IsEmailAlreadyExist, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("VerifyPinNumber")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> VerifyPinNumber([FromBody]VerifyPinNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.VerifyPinNumber(model);
                if (response.errorCode == 0)
                {
                    response.payload.GenerateToken(Configuration, model.UDID);
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyPinNumber, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("Logout")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> Logout()
        {
            try
            {
                var UDID = User.Claims.Where(x => x.Type == "UDID").FirstOrDefault().Value;
                var response = await Bl.Logout(UDID);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: Logout, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("ResendPinNumber")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> ResendPinNumber([FromBody]ResendPinNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.ResendPinNumber(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ResendPinNumber, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("ExternalLoginSignUp")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<ActionResult> ExternalLogin([FromBody]ExternalLoginRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.RegisterSocialMediaUser(model);

                if (response.errorCode == 0)
                {
                    //response.payload.GenerateToken(Configuration);
                    return Ok(response);

                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ExternalLogin, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("ForgotPassword")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.ForgotPassword(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ForgotPassword, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("VerifyForgotPasswordEmail")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> VerifyForgotPasswordEmail([FromBody]VerifyEmailRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.VerifyEmailbyToken(model, UserTokenTypes.PhoneNumberVerificationToken);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: VerifyForgotPasswordEmail, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("ReSendForgotPasswordToken")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> ReSendForgotPasswordToken([FromBody]ReSendTokenRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.ReSendForgotPasswordToken(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: ReSendForgotPasswordToken, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("UpdatePassword")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> UpdatePassword([FromBody]UpdateUserPasswordRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdatePassword(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: UpdatePassword, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetCreditHistory")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetCreditHistory()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetCreditHistory(new GetCreditHistoryRequestModel() { UserId = Convert.ToInt32(UserId) });

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetCreditHistory, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetTransferCreditHistory")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetTransferCreditHistory()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetTransferCreditHistory(new GetTransferCreditHistoryRequestModel() { UserId = Convert.ToInt32(UserId) });

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetTransferCreditHistory, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetUserInfo")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetUserInfo()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetUserinfo(new GetUserInfoRequestModel() { UserId = Convert.ToInt32(UserId) });

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserInfo, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("EditProfile")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> EditProfile(EditProfileRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.EditProfile(model, UserId);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: EditProfile, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetUserBalance")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetUserBalance()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetUserBalance(new GetUserBalanceRequestModel() { UserId = Convert.ToInt32(UserId) });

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetUserBalance, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetFavouriteTransactionNumbers")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetFavouriteTransactionNumbers()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetFavouriteTransactionNumbers(new GetFavouriteTransactionNumbersRequestModel() { UserId = Convert.ToInt32(UserId) });

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: GetFavouriteTransactionNumbers, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("SaveFavouriteTransactionNumber")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> SaveFavouriteTransactionNumber([FromBody]SaveFavouriteTransactionNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.SaveFavouriteTransactionNumber(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: SaveFavouriteTransactionNumber, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveFavouriteTransactionNumber")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveFavouriteTransactionNumber([FromBody]SaveFavouriteTransactionNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.RemoveFavouriteTransactionNumber(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: RemoveFavouriteTransactionNumber, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("SaveUpdateFCMToken")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> SaveUpdateFCMToken([FromBody]SaveUpdateFCMTokenRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.SaveUpdateFCMToken(model);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: SaveUpdateFCMToken, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveCreditHistory")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveCreditHistory([FromBody]RemoveCreditHistoryRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.RemoveCreditHistory(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: RemoveCreditHistory, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveTransferCreditHistory")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveTransferCreditHistory([FromBody]RemoveTransferCreditHistoryRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.RemoveTransferCreditHistory(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: RemoveTransferCreditHistory, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("UpdateUserNotificationSetting")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> UpdateUserNotificationSetting([FromBody]UpdateUserNotificationsSettingRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.UpdateUserNotificationsSetting(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: UpdateUserNotificationSetting, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("UpdateMailSubscription")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> UpdateMailSubscription([FromBody]UpdateMailSubscriptionRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.UpdateMailSubscription(model, Convert.ToInt32(UserId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: UpdateMailSubscription, Parameters=> {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}