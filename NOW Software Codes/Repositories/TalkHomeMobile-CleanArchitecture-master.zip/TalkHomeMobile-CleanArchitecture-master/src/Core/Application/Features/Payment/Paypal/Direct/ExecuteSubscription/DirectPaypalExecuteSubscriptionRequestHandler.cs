﻿using Application.Common.Interfaces.Payment;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using Domain.Aggregate;
using Mapster;
using Newtonsoft.Json;

namespace Application.Features.Payment.Paypal.Direct.ExecuteSubscription;

public class DirectPaypalExecuteSubscriptionRequestHandler : IRequestHandler<DirectPaypalExecuteSubscriptionRequest, Result<PaypalResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly IUnitOfWork _uow;
    private readonly ICurrentUser _currentUser;
    private readonly IUnitOfWork _unitOfWork;

    public DirectPaypalExecuteSubscriptionRequestHandler(IPaymentService paymentService,
        IUnitOfWork uow,
        ICurrentUser currentUser,
        IUnitOfWork unitOfWork)
    {
        _paymentService = paymentService;
        _uow = uow;
        _currentUser = currentUser;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<PaypalResponse>> Handle(
        DirectPaypalExecuteSubscriptionRequest request, CancellationToken cancellationToken)
    {
        return await _paymentService.HandlePaypalExecuteSubscriptionRequest(null!, null!, request.CustomerUniqueRef!, request.OrderId, request.Subscription_Id!);
    }
}