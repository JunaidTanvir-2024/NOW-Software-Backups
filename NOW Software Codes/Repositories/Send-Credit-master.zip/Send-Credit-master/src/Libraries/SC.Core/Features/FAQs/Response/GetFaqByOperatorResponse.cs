﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.FAQs.Response
{

    public sealed class GetFaqByOperatorResponse
    {
        public int OperatorFaqId { get; set; }
        public int OperatorId { get; set; }
        public int FaqId { get; set; }
        public string? Question { get; set; }
        public string? Answer { get; set; }
    }
}
