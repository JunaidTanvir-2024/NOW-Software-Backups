﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ApiContracts.Response;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SuccessObjectViewModel
    {
        public CheckOutTypes type { get; set; }
        public Pay360Resume3DResponseModel purchaseInfo { get; set; }
        public string PaymentMethod { get; set; }
    }
}
