namespace FH.Infrastructure.Services.MessageBroker;
public sealed class MessageBrokerSetting
{
    public const string SectionName = nameof(MessageBrokerSetting);
    public required string Username { get; set; }
    public required string Password { get; set; }
    public required ushort Port { get; set; }
    public required string Host { get; set; }
    public required bool ShouldIncludeDTOPrefix { get; set; }
    public required string MessagePrefix { get; set; }
}
