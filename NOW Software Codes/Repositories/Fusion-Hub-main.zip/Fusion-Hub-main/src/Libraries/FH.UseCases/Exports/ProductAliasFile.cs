using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using FluentValidation;

using MapsterMapper;

using Mediator;

using RW;

namespace FH.UseCases.Exports;
public sealed class ProductAliasFile
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public int Page { get; set; }
		public int RecordsPerPage { get; set; }
		public Filter? Filters { get; set; }

		public sealed record Filter
		{
			public string? CountryIsoCode { get; set; }
			public string? CurrencyCode { get; set; }
			public int? CallingCode { get; set; }
			public string? ValidityUnit { get; set; }
			public int? OperatorId { get; set; }
			public int? ProductId { get; set; }
			public int? ProductCategoryId { get; set; }
		}
	}

	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Page).GreaterThan(0);
			RuleFor(x => x.RecordsPerPage).LessThan(100);
		}
	}

	#endregion

	#region Response
	public sealed record Response
	{
		public long ProductId { get; set; }
		public string? ProductName { get; set; }
		public string? ProductAliasName { get; set; }
		public string? ProductDescription { get; set; }
		public string? ProductShortCode { get; set; }
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork, IMapper mapper) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;
		private readonly IMapper _mapper = mapper;

		public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
		{
			var productsRequestDto = _mapper.Map<ProductDto.Request>(request);

			productsRequestDto.IsActive = true;
			productsRequestDto.IsDeleted = false;

			(IEnumerable<ProductDto.Response> products, DatabasePaginationDto pagination) = await _unitOfWork.ProductRepository.GetProducts(productsRequestDto);

			if (products is null)
			{
				return ResultWrapper.Failure(AppConstants.StatusKey.NotFound, AppConstants.StatusCode.NotFound);
			}

			var excelFileData = products.Select(x => new Response()
			{
				ProductId = x.ProductId,
				ProductName = x.ProductName,
				ProductAliasName = string.Empty,
				ProductDescription = string.Empty,
				ProductShortCode = string.Empty
			});

			var excelFile = excelFileData.ConvertToCsvFile("Products");
			return ResultWrapper.Success(excelFile);
		}
	}
	#endregion
}
