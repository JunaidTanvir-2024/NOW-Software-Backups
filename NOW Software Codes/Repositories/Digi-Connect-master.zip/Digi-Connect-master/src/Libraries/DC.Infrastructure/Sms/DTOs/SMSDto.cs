using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DC.Infrastructure.Sms.DTOs;
internal sealed record SMSDto
{
    internal sealed record Request
    {
        public string? To { get; set; }
        public string message { get; set; }
        public string ProductCode { get; set; }
        public string RequestID { get; set; }
        public int RequestType { get; set; }
    }
    internal sealed record Response
    {

    }
}
