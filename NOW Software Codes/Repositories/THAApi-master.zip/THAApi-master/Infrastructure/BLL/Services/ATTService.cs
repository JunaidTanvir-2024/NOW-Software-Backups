﻿using Infrastructure.BLL.Services.Interfaces;
using Models.Contracts.Request;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services
{
    public class ATTService : IATTService
    {
        private readonly HttpClient _attClient;
        private readonly ILogger _logger;

        public ATTService(
            HttpClient httpClient,
            ILogger logger )
        {
            _attClient = httpClient;
            _logger = logger;
        }
        public async Task<AirtimeTransferProducts> GetProductsAsync(string account, string destination, string clientMSISDN)
        {
            string request = $"{account} - {destination} - {clientMSISDN}";

            try
            {
                var response = await _attClient.GetAsync($"transferToDirectGetOperatorProductsMSISDN?account={account}&destinationMSISDN={destination}&fromMSISDN={clientMSISDN}");

                var content = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<AirtimeTransferProducts>(content);
                }
                else
                {
                    _logger.Error($"Class=> ATTService, Method=> GetProductsAsync, Request=> {JsonConvert.SerializeObject(request)}, " +
                                  $"StatusCode=> {response.StatusCode}, Message=> {content}");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class=> ATTService, Method=> GetProductsAsync, Request=> {JsonConvert.SerializeObject(request)}, Message=> {ex.Message}");
            }
            return null;
        }
        public async Task<AirtimeTransferExecute> TransferBalance(TransFerTotransferConfirm request, string fromMsisdn)
        {
            try
            {
                var body = JsonConvert.SerializeObject(new
                {
                    request.nowtelTransactionReference,
                    request.operatorid,
                    request.product,
                    request.messageToRecipient,
                    fromMSISDN = fromMsisdn
                }, new JsonSerializerSettings
                {
                    ContractResolver = new DefaultContractResolver()
                });

                var requestMessage = new HttpRequestMessage(HttpMethod.Post, $"Execute")
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                var response = await _attClient.SendAsync(requestMessage);

                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<AirtimeTransferExecute>(await response.Content.ReadAsStringAsync());
                }
                else
                {
                    _logger.Error($"Class=> ATTService, Method=> TransferBalance, Request=> {JsonConvert.SerializeObject(request)}, " +
                                  $"StatusCode=> {response.StatusCode}, Message=> {response}");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class=> ATTService, Method=> TransferBalance, Request=> {JsonConvert.SerializeObject(request)}, Message=> {ex.Message}, StackTrace:{ex.StackTrace}");
            }
            return null;
        }
    }
}
