﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.DbConnections;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class Push_DL : IPush_DL
    {

        private IDbConnectionSettings DefaultConnection;
        private ILogger Logger;

        public Push_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));
            Logger = logger;
        }

        public async Task<GenericResult<bool>> AddPushToTagsRequest(SendPushToTagsRequest request, ApiPushResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode)
        {

            string logParameters = $" UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {JsonConvert.SerializeObject(apiResponseModel)}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblTags = new DataTable();
                tblTags.Columns.Add("tag", typeof(string));
                for (int i = 0; i < request.Tags.Count; i++)
                {
                    DataRow row = tblTags.NewRow();
                    row["tag"] = request.Tags[i];
                    tblTags.Rows.Add(row);
                }
                DataTable tblDevices = new DataTable();
                tblDevices.Columns.Add("deviceTypeId", typeof(int));
                for (int i = 0; i < request.DeviceTypes.Count; i++)
                {
                    DataRow row = tblDevices.NewRow();
                    row["deviceTypeId"] = (int)request.DeviceTypes[i];
                    tblDevices.Rows.Add(row);
                }
                var parameter = new DynamicParameters();
                parameter.Add("@push_id", apiResponseModel.PushIds[0]);
                parameter.Add("@product_code", request.ProductCode);
                parameter.Add("@operation_id", apiResponseModel.OperationId);
                parameter.Add("@notification_alert", request.Notification.Alert);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", JsonConvert.SerializeObject(apiResponseModel));
                parameter.Add("@push_type_id", (int)PushType.Notification);
                parameter.Add("@tag_group", request.TagGroup);
                parameter.Add("@tags", tblTags.AsTableValuedParameter("dbo.PushTagAudienceType"));
                parameter.Add("@devices", tblDevices.AsTableValuedParameter("dbo.PushDeviceType"));
                parameter.Add("@is_success", true);
                PushAudienceType audienceType = PushAudienceType.TagGroup;
                if(string.IsNullOrWhiteSpace(request.TagGroup))
                {
                    audienceType = PushAudienceType.Tag;
                }
                parameter.Add("@push_audience_type_id", (int)audienceType);
                if(request.Actions != null && request.Actions.Open != null)
                {
                    parameter.Add("@action_open_type", request.Actions.Open.Type.ToString());
                    parameter.Add("@action_open_content", request.Actions.Open.Content);
                    parameter.Add("@action_open_fallbackUrl", request.Actions.Open.FallbackUrl);
                }

                if(apiResponseModel.ContentUrls != null && apiResponseModel.ContentUrls.Count > 0)
                {
                    parameter.Add("@content_url", apiResponseModel.ContentUrls[0]);
                }

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddPushRequestTags", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_DL, Method: AddPushToTagsRequest, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddPushToTagsRequestError(SendPushToTagsRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode)
        {

            string logParameters = $" UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {airShipResponseJson}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblTags = new DataTable();
                tblTags.Columns.Add("tag", typeof(string));
                for (int i = 0; i < request.Tags.Count; i++)
                {
                    DataRow row = tblTags.NewRow();
                    row["tag"] = request.Tags[i];
                    tblTags.Rows.Add(row);
                }
                DataTable tblDevices = new DataTable();
                tblDevices.Columns.Add("deviceTypeId", typeof(int));
                for (int i = 0; i < request.DeviceTypes.Count; i++)
                {
                    DataRow row = tblDevices.NewRow();
                    row["deviceTypeId"] = (int)request.DeviceTypes[i];
                    tblDevices.Rows.Add(row);
                }
                var parameter = new DynamicParameters();               
                parameter.Add("@product_code", request.ProductCode);               
                parameter.Add("@notification_alert", request.Notification.Alert);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", airShipResponseJson);
                parameter.Add("@push_type_id", (int)PushType.Notification);
                parameter.Add("@tag_group", request.TagGroup);
                parameter.Add("@tags", tblTags.AsTableValuedParameter("dbo.PushTagAudienceType"));
                parameter.Add("@devices", tblDevices.AsTableValuedParameter("dbo.PushDeviceType"));
                parameter.Add("@is_success", false);
                PushAudienceType audienceType = PushAudienceType.TagGroup;
                if (string.IsNullOrWhiteSpace(request.TagGroup))
                {
                    audienceType = PushAudienceType.Tag;
                }
                parameter.Add("@push_audience_type_id", (int)audienceType);
                if (request.Actions != null && request.Actions.Open != null)
                {
                    parameter.Add("@action_open_type", request.Actions.Open.Type.ToString());
                    parameter.Add("@action_open_content", request.Actions.Open.Content);
                    parameter.Add("@action_open_fallbackUrl", request.Actions.Open.FallbackUrl);
                }
               
                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddPushRequestTags", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_DL, Method: AddPushToTagsRequestError, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddPushToNamedUser(SendPushToNamedUserRequest request, ApiPushResponse apiResponseModel, string airShipRequestJson, HttpStatusCode statusCode)
        {

            string logParameters = $" UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {JsonConvert.SerializeObject(apiResponseModel)}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblNamedUser = new DataTable();
                tblNamedUser.Columns.Add("named_user", typeof(string));
                for (int i = 0; i < request.NamedUsers.Count; i++)
                {
                    DataRow row = tblNamedUser.NewRow();
                    row["named_user"] = request.NamedUsers[i];
                    tblNamedUser.Rows.Add(row);
                }
                DataTable tblDevices = new DataTable();
                tblDevices.Columns.Add("deviceTypeId", typeof(int));
                for (int i = 0; i < request.DeviceTypes.Count; i++)
                {
                    DataRow row = tblDevices.NewRow();
                    row["deviceTypeId"] = (int)request.DeviceTypes[i];
                    tblDevices.Rows.Add(row);
                }
                var parameter = new DynamicParameters();
                parameter.Add("@push_id", apiResponseModel.PushIds[0]);
                parameter.Add("@product_code", request.ProductCode);
                parameter.Add("@operation_id", apiResponseModel.OperationId);
                parameter.Add("@notification_alert", request.Notification.Alert);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", JsonConvert.SerializeObject(apiResponseModel));
                parameter.Add("@push_type_id", (int)PushType.Notification);
                parameter.Add("@named_users", tblNamedUser.AsTableValuedParameter("dbo.PushNamedUserAudienceType"));
                parameter.Add("@devices", tblDevices.AsTableValuedParameter("dbo.PushDeviceType"));
                parameter.Add("@is_success", true);
                parameter.Add("@push_audience_type_id", (int)PushAudienceType.NamedUser);
                if (request.Actions != null && request.Actions.Open != null)
                {
                    parameter.Add("@action_open_type", request.Actions.Open.Type.ToString());
                    parameter.Add("@action_open_content", request.Actions.Open.Content);
                    parameter.Add("@action_open_fallbackUrl", request.Actions.Open.FallbackUrl);
                }

                if (apiResponseModel.ContentUrls != null && apiResponseModel.ContentUrls.Count > 0)
                {
                    parameter.Add("@content_url", apiResponseModel.ContentUrls[0]);
                }

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddPushRequestNamedUser", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_DL, Method: AddPushToNamedUser, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

        public async Task<GenericResult<bool>> AddPushToNamedUserError(SendPushToNamedUserRequest request, string airShipResponseJson, string airShipRequestJson, HttpStatusCode statusCode)
        {

            string logParameters = $" UserRequest => {JsonConvert.SerializeObject(request)}, ApiResponse => {airShipResponseJson}, ApiRequest: {airShipRequestJson}, ApiStatusCode: {statusCode.ToString()} ";
            try
            {
                DataTable tblNamedUser = new DataTable();
                tblNamedUser.Columns.Add("named_user", typeof(string));
                for (int i = 0; i < request.NamedUsers.Count; i++)
                {
                    DataRow row = tblNamedUser.NewRow();
                    row["named_user"] = request.NamedUsers[i];
                    tblNamedUser.Rows.Add(row);
                }
                DataTable tblDevices = new DataTable();
                tblDevices.Columns.Add("deviceTypeId", typeof(int));
                for (int i = 0; i < request.DeviceTypes.Count; i++)
                {
                    DataRow row = tblDevices.NewRow();
                    row["deviceTypeId"] = (int)request.DeviceTypes[i];
                    tblDevices.Rows.Add(row);
                }
                var parameter = new DynamicParameters();               
                parameter.Add("@product_code", request.ProductCode);                
                parameter.Add("@notification_alert", request.Notification.Alert);
                parameter.Add("@response_status_code", (int)statusCode);
                parameter.Add("@response_status", statusCode.ToString());
                parameter.Add("@user_request_Json", JsonConvert.SerializeObject(request));
                parameter.Add("@airship_request_Json", airShipRequestJson);
                parameter.Add("@airship_response_Json", airShipResponseJson);
                parameter.Add("@push_type_id", (int)PushType.Notification);
                parameter.Add("@named_users", tblNamedUser.AsTableValuedParameter("dbo.PushNamedUserAudienceType"));
                parameter.Add("@devices", tblDevices.AsTableValuedParameter("dbo.PushDeviceType"));
                parameter.Add("@is_success", false);
                parameter.Add("@push_audience_type_id", (int)PushAudienceType.NamedUser);
                if (request.Actions != null && request.Actions.Open != null)
                {
                    parameter.Add("@action_open_type", request.Actions.Open.Type.ToString());
                    parameter.Add("@action_open_content", request.Actions.Open.Content);
                    parameter.Add("@action_open_fallbackUrl", request.Actions.Open.FallbackUrl);
                }

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddPushRequestNamedUser", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: Push_DL, Method: AddPushToNamedUserError, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }

    }
}
