using MapsterMapper;

using MassTransit.NewIdProviders;

using Microsoft.AspNetCore.Mvc.Diagnostics;
using Microsoft.Extensions.Configuration;

using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Interfaces.Services;
using SC.Core.Common.Model;
using SC.Core.Features.CustomerOrder.Requests;
using SC.Core.Features.Notification.Request;
using SC.Core.Features.Products;
using SC.Core.Features.Products.Requests;
using SC.Core.Features.Products.Responses;
using SC.Core.Interfaces.Repositories;
using SC.Core.Models;
using SC.Core.Vendors.FusionHub;
using SC.Core.Vendors.Notification;
using SC.Core.Vendors.Payment;
using SC.Core.Vendors.Payment.Request;
using SC.Core.Vendors.Payment.Responses;

using static SC.Core.Models.PurchaseInventoryRequest;
using static SC.Core.Models.PurchaseInventoryResponse;

namespace SC.Core.Features.CustomerOrder;

internal sealed class ProcessOrderHandler : IRequestHandler<ProcessOrderRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IFusionHubService _fusionHubService;
    private readonly IPaymentIntegration _ipaymentIntegration;
    private readonly ICustomerOrderService _customerOrderService;
    private readonly IDiscountRepository _discountRepository;
    private readonly IMessageMatrixService _messageMatrixService;
    private readonly IConfiguration _configuration;

    public ProcessOrderHandler(ICustomerCartRespository customerCartRespository,
        IMapper mapper,
        ICommonService commonService,
        IFusionHubService fusionHubService,
        IPaymentIntegration paymentIntegration,
        ICustomerOrderService customerOrderService,
        IDiscountRepository discountRepository, 
        IMessageMatrixService messageMatrixService,
        IConfiguration configuration)
    {
        _customerCartRespository = customerCartRespository;
        _mapper = mapper;
        _commonService = commonService;
        _fusionHubService = fusionHubService;
        _ipaymentIntegration = paymentIntegration;
        _customerOrderService = customerOrderService;
        _discountRepository = discountRepository;
        _messageMatrixService = messageMatrixService;
        _configuration = configuration;
    }

    public async Task<IResultWrapper> Handle(ProcessOrderRequest request, CancellationToken cancellationToken)
    {
        string message = string.Empty;
        CustomerOrderDetailDto? orderDetail = await _customerCartRespository.GetCustomerOrderDetail(_commonService.GetUserID(), AppEnums.OrderStatusEnum.Init.Getkey());
        if (orderDetail == null || orderDetail.CartDetail.Count == 0)
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonCustomerOrderError, 404);
        (bool isValid, string MessageCode) = await IsValidOrder(orderDetail);
        if (!isValid)
            return ResultWrapper.Failure(MessageCode, 404);

        (decimal discountAmount, int discountTypeID) = await calculateDiscountAmount(request.PromoCode, orderDetail);// Discount logic
        if (discountAmount > 0)
        {
            orderDetail.DiscountInclusiveAmount = orderDetail.TotalOrderAmount - discountAmount;
            orderDetail.DiscountTypeId = discountTypeID;
            orderDetail.PromoCode = request.PromoCode!;
        }

        var paymentresponse = await ProcessPayment(request, orderDetail, discountAmount);// ProcessPayments

        if (paymentresponse != null && paymentresponse.IsFailure)
        {
            message = string.Empty;
            if (paymentresponse.Payload != null)
                message = string.Join(";", paymentresponse.Payload.Select(x => x.Value).ToArray());
            return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError + message, 404);
        }
        if (paymentresponse!.Require3DSecure)
        {
            return ResultWrapper.Success(paymentresponse);
        }
        var inventryresponse = await _customerOrderService.PurchaseInventory(orderDetail);

        if (inventryresponse == null || inventryresponse.Payload == null)
        {
            var cancelPaymentResposne = await _ipaymentIntegration.CancelPaymentAsync(new CancelPaymentRequest
            {
                TransactionId = paymentresponse!.TransactionId
            });
            await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, orderDetail.TotalOrderAmount, cancelPaymentResposne?.TransactionId, AppEnums.PaymentActionEnum.Cancel.Getkey(), cancelPaymentResposne?.IsFailure);// create history
            if (cancelPaymentResposne == null || cancelPaymentResposne.IsFailure)
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError, 404);
            return ResultWrapper.Failure(AppConstants.StatusKeys.PurchaseInventoryFailed, 404);
        }
        var purchaseInventroyResponse = _mapper.Map<PurchaseInventoryResponse>(inventryresponse.Payload);

        decimal RefundAmount = 0;
        if (purchaseInventroyResponse.PurchasedItems != null && purchaseInventroyResponse.PurchasedItems.Count > 0)
        {
            var failedProducts = purchaseInventroyResponse.PurchasedItems
                                                .Where(x => x.Status.ToUpper() == nameof(TransactionStatus.Cancelled).ToUpper() ||
                                                    x.Status.ToUpper() == nameof(TransactionStatus.Rejected).ToUpper() ||
                                                x.Status.ToUpper() == nameof(TransactionStatus.Declined).ToUpper()).ToList();
            if (failedProducts?.Count > 0)
                foreach (var product in failedProducts)
                {
                    var cartProduct = orderDetail.CartDetail.Where(x => x.ProductId == product.ProductId && x.ProductVendorCode == product.ProductVendorCode).FirstOrDefault();
                    if (cartProduct != null)
                        RefundAmount += cartProduct.Price;
                }
        }
        if (RefundAmount > 0)
        {
            var refundPayment = await _ipaymentIntegration.RefundPaymentAsync(new RefundPaymentRequest
            {
                TransactionId = paymentresponse!.TransactionId,
                IsFullRefund = false,
                PartialRefund = new PartialRefundDto
                {
                    Currency = orderDetail.Currency,
                    Amount = (float)Math.Round(RefundAmount, 2)
                }
            });
            await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, RefundAmount, refundPayment?.TransactionId, AppEnums.PaymentActionEnum.Refund.Getkey(), refundPayment?.IsFailure);// create history
            if (refundPayment == null || refundPayment.IsFailure)
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonPaymentError, 404);

            // email sent on failure
            await SendEmailOnPurchase(request, paymentresponse, orderDetail, AppConstants.EmailTemplates.PurchaseFailure);
        }

        await _customerOrderService.UpdateOrder(orderDetail);// Update Customer Order Status

        // Send Email on Successful order

        await SendEmailOnPurchase(request, paymentresponse, orderDetail, AppConstants.EmailTemplates.PurchaseConfirmation);

        return ResultWrapper.Success(orderDetail);
    }

    private async Task SendEmailOnPurchase(ProcessOrderRequest request, CardPayment360Response payment360Response, CustomerOrderDetailDto orderDetail, string templateName)
    {
        var emailTemplatePath = _configuration.GetSection("EmailTemplatePath").Value;


        Dictionary<string, string>? paramsTemplate = new()
                                                {
                                                    { "{F_NAME}" ,request?.Customer?.Name!  },
                                                    { "{Payment_Method}" ,"Card" },
                                                    { "{Transaction_ID}" , payment360Response.TransactionId  },
                                                    { "{Time_Stamp}" ,  DateTime.Now.ToShortDateString()  },
                                                    { "{Total_Amount}" ,orderDetail.TotalOrderAmount.ToString()},
                                                    { "{Service_Fee}" , orderDetail.ServiceFee.ToString()  },
                                                    { "{Total_Discount}",orderDetail.DiscountAmount.ToString() },
                                                    { "{Total_Payable}" ,orderDetail.TotalOrderAmount.ToString()  },
                                            };
        string productTable = "";
        foreach (var item in orderDetail.CartDetail)
        {
            string product = $"<tr><td style=\"color: #000000;font-size: 16px;padding-bottom: 10px;width: 180px;\">Description</td><td style=\"color: #000000;font-size: 16px;padding-bottom: 10px;word-break: break-all;\">{item.ProductName}</td></tr>";
            productTable = string.Concat(productTable, product);
            string email = $"<tr><td style=\"color: #000000;font-size: 16px;padding-bottom: 10px;width: 180px;\">Receiver Gets</td><td style=\"color: #000000;font-size: 16px;padding-bottom: 10px;\">{item.ProductName}</td></tr>";
            productTable =  string.Concat(productTable, email);
        }


        var body = EmailHelper.GenerateEmailContentPurchase(emailTemplatePath!,templateName, paramsTemplate, productTable);

        var requestEmail = new SendNotificationRequest()
        {
            To = request?.Customer?.EmailAddress!,
            EmailBody = body,
            ProductCode = "SC",
            Subject = AppConstants.EmailSubjects.PurchaseConfirmation + orderDetail.CustomerOrderID,
            EmailType = 1
        };

        await _messageMatrixService.SendEmailAsync(requestEmail);
    }

    private async Task<CardPayment360Response?> ProcessPayment(ProcessOrderRequest request, CustomerOrderDetailDto orderDetail, decimal discountAmount)
    {
        if (request.Customer == null)
            request.Customer = new Models.OrderCheckout.Payment.CardPaymentCustomerDto();
        if (request.Customer.BillingAddress == null)
            request.Customer.BillingAddress = new Models.OrderCheckout.Payment.BillingAddressDto();
        if (request.Payment == null)
            request.Payment = new Models.OrderCheckout.Payment.CardPaymentInfoDto();

        request.Customer.EmailAddress = orderDetail.Email;
        request.Customer.Name = orderDetail.Email;
        request.Customer.UniqueRef = orderDetail.CustomerID;
        request.Customer.Msisdn = orderDetail.Phone;
        request.Customer.BillingAddress.Line1 = orderDetail.StreetAddress1;
        request.Customer.BillingAddress.Line2 = orderDetail.StreetAddress2;
        request.Customer.BillingAddress.City = orderDetail.City;
        request.Customer.BillingAddress.Region = orderDetail.Region;
        request.Customer.BillingAddress.CountryCode = orderDetail.CountryCode;
        request.Customer.BillingAddress.PostCode = orderDetail.PostalCode;
        request.Payment.Currency = orderDetail.Currency;
        request.Payment.Amount = (float)Math.Round((orderDetail.TotalOrderAmount - discountAmount), 2);
        request.Payment.Recurring = false;
        request.Payment.Scheduling = false;
        request.Payment.Do3DSecure = _commonService.Do3DSecure();
        request.Payment.Deferred = false;// direct capture
        request.IpAddress = _commonService.GetIpAddress();
        var paymentresponse = await _ipaymentIntegration.CardPaymentAsync(request);// Perform Payments
        await _customerOrderService.CreateOrderPaymentHistory(orderDetail!.CustomerOrderID, (orderDetail.TotalOrderAmount - discountAmount), paymentresponse?.TransactionId, AppEnums.PaymentActionEnum.Payment.Getkey(), paymentresponse?.IsFailure, (paymentresponse?.Require3DSecure));// create history
        return paymentresponse;
    }

    private async Task<(bool isValid, string message)> IsValidOrder(CustomerOrderDetailDto orderDetail)
    {
        ProductPurchaseType productPurchaseType;
        bool IsValid = true;
        string message = string.Empty;

        string OrderIncompletionError = string.Empty;
        string WrongProductTypeError = string.Empty;
        var productstatusRequest = new GetProductStatusRequest() { ProductIds = new List<long>() };

        foreach (var item in orderDetail.CartDetail)
        {
            if (string.IsNullOrEmpty(item.ReceiverMobile) || string.IsNullOrEmpty(item.SenderMobile) || string.IsNullOrEmpty(item.ProductType) || string.IsNullOrEmpty(item.ProductVendorCode))
            {
                IsValid = false;
                message = AppConstants.StatusKeys.IncompleteOrder;
                break;
            }
            string productType = item.ProductType.ToUpper();
            switch (productType)
            {
                case AppConstants.ProductPurchaseType.Topup:
                    productPurchaseType = ProductPurchaseType.Topup; break;
                case AppConstants.ProductPurchaseType.Bundle:
                    productPurchaseType = ProductPurchaseType.Bundle; break;
                case AppConstants.ProductPurchaseType.InternetData:
                    productPurchaseType = ProductPurchaseType.InternetData; break;
                case AppConstants.ProductPurchaseType.GiftCard:
                    productPurchaseType = ProductPurchaseType.GiftCard; break;
                default:
                    {
                        IsValid = false;
                        message = AppConstants.StatusKeys.wrongProductType;
                        break;
                    }
            }

            if (!productstatusRequest.ProductIds.Contains(item.ProductId))
                productstatusRequest.ProductIds.Add(item.ProductId);
        }

        if (productstatusRequest.ProductIds.Count() > 0)
        {
            var productresponse = await _fusionHubService.GetProductsStatusAsync(productstatusRequest);
            if (productresponse?.Payload == null)
            {
                IsValid = false;
                message = AppConstants.StatusKeys.InvalidProductInCart;
            }
            var productResult = _mapper.Map<List<GetProductStatusResponse>>(productresponse?.Payload!);
            foreach (var product in orderDetail.CartDetail)
            {
                var systemproduct = productResult.FirstOrDefault(x => x.Product.Id == product.ProductId);
                if (systemproduct == null || (systemproduct?.IsActive == null || systemproduct.IsActive.ToUpper() != true.ToString().ToUpper()))
                {
                    IsValid = false;
                    message = AppConstants.StatusKeys.InvalidProductInCart;
                }
            }
        }
        return (IsValid, message);
    }

    private async Task<(decimal discount, int discountTypeID)> calculateDiscountAmount(string? promoCode, CustomerOrderDetailDto orderDetail)
    {
        decimal OrderDiscountAmount = 0;
        int DiscountTypeiD = 0;
        var discount = (await _discountRepository.GetDiscounts(new DiscountDto.Request() { IsActive = true, IsDeleted = false, Filters = new DiscountDto.Request.DiscountFilter() { Promocode = promoCode } })).FirstOrDefault();
        if (discount != null)
        {
            var CurrentCustomerLimit = await _discountRepository.GetNoOfCustomersDiscountAvailedAsync(_commonService.GetUserID(), discount.DiscountTypeId);
            var ThresholdLimit = await _discountRepository.GetNoOfCustomersDiscountAvailedAsync(null, discount.DiscountTypeId);
            var TotalDiscountAvailed = await _discountRepository.GetTotalOrderDiscountAmountByDiscountTypeID(null, discount.DiscountTypeId);

            switch (discount.DiscountTypeId)
            {
                case (int)DiscountTypeEnum.FlatOrder:
                    {
                        OrderDiscountAmount = discount.Value.HasValue ? discount.Value.Value : 0;
                        DiscountTypeiD = discount.DiscountTypeId;
                        break;
                    }
                case (int)DiscountTypeEnum.PercentageOrder:
                    {
                        OrderDiscountAmount = discount.Value.HasValue ? ((discount.Value.Value) / 100 * orderDetail.TotalOrderAmount) : 0;
                        DiscountTypeiD = discount.DiscountTypeId;
                        break;
                    }
                case (int)DiscountTypeEnum.FlatServiceFee:
                    {
                        OrderDiscountAmount = discount.Value.HasValue ? discount.Value.Value : 0;
                        DiscountTypeiD = discount.DiscountTypeId;
                        break;
                    }
                case (int)DiscountTypeEnum.PercentageServiceFee:
                    {
                        OrderDiscountAmount = discount.Value.HasValue ? ((discount.Value.Value) / 100 * orderDetail.ServiceFee) : 0;
                        DiscountTypeiD = discount.DiscountTypeId;
                        break;
                    }
                default:
                    {
                        OrderDiscountAmount = 0;
                        break;
                    }
            }
        }
        return (OrderDiscountAmount, DiscountTypeiD);
    }
}