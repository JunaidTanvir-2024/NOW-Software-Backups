﻿using THCC.Application.Features.User.Profile.UserProfile;
using THCC.Application.Models.Dtos;

namespace THCC.Application.MappingProfiles
{
    internal sealed class UserMappingProfile : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
            TypeAdapterConfig<UserDto, User>
                .NewConfig()
                .Map(user => user.Id, userDto => $"{userDto.Id}")
                .Map(user => user.FirstName, userDto => $"{userDto.FirstName}")
                .Map(user => user.LastName, userDto => $"{userDto.LastName}")
                .Map(user => user.Email, userDto => $"{userDto.Email}");

            TypeAdapterConfig<User, UserDto>
             .NewConfig()
             .Map(user => user.Id, userDto => $"{userDto.Id}")
             .Map(user => user.FirstName, userDto => $"{userDto.FirstName}")
             .Map(user => user.LastName, userDto => $"{userDto.LastName}")
             .Map(user => user.Email, userDto => $"{userDto.Email}")
             .Map(user => user.IsSubscribedToNewsletter, userDto => $"{userDto.IsSubscribedToNewsletter}")
             .Map(user => user.ImagePath, userDto => $"{userDto.ProfileImage}");

            TypeAdapterConfig<User, UserProfileResponse>
                .NewConfig()
                .Map(userProfile => userProfile.FirstName, user => $"{user.FirstName}")
                .Map(userProfile => userProfile.LastName, user => $"{user.LastName}")
                .Map(userProfile => userProfile.IsSubscribedToNewsletter, user => $"{user.IsSubscribedToNewsletter}")
                .Map(userProfile => userProfile.Image, user => $"{user.ProfileImage}");
        }

    }
}