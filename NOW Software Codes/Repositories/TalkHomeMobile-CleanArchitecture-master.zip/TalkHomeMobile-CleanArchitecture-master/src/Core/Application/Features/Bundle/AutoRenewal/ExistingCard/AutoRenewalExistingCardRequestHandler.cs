using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Features.Bundle.BundleDetail;
using Application.Features.Payment.Card.Models;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;

namespace Application.Features.Bundle.AutoRenewal.ExistingCard;

public class AutoRenewalExistingCardRequestHandler : IRequestHandler<AutoRenewalExistingCardRequest, Result<CardResponse>>
{
    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IMapper _mapper;
    private readonly ICardService _cardService;
    private readonly IStringLocalizer<AutoRenewalExistingCardRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IPayPalService _payPalService;

    public AutoRenewalExistingCardRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IMapper mapper,
        ICardService cardService,
        IStringLocalizer<AutoRenewalExistingCardRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        IPayPalService payPalService)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _mapper = mapper;
        _cardService = cardService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _payPalService = payPalService;
    }
    public async Task<Result<CardResponse>> Handle(AutoRenewalExistingCardRequest request, CancellationToken cancellationToken)
    {
        string existigCardNumber, cardScheme;

        //Check if card is user own card
        var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
        if (cards == null || cards != null &&
            !cards.Any(x => x.CardToken.Equals(
                request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)))
        {
            return Result<CardResponse>.Failure(
                _localizer[CustomStatusKey.InvalidPaymentCard], CustomStatusCode.InvalidPaymentCard);
        }

        existigCardNumber = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).MaskedPan;

        cardScheme = cards!.First(x => x.CardToken.Equals(
            request.PaymentCardInfo.CardToken, StringComparison.InvariantCultureIgnoreCase)).CardScheme;


        var bundleInfo = _mapper.Map<PaymentBundleInfo>(request);

        //Suspend PayPal subscription if Autorenewal is already setuped with paypal
        //var msisdnInfo = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn!);
        //var bundlesResponse = await _unitOfWork.BundleRepo.GetBundleById(new BundleByIdRequest() { Id = request.BundleId.ToString() });
        //var autoRenewal = await _unitOfWork.BundleRepo.GetBundleAutoRenewal(request.Msisdn!, msisdnInfo.AccountId!, bundlesResponse.UuId!);
        //if (autoRenewal?.IsRenew == true && autoRenewal?.PaymentMethod?.Equals("paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        //{
        //    await _payPalService.PayPalCancelSubscription(new PaypalSuspendSubscriptionRequest
        //    {
        //        SubscriptionId = autoRenewal.InitialTransactionId!,
        //    });
        //}
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: null!,
            paymentExistingCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: null!,
            topupInfo: null!,
            bundleInfo: bundleInfo,
            creditSimInfo: null!,
            msisdn: request.Msisdn,
            email: _currentUser.GetUserEmail()!,
            ipAddress: request.IpAddress,
            cardMaskedPan: existigCardNumber!,
            cardScheme: cardScheme!,
            isAuthorizeOnly: true
            );
    }
}