﻿
namespace Application.Features.Bundle.SuggestedBundle;
public class SuggestedBundleRequestValidator : AbstractValidator<SuggestedBundleRequest>
{
    public SuggestedBundleRequestValidator(ICommonService commonService)
    {
        
    }
}
