﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class AutoTopupSettingsViewModel
    {
        [Required(ErrorMessage = "Select Number"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed"), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed")]
        public string productRef { get; set; }
        public string productCode { get; set; }
        public string productItemCode { get; set; }
        [Required(ErrorMessage = "Enter Threshold Amount"), Range(1, 30, ErrorMessage = "Range Must Be Between 1-30")]
        public float thresholdBalanceAmount { get; set; } = 1f;
        public bool isAutoTopup { get; set; }
        [Required(ErrorMessage = "Enter TopUp Amount")]
        public decimal topupAmount { get; set; }
        public string topupCurrency { get; set; }
    }
}
