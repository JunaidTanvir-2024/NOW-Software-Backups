﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TH.Models.Database
{
    public class PurchaseResult
    {
        public int ErrorCode { get; set; }
        public string ErrorMsg { get; set; }
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }       
    }
}
