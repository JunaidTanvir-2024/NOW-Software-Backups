﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Models.Configurations
{
    public class JwtConfig
    {
        public string ValidAudience { get; set; }
        public string ValidIssuer { get; set; }
        public string Secret { get; set; }
        public bool IsJwtOn { get; set; }
        public int TokenExpiryTimeInMins { get; set; }

    }

    
}
