using Application.Features.Rate.Extensions;
using Application.Features.Rate.Model;

namespace Application.Features.Rate.International;

public class InternationalRatesRequestHandler : IRequestHandler<InternationalRatesRequest, Result<List<InternationalRate>>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<InternationalRatesRequestHandler> _localizer;

    public InternationalRatesRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<InternationalRatesRequestHandler> localizer)
    {
        _uow = uow;
        _localizer = localizer;
    }

    public async Task<Result<List<InternationalRate>>> Handle(InternationalRatesRequest request, CancellationToken cancellationToken)
    {
        var rates = await _uow.RateRepo.GetInternationalRates();
        if (rates?.Count > 0)
        {
            rates.ToList().ForEach(x =>
           {
               x.Landline = x.Landline?.GetRate();
               x.Mobile = x.Mobile?.GetRate();
               x.Sms = x.Sms?.GetRate();
               x.LandlineStandard= x.LandlineStandard?.GetRate();
               x.MobileStandard= x.MobileStandard?.GetRate();
               x.SmsStandard= x.SmsStandard?.GetRate();
           });
        }
        return Result<List<InternationalRate>>.Success(rates!, _localizer[CustomStatusKey.Success]);
    }
}