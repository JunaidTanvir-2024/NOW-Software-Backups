﻿namespace Application.Features.Payment.Card.Models;

public class PaymentAddressInfo
{
    public string? AddressL1 { get; set; }
    public string? AddressL2 { get; set; }
    public string? AddressL3 { get; set; }
    public string? AddressL4 { get; set; }
    public string? City { get; set; }
    public string? CountryCode { get; set; }
    public string? PostCode { get; set; }
    public string? Region { get; set; }
}
