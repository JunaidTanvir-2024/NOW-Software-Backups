using System.Text.Json.Serialization;

using Voucherify.Api.Features.Promotions.Responses;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Campaigns.Responses;

public class CampaignResponse
{
    public string? Id { get; set; }

    public string? Name { get; set; }

    public bool Active { get; set; }

    public string? Description { get; set; }

    public string? CampaignType { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? ExpirationDate { get; set; }

    public Metadata? Metadata { get; set; }

    public List<PromotionTierResponse>? PromotionTiers { get; set; }
}
