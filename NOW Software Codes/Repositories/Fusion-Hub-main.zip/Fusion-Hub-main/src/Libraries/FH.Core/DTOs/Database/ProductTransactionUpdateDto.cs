namespace FH.Core.DTOs.Database;
public sealed class ProductTransactionUpdateDto
{
    public sealed record Request
    {
        public required string VendorTransactionId { get; set; }
        public required string Status { get; set; }
    }

    public sealed record Response
    {
        public required string ProductVendorCode { get; set; }
        public required long ProductId { get; set; }
        public required string CartReference { get; set; }
        public required string TransactionReference { get; set; }
        public required string TransactionStatus { get; set; }
    }
}
