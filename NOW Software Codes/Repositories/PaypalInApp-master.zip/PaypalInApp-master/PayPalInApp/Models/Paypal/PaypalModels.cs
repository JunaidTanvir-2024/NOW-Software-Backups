﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PayPalInApp.Models.Paypal
{
    public class PayPalCreateSalePaymentRequest
    {
        [JsonProperty("customerName")]
        [Required]
        public string CustomerName { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("customerMsisdn")]
        public string CustomerMsisdn { get; set; }

        [JsonProperty("CustomerEmail")]
        public string CustomerEmail { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("redirect_urls")]
        [Required]
        public RedirectUrls RedirectUrl { get; set; }

        [JsonProperty("transactions")]
        [Required]
        public Transactions Transaction { get; set; }

        [JsonProperty("basket")]
        [Required]
        public List<ProductBasket> Basket { get; set; }
    }

    public class ProductBasket
    {
        [JsonProperty("productItemCode")]
        [Required]
        public string ProductItemCode { get; set; }

        [JsonProperty("amount")]
        [Required]
        public float Amount { get; set; }

        [JsonProperty("productRef")]
        public string ProductRef { get; set; }

        [JsonProperty("bundleRef")]
        public string BundleRef { get; set; }

    }

    public class RedirectUrls
    {
        [JsonProperty("return_url")]
        [Required]
        public string ReturnUrl { get; set; }

        [JsonProperty("cancel_url")]
        [Required]
        public string CancelUrl { get; set; }
    }

    public class Transactions
    {
        [JsonProperty("amount")]
        [Required]
        public Amounts Amount { get; set; }

        [JsonProperty("description")]
        [Required]
        public string Description { get; set; }
    }
    public class Amounts
    {
        [JsonProperty("total")]
        [Required]
        public float Total { get; set; }

        [JsonProperty("currency")]
        [Required]
        public string Currency { get; set; }
    }

    public class PayPalExecuteSalePaymentRequest
    {
        [JsonProperty("payer_id")]
        [Required]
        public string PayerId { get; set; }


        [JsonProperty("payment_id")]
        [Required]
        public string PaymentId { get; set; }

        [JsonProperty("customerUniqueRef")]
        [Required]
        public string CustomerUniqueRef { get; set; }

        [JsonProperty("productCode")]
        [Required]
        public string ProductCode { get; set; }
    }

    public class GenericPayPalApiResponse<T>
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public T payload { get; set; }
    }

    public class PayPalCreateSalePaymentResponse
    {
        [JsonProperty("redirectUrl")]
        public string RedirectUrl { get; set; }
    }

    public class CancelReturnPayPalViewModel
    {
        public string token { get; set; }
    }

    public class PayPalExecuteSalePaymentResponse
    {
        [JsonProperty("paypalTransactionId")]
        public string PaypalTransactionId { get; set; }

        [JsonProperty("createTime")]
        public DateTime CreateTime { get; set; }

        [JsonProperty("intent")]
        public string Intent { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("saleId")]
        public string SaleId { get; set; }

        [JsonProperty("basketResponse")]
        public List<BasketItemsResponse> BasketResponse { get; set; }
    }

    public class BasketItemsResponse
    {
        public string ProductItemCode { get; set; }
        public bool IsFullFilled { get; set; }
        public string Pin { get; set; }
    }
}
