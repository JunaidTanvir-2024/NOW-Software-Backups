using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;
public interface IUnitOfWork : ResolveAs.IScoped
{
	ICountryRepository CountryRepository { get; }
	ILoggerRepository LoggerRepository { get; }
	IUserRepository UserRepository { get; }
	IOtpRepository OtpRepository { get; }
	ITripRepository TripRepository { get; }
	ITravelerRepository TravelerRepository { get; }
	ISubscriptionRepository SubscriptionRepository { get; }
	IExpenseRepository ExpenseRepository { get; }
	IMediaRepository MediaRepository { get; }
	IPlaceRepository PlaceRepository { get; }
	IFriendshipRepository FriendshipRepository { get; }
	IChatRoomRepository ChatRoomRepository { get; }

	void BeginTransaction();
	void SaveChanges();
	void Commit();
	void Dispose();
	void Rollback();
}
