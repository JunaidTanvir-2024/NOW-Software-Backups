﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Services.Airship
{
    public class BundleInfoAirShip
    {
        public string Msisdn { get; set; }
        public string Origination { get; set; }
        public string Destination { get; set; }
        public BundleType BundleType { get; set; }
        public bool IsSuccess { get; set; }
        public bool? IsCard { get; set; }
        public decimal Amount { get; set; }
    }
}
