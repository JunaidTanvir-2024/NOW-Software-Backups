﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class AddListRequest
    {
        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }

        [JsonProperty("name")]
        [Required]
        public string name { get; set; }

        [JsonProperty("description")]
        [Required]
        public string description { get; set; }

        [JsonProperty("extra")]
        [Required]
        public List<string> extra { get; set; }
    }
}
