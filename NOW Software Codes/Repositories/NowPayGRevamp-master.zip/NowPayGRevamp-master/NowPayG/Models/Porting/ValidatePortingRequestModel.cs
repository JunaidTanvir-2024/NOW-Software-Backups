﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayG.Models.Porting
{
    public class ValidatePortingRequestModel
    {
        public string Email { get; set; }
        public PortTypes PortType { get; set; }
    }
}
