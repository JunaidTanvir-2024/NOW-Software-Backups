﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransferToJsonGetTransactionResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }        
        public TransferToGetTransactionResponse payload { get; set; }
    }
}
