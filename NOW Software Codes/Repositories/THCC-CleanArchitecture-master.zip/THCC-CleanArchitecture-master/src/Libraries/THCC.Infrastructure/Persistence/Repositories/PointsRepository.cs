﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using Serilog;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;
using THCC.Application.Interfaces.Repositories;
using THCC.Domain.Constants;

namespace THCC.Infrastructure.Persistence.Repositories
{
    public class PointsRepository:IPointsRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public PointsRepository(IConfiguration configuration, ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<bool> Redeempoints(string cardnumber, decimal points, string subscriberid)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@productref", cardnumber);
                parameter.Add("@amount", points);
                parameter.Add("@creditReason", "TOPUP By Points[ " + points.ToString() + " ]");
                parameter.Add("@paymentMethod", "Credit");
                parameter.Add("@reference", subscriberid);
                parameter.Add("@errorcode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameter.Add("@errormsg", dbType: DbType.String, direction: ParameterDirection.Output, size: 200);
                parameter.Add("@account", dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
                parameter.Add("@thccpin", dbType: DbType.String, direction: ParameterDirection.Output, size: 150);

                await DapperWrapper.ExecuteAsync(StoredProcedures.RedeemPoints, parameter, CommandType.StoredProcedure, _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
                int errorCode = parameter.Get<int>("@errorcode");
                string errorMsg = parameter.Get<string>("@errormsg");
                if (errorCode != 0) // Success
                {
                    _logger.Debug("PointsRepo: Redeempoints==> " + errorCode+"-"+ errorMsg);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error("PointsRepo: Redeempoints==>"+ ex.Message.ToString());
                return false;
            }
        }

        public async Task<int> GetPoints(string account)
        {
            var parameter = new DynamicParameters();
            parameter.Add("@account", account);
            return await DapperWrapper.QueryFirstOrDefaultAsync<int>(StoredProcedures.GetPoints, parameter, CommandType.StoredProcedure, _configuration.GetConnectionString(ThccConstants.ConnectionStrings.BackHome));
        }
    }
}
