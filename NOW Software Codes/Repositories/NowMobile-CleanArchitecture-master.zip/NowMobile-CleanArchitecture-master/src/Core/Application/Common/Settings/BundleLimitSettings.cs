﻿namespace Application.Common.Settings;

public class BundleLimitSettings
{
    public const string SectionName = "BundleLimitSettings";
    public static BundleLimitSettings Bind = new BundleLimitSettings();
    public List<decimal> Percentage { get; set; } = new List<decimal>();
}

