﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.RoamingBundle;
public class RoamingBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
