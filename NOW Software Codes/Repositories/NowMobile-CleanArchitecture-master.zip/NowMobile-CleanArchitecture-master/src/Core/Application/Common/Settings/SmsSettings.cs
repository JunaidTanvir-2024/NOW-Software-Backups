﻿namespace Application.Common.Settings;

public class SmsSettings
{
    public const string SectionName = "SmsSettings";
    public static SmsSettings Bind = new SmsSettings();
    public string ApiEndpoint { get; set; } = default!;
    public string UserName { get; set; } = default!;
    public string Password { get; set; } = default!;
    public string From { get; set; } = default!;
    public string SMSContent { get; set; } = default!;
    public bool IsActive { get; set; } = default!;
}
