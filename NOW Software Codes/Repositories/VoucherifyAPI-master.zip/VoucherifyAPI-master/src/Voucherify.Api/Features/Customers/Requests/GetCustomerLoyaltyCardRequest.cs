using FluentValidation;

using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.Customers.Requests;

public class GetCustomerLoyaltyCardRequest
{
    public string CustomerSourceId { get; set; } = null!;
    public string? LoyaltyCampaignId { get; set; }
}

internal class GetCustomerLoyaltyCardRequestValidator : AbstractValidator<GetCustomerLoyaltyCardRequest>
{
    public GetCustomerLoyaltyCardRequestValidator()
    {
        RuleFor(p => p.CustomerSourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.CustomerSourceId = phoneNumber);
    }
}
