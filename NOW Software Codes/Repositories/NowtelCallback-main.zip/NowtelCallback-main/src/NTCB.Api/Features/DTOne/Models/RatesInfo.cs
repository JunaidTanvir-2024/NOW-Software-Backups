﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class RatesInfo
{
    [JsonPropertyName("_base")]
    public float? Base { get; set; }
    
    [JsonPropertyName("retail")]
    public int? Retail { get; set; }
    
    [JsonPropertyName("wholesale")]
    public float? Wholesale { get; set; }
}
