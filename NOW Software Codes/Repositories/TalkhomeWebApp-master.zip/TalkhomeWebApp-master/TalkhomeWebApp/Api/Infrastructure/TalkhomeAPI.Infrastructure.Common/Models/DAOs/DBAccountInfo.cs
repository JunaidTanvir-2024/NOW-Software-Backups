﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
    public class DBAccountInfo
    {
        public string AccountID { get; set; }
        public string Na_Service_Id { get; set; }
        public decimal Balance { get; set; }
        public string Currency { get; set; }
        public string subscriber_id { get; set; }
    }
}
