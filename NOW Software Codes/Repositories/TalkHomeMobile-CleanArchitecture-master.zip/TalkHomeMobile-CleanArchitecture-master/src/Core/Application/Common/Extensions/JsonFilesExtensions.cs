﻿
using Application.Common.Settings;
using Microsoft.Extensions.Configuration;

namespace Application.Common.Extensions;
public static class JsonFilesExtensions
{
    public static SectionNeedsToBind GetJsonFileConfigurations<SectionNeedsToBind>(this IServiceCollection services, SectionNeedsToBind bind, string sectionName, IConfiguration config)
    {
        services.Configure<JwtSettings>(config.GetSection(JwtSettings.SectionName));
        return config.GetSection(sectionName).Get<SectionNeedsToBind>();
    }
}