﻿namespace Application.Features.Account.Product.UpdateResend;
public class UpdateProductResendRequest : IRequest<Result<object>>
{
    public int ProductId { get; set; }
    //public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
}
