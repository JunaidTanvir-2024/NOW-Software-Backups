using FH.Core.Definitions;
using FH.Core.Extensions;

using Microsoft.AspNetCore.Http;

using RW;

using Serilog;

namespace FH.Infrastructure.Common.Middlewares;

public class AppExceptionMiddleware(RequestDelegate next, ILogger logger)
{
    public async Task Invoke(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            // Handle the exception and generate an appropriate response
            context.Response.ContentType = AppConstants.ContentType.ApplicationJson;
            context.Response.StatusCode = AppConstants.StatusCode.InternalServerError;

            logger.ErrorLog(ex);

            await context.Response.WriteAsJsonAsync(ResultWrapper.Failure(ex.StackTrace!.ToString(), AppConstants.StatusCode.InternalServerError));
        }
    }
}
