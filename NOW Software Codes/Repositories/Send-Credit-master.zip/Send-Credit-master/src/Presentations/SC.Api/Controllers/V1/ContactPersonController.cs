﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using SC.Core.Features.Contacts.Requests;
using SC.Core.Features.Countries.Requests;
using SC.Core.Models.Dtos;

namespace SC.Api.Controllers.V1
{
    [ApiVersion(1.0)]
    public class ContactPersonController : BaseApiController
    {
        [Authorize]
        [HttpPost("GetContactPersons")]
        public async Task<ActionResult> GetContactPerson(GetContactPersonRequest request)
        {
            var result = await Mediator.Send(request);

            if (result.IsSuccess)
            {
                return Ok(result);
            }
            return NotFound(result);
        }

        [Authorize]
        [HttpPost]
        public async Task<ActionResult> AddContactPerson(InsertContactPersonRequest request)
        {
            var result = await Mediator.Send(request);

            if (result.IsSuccess)
            {
                return Ok(result);
            }
            return NotFound(result);
        }

        [Authorize]
        [HttpPut]
        public async Task<ActionResult> UpdateContactPerson(UpdateContactPersonRequest request)
        {
            var result = await Mediator.Send(request);

            if (result.IsSuccess)
            {
                return Ok(result);
            }
            return NotFound(result);
        }

        [Authorize]
        [HttpDelete]
        public async Task<ActionResult> DeleteContactPerson(DeleteContactPersonRequest request)
        {
            var result = await Mediator.Send(request);

            if (result.IsSuccess)
            {
                return Ok(result);
            }
            return NotFound(result);
        }
    }
}