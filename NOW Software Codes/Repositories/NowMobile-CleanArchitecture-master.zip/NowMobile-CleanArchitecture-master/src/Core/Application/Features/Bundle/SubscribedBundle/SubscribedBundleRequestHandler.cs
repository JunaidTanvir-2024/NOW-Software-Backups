﻿using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.SubscribedBundle;

public class SubscribedBundleRequestHandler : IRequestHandler<SubscribedBundleRequest, Result<List<SubscribedBundleInfo>>>
{
    #region Fields

    private readonly IUnitOfWork _unitOfWork;
    private readonly IStringLocalizer<SubscribedBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;

    #endregion

    #region Ctors

    public SubscribedBundleRequestHandler(
        IUnitOfWork unitOfWork,
        IStringLocalizer<SubscribedBundleRequestHandler> localizer,
        IMapper mapper,
        ICommonService commonService,
        IUserService userService)
    {
        _unitOfWork = unitOfWork;
        _localizer = localizer;
        _mapper = mapper;
        _commonService = commonService;
        _userService = userService;
    }

    public async Task<Result<List<SubscribedBundleInfo>>> Handle(SubscribedBundleRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        var msisdnDetails = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdnDetails == null)
        {
            return Result<List<SubscribedBundleInfo>>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var subscribeBundlesList = _mapper.Map<List<SubscribedBundleInfo>>(await _unitOfWork.UserRepo.GetSubscribedBundles(msisdnDetails.AccountId!));
        var bundles = _mapper.Map<List<BundleInfo>>(await _unitOfWork.BundleRepo.GetBundles(new BundlesRequest()));

        if (subscribeBundlesList.Any())
        {
            foreach (var item in subscribeBundlesList)
            {
                item.IsAllowancewbundle = false;
                var result = bundles.FirstOrDefault(x => x.UuId.Trim().ToLower() == item.Id.ToString().ToLower());
                if (result == null)
                {
                    item.IsAllowancewbundle = true;
                    item.PlanName = item.BrandedName;
                }
                else
                {
                    item.PlanName = result.Name.ToString();
                    item.Price = result.Price;
                    item.Bundleid = result.Id;
                    //item.GoodyBagColorCode = result!.GoodyBagColorCode!;
                }
                item.NoOfDays = Convert.ToInt32((item.Expiry - DateTime.Now).TotalDays);
                item.ShowAutoRenew = item.Type == BundleType.PAYG || item.Type == BundleType.BoltOn;
            }
        }

        return Result<List<SubscribedBundleInfo>>.Success(subscribeBundlesList, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
