﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts
{
    public enum HttpRequestType
    {
        Post,
        Get
    }
}
