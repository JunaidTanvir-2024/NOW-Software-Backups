﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class TalkHomeConfig
    {
        public string ApiEndPoint { get; set; }
        public string NowtelAuthToken { get; set; }
    }
}
