﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class TransferByNewCardRequestModel
    {
        [Required]
        public string nowtelRef { get; set; }

        [Required]
        public string product { get; set; }

        [Required]
        public string operatorId { get; set; }

        public PaymentCardModel cardData { get; set; }
        public BillingAddressModel billingAddressData { get; set; }
        [Required]
        public string ipAddress { get; set; }
    }
}
