using FluentValidation;

namespace Voucherify.Api.Features.Products.Requests;

public class GetProductSkuRequest
{
    public string? SkuNameOrId { get; set; }
}

internal class GetProductSkuRequestValidator : AbstractValidator<GetProductSkuRequest>
{
    public GetProductSkuRequestValidator()
    {
        RuleFor(p => p.SkuNameOrId).NotEmpty().NotNull();
    }
}