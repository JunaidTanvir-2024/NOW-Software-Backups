﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasketWebPanel.ApiModules.Utilities
{
    public enum Roles
    {
        Guest = 1,
        User = 2,
        Admin = 3,
        Owner = 4
    }
}