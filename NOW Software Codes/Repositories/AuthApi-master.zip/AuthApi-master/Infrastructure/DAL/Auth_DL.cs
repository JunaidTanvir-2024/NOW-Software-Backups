﻿
using Models.DbConnections;
using System;
using System.Collections.Generic;
using Serilog;
using Microsoft.Extensions.Options;
using Models.Configurations;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using Models.Database;
using Models.Contracts;
using Newtonsoft.Json;

namespace Infrastructure.DAL
{
    public class Auth_DL : IAuth_DL
    {

        private IDbConnectionSettings DbConnection;       
        private ILogger Logger;      


        public Auth_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));           
            Logger = logger;        
        }

        public async Task<bool> VerifyPreAuth(string enc_tx, string product_code, string product_item_code)
        {

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@enc_tx", enc_tx);
                parameters.Add("@product_code", product_code);
                parameters.Add("@product_item_code", product_item_code);

                bool result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<bool>("sp_verify_auth", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_DL, Method: VerifyPreAuth, Parameters => product_code: {product_code}, product_item_code: {product_item_code}, enc_tx: {enc_tx}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
                return false;
            }

        }

        public async Task<Auth> GetPreAuth(string enc_tx, string product_code, string product_item_code)
        {

            try
            {
                DynamicParameters parameters = new DynamicParameters();                
                parameters.Add("@enc_tx", enc_tx);               
                parameters.Add("@product_code", product_code);
                parameters.Add("@product_item_code", product_item_code);

                Auth result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<Auth>("sp_get_auth", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_DL, Method: GetPreAuth, Parameters => product_code: {product_code}, product_item_code: {product_item_code}, enc_tx: {enc_tx}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
                return null;
            }

        }

        public async Task<int> AddPreAuth(PreAuthRequest request, string enc_g, string enc_k, string enc_tx, int enc_a, string enc_d, int enc_ty, string remoteIp)
        {

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", request.Msisdn);
                parameters.Add("@device_uuid", request.DeviceUuid);
                parameters.Add("@email", request.Email);
                parameters.Add("@enc_g", enc_g);
                parameters.Add("@enc_k", enc_k);
                parameters.Add("@enc_tx", enc_tx);
                parameters.Add("@enc_a", enc_a);
                parameters.Add("@enc_d", enc_d);
                parameters.Add("@enc_ty", enc_ty);
                parameters.Add("@product_code", request.ProductCode);
                parameters.Add("@product_item_code", request.ProductItemCode);
                parameters.Add("@ip_address", remoteIp);               

                int result = await DbConnection.SqlConnection.ExecuteAsync("sp_add_auth_request", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: Auth_DL, Method: AddPreAuth, Parameters => request: {JsonConvert.SerializeObject(request)}, enc_g: {enc_g}, enc_k: {enc_k}, product_code: {request.ProductCode}, product_item_code: {request.ProductItemCode}, enc_tx: {enc_tx}, enc_a: {enc_a}, enc_d: {enc_d}, enc_ty: {enc_ty}, remoteIp: {remoteIp}, ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + ", StackTrace: " + ex.StackTrace);
                return 0;
            }

        }
        

    }
}
