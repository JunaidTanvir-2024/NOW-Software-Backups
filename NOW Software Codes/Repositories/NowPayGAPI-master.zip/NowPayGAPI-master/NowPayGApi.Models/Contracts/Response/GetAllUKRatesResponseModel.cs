﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetAllUKRatesResponseModel
    {
        public IEnumerable<UKRatesResponseModel> UKRatesList { get; set; }
    }
}
