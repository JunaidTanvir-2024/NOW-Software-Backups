namespace FH.Core.Entities;
public sealed record CurrencyUnitEntity : BaseEntity<long>
{
    public string? Name { get; set; }
    public string? Code { get; set; }
    public bool IsDefault { get; set; }
}
