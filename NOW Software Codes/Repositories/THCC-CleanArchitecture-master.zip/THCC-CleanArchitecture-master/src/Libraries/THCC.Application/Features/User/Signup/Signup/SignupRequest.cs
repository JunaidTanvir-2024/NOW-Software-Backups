﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.Signup.Signup;

public class SignupRequest : IRequest<object>
{
    public SignupUserDto UserInfo { get; set; } = new SignupUserDto();
}

public class SignupRequestValidator : AbstractValidator<SignupRequest>
{
    private readonly ICommonService _commonService;

    public SignupRequestValidator(ICommonService commonService)
    {
        _commonService = commonService;

        RuleFor(p => p.UserInfo.FirstName)
         .NotNull()
         .NotEmpty()
         .MaximumLength(255).WithMessage("Your firstname length must not exceed 255.");

        RuleFor(p => p.UserInfo.LastName)
         .NotNull()
         .NotEmpty()
         .MaximumLength(255).WithMessage("Your lastname length must not exceed 255.");

        RuleFor(p => p.UserInfo.Email)
         .NotNull()
         .NotEmpty()
          .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
         .Must(p => _commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");

        RuleFor(p => p.UserInfo.Password)
         .NotNull()
         .NotEmpty()
         .MinimumLength(6).WithMessage("Your password length must be at least 6.")
         .MaximumLength(20).WithMessage("Your password length must not exceed 20.")
         .Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
         .Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
         .Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.");
    }
}

public class SignupUserDto
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}