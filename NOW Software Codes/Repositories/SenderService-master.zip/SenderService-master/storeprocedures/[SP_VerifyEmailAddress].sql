USE [EmailSenderService]
GO
/****** Object:  StoredProcedure [dbo].[SP_VerifyEmailAddress]    Script Date: 2/28/2023 4:42:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[SP_VerifyEmailAddress]
    @Domain NVARCHAR(250),
    @Email NVARCHAR(510)
AS
BEGIN
    DECLARE @DomainBlocked BIT
	DECLARE @IsVerified BIT
	DECLARE @IsDomainBlocked BIT
    -- Check if domain is blocked
    SELECT @DomainBlocked = CASE WHEN EXISTS (SELECT 1 FROM BlockedDomains WHERE Domain = @Domain) THEN 1 ELSE 0 END

    IF @DomainBlocked = 1
    BEGIN
        -- Domain is blocked, set IsVerified to false
        SET @IsVerified = 0
        SET @IsDomainBlocked = 1
    END
    ELSE
    BEGIN
        -- Domain is not blocked, check email verification status
        DECLARE @EmailValidation TABLE (IsVerified BIT)
        INSERT INTO @EmailValidation (IsVerified)
        SELECT IsVerified FROM EmailValidations WHERE Email = @Email

        IF EXISTS (SELECT 1 FROM @EmailValidation WHERE IsVerified = 1)
        BEGIN
            -- Email is verified, set IsVerified to true
            SET @IsVerified = 1
            SET @IsDomainBlocked = 0
        END
        ELSE
        BEGIN
            -- Email is not verified, set IsVerified to false
            SET @IsVerified = 0
            SET @IsDomainBlocked = 0
        END
    END
    SELECT @IsVerified AS IsVerified, @IsDomainBlocked AS IsDomainBlocked
END
