using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Country;

public abstract class GetTrip
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long Id { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Id).NotNull();
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Name { get; set; }
        public DateTime StartingDate { get; set; }
        public long CreatorId { get; set; }
        public required CurrencyInfo Currency { get; set; }
        public int TotalPlaces { get; set; }
        public int TotalMedia { get; set; }
        public int TotalExpense { get; set; }
        public int TotalTravelers { get; set; }
        public IEnumerable<TravelerInfo> Travelers { get; set; } = [];
        public IEnumerable<PlaceInfo> Places { get; set; } = [];
        public IEnumerable<ExpenseInfo> Expenses { get; set; } = [];
        public IEnumerable<MediaInfo> Media { get; set; } = [];
        public sealed record TravelerInfo
        {
            public required long Id { get; set; }
            public required string FullName { get; set; }
            public required string Email { get; set; }
        }
        public sealed record CurrencyInfo
        {
            public long Id { get; set; }
            public required string Name { get; set; }
            public required string Code { get; set; }
            public required string Symbol { get; set; }
        }
        public sealed record PlaceInfo
        {
            public long Id { get; set; }
            public required string Name { get; set; }
            public string? Description { get; set; }
            public decimal Latitude { get; set; }
            public decimal Longitude { get; set; }
            public string? Type { get; set; }
            public string? ImageUrl { get; set; }
        }
        public sealed record ExpenseInfo
        {
            public long Id { get; set; }
            public string? Description { get; set; }
            public decimal Amount { get; set; }
            public ExpenseCategory? Category { get; set; }
            public sealed record ExpenseCategory
            {
                public required long Id { get; set; }
                public required string Name { get; set; }
            }
        }
        public sealed record MediaInfo
        {
            public long Id { get; set; }
            public required string Type { get; set; }
            public required string Url { get; set; }
        }

    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var trip = await _unitOfWork.TripRepository.GetTrip(x => x.Id.Equals(query.Id) && x.IsActive == true);

            if (trip is not null)
            {
                return ResultWrapper.Success(new Response()
                {
                    Id = trip.Id,
                    Name = trip?.Name!,
                    StartingDate = trip?.StartingDate ?? default,
                    CreatorId = trip?.CreatorId ?? default,
                    Currency = trip?.Currency is not null ? new Response.CurrencyInfo()
                    {
                        Id = trip.Currency.Id,
                        Name = trip.Currency.Name,
                        Code = trip.Currency.Code,
                        Symbol = trip.Currency.Symbol,
                    } : default!,
                    TotalExpense = trip?.Expenses.Count ?? default,
                    TotalMedia = trip?.Media?.Count ?? default,
                    TotalPlaces = trip?.TripPlaces?.Count ?? default,
                    TotalTravelers = trip?.Travelers?.Count ?? default,
                    Travelers = trip?.Travelers is not null ? trip.Travelers.Select(x => new Response.TravelerInfo()
                    {
                        Id = x.User.Id,
                        Email = x?.User?.Email!,
                        FullName = x?.User?.UserDetail?.FullName!,
                    }) : [],
                    Places = trip?.TripPlaces is not null ? trip.TripPlaces.Select(x => new Response.PlaceInfo()
                    {
                        Id = x.Id,
                        Description = x?.Place?.Description,
                        Name = x?.Place?.Name!,
                        ImageUrl = x?.Place?.ImageUrl,
                        Latitude = x?.Place?.Latitude ?? default,
                        Longitude = x?.Place?.Longitude ?? default,
                        Type = x?.Place?.Type
                    }) : [],
                    Expenses = trip?.Expenses is not null ? trip.Expenses.Select(expense => new Response.ExpenseInfo()
                    {
                        Id = expense.Id,
                        Amount = expense?.Amount ?? default,
                        Description = expense?.Description,
                        Category = expense?.Category is not null ? new Response.ExpenseInfo.ExpenseCategory()
                        {
                            Id = expense.Category.Id,
                            Name = expense?.Category?.Name!
                        } : default
                    }) : [],
                    Media = trip?.Media is not null ? trip.Media.Select(media => new Response.MediaInfo()
                    {
                        Id = media.Id,
                        Type = media?.Type!,
                        Url = media?.Url!
                    }) : []
                });
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
