﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Filters;

namespace ThmApi.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class BasicAuthAttribute : TypeFilterAttribute
    {
        public BasicAuthAttribute() : base(typeof(BasicAuthFilter)) { }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class IpAddressAttribute : TypeFilterAttribute
    {
        public IpAddressAttribute() : base(typeof(IpAddressFilter)) { }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class ActiveUserAttribute : TypeFilterAttribute
    {
        public ActiveUserAttribute() : base(typeof(ActiveUserFilter)) { }
    }
}
