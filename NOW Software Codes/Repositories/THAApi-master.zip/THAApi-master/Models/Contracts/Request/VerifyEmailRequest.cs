﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class VerifyEmailRequest
    {
        [Required]
        [EmailAddress]
        public string email { get; set; }
    }

    
}
