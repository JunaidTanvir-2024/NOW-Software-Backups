﻿using TransferHome.Models.Contracts.Service.PaypalApiContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransferHome.Infrastructure.Services.Interfaces
{
    public interface IPayPalService
    {
        string GetResumeUrl(string path, string baseUrl);
        Task<GenericPayPalApiResponse<PayPalCreateSalePaymentResponse>> PayPalCreateSalePayment(PayPalCreateSalePaymentRequest request);
        Task<GenericPayPalApiResponse<PayPalExecuteSalePaymentResponse>> PayPalExecuteSalePayment(PayPalExecuteSalePaymentRequest request);
    }
}
