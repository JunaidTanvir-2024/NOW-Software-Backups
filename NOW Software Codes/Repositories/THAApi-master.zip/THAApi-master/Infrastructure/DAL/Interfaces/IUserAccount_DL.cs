﻿using Models.Contracts;
using Models.Database;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using Models.Enums;

namespace Infrastructure.DAL.Interfaces
{
    public interface IUserAccount_DL
    {
        Task<int> InsertEmailVerificationToken(string phoneNumber, string token);
        Task<DateTime> GetUserRegistrationDate(string accountNumber);
        Task<IEnumerable<DBBundles>> GetBundlesHistory(string accountNumber);
        Task<DBAccountInfo> GetAccountDetailsBySipUsername(string sipUsername);
        Task<GenericResult<UserNotifications>> GetUserNotifications(string msisdn);
        Task<GenericResult<string>> UpdateUserNotifications(UserNotifications request, string msisdn);
        Task<GenericResult<string>> UpdateUserProfile(UpdateUserProfileResponse request, string msisdn);
        Task<GenericResult<Profile>> GetUserProfile(string msisdn);
        Task<UserAccount> GetUserAccountWithBalance(string msisdn);
        Task<DestinationRate> GetDestinationRate(string sourceMsisdn, string destinationMsisdn);
        Task<bool> StoreMessageCount(string receivedMsisdn, int messageCount);
        Task<bool> SmsHttpSendFailed(string receivedMsisdn, string clxHttpRequest);
        Task<bool> PinSent(string receivedMsisdn, string smsSentToMsisdn, string clxHttpRequest);
        Task<bool> StorePinMessageLengthAndEncodingType(string receivedMsisdn, int pinMessageLength, string encodingType);
        Task<bool> ChargeUser(string from, string to, int messageCount);
        Task<bool> SendToNumberParseFailed(string receivedMsisdn);
        Task<bool> PassesSmsValidation(string receivedMsisdn);
        Task<bool> BeginPinSend(string receivedMsisdn);
        Task<GenericApiResponse<string>> ExecuteWebCallthrough(string msisdn, string destination, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<GenericApiResponse<bool>> SetEmail(string msisdn, Email email);
        Task<GenericApiResponse<useremailRegistration>> getEmail(string msisdn);
        Task<bool> IsEnabledForUser(string msisdn);
        Task<GenericApiResponse<bool>> SetFCMToken(FCMToKenReq fcmToken, string msisdn);
        Task<string> GetUserAccountPin(string msisdn);
        Task<GenericApiResponse<bool>> AddRemoveCreditToBalanceTransfer(TransferBalanceTransaction transaction,
           UserAccount sourceUserAccount,
           UserAccount destinationAccount
           );
        Task<bool> IsNewUser(string msisdn);
        Task<GenericApiResponse<IEnumerable<LocalAccessNumber2>>> Get2(string msisdn, bool IsIOS = false, bool IsAndroid = false);
        Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion);
        Task<GenericApiResponse<IEnumerable<Country>>> GetPromotionAlerts(string msisdn);
        Task<GenericApiResponse<Referrals>> GetReferrals(string msisdn);
        Task<DBAccountBalance> DebitAccountBalance(string account, decimal Amount, string reference, string authcode);
        Task<SipConfigurationsResponse> GetSipConfigurations(string msisdn, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<GenericApiResponse<string>> UpdateReferralCode(string msisdn, ReferralCode referralCode);
        Task<GenericApiResponse<ReferralCode>> CreateReferralCode(string msisdn, string name);
        Task<int> SaveReferralSMSs(string referredByMSISDN, string referredMSISDN, string referral_sms);
        Task<UserAccountBalance> GetUserAccountBalanceAsync(string msisdn);
        Task<bool> ChargeUser1(string from, string to, int messageCount);
        Task<bool> SmsDbContextSaveFailed(string receivedMsisdn);
        Task<string> GetPinAsync(string msisdn);
        Task<bool> IsUserBlockedAsync(string msisdn);
        Task<ValidationResponse> ValidateDeviceAndIpAddressAsync(string devicePersistentId, string ipAddress);
        Task<GenericApiResponse<IEnumerable<LocalAccessNumber2>>> Get2(string msisdn, bool IsIOS, bool IsAndroid, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<UserAccount> GetUserAccount(string msisdn, AppInfo appInfo, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<IEnumerable<string>> GetStunServers();
        Task<string> GetBundlePromoGuid(int prefix);
        int CheckBundlePromo(string msisdn);
        Task<string> GetBundleRatePromoGuid(string msisdn);
        Task<bool> AddBundlePromo(string bundleId, int SubscriberId);
        Task<string> GetBundlePoundPromoGuid(string msisdn);
        Task<bool> AddSignUpPromo(string accountID, string msisdn);
        Task<SignupPromo> GetSignupPromo(string msisdn);
        Task<bool> AccountHasPromo(string account, string msisdn);
        Task<bool> RatesSheetConfigured(string receivedMsisdn);
        Task<int> GetNaServiceId(string currency);
        Task<int> GetNaServiceIdByMSISDN(string msisdn);
        Task<int?> DetermineRateSheet(string msisdn);
        Task<bool> ConfigureRateSheet(string msisdn, string account);
        Task<bool> AppInfoHandled(string receivedMsisdn);
        Task<IMUserAccount> GetUnallocatedIMUserAccount(string msisdn, string account);
        Task<bool> SubscriberUpdatesApplied(string receivedMsisdn);
        Task<int> CountDeletedAccountAsync(string msisdn);
        Task<bool> SoftDeleteAccountAsync(string msisdn, string account, string merchantRef, string paypalMerchantRef);
        Task<bool> UnallocatedAccountObtained(string receivedMsisdn);
        Task<string> GetUnallocatedAccount(string msisdn, string accountCurrency);
        Task<string> GetTemporaryAccount(UserInf signup, string accountCurrency,string remoteIp);
        Task<int> SaveSms(Sms sms);
        Task<int> GetSMSOperator(int na_service_id, string msisdn);
        Task<int> GetSMSCount(string msisdn, string remoteIp);
        Task UpdateSignUpAccount(UserAccount userAccount);
        Task<bool> GenericTimestamp(string receivedMsisdn, string fieldName, string milliseconds);
        Task<UserAccount> GetUserAccountResult(string msisdn, string account);
        Task<string> ValidateAsyncUser(string msisdn, string ipAddress, int type);
		Task<AccountInfo> GetAccountCurrencyAndPin(string msisdn);

		Task<bool> ValidateNowtelTokenAsync(string nowtelToken);
        Task<UserAccountInformation> GetUserAccountInfo(string sipUserName);
        Task<UserAccount> GetUserAccount(string msisdn);
        Task<UserAccount> GetUserAccount(string msisdn, AppInfo appInfo);
        Task HandleAppInfo(UserAccount userAccount, AppInfo info);
        Task<bool> SaveCallQuality(CallQualityRequest request, string msisdn);
        Task<SaveClientCallDbResponse> SaveClientCallLogs(SaveClientCallRequest request, string msisdn);
        Task<IEnumerable<InAPPAndroidPaymentSettings>> getAndriodPaymentOptions(string currency);
        Task<decimal?> getAndriodPaymentOption(string productId);
        Task<FullfilmentResponse> ThaGooglePayCustomerFullfilment(string prodRef, string amount, string CssTransId, string ccAuthCode, string bundleRef);
        Task<UserAccount> GetRawUserAccount(string sipUserName);
        Task<UserSubscriberDetails> GetUserSubscriberDetails(string account);
        Task<bool> CanUseReferralCodeRevised(int na_service_id, string msisdn);
        Task<string> GetReferralCode(string msisdn);
        Task<int> IsBundleExists(string msisdn);
        Task<IEnumerable<DBCallHistory>> GetCallingHistory(string accountNumber);
        Task<bool> IsFirstTopUp(string msisdn);
        Task<bool> IsFirstBundle(string msisdn);
        Task UpdateSignUpAccount2(UserAccount userAccount);
        Task HandleAppInfo(UserAccount userAccount, AppInfo info, string remoteIp, string accountCurrency);
        Task<GenericResult<string>> UpdateUserProfileV2(UpdateUserProfileResponse request, string msisdn, bool isProfileCompleted);
        Task<GenericResult<Profile>> GetUserProfileV2(string msisdn);
        Task<string> GetFxRateFromDB(string fromCurrency, string toCurrency);
        Task<bool> ValidateTransfer(string sourceAmount, string sourceMsisdn, string sourceAccount, string destinationAmount, string destinationMsisdn, string destinationAccount);
        Task<int> CreateDeleteAccountRequest(DeleteAccountLogRequestModel model);       
        Task<List<DeleteAccountReason>> GetDeleteAccountReasons(string languageName);      
        Task<DeleteAccountLogRequest> GetDeleteAccountLogRequest(string msisdn);
        Task<bool> UpdateDeletedAccountStatus(DeleteAccountLogRequestModel model);
        Task<List<DeleteAccountLogRequest>> GetDeleteAccountLogRequestsList();
        Task<bool> SetAccountDeletedStatus(string msisdn, string account, string message);

    }
}
