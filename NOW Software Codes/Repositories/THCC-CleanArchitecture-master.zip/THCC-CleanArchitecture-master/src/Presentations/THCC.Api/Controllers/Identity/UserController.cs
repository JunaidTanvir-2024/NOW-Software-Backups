﻿using MediatR;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

using THCC.Api.Controllers.Common;
using THCC.Application.Features.User.AccountSummary;
using THCC.Application.Features.User.CallingCardSummary;
using THCC.Application.Features.User.ChangePassword;
using THCC.Application.Features.User.ForgotPassword.ForgotPasswod;
using THCC.Application.Features.User.ForgotPassword.ForgotPasswordConfirm;
using THCC.Application.Features.User.ForgotPassword.ForgotPasswordResend;
using THCC.Application.Features.User.ForgotPassword.NewPassword;
using THCC.Application.Features.User.Guest.Guest;
using THCC.Application.Features.User.Guest.GuestConfirm;
using THCC.Application.Features.User.Guest.GuestResend;
using THCC.Application.Features.User.History.CallHistory;
using THCC.Application.Features.User.History.CallingCardsHistory;
using THCC.Application.Features.User.History.PaymentHistory;
using THCC.Application.Features.User.Login;
using THCC.Application.Features.User.Product.AddProduct;
using THCC.Application.Features.User.Product.Product;
using THCC.Application.Features.User.Profile.AddUserPassword;
using THCC.Application.Features.User.Profile.UpdateProfileImage;
using THCC.Application.Features.User.Profile.UpdateUserProfile;
using THCC.Application.Features.User.Profile.UserProfile;
using THCC.Application.Features.User.Rating;
using THCC.Application.Features.User.Signup.Signup;
using THCC.Application.Features.User.Signup.SignupConfirm;
using THCC.Application.Features.User.Signup.SignupResend;
using THCC.Application.Features.User.SocialLoginSignUp;
using THCC.Application.Models.Dtos;
using THCC.Domain.Aggregates;

namespace THCC.Api.Controllers.Identity;


public class UserController : BaseApiController
{
    #region Forgot Password

    [HttpPost("forgotpassword"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ForgotPasswordAsync([FromBody] ForgotPasswordRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("forgotpassword/confirm"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ForgotPasswordConfirmation([FromBody] ForgotPasswordConfirmRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("forgotpassword/confirm/resend"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ForgotPasswordResendAsync([FromBody] ForgotPasswordResendRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("forgotpassword/newpassword"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> NewPasswordAsync([FromBody] NewPasswordRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region SignUp

    [HttpPost("signup"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> SignupAsync([FromBody] SignupRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("signup/confirm"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LoginResponse))]
    public async Task<IActionResult> SignupConfirmAsync([FromBody] SignupConfirmRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("signup/confirm/resend"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ResendSignupAsync([FromBody] SignupResendRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Login

    [AllowAnonymous]
    [HttpPost("login")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LoginResponse))]
    public async Task<IActionResult> LoginAsync([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("login/social")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LoginResponse))]
    public async Task<IActionResult> SocialLoginAsync([FromBody] SocialLoginSignUpRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Account Summary

    [HttpGet("account/Summary"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountSummaryDto))]
    public async Task<IActionResult> AccountSummary(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new AccountSummaryRequest(), cancellationToken));
    }

    [HttpGet("account/{CardPin}/Summary"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CallingCardSummaryResponse))]
    public async Task<IActionResult> CallingCardSummary([FromRoute] CallingCardSummaryRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Profile

    [HttpGet("profile"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserProfileResponse))]
    public async Task<IActionResult> GetProfile(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new UserProfileRequest(), cancellationToken));
    }

    [HttpPut("profile"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateProfile([FromBody] UpdateUserProfileRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("password"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> AddPassword([FromBody] AddUserPasswordRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }
    [HttpPut("password"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Updatepassword([FromBody] ChangePasswordRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPut("profile/image"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateProfileImageResponse))]
    public async Task<IActionResult> Updateprofileimage([FromForm] UpdateProfileImageRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Product

    [HttpPost("product"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> AddProduct([FromBody] AddProductRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpGet("product"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetProduct(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new GetProductRequest(), cancellationToken));
    }

    #endregion

    #region History

    [HttpGet("history/payment"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PaymentHistoryResponse))]
    public async Task<IActionResult> GetPaymentHistory([FromQuery] PaymentHistoryRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpGet("history/callingcards"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<CallingCardsHistoryResponse>))]
    public async Task<IActionResult> GetCallingCardsHistory(CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(new CallingCardsHistoryRequest(), cancellationToken));
    }

    [HttpGet("history/{CardPin}/call"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CallHistoryResponse))]
    public async Task<IActionResult> GetCallHistory([FromRoute] CallHistoryRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Rating

    [HttpPost("rating"), Authorize]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> Addrating([FromBody] RatingRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    #endregion

    #region Guest
    [HttpPost("guest"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GuestAsync([FromBody] GuestRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("guest/confirm"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LoginResponse))]
    public async Task<IActionResult> GuestConfirmAsync([FromBody] GuestConfirmRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }

    [HttpPost("guest/confirm/resend"), AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GuestSignupAsync([FromBody] GuestResendRequest request, CancellationToken cancellationToken)
    {
        return HandleResponse(await Mediator.Send(request, cancellationToken));
    }
    #endregion
}