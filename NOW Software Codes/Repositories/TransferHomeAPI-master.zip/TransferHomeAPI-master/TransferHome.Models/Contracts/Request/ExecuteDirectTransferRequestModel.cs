﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Request
{
    public class ExecuteDirectTransferRequestModel
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }

        public int UserId { get; set; }
        public TransferTransactionType TransactionType { get; set; }
        public PaymentType PaymentType { get; set; }

    }
}
