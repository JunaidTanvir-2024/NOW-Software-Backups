﻿using ATT.Models.Configurations;
using ATT.Models.Contracts.Ding.Request;
using ATT.Models.Contracts.Ding.Response;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Ding
{
    public class DingAuth_BL : IDingAuth_BL
    {
        DingConfig _dingConf;
        private ILogger _logger;
        private readonly HttpConfig httpConfig;

        public DingAuth_BL(ILogger appLoggers, IOptions<DingConfig> dingConfig, IOptions<HttpConfig> http)
        {
            _logger = appLoggers;
            _dingConf = dingConfig.Value;
            httpConfig = http.Value;
        }
        public async Task<DingAuthResponse> getAuthToken(string account)
        {
            DingAuthRequest authRequest = new DingAuthRequest();
            authRequest.AuthApiEndPoint = _dingConf.AuthApiEndPoint;
            authRequest.grant_type = _dingConf.grant_type;
            if (account.ToLower().Equals("gbp"))
            {
                authRequest.client_id = _dingConf.GBP_client_id;
                authRequest.client_secret = _dingConf.GBP_client_secret;
            }
            else
            {
                authRequest.client_id = _dingConf.EUR_client_id;
                authRequest.client_secret = _dingConf.EUR_client_secret;
            }

            var response = await getDingAuthToken(authRequest);
            return response;
        }

        private async Task<DingAuthResponse> getDingAuthToken(DingAuthRequest request)
        {
            DingAuthResponse authResponse = new DingAuthResponse();
            var baseAddress = new Uri(_dingConf.AuthApiEndPoint);
            HttpClient DingHttpClient = new HttpClient { Timeout= TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
            var json = JsonConvert.SerializeObject(request);

            var nvc = new List<KeyValuePair<string, string>>();
            nvc.Add(new KeyValuePair<string, string>("client_id", request.client_id));
            nvc.Add(new KeyValuePair<string, string>("client_secret", request.client_secret));
            nvc.Add(new KeyValuePair<string, string>("grant_type", request.grant_type));
            var httpContent = new FormUrlEncodedContent(nvc);
            try
            {
                var httpResponse = await DingHttpClient.PostAsync("", httpContent);

                if (httpResponse.StatusCode == HttpStatusCode.OK && httpResponse.Content != null)
                {
                    string returnData = "";
                    returnData = await httpResponse.Content.ReadAsStringAsync();
                    authResponse = JsonConvert.DeserializeObject<DingAuthResponse>(returnData);
                }
                else
                {
                    Exception ex = new Exception($"Ding API Call Exception - Empty Contents Received - {json}");
                    throw ex;
                }
            }
            catch (WebException wex)
            {
                _logger.Debug($"\"Post  Ding API Web Access\"     Failed      Data:{json}     Message:{wex.ToString()}");
                throw wex;
            }
            catch (Exception ex)
            {
                _logger.Debug($"\"Post  Ding API\"  Failed       Generasl Exception       Data:{json}      Message:{ex.ToString()}");
                throw ex;
            }

            return authResponse;
        }
    }
}
