﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs.Digitalk
{
    public class DBResultAddBundle
    {
        public int error_code { get; set; }
        public string error_msg { get; set; }
    }
}
