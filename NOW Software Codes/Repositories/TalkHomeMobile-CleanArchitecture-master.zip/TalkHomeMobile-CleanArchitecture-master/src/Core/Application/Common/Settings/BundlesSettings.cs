﻿namespace Application.Common.Settings;
public class BundlesSettings
{
    public const string SectionName = "BundlesSettings";
    public static BundlesSettings Bind = new BundlesSettings();
    public bool ShowProductionBundle { get; set; }
}
