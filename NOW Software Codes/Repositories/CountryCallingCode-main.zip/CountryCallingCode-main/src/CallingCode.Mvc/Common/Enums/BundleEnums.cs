﻿namespace CallingCode.Mvc.Common.Enums;


public enum BundleCategory
{
    Platinum = 1,
    Gold,
    Silver
}
public enum BundleType
{
    Welcome = 1,
    Monthly,
    PAYG,
    Trial
}