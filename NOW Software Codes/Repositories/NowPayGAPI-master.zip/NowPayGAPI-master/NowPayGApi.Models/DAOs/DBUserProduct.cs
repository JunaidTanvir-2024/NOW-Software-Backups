﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBUserProduct
    {
        public int Id { get; set; }
        public ProductType ProductId { get; set; }
        public int UserId { get; set; }
        public string ProductRef { get; set; }
        public DateTime AddedDatetime { get; set; }
        public bool IsActive { get; set; }
        public string AccountId { get; set; }
    }
}
