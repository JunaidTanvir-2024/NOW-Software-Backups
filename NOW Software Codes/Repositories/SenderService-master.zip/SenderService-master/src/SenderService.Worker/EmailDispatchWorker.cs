using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using SenderService.Core.Common.Enums;
using SenderService.Core.Common.Models;
using SenderService.Core.Common.Settings;
using SenderService.Core.Persistence.Repository;
using SenderService.Core.Services.Mailing;

namespace SenderService.Worker;

public class EmailDispatchWorker : BackgroundService
{
    private readonly ISmtpMailService _emailSender;
    private readonly ILogger<EmailDispatchWorker> _logger;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly EmailDispatcherSettings _emailDispatcherSettings;
    private readonly AsyncRetryPolicy _retryPolicy;

    public EmailDispatchWorker(ISmtpMailService emailSender, ILogger<EmailDispatchWorker> logger, IServiceScopeFactory serviceScopeFactory, IOptions<EmailDispatcherSettings> emailDispatcherSettings)
    {
        _emailSender = emailSender;
        _logger = logger;
        _serviceScopeFactory = serviceScopeFactory;
        _emailDispatcherSettings = emailDispatcherSettings.Value;
        _retryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(retryCount: _emailDispatcherSettings.EmailRetryLimit, sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Worker Service Started");

        while (!stoppingToken.IsCancellationRequested)
        {
            using (IServiceScope scope = _serviceScopeFactory.CreateScope())
            {
                var emailRepository = scope.ServiceProvider.GetRequiredService<IEmailRepository>();
                List<EmailData>? emails = emailRepository.GetEmailsByStoreProcedureAsync(_emailDispatcherSettings.EmailBatchSize);

                foreach (var email in emails)
                {
                    MailRequest mailRequest = new MailRequest() { };

                    mailRequest.FromEmail = email.FromEmail;
                    mailRequest.FromName = email.FromName;

                    if (email.RecipientType == (int) RecipientType.To)
                    {
                        mailRequest.ToEmails = new List<string> { email.EmailAddress };
                    }
                    if (email.RecipientType == (int) RecipientType.CC)
                    {
                        mailRequest.CcEmails = new List<string>() { email.EmailAddress };
                    }
                    if (email.RecipientType == (int) RecipientType.BCC)
                    {
                        mailRequest.BccEmails = new List<string>() { email.EmailAddress };
                    }

                    mailRequest.Subject = email.Subject;
                    mailRequest.Body = email.Body;

                    bool isEmailSent = false;

                    while (!isEmailSent && email.Attempts < _emailDispatcherSettings.EmailRetryLimit)
                    {
                        try
                        {
                            isEmailSent = await _emailSender.SendAsync(mailRequest, stoppingToken);


                            email.ProcessingStatus = (byte) ProcessingState.Complete;
                            email.IsSent = isEmailSent;
                            email.SentDateTimeUtc = DateTime.UtcNow;

                            await emailRepository.UpdateEmailByStoreProcedureAsync(email.Id, email.IsSent, email.SentDateTimeUtc, email.Attempts, email.LastAttemptDateTimeUtc, email.ProcessingStatus, email.ErrorMessage).ConfigureAwait(false);

                            _logger.LogInformation($"{email.Id} is sent successfully");
                        }
                        catch (Exception ex)
                        {
                            email.ProcessingStatus = (byte) ProcessingState.Failed;
                            email.LastAttemptDateTimeUtc = DateTime.UtcNow;
                            email.ErrorMessage = ex.Message;
                            email.Attempts += 1;

                            await emailRepository.UpdateEmailByStoreProcedureAsync(email.Id, email.IsSent, email.SentDateTimeUtc, email.Attempts, email.LastAttemptDateTimeUtc, email.ProcessingStatus, email.ErrorMessage).ConfigureAwait(false);

                            _logger.LogInformation(email.ErrorMessage);
                        }
                    }
                }
            }

            _logger.LogInformation("Worker running at: {time}", DateTime.UtcNow);
            var time = TimeSpan.FromSeconds(_emailDispatcherSettings.SendDelayInSeconds);
            await Task.Delay(Convert.ToInt16(time.TotalMilliseconds), stoppingToken);
        }
    }
}
