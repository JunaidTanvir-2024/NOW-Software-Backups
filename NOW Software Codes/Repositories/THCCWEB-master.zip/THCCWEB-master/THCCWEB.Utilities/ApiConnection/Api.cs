﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using static THCCWEB.Utilities.ConnectionEnums.ApiEnums;

namespace THCCWEB.Utilities.ApiConnection
{
    public class Api
    {
        static HttpClient client;
        public static async Task<JObject> CallApi(string Uri, IPrincipal User, ApiCallType callType, object model = null, bool GetRequest = false, bool isMultipart = false, MultipartFormDataContent multipartContent = null, string basicauthtoken = null, params string[] parameters)
        {
            try
            {
                HttpResponseMessage response;
                string paramString = parameters.Count() > 0 ? "?" : String.Empty;
                using (client = new HttpClient())
                {
                    foreach (var param in parameters)
                    {
                        paramString += param + "&";
                    }
                    paramString = paramString.TrimEnd('&');

                    var claimsIdentity = (ClaimsIdentity)User.Identity;
                    var access_token = claimsIdentity.FindFirst("access_token");

                    if (access_token != null)
                    {
                        if (isMultipart)
                        {
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(claimsIdentity.FindFirst("token_type").Value, access_token.Value);
                        }
                        else
                        {
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(claimsIdentity.FindFirst("token_type").Value, access_token.Value);
                        }
                    }
                    if (isMultipart)
                    {
                        response = await client.PostAsync(Uri, multipartContent);
                    }
                    else
                    {
                        if (GetRequest)
                        {
                            response = await client.GetAsync(Uri + paramString);
                        }
                        else
                        {
                            response = await client.PostAsJsonAsync(Uri, model);
                        }
                    }

                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseJson = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                        if (responseJson.GetValue("errorCode").ToObject<int>() == 0)
                        {
                            return responseJson;
                        }
                        else
                        {
                            var errorCode = responseJson.GetValue("errorCode").ToObject<int>();
                            var errorMsg = responseJson.GetValue("message").ToString();
                            return new Error { ErrorCode = errorCode, ErrorMessage = errorMsg };
                        }
                    }
                    else if (response.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        return null;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
    [JsonObject(Title = "Error")]
   public class Error : JObject
    {
        [JsonProperty("message")]
        public string ErrorMessage { get; set; }
        [JsonProperty("errorCode")]
        public int ErrorCode { get; set; }

    }
    public class JsonContent : StringContent
    {
        public JsonContent(object obj) :
            base(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json")
        { }
    }
}
