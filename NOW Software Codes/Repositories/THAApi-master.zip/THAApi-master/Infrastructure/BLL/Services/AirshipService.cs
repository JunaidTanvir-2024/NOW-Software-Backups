﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Serilog;
using Microsoft.Extensions.Options;
using Models.Contracts.Request;
using Models.Configurations;
using Infrastructure.BLL.Services.Interfaces;
using Models.Enums;
using Infrastructure.BLL.Interfaces;
using Models.Services.Airship;
using Microsoft.AspNetCore.Http;
using Infrastructure.Utilities;
using Models.Contracts.Response;

namespace Infrastructure.BLL.Services
{
    public class AirShipService : IAirShipService
    {
        private readonly AirShipConfig _airShipConfig;
        private readonly HttpClient _airShipClient;
        private readonly IHttpContextAccessor _httpContext;
        private readonly ILogger _logger;
        private List<string> transactionTags;
        public AirShipService(
            ILogger logger,
            IOptions<AirShipConfig> airShipConfig,
            HttpClient httpClient,
            IHttpContextAccessor httpContext)
        {
            _logger = logger;
            _airShipConfig = airShipConfig.Value;
            _airShipClient = httpClient;
            this._httpContext = httpContext;
        }
        public async Task AddNamedUserTags(NamedUserTagsRequest request)
        {
            if (!_airShipConfig.IsActive)
                return;

            try
            {
                string endpoint = "NamedUser/AddNuserTags";
                var json = JsonConvert.SerializeObject(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                _airShipClient.PostAsync(endpoint, content);
                //if (!response.IsSuccessStatusCode)
                //{
                //    var responseMessage = response.Content.ReadAsStringAsync().Result;
                //    _logger.Error($"Method=> AddNamedUserTags, Request=> {JsonConvert.SerializeObject(request)}, " +
                //                 $"StatusCode=> {response.StatusCode}, Message=> {responseMessage}");
                //}
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> AddNamedUserTags, Request=> {JsonConvert.SerializeObject(request)}, " +
                             $"Message=> {ex.Message}");
            }
        }
        public async Task RemoveNamedUserTags(NamedUserTagsRequest request)
        {
            if (!_airShipConfig.IsActive)
                return;
            try
            {
                string endpoint = "NamedUser/RemoveNuserTags";
                var json = JsonConvert.SerializeObject(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                _airShipClient.PostAsync(endpoint, content);
                //if (!response.IsSuccessStatusCode)
                //{
                //    var responseMessage = response.Content.ReadAsStringAsync().Result;
                //    _logger.Error($"Method=> AddNamedUserTags, Request=> {JsonConvert.SerializeObject(request)}, " +
                //                 $"StatusCode=> {response.StatusCode}, Message=> {responseMessage}");
                //}
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> RemoveNamedUserTags, Request=> {JsonConvert.SerializeObject(request)}, " +
                             $"Message=> {ex.Message}");
            }
        }
        public async Task AddCustomEvent(CustomEventsRequest request)
        {
            if (!_airShipConfig.IsActive)
                return;
            try
            {
                string endpoint = "CustomEvent/AddCustomEvent";
                var json = JsonConvert.SerializeObject(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                _airShipClient.PostAsync(endpoint, content);
                //if (!response.IsSuccessStatusCode)
                //{
                //    var responseMessage = response.Content.ReadAsStringAsync().Result;
                //    _logger.Error($"Method=> AddCustomEvent, Request=> {JsonConvert.SerializeObject(request)}, " +
                //                 $"StatusCode=> {response.StatusCode}, Message=> {responseMessage}");
                //}
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> AddCustomEvent, Request=> {JsonConvert.SerializeObject(request)}, " +
                             $"Message=> {ex.Message}");
            }
            return;
        }
        public async Task EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            var jsonRequest = JsonConvert.SerializeObject(new
            {
                EmailAddress = emailAddress,
                NamedUserId = namedUserId,
                ProductCode = "THA"
            });

            try
            {
                var request = new HttpRequestMessage(
                    HttpMethod.Post, "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(jsonRequest, Encoding.UTF8, "application/json")
                };

                await _airShipClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> EmailAssociationWithNamedUser, Request=> {jsonRequest} ,Message=> {ex.Message}");
            }
        }
        public async Task AddEmailChannel(string emailAddress)
        {
            var jsonRequest = JsonConvert.SerializeObject(new
            {
                Address = emailAddress,
                ProductCode = "THA"
            });

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, "Email/AddEmailChannel")
                {
                    Content = new StringContent(jsonRequest, Encoding.UTF8, "application/json")
                };

                await _airShipClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> AddEmailChannel, Request=> {jsonRequest} ,Message=> {ex.Message}");
            }
        }
        public async Task AddEmailChannelCommercial(string emailAddress)
        {
            var jsonRequest = JsonConvert.SerializeObject(new
            {
                Address = emailAddress,
                ProductCode = "THA",
                commercialOptedIn = DateTime.UtcNow
            });
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, "Email/AddEmailChannel")
                {
                    Content = new StringContent(jsonRequest, Encoding.UTF8, "application/json")
                };

                await _airShipClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> AddEmailChannelCommercial, Request=> {jsonRequest} ,Message=> {ex.Message}");
            }
        }
        public async Task RemoveEmailChannelCommercial(string emailAddress)
        {
            var jsonRequest = JsonConvert.SerializeObject(new
            {
                Address = emailAddress,
                ProductCode = "THA",
                commercialOptedOut = DateTime.UtcNow
            });

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, "Email/AddEmailChannel")
                {
                    Content = new StringContent(jsonRequest, Encoding.UTF8, "application/json")
                };

                await _airShipClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> RemoveEmailChannelCommercial, Request=> {jsonRequest} ,Message=> {ex.Message}");
            }
        }
        public async Task DisassociateEmailChannelFromNamedUser(string namedUserId, string emailAddress)
        {
            var jsonRequest = JsonConvert.SerializeObject(new
            {
                EmailAddress = emailAddress,
                NamedUserId = namedUserId,
                ProductCode = "THA"
            });

            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, "NamedUser/DisassociateEmailChannelFromNamedUser")
                {
                    Content = new StringContent(jsonRequest, Encoding.UTF8, "application/json")
                };

                await _airShipClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.Error($"Method=> DisassociateEmailChannelFromNamedUser, Request=> {jsonRequest} ,Message=> {ex.Message}");
            }
        }
        public async Task HandleTopupTagsAndEvents(TopupInfoAirship info)
        {
            try
            {
                if (!_airShipConfig.IsActive) return;
                transactionTags = new List<string>();

                string paymentMethod = GetPaymentMethod(info.IsCard, "Topup");

                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();

                if (!_httpContext.HttpContext.AirshipEventsDisable())
                {

                    var customEventRequest = new CustomEventsRequest()
                    {
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = info.Msisdn,
                        InteractionType = "URL",
                        InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "Topup/Card" : "Topup/Paypal" : "Topup/Voucher"
                    };

                    if (info.IsSuccess)
                    {
                        customEventRequest.Value = Convert.ToDouble(info.Amount);

                        if (info.IsCard.HasValue)
                        {
                            customEventRequest.CustomEventName = "topup_any_app";
                            await this.AddCustomEvent(customEventRequest);
                        }


                        customEventRequest.CustomEventName = $"topup_{info.Amount}_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"topup_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"topup_any_{info.Origination}_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"pay_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"topup_{info.Amount}_app";
                        await this.AddCustomEvent(customEventRequest);


                    }
                    else
                    {
                        customEventRequest.CustomEventName = $"payfail_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = "payfail_any_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"payfail_any_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                    }
                }
                if (transactionTags.Count > 0)
                {
                    if (info.IsSuccess)
                    {
                        transactionTags.Add("topup_app");

                        //transactionTags.Add("topup_any_app");
                        //transactionTags.Add($"topup_{info.Amount}_app");
                        //transactionTags.Add($"topup_{info.Origination}_app");
                        //transactionTags.Add($"topup_{info.Amount}_{info.Origination}_app");
                        //transactionTags.Add($"topup_any_{info.Origination}_{paymentMethod}_app");

                        await this.AddNamedUserTags(
                              new NamedUserTagsRequest()
                              {
                                  NamedUser = info.Msisdn,
                                  Tags = transactionTags,
                                  TagGroup = _airShipConfig.TransactionTagGroupName
                              });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: HandleTopupTagsAndEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleBundleTagsAndEvents(BundleInfoAirShip info)
        {
            try
            {
                if (!_airShipConfig.IsActive) return;
                var transactionTags = new List<string>();
                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();
                if (!string.IsNullOrEmpty(info.Destination))
                    info.Destination = info.Destination.ToLower().Trim();

                string bundleType = GetBundleType(info.BundleType);
                string paymentMethod = "";
                if (info.IsCard.HasValue)
                {
                    if (info.IsCard.Value)
                    {
                        paymentMethod = "card";
                    }
                    else
                    {
                        paymentMethod = "paypal";
                    }
                }
                else
                {
                    paymentMethod = "balance";
                }
                if (!_httpContext.HttpContext.AirshipEventsDisable())
                {
                    var customEventRequest = new CustomEventsRequest()
                    {
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = info.Msisdn,
                        InteractionType = "URL",
                        Value = Convert.ToDouble(info.Amount),
                        InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "Bundle/Card" : "Bundle/Paypal" : "Bundle/AccountBalance"
                    };

                    if (info.IsSuccess)
                    {

                        if (info.IsCard.HasValue)
                        {
                            customEventRequest.CustomEventName = "bun_any_app";
                            await this.AddCustomEvent(customEventRequest);
                        }

                        customEventRequest.CustomEventName = $"bun_{bundleType}_any_app";
                        await this.AddCustomEvent(customEventRequest);


                        customEventRequest.CustomEventName = $"bun_dest_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_orig_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_dest_{bundleType}_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_orig_{bundleType}_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_any_{info.Origination}_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_{bundleType}_{info.Origination}_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_{bundleType}_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_{bundleType}_{info.Origination}_{info.Destination}_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"bun_{paymentMethod}_app";
                        await this.AddCustomEvent(customEventRequest);

                        //customEventRequest.CustomEventName = $"view_bun_buy_via_{paymentMethod}_app";
                        //await this.AddCustomEvent(customEventRequest);

                    }
                }
                if (transactionTags.Count > 0)
                {
                    if (info.IsSuccess)
                    {
                        transactionTags.Add($"bundle_app");
                        transactionTags.Add($"bun_any_app");
                        transactionTags.Add($"bun_{bundleType}_any_app");
                        transactionTags.Add($"bun_dest_{info.Destination}_app");
                        transactionTags.Add($"bun_orig_{info.Origination}_app");
                        transactionTags.Add($"bun_dest_{bundleType}_{info.Destination}_app");
                        transactionTags.Add($"bun_orig_{bundleType}_{info.Origination}_app");
                        transactionTags.Add($"bun_{bundleType}_{info.Origination}_{info.Destination}_app");
                        transactionTags.Add($"bun_{bundleType}_{paymentMethod}_app");
                        transactionTags.Add($"bun_{bundleType}_{info.Origination}_{info.Destination}_{paymentMethod}_app");
                        transactionTags.Add($"bun_{paymentMethod}_app");
                        await this.AddNamedUserTags(
                              new NamedUserTagsRequest()
                              {
                                  NamedUser = info.Msisdn,
                                  Tags = transactionTags,
                                  TagGroup = _airShipConfig.TransactionTagGroupName
                              });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: HandleBundleTagsAndEvents, " +
                              $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleIntTopupTagsAndEvents(IntTopupInfoAirShip info)
        {
            try
            {
                if (!_airShipConfig.IsActive) return;
                transactionTags = new List<string>();
                if (!string.IsNullOrEmpty(info.Origination))
                    info.Origination = info.Origination.ToLower().Trim();
                if (!string.IsNullOrEmpty(info.Destination))
                    info.Destination = info.Destination.ToLower().Trim();

                if (!_httpContext.HttpContext.AirshipEventsDisable())
                {
                    var customEventRequest = new CustomEventsRequest()
                    {
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = info.Msisdn,
                        InteractionType = "URL",
                        InteractionId = info.IsCard.HasValue ? info.IsCard.Value ? "IntTopup/Card" : "IntTopup/Paypal" : "IntTopup/AccountBalance"
                    };

                    if (info.IsSuccess)
                    {
                        customEventRequest.Value = Convert.ToDouble(info.Amount);
                        if (info.IsCard.HasValue)
                        {
                            customEventRequest.CustomEventName = "inttop_any_app";
                            await this.AddCustomEvent(customEventRequest);
                        }

                        customEventRequest.CustomEventName = $"inttop_any_{info.Origination}_to_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = info.IsCard.HasValue ? info.IsCard.Value ? "inttop_card_app" : "inttop_paypal_app" : "inttop_balance_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"inttop_dest_{info.Destination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"inttop_orig_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        if (info.IsTransferRequest)
                        {
                            customEventRequest.CustomEventName = $"req_inttop_sent_app";
                            await this.AddCustomEvent(customEventRequest);
                        }
                    }
                    else
                    {
                        customEventRequest.CustomEventName = $"inttop_failure_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = $"inttopfail_any_{info.Origination}_app";
                        await this.AddCustomEvent(customEventRequest);

                        customEventRequest.CustomEventName = info.IsCard.HasValue ? info.IsCard.Value ? "inttopfail_card_app" : "inttopfail_paypal_app" : "inttopfail_balance_app";
                        await this.AddCustomEvent(customEventRequest);
                    }
                }

                if (transactionTags.Count > 0)
                {
                    if (info.IsSuccess)
                    {
                        transactionTags.Add("inttop_app");
                        transactionTags.Add($"inttop_orig_{info.Origination}_app");
                        transactionTags.Add($"inttop_dest_{info.Destination}_app");
                        transactionTags.Add($"inttop_{info.Origination}_to_{info.Destination}_app");
                        await this.AddNamedUserTags(
                              new NamedUserTagsRequest()
                              {
                                  NamedUser = info.Msisdn,
                                  Tags = transactionTags,
                                  TagGroup = _airShipConfig.TransactionTagGroupName
                              });
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: HandleIntTopupTagsAndEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleAutoTopup(string msisdn, bool isActive)
        {
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = new List<string>() { "autotop_app" },
                TagGroup = _airShipConfig.ActivityTagGroupName,
            };

            if (isActive)
                await this.AddNamedUserTags(eventReq);
            else
                await this.RemoveNamedUserTags(eventReq);
        }
        public async Task HandleAutoRenew(string msisdn, bool isActive, string destination, BundleType bundleType)
        {
            //Handle Airship Events
            var eventReq = new NamedUserTagsRequest()
            {
                NamedUser = msisdn,
                Tags = new List<string>() { "autoren_app" },
                TagGroup = _airShipConfig.ActivityTagGroupName
            };

            if (isActive)
            {
                await this.AddNamedUserTags(eventReq);

                var customEventRequest = new CustomEventsRequest()
                {
                    ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                    ChannelIdentifierValue = msisdn,
                    InteractionType = "URL",
                    InteractionId = "Bundle/AutoRenew",
                    CustomEventName = $"bun_enable_autorenew_{destination}_{GetBundleType(bundleType)}_app"
                };
                await this.AddCustomEvent(customEventRequest);
            }
            else
                await this.RemoveNamedUserTags(eventReq);
        }
        private string GetBundleType(BundleType bundleType)
        {
            if (bundleType == BundleType.Welcome)
            {
                return "welcome";
            }
            else if (bundleType == BundleType.PAYG)
            {
                return "payg";
            }
            else if (bundleType == BundleType.Monthly)
            {
                return "roll";
            }
            else
            {
                return "trial";
            }
        }
        private string GetPaymentMethod(bool? IsCard, string type = null)
        {
            if (IsCard.HasValue)
            {
                if (IsCard.Value)
                {
                    return "card";
                }
                else
                {
                    return "paypal";
                }
            }
            else
            {
                if (type == "Topup")
                {
                    return "voucher";
                }
                else
                {
                    return "balance";
                }
            }
        }
        public async Task ReferralRedeemedAirshipEvent(string msisdn, int points = 0)
        {
            var customEventRequest = new CustomEventsRequest()
            {
                CustomEventName = "referral_redeemed_referrer",
                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                ChannelIdentifierValue = msisdn,
                InteractionType = "URL",
                Value = points
            };

            await this.AddCustomEvent(customEventRequest);
        }
        public async Task VoucherifyPointsEarnAirshipEvent(string msisdn, int points = 0)
        {
            var customEventRequest = new CustomEventsRequest()
            {
                CustomEventName = "total_points_earned",
                ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                ChannelIdentifierValue = msisdn,
                InteractionType = "URL",
                Value = points
            };

            await this.AddCustomEvent(customEventRequest);
        }
    }
}