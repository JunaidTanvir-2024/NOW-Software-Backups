
GO
CREATE PROCEDURE [dbo].[ch_app_log_upsert]
  @request_timestamp DATETIME2,
  @request_path NVARCHAR(255),
  @request_method NVARCHAR(10),
  @request_body NVARCHAR(MAX),
  @response_body NVARCHAR(MAX),
  @status_code INT,
  @duration BIGINT,
  @client_ip NVARCHAR(50),
  @user_agent NVARCHAR(255),
  @response_size BIGINT,
  @error_reason NVARCHAR(MAX),
  @correlation_id UNIQUEIDENTIFIER,
  @query_string NVARCHAR(MAX)
AS
BEGIN
  IF EXISTS (SELECT 1
  FROM [app_log]
  WHERE correlation_id = @correlation_id)  
    BEGIN
    UPDATE [app_log]  
        SET response_body = @response_body  
        WHERE correlation_id = @correlation_id;
  END  
    ELSE  
    BEGIN
    INSERT INTO [app_log]
      (request_timestamp, request_path, request_method, request_body, response_body, status_code, duration, client_ip, user_agent, response_size, error_reason, correlation_id, query_string)
    VALUES
      (@request_timestamp, @request_path, @request_method, @request_body, @response_body, @status_code, @duration, @client_ip, @user_agent, @response_size, @error_reason, @correlation_id, @query_string);
  END
END



GO
CREATE PROCEDURE [dbo].[ch_vendor_log_insert]
  (
  @request_timestamp DATETIME2,
  @request_path NVARCHAR(255),
  @request_method NVARCHAR(10),
  @request_body NVARCHAR(MAX),
  @response_body NVARCHAR(MAX),
  @status_code INT,
  @duration BIGINT,
  @response_size BIGINT,
  @error_reason NVARCHAR(MAX),
  @correlation_id UNIQUEIDENTIFIER,
  @headers NVARCHAR(MAX),
  @query_string NVARCHAR(MAX),
  @vendor_id INT
)
AS
BEGIN
  INSERT INTO vendor_log
    (
    request_timestamp,
    request_path,
    request_method,
    request_body,
    response_body,
    status_code,
    duration,
    response_size,
    error_reason,
    correlation_id,
    headers,
    query_string,
    vendor_id
    )
  VALUES
    (
      @request_timestamp,
      @request_path,
      @request_method,
      @request_body,
      @response_body,
      @status_code,
      @duration,
      @response_size,
      @error_reason,
      @correlation_id,
      @headers,
      @query_string,
      @vendor_id
    );
END;
GO