﻿using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Serilog;

using System.Text;

using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Airship;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Infrastructure.Services.Tracking.AirShip.Models;

using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services.Tracking.AirShip
{
    public class AirshipService : IAirshipService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger _logger;
        private readonly AirShipSettings _airshipSetting;

        public AirshipService(
            IHttpClientFactory httpClientFactory,
            IOptions<AirShipSettings> airshipSetting,
            ILogger logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _airshipSetting = airshipSetting.Value;
        }

        public async Task<(bool IsSuccess, string? ErrorMessage)> EmailAssociationWithNamedUser(string namedUserId, string emailAddress)
        {
            if (!_airshipSetting.IsActive) return (false, "Airship is inactive");
            string loggingParameters = $"namedUserId: {namedUserId} emailAddress={emailAddress} ";
            try
            {
                var request = new HttpRequestMessage(
                    HttpMethod.Post, _airshipSetting.ApiEndpoint + "NamedUser/EmailAssociationWithNamedUser")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        EmailAddress = emailAddress,
                        NamedUserId = namedUserId,
                        ProductCode = nameof(ProductCode.THCC)
                    }), Encoding.UTF8, "application/json")
                };
                var client = _httpClientFactory.CreateClient();
                var output = await client.SendAsync(request);
                if (!output.IsSuccessStatusCode)
                {
                    var ErrMsg = JsonConvert.DeserializeObject<dynamic>(output.Content.ReadAsStringAsync().Result);
                    return (false, ErrMsg!);
                }
                return (true, null!);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: EmailAssociationWithNamedUser, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return (false, ex.Message!);
            }
        }
        public async Task<(bool IsSuccess, string? ErrorMessage)> CreateEmailChannelCommercial(string emailAddress)
        {
            if (!_airshipSetting.IsActive) return (false, "Airship is inactive");
            string loggingParameters = $"emailAddress={emailAddress} ";
            try
            {
                var request = new HttpRequestMessage(
                    HttpMethod.Post, _airshipSetting.ApiEndpoint + "Email/AddEmailChannel")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Address = emailAddress,
                        ProductCode = nameof(ProductCode.THCC),
                        commercialOptedIn = DateTime.UtcNow
                    }), Encoding.UTF8, "application/json")
                };
                var client = _httpClientFactory.CreateClient();
                var output = await client.SendAsync(request);
                if (!output.IsSuccessStatusCode)
                {
                    var ErrMsg = JsonConvert.DeserializeObject<dynamic>(output.Content.ReadAsStringAsync().Result);
                    return (false, ErrMsg!);
                }
                return (true, null);
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: AddEmailChannelCommercial, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return (false, ex.Message!);
            }
        }
        public async Task<bool?> IsEmailChannelAlreadyExists(string emailAddress)
        {
            if (!_airshipSetting.IsActive) return null;
            string loggingParameters = $"emailAddress={emailAddress} ";
            try
            {
                var request = new HttpRequestMessage(
                    HttpMethod.Post, _airshipSetting.ApiEndpoint + "Email/GetChannelByEmail")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(new
                    {
                        Email_Channel_Id = emailAddress,
                        ProductCode = nameof(ProductCode.THCC),
                    }), Encoding.UTF8, "application/json")
                };
                var client = _httpClientFactory.CreateClient();
                var output = await client.SendAsync(request);
                string outputData = await output.Content.ReadAsStringAsync();
                if (output.IsSuccessStatusCode)
                {
                    var deserializeResponse = JsonConvert.DeserializeObject<GenericApiResponse<AirShipEmailChannelModel>>(outputData)!;
                    return deserializeResponse != null
                        && deserializeResponse?.ErrorCode == 0
                        && deserializeResponse.Payload?.Channel?.OptIn == true;
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: GetChannelByEmail, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return null;
            }
        }
        public async Task<(bool IsSuccess, string? ErrorMessage)> CreateEmailChannelAndAssociation(string emailAddress, bool isNew = false)
        {
            if (!_airshipSetting.IsActive) return (false, "Airship is inactive");
            string loggingParameters = $"emailAddress={emailAddress} ";
            try
            {
                if (isNew)
                {
                    var createEmailChannelResponse = await CreateEmailChannelCommercial(emailAddress);
                    if (!createEmailChannelResponse.IsSuccess)
                    {
                        _logger.Error($"Class: AirshipService, Method: CreateEmailChannelAndAssociation, ErrorMessage: {createEmailChannelResponse.ErrorMessage}");
                        return (false, createEmailChannelResponse.ErrorMessage);
                    }
                    var emailAssociationResponse = await EmailAssociationWithNamedUser(emailAddress, emailAddress);
                    if (!emailAssociationResponse.IsSuccess)
                    {
                        _logger.Error($"Class: AirshipService, Method: CreateEmailChannelAndAssociation, ErrorMessage: {emailAssociationResponse.ErrorMessage}");
                        return (false, emailAssociationResponse.ErrorMessage);
                    }
                    return (true, null!);
                }
                else
                {
                    var airshipResponse = await IsEmailChannelAlreadyExists(emailAddress);
                    if (airshipResponse != null && airshipResponse == false)
                    {

                        var createEmailChannelResponse = await CreateEmailChannelCommercial(emailAddress);
                        if (!createEmailChannelResponse.IsSuccess)
                        {
                            _logger.Error($"Class: AirshipService, Method: CreateEmailChannelAndAssociation, ErrorMessage: {createEmailChannelResponse.ErrorMessage}");
                            return (false, createEmailChannelResponse.ErrorMessage);
                        }
                        var emailAssociationResponse = await EmailAssociationWithNamedUser(emailAddress, emailAddress);
                        if (!emailAssociationResponse.IsSuccess)
                        {
                            _logger.Error($"Class: AirshipService, Method: CreateEmailChannelAndAssociation, ErrorMessage: {emailAssociationResponse.ErrorMessage}");
                            return (false, emailAssociationResponse.ErrorMessage);
                        }
                    }
                    return (true, null!);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: AirshipService, Method: RegisterEmail, Parameters => {loggingParameters}, ErrorMessage: {ex.Message}");
                return (false, ex.Message!);
            }
        }
        public async Task<bool> AddCustomEvents(CustomEventsRequest request)
        {
            var json = JsonConvert.SerializeObject(request);
            try
            {
                var httpClient = _httpClientFactory.CreateClient();
                string endpoint = $"{_airshipSetting.ApiEndpoint + "CustomEvent/AddCustomEvent"}";
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);
                if (!result.IsSuccessStatusCode)
                {
                    _logger.Debug($"Service: AirshipService, Method: AddCustomEvent, Request: {JsonConvert.SerializeObject(json)},  Response: {result.StatusCode}");
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Service: AirshipService, Method: AddCustomEvent, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
                return false;
            }
        }
        public async Task<bool> AddCustomUserTags(CustomUserTagsRequest request)
        {
            var json = JsonConvert.SerializeObject(request);
            try
            {
                var httpClient = _httpClientFactory.CreateClient();
                string endpoint = $"{_airshipSetting.ApiEndpoint + "NamedUser/AddNuserTags"}";
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                HttpResponseMessage result = await httpClient.PostAsync(endpoint, content);

                if (!result.IsSuccessStatusCode)
                {
                    _logger.Debug($"Service: AirshipService, Method: AddUserTags, Request: {JsonConvert.SerializeObject(json)},  Response: {result.StatusCode}");
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Service: AirshipService, Method: AddUserTags, Request: {JsonConvert.SerializeObject(json)},  Exception:{ex.Message} ");
                return false;
            }
        }
    }
}