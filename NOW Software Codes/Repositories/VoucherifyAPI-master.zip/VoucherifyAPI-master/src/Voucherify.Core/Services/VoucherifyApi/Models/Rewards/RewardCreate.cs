using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

using static Voucherify.Core.Services.VoucherifyApi.Definations.VoucherifyEnums;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

public class RewardCreate
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("type")]
    public RewardType? Type { get; set; }

    [JsonPropertyName("parameters")]
    public RewardParameters? Parameters { get; set; }

    [JsonPropertyName("stock")]
    public string? Stock { get; set; }

    [JsonPropertyName("attributes")]
    public Metadata? Attributes { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}