﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;

namespace THCC.Application.Features.User.Rating
{
    #region Fields

    #endregion

    #region Ctor

    #endregion

    #region Method

    #endregion

    public class RatingRequestHandler : IRequestHandler<RatingRequest, object>
    {
        private readonly IUserRepository _userRepository;
        private readonly ICurrentUser _currentUser;

        public RatingRequestHandler(IUserRepository userRepository, ICurrentUser currentUser)
        {
            _userRepository = userRepository;
            _currentUser = currentUser;
        }

        public async Task<object> Handle(RatingRequest request, CancellationToken cancellationToken)
        {
            var userId = _currentUser.GetUserId();
            await _userRepository.AddRating(request.Rating, userId);
            return Unit.Value;
        }
    }
}
