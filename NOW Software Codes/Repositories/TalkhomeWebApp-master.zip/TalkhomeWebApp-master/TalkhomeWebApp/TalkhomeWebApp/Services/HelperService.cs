﻿using Newtonsoft.Json;
using PhoneNumbers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TalkhomeWebApp.Models;

namespace TalkhomeWebApp.Services
{
    public class HelperService : IHelperService
    {
        public string GetCountryCode(string msisdn)
        {
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber ToNumber = phoneNumberUtil.Parse(msisdn.StartsWith("+") ?
                                        msisdn.Trim() : "+" + msisdn.Trim(), "");
            return phoneNumberUtil.GetRegionCodeForNumber(ToNumber);
        }
        public string GetCountryNameByCountryCode(string code)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/json/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.IsoTwoCharacterCode.Equals(code,System.StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault()?.Name.Trim();
        } 
        public string GetCountryCodeByCountryName(string name)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/json/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.Name.Equals(name,System.StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault()?.IsoTwoCharacterCode.Trim();
        }
        public Country GetCountryByCountryName(string name)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/json/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.Name.Replace('-',' ').Equals(name, System.StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
        }
        public TopupCountryVariation GetTopupCountry(string countryCode,string countryName)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/json/TopupLandingPagesData/TopupCountry.json"));
            var json = JsonConvert.DeserializeObject<TopupCountry>(File.ReadAllText(completePath));
            var data= json.Variations.FirstOrDefault(e=> e.CountryCodeStartsWith.Split(',').Any(f=> countryCode.StartsWith(f,System.StringComparison.InvariantCultureIgnoreCase)));
            data.MetaTitle = data.MetaTitle.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MetaDescription = data.MetaDescription.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MetaKeywords = data.MetaKeywords.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Heading1 = data.Heading1.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Heading2 = data.Heading2.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Heading3 = data.Heading3.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Heading4 = data.Heading4.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Description1 = data.Description1.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Description2 = data.Description2.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Description3 = data.Description3.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.Description4 = data.Description4.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            return data;
        }
        public RateLandingPageVariation GetLandingPageContent(string countryCode, string countryName,string callingRate,string minorCurrencyUnit)
        {
            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/json/CallingRatesLandingPagesData/LandingPageVariation.json"));
            var json = JsonConvert.DeserializeObject<LandingPageRate>(File.ReadAllText(completePath));
            var data = json.Variations.FirstOrDefault(e => e.CountryCodeStartsWith.Split(',').Any(f => countryCode.StartsWith(f, System.StringComparison.InvariantCultureIgnoreCase)));
            data.MainHeading = data.MainHeading.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.IntCallingHeading = data.IntCallingHeading.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MobileTopUpHeading = data.MobileTopUpHeading.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MainDescription = data.MainDescription.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase).Replace("[Country Calling Rate]", callingRate,System.StringComparison.InvariantCultureIgnoreCase).Replace("[Minor Currency Unit]", minorCurrencyUnit, System.StringComparison.InvariantCultureIgnoreCase);
            data.IntCallingDesc = data.IntCallingDesc.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MobileTopUpDesc = data.MobileTopUpDesc.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            data.MetaDescription = data.MetaDescription.Replace("[Country Name]", countryName, System.StringComparison.InvariantCultureIgnoreCase);
            return data;
        }
    }
}
