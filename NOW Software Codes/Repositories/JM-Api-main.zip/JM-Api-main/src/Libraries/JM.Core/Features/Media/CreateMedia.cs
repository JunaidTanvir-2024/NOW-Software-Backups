using FluentValidation;

using JM.Core.Features.Traveler;
using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

using RW;

namespace JM.Core.Features.Media;

public abstract class CreateMedia
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public AppEnum.MediaType Type { get; set; }
        public IFormFile Media { get; set; } = default!;
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.Type).NotNull().NotEmpty();
            RuleFor(x => x.Media).NotNull().NotEmpty();
        }
        #endregion
    }
    #region Response
    public sealed record Response
    {
        public long Id { get; set; }
        public required string Type { get; set; }
        public required string Url { get; set; }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork, IWebHostEnvironment webHostEnvironment, IHttpContextAccessor contextAccessor, IMediator mediator) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;
        private readonly IWebHostEnvironment _webHostEnvironment = webHostEnvironment;
        private readonly IHttpContextAccessor _contextAccessor = contextAccessor;
        private readonly IMediator _mediator = mediator;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var userId = _contextAccessor.HttpContext?.User.GetId();

            var getTraveler = await _mediator.Send(new GetTraveler.Query()
            {
                Id = userId ?? default
            }, cancellationToken);

            if (getTraveler.IsSuccess)
            {
                var travelerInfo = getTraveler.TypedPayload<GetTraveler.Response>()?.Trip;

                var saveFileUrl = await query.Media.SaveUserMedia(travelerInfo?.Traveler.Id, travelerInfo?.Id, _webHostEnvironment);

                var newMedia = new Entities.Media()
                {
                    TravelerId = travelerInfo?.Traveler?.Id ?? default,
                    TripId = travelerInfo?.Id ?? default,
                    Url = saveFileUrl,
                    Type = Enum.GetName(query.Type)!,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                };
                var media = await _unitOfWork.MediaRepository.AddMedia(newMedia);
                _unitOfWork.SaveChanges();

                if (media is not null)
                {
                    return ResultWrapper.Success(new Response()
                    {
                        Id = media.Id,
                        Type = media.Type,
                        Url = media.Url
                    });
                }
                return ResultWrapper.Failure(AppConstant.StatusKey.Forbidden, AppConstant.StatusCode.Forbidden);
            }

            return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
        }
    }
    #endregion
}
