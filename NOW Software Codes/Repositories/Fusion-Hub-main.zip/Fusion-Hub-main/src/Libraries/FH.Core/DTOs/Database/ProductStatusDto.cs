namespace FH.Core.DTOs.Database;
public sealed record ProductStatusDto
{
	public sealed record Request
	{
		public required IEnumerable<long> ProductIds { get; set; }
	}

	public sealed record Response
	{
		public long ProductId { get; set; }
		public required string ProductVendorCode { get; set; }
		public required string ProductNameAlias { get; set; }
		public required long OperatorId { get; set; }
		public required string OperatorNameAlias { get; set; }
		public required long ProductCategoryId { get; set; }
		public required string ProductCategory { get; set; }
		public required long ProductSubcategoryId { get; set; }
		public required string ProductSubcategory { get; set; }
		public required long VendorId { get; set; }
		public required string IsActive { get; set; }
	}
}
