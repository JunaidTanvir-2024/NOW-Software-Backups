namespace Voucherify.Core.Commons.Settings;

public class EndpointsSettings
{
    public const string SectionName = nameof(EndpointsSettings);
    public bool EnableVouchersEndpoint { get; set; }
    public bool EnableCustomersEndpoint { get; set; }
    public bool EnablePromotionsEndpoint { get; set; }
    public bool EnableCampaignsEndpoint { get; set; }
    public bool EnableEarningRulesEndpoint { get; set; }
    public bool EnableLoyaltiesEndpoint { get; set; }
    public bool EnableStackableDiscountsEndpoint { get; set; }
    public bool EnableProductsEndpoint { get; set; }
    public bool EnableUtilityEndpoint { get; set; }
    public bool EnableRewardsEndpoint { get; set; }
}
