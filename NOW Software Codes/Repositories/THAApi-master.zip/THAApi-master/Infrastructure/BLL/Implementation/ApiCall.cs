﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.BLL.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Models.Contracts.Request;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class ApiCall : IApiCall
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IPhoneNumberService _phoneNumberService;

        public ApiCall(
            HttpClient client,
            IHttpContextAccessor httpContextAccessor,
            IPhoneNumberService phoneNumberService)
        {
            _client = client;
            _httpContextAccessor = httpContextAccessor;
            _phoneNumberService = phoneNumberService;
        }

        public async Task<HttpResponseMessage> GetAsync(string Uri, TokenType authTokenType, string authToken, params string[] parameters)
        {
            HttpResponseMessage response;

            try
            {
                //

                string paramString = parameters.Count() > 0 ? "?" : String.Empty;

                foreach (var param in parameters)
                {
                    paramString += param + "&";
                }
                paramString = paramString.TrimEnd('&');

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                response = await _client.GetAsync(Uri + paramString);

                return response;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<HttpResponseMessage> GetAsync(string Uri, TokenType authTokenType, string authToken)
        {
            HttpResponseMessage response;

            try
            {
                //

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);

                response = await _client.GetAsync(Uri);

                return response;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<HttpResponseMessage> GetAsync(string Uri)
        {
            HttpResponseMessage response;

            try
            {
                

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                response = await _client.GetAsync(Uri);

                return response;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<HttpResponseMessage> PostUrlEncodedAsync(string Uri, TokenType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel)
        {
            try
            {
                

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);
                HttpContent content = new FormUrlEncodedContent(postDataModel);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                content.Headers.ContentType.CharSet = "UTF-8";
                HttpResponseMessage resposne = await _client.PostAsync(Uri, content);
                return resposne;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<HttpResponseMessage> PostAsync(string Uri, TokenType authTokenType, string authToken, string requestJson)
        {
            try
            {
                

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authTokenType.ToString(), authToken);
                var stringContent = new StringContent(requestJson, Encoding.UTF8, "application/json");
                HttpResponseMessage resposne = await _client.PostAsync(Uri, stringContent);
                return resposne;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<HttpResponseMessage> PostAsync(string Uri, string requestJson)
        {
            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                var stringContent = new StringContent(requestJson, Encoding.UTF8, "application/json");
                HttpResponseMessage resposne = await _client.PostAsync(Uri, stringContent);
                return resposne;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}