﻿using ATT.Infrastructure.BLL.Reloady;
using ATT.Models.Database;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Threading.Tasks;

namespace ATT.Controllers
{
    [Route("reloadly")]
    [ApiController]
    public class ReloadlyController : ControllerBase
    {
        private IReloadlyPost_BL _reloadlyPost_BL;
        private ILogger _logger;

        //public ReloadlyController(IReloadlyPost_BL reloadlyPost_BL, ILogger logger)
        //{
        //    _reloadlyPost_BL = reloadlyPost_BL;
        //    _logger = logger;
        //}

        //#region GetOperatorProducts

        //[HttpGet]
        //[Route("GetOperatorProducts")]
        //public async Task<IActionResult> GetOperatorProducts(string destinationMSISDN, string account, string fromMSISDN, string productCode, string productItemCode = null)
        //{
        //    try
        //    {
        //        var response = await _reloadlyPost_BL.ReloadlyGetPhoneOperator(fromMSISDN, account, destinationMSISDN, productCode, productItemCode);

        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Debug($"ReloadlyGetPhoneOperator  Failed  Source:General   Parameters: destinationMSISDN{destinationMSISDN}  account{account} fromMSISDN{fromMSISDN} productCode{productCode} productItemCode{productItemCode}    Message:{ex.ToString()}");
        //        var result = new { errorCode = 1, Message = "API Error" };
        //        return Ok(result);
        //    }

        //}

        //#endregion


        //#region topup

        //[HttpPost]
        //[Route("topup")]
        //public async Task<IActionResult> ReloadyExecuteTopup(ExecuteData request)
        //{
        //    try
        //    {
        //        var response = await _reloadlyPost_BL.ReloadlyTopUp(request);

        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Debug($"  ReloadyExecuteTopup  Failed  Source:General   Parameters:{JsonConvert.SerializeObject(request)}   Message:{ex.ToString()}");
        //        var result = new { errorCode = 1, Message = "API Error" };
        //        return Ok(result);
        //    }

        //}

        //#endregion

    }
}