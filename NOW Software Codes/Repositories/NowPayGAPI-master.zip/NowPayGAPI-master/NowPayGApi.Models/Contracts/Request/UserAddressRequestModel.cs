﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class UserAddressRequestModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        [Required]
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        [Required]
        public string City { get; set; }
        public string County { get; set; }
        public string PostCode { get; set; }
        [Required]
        public int CountryId { get; set; }
        public AddressTypes AddressType { get; set; }
    }
}
