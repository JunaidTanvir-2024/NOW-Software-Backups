﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Request
{
    public class SaveAutoTransferSettingsRequestModel
    {
        public string nowtelTransactionReference { get; set; }
        public string operatorid { get; set; }
        public string product { get; set; }
        public string messageToRecipient { get; set; }
        public string fromMSISDN { get; set; }

        public PaymentType PaymentType { get; set; }
        public RegularityType RegularityType { get; set; }

        public DateTime RequestDateTime { get; set; }
        public DateTime LastTransactionExecutionDateTime { get; set; }
    }
}
