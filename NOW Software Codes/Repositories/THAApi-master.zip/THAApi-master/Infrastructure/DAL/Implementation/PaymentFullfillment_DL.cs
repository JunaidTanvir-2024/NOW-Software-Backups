﻿using Dapper;
using Infrastructure.DAL.Interfaces;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.Voucherify;
using Models.Contracts.Response;
using Models.Database;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Implementation
{
    public class PaymentFullfillment_DL : IPaymentFullfillment_DL
    {
        private readonly ILogger _logger;
        private readonly ConnectionStrings _dbConnections;
        public PaymentFullfillment_DL(
            ILogger logger,
            IOptions<ConnectionStrings> dbConnections
            )
        {
            _dbConnections = dbConnections.Value;
            _logger = logger;
        }

        /// <summary>
        /// Tha Pay360 Card Customer Fullfilment
        /// </summary>
        /// <param name="msisdn"></param>
        /// <param name="amount"></param>
        /// <param name="ccsTransId"></param>
        /// <param name="ccAuthCode"></param>
        /// <param name="bundleRef"></param>
        /// <returns></returns>
        public async Task<FullfilmentResponse> ThaPay360cardCustomerFullfilmentAsync(string msisdn, decimal amount, string ccsTransId, string ccAuthCode, string bundleRef)
        {
            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                AccountBalance result = new AccountBalance();
                int errorCode = 0;

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@msisdn", msisdn);
                parameters.Add("@amount", amount);
                parameters.Add("@reference", ccsTransId);
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@ccAuthCode", ccAuthCode);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<AccountBalance>("tha_account_update_topup_add_bundle_pay_360", parameters, commandType: CommandType.StoredProcedure);

                    errorCode = parameters.Get<int>("@error_code");
                }

                //if (result != null && result.audit_id > 0) // Fullfilment Successfull

                if (errorCode == 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.audit_id = result.audit_id;
                    response.Audit = new FullfilmentAudit() { audit_id = result.audit_id, new_balance = Convert.ToDecimal(result.new_balance, CultureInfo.InvariantCulture) };
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = parameters.Get<string>("@error_msg");
                    response.audit_id = 0;
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: DL_Pay360, Method: ThaCustomerFullfilment, Parameters=> msisdn: {msisdn}, bundleRef: {bundleRef}, amount: {amount}, ccsTransId: {ccsTransId}, ccAuthCode: {ccAuthCode}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                response.ErrorCode = 111;
                response.ErrorMessage = ex.Message;
            }
            return response;
        }

        /// <summary>
        /// Tha Pay360 Paypal Straight Customer Fullfilment
        /// </summary>
        /// <param name="transactionId"></param>
        /// <param name="bundleRef"></param>
        /// <param name="amount"></param>
        /// <param name="productRef"></param>
        /// <returns></returns>
        public async Task<FullfilmentResponse> ThaPay360paypalStraightCustomerFullfilmentAsync(string transactionId, string bundleRef, decimal amount, string productRef)
        {
            FullfilmentResponse response = new FullfilmentResponse();
            try
            {
                FullfilmentAudit result = null;
                int errorCode = 0;

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@bundleref", bundleRef);
                parameters.Add("@productref", productRef);
                parameters.Add("@amount", amount);
                parameters.Add("@transactionid", transactionId);
                parameters.Add("@ccAuthCode", transactionId);
                parameters.Add("@bundlename", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);
                parameters.Add("@error_code", null, DbType.Int32, ParameterDirection.Output);
                parameters.Add("@error_msg", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    result = await dbConnection.QueryFirstOrDefaultAsync<FullfilmentAudit>("tha_paypal_account_update_balance_add_bundle_v1", parameters, commandType: CommandType.StoredProcedure);
                    errorCode = parameters.Get<int>("@error_code");
                }

                if (errorCode == 0) // Fullfilment Successfull
                {
                    response.ErrorCode = 0;
                    response.ErrorMessage = "Success";
                    response.Audit = result;
                    response.BundleName = parameters.Get<string>("@bundlename");
                }
                else
                {
                    response.ErrorCode = 2;
                    response.ErrorMessage = "Topup failed";
                    response.Audit = null;
                }

            }
            catch (Exception ex)
            {
                response.ErrorCode = 111;
                response.ErrorMessage = "Fullfilment failed";
                _logger.Error($"Class: DL_Paypal, Method: ThaStraightCustomerFullfilment, Parameters => transactionId: {transactionId}, bundleRef: {bundleRef}, amount: {amount}, productRef: {productRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
            }
            return response;
        }

        /// <summary>
        /// Get Basket Item
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TransactionbaketitemsResponseModel>> GetBasketItemAsync(string id)
        {
            try
            {
                var parameter = new DynamicParameters();
                parameter.Add("@tID", id);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.QueryAsync<TransactionbaketitemsResponseModel>("tha_web_Gettransaction_basketitems", parameter, commandType: CommandType.StoredProcedure);
                }
            }

            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: GetBasketItemAsync, Class: PaymentFullfillment_DL, Parameters: Id {id}");
            }
            return null;
        }

        /// <summary>
        /// Update Payment Transactions Items
        /// </summary>
        /// <param name="isfullfilled"></param>
        /// <param name="id"></param>
        /// <param name="msg"></param>
        /// <param name="isemailsent"></param>
        /// <param name="bundleName"></param>
        /// <returns></returns>
        public async Task<int> UpdatePaymentTransactionsItemsAsync(bool isfullfilled, int id, string msg, bool isemailsent, string bundleName)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@isfullfillment", isfullfilled);
                parameters.Add("@idtoupdate", id);
                parameters.Add("@msg", msg);
                parameters.Add("@isemailsent", isemailsent);
                parameters.Add("@bundleName", bundleName);

                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
                {
                    return await dbConnection.ExecuteScalarAsync<int>("tha_update_payment_transactions_items_v2", parameters, commandType: CommandType.StoredProcedure);
                }
            }

            catch (Exception ex)
            {
                _logger.Error(ex, $"StackTrace: {ex.StackTrace}, Method: UpdatePaymentTransactionsItemsAsync, Class: PaymentFullfillment_DL, Parameters: Isfullfilled {isfullfilled}, Id {id}, Msg {msg}, IsEmailSent {isemailsent}, BundleName {bundleName}");
            }
            return 0;
        }

        /// <summary>
        /// Update Payment Transaction
        /// </summary>
        /// <param name="id"></param>
        /// <param name="isPaymentSuccess"></param>
        /// <param name="transactionId"></param>
        /// <param name="paymentErrorMsg"></param>
        /// <returns></returns>
        public async Task<int> UpdatePaymentTransactionAsync(int id, bool isPaymentSuccess, string transactionId = null, string paymentErrorMsg = null,bool isTestPayment=false)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@id", id);
            parameters.Add("@isPaymentSuccess", isPaymentSuccess);
            parameters.Add("@paymentErrorMsg", paymentErrorMsg);
            parameters.Add("@transactionId", transactionId);
            parameters.Add("@isTestPayment", isTestPayment);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                return await dbConnection.ExecuteAsync("tha_app_update_payment_transaction_v2", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        /// <summary>
        /// Insert Transaction Payment
        /// </summary>
        /// <param name="basket"></param>
        /// <param name="transactionCurrency"></param>
        /// <param name="customerEmail"></param>
        /// <param name="productCode"></param>
        /// <param name="transactionId"></param>
        /// <param name="productRef"></param>
        /// <param name="type"></param>
        /// <param name="promotionid"></param>
        /// <param name="isTrialBundle"></param>
        /// <param name="discountCode"></param>
        /// <param name="discountCodeType"></param>
        /// <returns></returns>
        public async Task<int> InsertTransactionPaymentAsync(List<basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, TransactionsPaymentType type, int promotionid, bool isTrialBundle, string discountCode, DiscountCodeType? discountCodeType)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PaymentTransactionId", typeof(int));
            dt.Columns.Add("ProductItemCode");
            dt.Columns.Add("Bundleref");
            dt.Columns.Add("Prodref");
            dt.Columns.Add("Amount", typeof(decimal));
            dt.Columns.Add("Discount", typeof(decimal));
            dt.Columns.Add("TotalAmount", typeof(decimal));
            dt.Columns.Add("DiscountCode");
            dt.Columns.Add("DiscountCodeType", typeof(Int32));
            dt.Columns.Add("Isfullfillment");
            dt.Columns.Add("CreatedatDateTime", typeof(DateTime));
            dt.Columns.Add("LastUpdateDateTime", typeof(DateTime));
            dt.Columns.Add("Email");
            dt.Columns.Add("FullfillmentDateTime", typeof(DateTime));
            dt.Columns.Add("Transactioncurrency");
            basket.ForEach(x => dt.Rows.Add(0, x.productItemCode, x.bundleRef == "" ? null : x.bundleRef, productRef, isTrialBundle ? 0 : (float)(x.chargeAmount + x.discountAmount), x.discountAmount, x.chargeAmount, discountCode, discountCodeType, 0, DateTime.UtcNow, DateTime.UtcNow, customerEmail, null, transactionCurrency));

            var param = new DynamicParameters();
            param.Add("@table", dt.AsTableValuedParameter("dbo.tha_Transactionitems_tabletype_v3"));
            param.Add("@TransactionId", transactionId);
            param.Add("@prodcode", "THA");
            param.Add("@fullfillmenttype", type);
            param.Add("@promotionid", promotionid);
            param.Add("@id", dbType: DbType.Int32, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                int result = await dbConnection.ExecuteAsync("tha_app_InsertTransaction_and_transactionitems_v2", param, commandType: CommandType.StoredProcedure);
                return param.Get<int>("@id");
            }
        }

        /// <summary>
        ///Insert Paypal Transaction Payment
        /// </summary>
        /// <param name="basket"></param>
        /// <param name="transactionCurrency"></param>
        /// <param name="customerEmail"></param>
        /// <param name="productCode"></param>
        /// <param name="transactionId"></param>
        /// <param name="productRef"></param>
        /// <param name="type"></param>
        /// <param name="promotionid"></param>
        /// <param name="discountCode"></param>
        /// <param name="discountCodeType"></param>
        /// <returns></returns>
        public async Task<int> InsertPaypalTransactionPaymentAsync(List<PayPalByPay360Basket> basket, string transactionCurrency, string customerEmail, string productCode, string transactionId, string productRef, TransactionsPaymentType type, int promotionid, string discountCode, DiscountCodeType? discountCodeType)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PaymentTransactionId", typeof(int));
            dt.Columns.Add("ProductItemCode");
            dt.Columns.Add("Bundleref");
            dt.Columns.Add("Prodref");
            dt.Columns.Add("Amount");
            dt.Columns.Add("Discount");
            dt.Columns.Add("TotalAmount");
            dt.Columns.Add("DiscountCode");
            dt.Columns.Add("DiscountCodeType", typeof(int));
            dt.Columns.Add("Isfullfillment");
            dt.Columns.Add("CreatedatDateTime", typeof(DateTime));
            dt.Columns.Add("LastUpdateDateTime", typeof(DateTime));
            dt.Columns.Add("Email");
            dt.Columns.Add("FullfillmentDateTime", typeof(DateTime));
            dt.Columns.Add("Transactioncurrency");
            basket.ForEach(x => dt.Rows.Add(0, x.productItemCode, x.bundleRef == "" ? null : x.bundleRef, productRef, (float)(x.chargeAmount + x.discountAmount), x.discountAmount, x.chargeAmount, discountCode, discountCodeType, 0, DateTime.UtcNow, DateTime.UtcNow, customerEmail, null, transactionCurrency));

            var param = new DynamicParameters();
            param.Add("@table", dt.AsTableValuedParameter("dbo.tha_Transactionitems_tabletype_v3"));
            param.Add("@TransactionId", transactionId);
            param.Add("@prodcode", "THA");
            param.Add("@fullfillmenttype", type);
            param.Add("@promotionid", promotionid);
            param.Add("@id", dbType: DbType.Int32, direction: ParameterDirection.Output);

            using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDb))
            {
                int result = await dbConnection.ExecuteAsync("tha_app_InsertTransaction_and_transactionitems_v2", param, commandType: CommandType.StoredProcedure);
                return param.Get<int>("@id");
            }
        }

        /// <summary>
        /// Get Customer By Merchant Reference
        /// </summary>
        /// <param name="merchantRef"></param>
        /// <returns></returns>
        public async Task<PaymentCustomer> GetCustomerByMerchantRef(string merchantRef)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@MerchantRef", merchantRef);

                using (var dbConnection = new SqlConnection(_dbConnections.CentralisedPaymentConnection))
                {
                    var result = await dbConnection.QueryFirstOrDefaultAsync<PaymentCustomer>("Pay360_Daemon_GetCustomerByMerchantRef", parameters, commandType: CommandType.StoredProcedure);
                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: IDL_Pay360AutoRenewalTransaction, Method: GetCustomerByMerchantRef, Parameters=> merchantRef: {merchantRef}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                throw;
            }
        }

        /// <summary>
        /// Voucherify Fulfillment
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="redemptionId"></param>
        /// <param name="creditReason"></param>
        /// <param name="paymentMethod"></param>
        /// <param name="balanceAmount"></param>
        /// <returns></returns>
        public async Task<bool> VoucherifyFulfillment(string accountId, string redemptionId, string creditReason, string paymentMethod, decimal balanceAmount = 300)
        {
            try
            {
                using (var dbConnection = new SqlConnection(_dbConnections.TalkHomeAppDigiTalkDb))
                {
                    await dbConnection.ExecuteAsync("AccountUpdateBalance", new
                    {
                        account = accountId,
                        channel = 1,
                        amount = balanceAmount, // 300 means 3USD
                        bonus = 0m,
                        creditReason = creditReason,
                        paymentMethod = paymentMethod,
                        rechargeType = 45, // Don't know what does mean by recharge type
                        reference = redemptionId,
                        ccsTransId = 0,
                        ccAuthCode = 0,
                    }, commandType: CommandType.StoredProcedure);

                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: DL_Paypal, Method: VoucherifyFulfillment, Parameters => redemptionId: {redemptionId}, accountId: {accountId}, amount: {balanceAmount}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
