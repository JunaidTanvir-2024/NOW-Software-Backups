using RW;

using Voucherify.Api.Features.Campaigns.Requests;
using Voucherify.Api.Features.Campaigns.Responses;

using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Domain.Definitions;
using Voucherify.Core.Services.VoucherifyApi;

namespace Voucherify.Api.Features.Campaigns;

public interface ICampaignsHandler
{
    Task<IResultWrapper<bool>> DeleteCampaign(DeleteCampaignRequest request);
    Task<IResultWrapper<CampaignResponse>> GetSpecificCampaign(GetCampaignRequest request);
    Task<IResultWrapper<List<CampaignResponse>>> GetCampaignsList(GetCampaignsRequest request);
}

internal class CampaignsHandler : ICampaignsHandler
{
    private const string Campaign = "Campaign";
    private readonly IVoucherifyImplementation _voucherifyImplementation;

    public CampaignsHandler(IVoucherifyImplementation voucherifyImplementation)
    {
        _voucherifyImplementation = voucherifyImplementation;
    }

    public async Task<IResultWrapper<List<CampaignResponse>>> GetCampaignsList(GetCampaignsRequest request)
    {
        var campaigns = await _voucherifyImplementation.GetCampaigns(request.PageNumber, request.PageSize);
        if (campaigns != null)
        {
            var result = campaigns?.Select(campaign => new CampaignResponse()
            {
                Name = campaign.Name,
                Description = campaign.Description,
                Id = campaign.Id,
                PromotionTiers = campaign.Promotion?.Tiers?.ConvertAll(promotion => new Promotions.Responses.PromotionTierResponse()
                {
                    PromotionId = promotion.Id,
                    Name = promotion.Name,
                    Banner = promotion.Banner,
                    Metadata = promotion.Metadata,
                    Category = promotion.Category,
                    CategoryId = promotion.CategoryId,
                    CampaignId = promotion.Campaign?.Id,
                    CampaignStartDate = promotion.Campaign?.StartDate,
                    IsCampaignActive = promotion.Campaign?.Active,
                    CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                    AmountOff = promotion.Action?.Discount?.AmountOff,
                    PercentOff = promotion.Action?.Discount?.PercentOff,
                    UnitOff = promotion.Action?.Discount?.UnitOff,
                    UnitType = promotion.Action?.Discount?.UnitType,
                    AmountLimit = promotion.Action?.Discount?.AmountLimit,
                    DiscountType = Convert.ToString(promotion.Action?.Discount?.Type),
                    DiscountEffect = Convert.ToString(promotion.Action?.Discount?.Effect)
                }),
                Active = campaign.Active,
                ExpirationDate = campaign.ExpirationDate,
                Metadata = campaign.Metadata,
                StartDate = campaign.StartDate,
                CampaignType = Convert.ToString(campaign.CampaignType)
            }).ToList();

            return ResultWrapper.Success(result).IncludePagination(request.PageNumber, request.PageSize, result?.Count);
        }

        return ResultWrapper.Failure<List<CampaignResponse>>(AppConstants.StatusMessages.CampaignNotFound, AppConstants.StatusCodes.CampaignNotFound);
    }
    public async Task<IResultWrapper<CampaignResponse>> GetSpecificCampaign(GetCampaignRequest request)
    {
        var campaign = await _voucherifyImplementation.GetCampaign(request.CampaignNameOrId);

        return campaign != null ?
        ResultWrapper.Success(new CampaignResponse()
        {
            Name = campaign.Name,
            Description = campaign.Description,
            Id = campaign.Id,
            PromotionTiers = campaign.Promotion?.Tiers?.ConvertAll(promotion => new Promotions.Responses.PromotionTierResponse()
            {
                PromotionId = promotion.Id,
                Name = promotion.Name,
                Banner = promotion.Banner,
                Metadata = promotion.Metadata,
                Category = promotion.Category,
                CategoryId = promotion.CategoryId,
                CampaignId = promotion.Campaign?.Id,
                CampaignStartDate = promotion.Campaign?.StartDate,
                IsCampaignActive = promotion.Campaign?.Active,
                CampaignExpirationDate = promotion.Campaign?.ExpirationDate,
                AmountOff = promotion.Action?.Discount?.AmountOff,
                PercentOff = promotion.Action?.Discount?.PercentOff,
                UnitOff = promotion.Action?.Discount?.UnitOff,
                UnitType = promotion.Action?.Discount?.UnitType,
                AmountLimit = promotion.Action?.Discount?.AmountLimit,
                DiscountType = Convert.ToString(promotion.Action?.Discount?.Type),
                DiscountEffect = Convert.ToString(promotion.Action?.Discount?.Effect)
            }),
            Active = campaign.Active,
            ExpirationDate = campaign.ExpirationDate,
            Metadata = campaign.Metadata,
            StartDate = campaign.StartDate,
            CampaignType = Convert.ToString(campaign.CampaignType)
        }) :

            ResultWrapper.Failure<CampaignResponse>(AppConstants.StatusMessages.CampaignNotFound, AppConstants.StatusCodes.CampaignNotFound);
    }
    public async Task<IResultWrapper<bool>> DeleteCampaign(DeleteCampaignRequest request)
    {
        var result = await _voucherifyImplementation.DeleteCampaign(request.CampaignNameOrId);
        return result ? ResultWrapper.Success(result) :
            ResultWrapper.Failure<bool>(AppConstants.StatusMessages.CampaignNotDeleted, AppConstants.StatusCodes.CampaignNotDeleted);
    }

}
