using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class ValidatePromotionTierRequest
    {
        public string PromotionTierId { get; set; } = null!;
        public string CustomerSourceId { get; set; } = null!;
        public Metadata CustomerMetadata { get; set; }
    }
}
