﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;

namespace Application.Features.Identity.ForgotPassword.ForgotPasswordResend;
public class ForgotPasswordResendRequestHandler : IRequestHandler<ForgotPasswordResendRequest, Result<object>>
{
    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<ForgotPasswordResendRequestHandler> _localizer;
    private readonly IMailService _mailService;
    private readonly IUnitOfWork _unitOfWork;

    public ForgotPasswordResendRequestHandler(
         IOtpService otpService,
         IStringLocalizer<ForgotPasswordResendRequestHandler> localizer,
         IMailService mailService,
         IUnitOfWork unitOfWork
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _mailService = mailService;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<object>> Handle(ForgotPasswordResendRequest request, CancellationToken cancellationToken)
    {
        //Validate user for any type of deactivation

        //get user by email
        var userReponse = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailAddress);
        if (userReponse == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.AccountNotRegistered], CustomStatusCode.AccountNotRegistered);
        }

        var (Otp, otpModel) = await _otpService.CreateOtp(request.EmailAddress, OtpType.ForgotPassword, true);
        if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            await _mailService.SendForgotPasswordEmailAsync(request.EmailAddress, Otp);
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
}

