﻿namespace Infrastructure.Caching;

internal static class DependenciesContainer
{
    internal static IServiceCollection AddCachingServices(this IServiceCollection services, IConfiguration config)
    {
        services.AddMemoryCache();
        services.AddTransient<ICacheService, LocalCacheService>();
        services.Configure<CacheSettings>(config.GetSection(nameof(CacheSettings)));
        return services;
    }
}