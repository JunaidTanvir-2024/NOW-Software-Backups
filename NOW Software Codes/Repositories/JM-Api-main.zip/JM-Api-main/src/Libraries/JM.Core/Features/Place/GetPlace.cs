using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.Place;

public abstract class GetPlace
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long Id { get; set; }
		public decimal Latitude { get; set; }
		public decimal Longitude { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long Id { get; set; }
		public required string Name { get; set; }
		public string? Description { get; set; }
		public decimal Latitude { get; set; }
		public decimal Longitude { get; set; }
		public string? Type { get; set; }
		public string? ImageUrl { get; set; }
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var expenseCategory = await _unitOfWork.PlaceRepository.GetPlace(x => x.IsActive && x.Id.Equals(query.Id) && x.Longitude.Equals(query.Longitude) && x.Latitude.Equals(query.Latitude));

			if (expenseCategory is not null)
			{
				return ResultWrapper.Success(new Response()
				{
					Id = expenseCategory.Id,
					Name = expenseCategory.Name,
					Description = expenseCategory.Description,
					ImageUrl = expenseCategory.ImageUrl,
					Latitude = expenseCategory.Latitude,
					Longitude = expenseCategory.Longitude
				});
			}
			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
