﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.AndroidInAppPayment
{
	public class AndroidPaymentVerificationRequest
	{
		public string orderId { get; set; }
		public string packageName { get; set; }
		public string productId { get; set; }
		public string purchaseToken { get; set; }
	}

	public class PaymentConfigurations
	{
		public bool ShowVoucherPayment { get; set; }

		public bool ShowCardPayment { get; set; }

		public bool ShowPaypalPayment { get; set; }

		public bool ShowAmazonPayment { get; set; }

		public bool ShowIvrPayment { get; set; }

		public bool InAppPayment { get; set; }

	}
}
