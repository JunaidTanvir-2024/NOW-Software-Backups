using Application.Common.Models.ResponseWrappers;

namespace Application.Features.Identity.Signup.Signup;

public sealed class SignupRequest : IRequest<Result<object>>
{
    public UserInfo UserInfo { get; set; } = new UserInfo();

    [JsonIgnore]
    public string? IpAddress { get; set; }
}