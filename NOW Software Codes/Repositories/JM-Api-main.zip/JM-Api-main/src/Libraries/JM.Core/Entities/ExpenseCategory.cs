using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class ExpenseCategory : IBaseEntity<long>, IAuditEntity
{
	public long Id { get; set; }
	public string Name { get; set; } = null!;
	public bool IsActive { get; set; } = true;
	public bool IsDeleted { get; set; } = false;
	public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
	public DateTime? UpdatedAt { get; set; }
	public DateTime? DeletedAt { get; set; }
	public ICollection<Expense> Expenses { get; set; } = [];
}
