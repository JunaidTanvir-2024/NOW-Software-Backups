﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Newtonsoft.Json;

namespace TH.Models.Contracts.Request
{
    public class UserReqPrimarySimState
    {
        [Required]
        [JsonProperty("msisdn")]
        public string msisdn { get; set; }

        [Required]
        [JsonProperty("state")]
        public int state { get; set; }

        [Required]
        [JsonProperty("userId")]
        public string userId { get; set; }

    }
}
