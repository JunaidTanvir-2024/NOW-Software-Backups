namespace FH.Core.DTOs.Database;

public sealed record OperatorBySubCategoryDto
{
    public sealed record Request
    {

        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string? CountryIsoCode { get; set; }
        public string? CurrencyCode { get; set; }
        public string? ProductCategoryAliasName { get; set; }
        public string? ProductSubCategoryAliasName { get; set; }
        public int Limit { get; set; }

        
      
    }


    public sealed record Response
    {
        public string? OperatorName { get; set; }
        public string? OperatorAliasName { get; set; }
        public string? OperatorShortCode { get; set; }
        public string? OperatorDescription { get; set; }
        public string? Logo { get; set; }
        public string? CountryIsoCode{ get; set; }
        public string? CurrencyCode { get; set; }
        public string? CategoryName { get; set; }
        public string? SubCategoryName { get; set; }
    }
}

