﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Utilities
{
    public interface IApiCall
    {
        Task<HttpResponseMessage> Get(string Uri, TokenType authTokenType, string authToken, params string[] parameters);
        Task<HttpResponseMessage> Get(string Uri, TokenType authTokenType, string authToken);
        Task<HttpResponseMessage> Post(string Uri, TokenType authTokenType, string authToken, string requestJson);
        Task<HttpResponseMessage> Post(string Uri, string requestJson);
        Task<HttpResponseMessage> PostUrlEncoded(string Uri, TokenType authTokenType, string authToken, List<KeyValuePair<string, string>> postDataModel);
        Task<HttpResponseMessage> Delete(string Uri, TokenType authTokenType, string authToken, string requestJson);
    }
}
