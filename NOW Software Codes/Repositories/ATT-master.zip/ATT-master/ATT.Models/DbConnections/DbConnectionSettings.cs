﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ATT.Models.DbConnections
{
    public class DbConnectionSettings : IDbConnectionSettings
    {

        public IDbConnection Connection { get; }

        public DbConnectionSettings(IDbConnection connection)
        {
            Connection = connection;
        }

    }
}
