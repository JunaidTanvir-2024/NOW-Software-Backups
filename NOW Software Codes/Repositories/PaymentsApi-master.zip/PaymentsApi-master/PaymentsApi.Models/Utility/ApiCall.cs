﻿using Newtonsoft.Json;
using PaymentsApi.Models.Configurations;
using PaymentsApi.Models.Utility;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PaymentsApi.Utility
{
	public class ApiCall : IApiCall
	{
		private HttpClient client;
		public ApiCall(HttpClient httpClient)
		{
			client = httpClient;
		}
		public async Task<HttpResponseMessage> Get(string Uri, string authToken, params string[] parameters)
		{
			HttpResponseMessage response;

			try
			{
				string paramString = parameters.Count() > 0 ? "?" : String.Empty;

				foreach (var param in parameters)
				{
					paramString += param + "&";
				}
				paramString = paramString.TrimEnd('&');

				ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

				client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

				response = await client.GetAsync(Uri + paramString);

				return response;
			}
			catch (Exception)
			{
				throw;
			}
		}

		public async Task<HttpResponseMessage> Post(string Uri, object model, string AuthToken)
		{
			try
			{
				ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

				//client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", UtilityFunctions.CreateBasicHeader(pay360Config.ApiUserName, pay360Config.ApiPassword));
				client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthToken);
				string json = JsonConvert.SerializeObject(model);
				var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
				return await client.PostAsync(Uri, stringContent);
			}
			catch (Exception)
			{
				throw;
			}
		}

	}
}
