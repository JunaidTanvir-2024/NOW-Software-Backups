namespace Voucherify.Api.Features.Customers.Responses;

public class CustomerLoyaltyCardResponse
{
    public string? CustomerId { get; set; }
    public string? LoyaltyCard { get; set; }
}
