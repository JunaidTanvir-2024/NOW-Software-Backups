﻿namespace Application.Features.Account.Product.AddConfirm;
public class AddProductConfirmRequest : IRequest<Result<object>>
{
    public string Alias { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
    public int Otp { get; set; }
}
