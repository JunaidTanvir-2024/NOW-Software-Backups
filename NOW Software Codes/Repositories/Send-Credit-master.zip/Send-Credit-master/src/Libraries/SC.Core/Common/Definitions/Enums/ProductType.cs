﻿namespace SC.Core.Common.Definitions.Enums
{
    public enum ProductType
    {
        Ranged=1,
        Fixed
    }
}
