﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoServciesList
    {
        public List<Service> services { get; set; }
    }

    public class Service
    {
        public int service_id { get; set; }
        public string service { get; set; }
    }

  
}
