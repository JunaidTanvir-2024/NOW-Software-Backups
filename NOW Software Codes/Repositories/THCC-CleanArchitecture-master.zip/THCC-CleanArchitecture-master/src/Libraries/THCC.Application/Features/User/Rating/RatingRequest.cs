﻿namespace THCC.Application.Features.User.Rating
{
    public class RatingRequest : IRequest<object>
    {
        public int Rating { get; set; }
    }
    public class RatingRequestValidator : AbstractValidator<RatingRequest>
    {
        public RatingRequestValidator()
        {
            RuleFor(x => x.Rating)
                .NotEmpty()
                .NotNull()
                .InclusiveBetween(1, 5);
        }
    }
}
