﻿using THCC.Application.Interfaces.Services;

namespace THCC.Application.Features.User.Guest.Guest;

public class GuestRequest : IRequest<object>
{
    public string Email { get; set; } = string.Empty;
}

public class GuestRequestValidator : AbstractValidator<GuestRequest>
{
    private readonly ICommonService _commonService;

    public GuestRequestValidator(ICommonService commonService)
    {
        _commonService = commonService;

        RuleFor(p => p.Email)
         .NotNull()
         .NotEmpty()
          .MaximumLength(100).WithMessage("Your email length must not exceed 100.")
         .Must(p => _commonService.IsValidEmailAddress(p)).WithMessage("Invalid Email Address");
    }
}