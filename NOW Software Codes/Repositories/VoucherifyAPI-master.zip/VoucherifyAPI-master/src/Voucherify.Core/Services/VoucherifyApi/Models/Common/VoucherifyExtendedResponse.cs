using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Common;
public class VoucherifyExtendedResponse
{
    [JsonPropertyName("expand")]
    public string[] Expand { get; set; }

    public VoucherifyExtendedResponse()
    {
        Expand = new string[] { "redeemable", "redemption", "category", "order" };
    }
}
