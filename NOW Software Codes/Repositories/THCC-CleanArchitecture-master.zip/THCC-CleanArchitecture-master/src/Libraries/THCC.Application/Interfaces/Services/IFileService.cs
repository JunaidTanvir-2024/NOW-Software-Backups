﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services;

public interface IFileService : ServiceType.ITransient
{
    Task<(string fileName, bool isSuccess, string errorMessage)> FileUploaderAsync(IFormFile file, string path);
    string PathNormalizer(string path);
    bool FileExtensionValidator(IFormFile file);
    bool FileSizeValidator(IFormFile file);
    ServerDirectoriesModel GetVirtualDirectoriesBySite(string siteName = "THCC");
    string? VirtualPathGenerator(string fileName, string virtualDirectoryName, string siteName = "THCC");
    Task<string> DownloadImageAsync(string imageUrl, string userId, string SiteName, string virtualDirectoryName);
}