﻿namespace Infrastructure.BLL.Interfaces.Languages
{
	public interface IMessageService
	{
		string Locale { set; get; }
		string[] Languages { get; }
	}
}
