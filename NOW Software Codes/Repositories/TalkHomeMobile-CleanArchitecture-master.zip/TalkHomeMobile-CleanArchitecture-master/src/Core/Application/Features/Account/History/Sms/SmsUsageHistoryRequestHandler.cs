using Application.Features.Account.History.Models;

namespace Application.Features.Account.History.Sms;
public class SmsUsageHistoryRequestHandler : IRequestHandler<SmsUsageHistoryRequest, Result<SmsHistoryResponse>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<SmsUsageHistoryRequestHandler> _localizer;
    private readonly ICommonService _commonService;
    private readonly IUserService _userService;
    public SmsUsageHistoryRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<SmsUsageHistoryRequestHandler> localizer,
        ICommonService commonService,
        IUserService userService)
    {
        _uow = uow;
        _localizer = localizer;
        _commonService = commonService;
        _userService = userService;
    }
    public async Task<Result<SmsHistoryResponse>> Handle(SmsUsageHistoryRequest request, CancellationToken cancellationToken)
    {
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        if (IsAppRequest)
        {
            request.StartDate = DateTime.UtcNow.Date;
            request.EndDate = DateTime.UtcNow.Date.AddDays(7);
            request.PageNo = 1;
            request.PageSize = 20;
        }
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<SmsHistoryResponse>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var smsHistory = await _uow.UserRepo.SmsHistory(request.Msisdn, request.StartDate, request.EndDate, request.PageNo, request.PageSize);
        var smsHistoryResponse = new SmsHistoryResponse()
        {
            History = smsHistory,
            TotalCount = smsHistory.Select(x => x.TotalCount).FirstOrDefault(),
            PageNo = request.PageNo,
            RecordsFiltered = smsHistory.Count()
        };
        return Result<SmsHistoryResponse>.Success(smsHistoryResponse, _localizer[CustomStatusKey.Success]);
    }
}