﻿namespace SC.Infrastructure.Common.Settings;

public class SecurityHeaderSetting
{
    public const string SectionName = nameof(SecurityHeaderSetting);
    public static SecurityHeaderSetting Bind { get; } = new SecurityHeaderSetting();
    public bool Enable { get; set; }

    public string? XFrameOptions { get; set; }

    public string? XContentTypeOptions { get; set; }

    public string? ReferrerPolicy { get; set; }

    public string? PermissionsPolicy { get; set; }

    public string? SameSite { get; set; }

    public string? XXSSProtection { get; set; }

    public List<string>? ContentPolicy { get; set; }
}
