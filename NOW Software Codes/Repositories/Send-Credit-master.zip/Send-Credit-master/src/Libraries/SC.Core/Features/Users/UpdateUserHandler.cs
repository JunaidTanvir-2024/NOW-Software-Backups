﻿namespace SC.Core.Features.Users;

internal class UpdateUserHandler : IRequestHandler<UpdateUserRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;
    public UpdateUserHandler(
      IUserRepository IUserRepository)
    {
        _userRepository = IUserRepository;
    }

    public async Task<IResultWrapper> Handle(UpdateUserRequest request, CancellationToken cancellationToken)
    {
        await _userRepository.UpdateUserAsync(request.UserID, request.UserStatus, request.UserToken, request.TokenPurpose,request.UserType);

        return ResultWrapper.Success(Unit.Value);
    }
}

