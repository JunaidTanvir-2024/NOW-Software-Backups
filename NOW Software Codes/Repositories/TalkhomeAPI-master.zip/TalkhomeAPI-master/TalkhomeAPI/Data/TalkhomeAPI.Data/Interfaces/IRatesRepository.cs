﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface IRatesRepository
    {
        Task<IEnumerable<Rates>> GetRates(string IsoCode);
    }
}
