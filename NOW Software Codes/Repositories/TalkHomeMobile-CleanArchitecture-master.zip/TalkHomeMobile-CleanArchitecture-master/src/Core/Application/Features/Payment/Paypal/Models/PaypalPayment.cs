﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Application.Features.Payment.Paypal.Models;

public class PaypalPaymentRequest
{
    public string? CustomerName { get; set; }
    public string Msisdn { get; set; } = default!;
    public string Email { get; set; } = default!;
    public CheckOutType CheckoutType { get; set; } = default!;
    public string? BundleUuid { get; set; }
    public float BundleAmount { get; set; }
    public float EarlyTerminationAmount { get; set; }
    public float BundleDiscount { get; set; }
    public float TopupAmount { get; set; }
    public float TopupDiscount { get; set; }
    public string IpAddress { get; set; } = default!;
    public bool IsAppRequest { get; set; }
    public bool IsFastTopup { get; set; } = false;
    public int OrderId { get; set; }
    public int? NoOfCycles { get; set; }
    public string FollowedByBundleRef { get; set; }
    public float? FollowedByBundleAmount { get; set; }
    public int? FollowedByBundleNoOfCycles { get; set; }
}
public class PaypalSuspendSubscriptionRequest
{
    public string SubscriptionId { get; set; } = string.Empty;
}

public class PaypalPaymentResponse
{
    public string? RedirectUrl { get; set; }
    public string? TransactionId { get; set; }
    public bool IsSuccess { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
    public string SubscriptionId { get; set; } = string.Empty;
}
public class PayPalUpdateSubscriptionResponse
{
    public bool IsSuccess { get; set; }
    public int ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
}


#region Paypal Refund Payment
public class ApiRefundPaymentRequest
{
    public string SaleId { get; set; }
    public Amounts? Amount { get; set; }
}


public class RefundPaymentResponse
{
    [JsonProperty("id")]
    public string Id { get; set; }
    [JsonProperty("create_time")]
    public DateTime Createtime { get; set; }
    [JsonProperty("update_time")]
    public DateTime Updatetime { get; set; }
    [JsonProperty("state")]
    public string State { get; set; }
    [JsonProperty("amount")]
    public Amounts Amount { get; set; }
    [JsonProperty("refund_from_transaction_fee")]
    public Refund_From_Transaction_Fee RefundFromTransactionFee { get; set; }
    [JsonProperty("total_refunded_amount")]
    public Total_Refunded_Amount TotalRefundedAmount { get; set; }
    [JsonProperty("refund_from_received_amount")]
    public Refund_From_Received_Amount RefundFromReceivedAmount { get; set; }
    [JsonProperty("sale_id")]
    public string SaleId { get; set; }
    [JsonProperty("parent_payment")]
    public string ParentPayment { get; set; }
    [JsonProperty("invoice_number")]
    public string InvoiceNumber { get; set; }
}

public class Refund_From_Transaction_Fee
{
    [JsonProperty("currency")]
    public string Currency { get; set; }
    [JsonProperty("value")]
    public string Value { get; set; }
}


public class Refund_From_Received_Amount
{
    [JsonProperty("currencyalue")]
    public string Currency { get; set; }
    [JsonProperty("value")]
    public string Value { get; set; }
}

public class Total_Refunded_Amount
{
    [JsonProperty("value")]
    public string Value { get; set; }
    [JsonProperty("currency")]
    public string Currency { get; set; }
}

public class Amounts
{
    [JsonProperty("total")]
    [Required]
    public float Total { get; set; }

    [JsonProperty("currency")]
    [Required]
    public string Currency { get; set; }
}

#endregion