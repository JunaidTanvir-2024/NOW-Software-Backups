﻿using THCC.Application.Settings;

namespace THCC.Application.Features.TrustPilot;

public class RatingRequest : IRequest<TrustPilotSettings> { }