﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Services.Models.FaceBook;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class FaceBookService : IFaceBookService
    {
        private readonly FaceBookConfig _faceBookConfig;
        private readonly ILogger Logger;
        private readonly HttpClient faceBookClient;

        public FaceBookService(
                        IOptions<FaceBookConfig> faceBookConfig,
                        ILogger logger,
                        HttpClient httpClient)
        {
            _faceBookConfig = faceBookConfig.Value;
            Logger = logger;
            faceBookClient = httpClient;
        }



        public async Task HandleTopupEvents(string advertiserID, bool IsSuccess, bool? IsCard, decimal Amount, string currency, string origination, bool IsAutoTopUp)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;
                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();
                string paymentMethod = GetPaymentMethod(IsCard, "Topup");
                string eventRevenenuCurrency = "";

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (IsSuccess)
                {
                    if (IsCard == true)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = IsAutoTopUp ? "enable_autotop_web" : "disable_autotop_web",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = "conversion_web",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "topup_any_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "total_purchase_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_any_{origination}_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{Amount}_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{Amount}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"topup_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_any_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_any_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                await this.CreateCustomEvent(advertiserID, transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleBundlePurchaseEvents(string advertiserID, string origination, string destination, int BundleType, bool IsSuccess, bool? IsCard, decimal Amount, decimal remainingBalance, string currency)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;
                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();
                string bundleType = GetBundleType(BundleType);
                string paymentMethod = GetPaymentMethod(IsCard);
                string eventRevenenuCurrency = "";


                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();




                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = "conversion_web",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_any_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"total_purchase_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_dest_any_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bunorig_any_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_dest_{bundleType}_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bunorig_{bundleType}_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_any_{origination}_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"bun_{bundleType}_{origination}_{destination}_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });

                    if (IsCard == null) // Balance Payment
                    {
                        if (remainingBalance < 1)
                        {
                            transactionevents.Add(new EventDetailsModel
                            {
                                _eventName = $"acc_bal_low_web",
                            });
                        }
                    }
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_bun_any_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"payfail_bun_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }

                await this.CreateCustomEvent(advertiserID, transactionevents);

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleBundlePurchaseEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        public async Task HandleIntTopupEvents(string advertiserID, string origination, string destination, bool IsSuccess, bool? IsCard, decimal Amount, decimal remainingBalance, string currency)
        {
            try
            {
                if (!_faceBookConfig.IsActive)
                    return;

                if (String.IsNullOrEmpty(advertiserID))
                    return;

                var transactionevents = new List<EventDetailsModel>();

                string paymentMethod = GetPaymentMethod(IsCard);
                string eventRevenenuCurrency = "";

                if (!string.IsNullOrEmpty(origination))
                    origination = origination.ToLower().Trim();

                if (!string.IsNullOrEmpty(destination))
                    destination = destination.ToLower().Trim();



                if (IsSuccess)
                {
                    if (IsCard.HasValue)
                    {
                        transactionevents.Add(new EventDetailsModel
                        {
                            _eventName = "conversion_web",
                            fb_currency = eventRevenenuCurrency,
                            _valueToSum = Amount
                        });
                    }
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_any_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = "total_purchase_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_orig_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_any_{origination}_to_{destination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    if (IsCard == null) // Balance Payment
                    {
                        if (remainingBalance < 1)
                        {
                            transactionevents.Add(new EventDetailsModel
                            {
                                _eventName = $"acc_bal_low_web",
                                fb_currency = eventRevenenuCurrency,
                                _valueToSum = Amount
                            });
                        }
                    }
                }
                else
                {
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttop_failure_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttopfail_{paymentMethod}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                    transactionevents.Add(new EventDetailsModel
                    {
                        _eventName = $"inttopfail_any_{origination}_web",
                        fb_currency = eventRevenenuCurrency,
                        _valueToSum = Amount
                    });
                }
                await this.CreateCustomEvent(advertiserID, transactionevents);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: HandleIntTopupEvents, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
       
        public async Task CreateCustomEvent(string advertiserID, List<EventDetailsModel> eventDetails)
        {
            try
            {
                var requestModel = new FaceBookCreateEventRequestModel()
                {
                    _event = "CUSTOM_APP_EVENTS",
                    advertiser_tracking_enabled = 1,
                    application_tracking_enabled = 1,
                    custom_events = eventDetails,
                    advertiser_id = advertiserID,
                    accesstoken = _faceBookConfig.APPAccessToken
                };

                string URL = _faceBookConfig.ApiEndpoint + _faceBookConfig.APPID + "/activities";

                var request = new HttpRequestMessage(HttpMethod.Post, URL)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json")
                };

                await faceBookClient.SendAsync(request);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: FaceBookService, Method: CreateCustomEvent, " +
                             $"ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }
        private string GetBundleType(int bundleType)
        {
            if (bundleType == (int)BundleType.Welcome)
            {
                return "welcome";
            }
            else if (bundleType == (int)BundleType.PAYG)
            {
                return "payg";
            }
            else if (bundleType == (int)BundleType.Monthly)
            {
                return "roll";
            }
            else
            {
                return "trial";
            }
        }
        private string GetPaymentMethod(bool? IsCard, string type = null)
        {
            if (IsCard.HasValue)
            {
                if (IsCard.Value)
                {
                    return "card";
                }
                else
                {
                    return "paypal";
                }
            }
            else
            {
                if (type == "Topup")
                {
                    return "voucher";
                }
                else
                {
                    return "balance";
                }
            }
        }
    }
}
