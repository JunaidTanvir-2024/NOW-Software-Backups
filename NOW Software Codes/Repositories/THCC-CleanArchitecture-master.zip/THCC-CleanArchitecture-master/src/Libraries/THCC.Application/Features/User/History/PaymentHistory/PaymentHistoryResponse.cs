﻿using THCC.Domain.Aggregates;

namespace THCC.Application.Features.User.History.PaymentHistory;

public class PaymentHistoryResponse
{
    public int TotalRecords { get; set; }
    public IList<PaymentDetail> PaymentDetails { get; set; }=new List<PaymentDetail>();
}
