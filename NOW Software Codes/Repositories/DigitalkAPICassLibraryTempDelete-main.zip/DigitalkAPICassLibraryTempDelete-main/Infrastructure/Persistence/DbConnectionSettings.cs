﻿using Application.Common.Extensions.DependencyResolver;

namespace Infrastructure.Persistence;

public interface IDbConnectionSettings
{
    IDbConnection SqlConnection { get; }
}

internal sealed class DbConnectionSettings : IDbConnectionSettings
{
    public IDbConnection SqlConnection { get; }
    public DbConnectionSettings(IDbConnection connection)
    {
        SqlConnection = connection;
    }
}

public interface IConnectionString : IServicesType.IScopedService
{
    DatabaseSettings DatabaseConnection { get; }
}
internal sealed class ConnectionString : IConnectionString
{
    public DatabaseSettings DatabaseConnection { get; }
    public ConnectionString(IOptions<DatabaseSettings> dbSettings)
    {
        DatabaseConnection = dbSettings.Value;
    }
}
