﻿namespace SMSOutReach.Web.Models
{
    public class ModalHeader
    {
        public string Heading { get; set; }
    }
}