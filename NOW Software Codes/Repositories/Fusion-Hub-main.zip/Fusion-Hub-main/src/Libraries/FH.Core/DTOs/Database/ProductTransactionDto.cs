namespace FH.Core.DTOs.Database;
public sealed record ProductTransactionDto
{
    public sealed record Request
    {
        public required string TransactionReference { get; set; }
        public required long ProductId { get; set; }
        public required bool Status { get; set; }
    }

    public sealed record Response { }
}
