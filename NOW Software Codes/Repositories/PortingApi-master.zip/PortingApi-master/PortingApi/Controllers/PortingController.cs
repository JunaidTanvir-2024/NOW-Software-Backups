﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Infrastructure.BLL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace PortingApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PortingController : ControllerBase
    {
        public IBL_Porting Bl;
        public ILogger Logger;

        public PortingController(IBL_Porting bl, ILogger logger)
        {
            Bl = bl;
            Logger = logger;
        }

        [HttpGet]
        [Route("PortIn")]
        [AllowAnonymous]
        public async Task<IActionResult> PortIn([FromQuery]PortInRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.PortIn(model, PortTypes.PortIn);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: PortIn, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("PortInNewOrder")]
        [AllowAnonymous]
        public async Task<IActionResult> PortInNewOrder([FromQuery]PortInNewRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                PortInRequestModel PortInRequestModel = new PortInRequestModel()
                {
                    Email = model.Email,
                    PortMsisdn = model.PortMsisdn,
                    Code = model.Code,
                    Product = model.Product,
                    Medium = model.Medium
                };
                response = await Bl.PortIn(PortInRequestModel, PortTypes.PortInNew,model.OrderReferenceId);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: PortInNewOrder, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("PortOutPAC")]
        [AllowAnonymous]
        public async Task<IActionResult> PortOutPAC([FromQuery]PortOutRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                response = await Bl.PortOut(model, CodeTypes.PAC, PortTypes.PortOut);

                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: PortOutPAC, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("PortOutSTAC")]
        [AllowAnonymous]
        public async Task<IActionResult> PortOutSTAC([FromQuery]PortOutRequestModel model)
        {
            try
            {
                GenericApiResponse<bool> response;

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                response = await Bl.PortOut(model, CodeTypes.STAC, PortTypes.PortOut);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: PortOutSTAC, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetPortingRequests")]
        [AllowAnonymous]
        public async Task<IActionResult> GetPortingRequests([FromQuery]GetPortingRequestsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetPortingRequests(model);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: GetPortingRequests, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("UpdatePortingDate")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateUserPortingDate([FromQuery]UpdateUserPortingDateRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.UpdateUserPortingDate(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: UpdateUserPortingDate, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("ValidateRequest")]
        [AllowAnonymous]
        public async Task<IActionResult> ValidatePortingRequest([FromQuery]ValidatePortingRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.ValidatePortingRequest(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: ValidatePortingRequest, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("CancelPortingRequest")]
        [AllowAnonymous]
        public async Task<IActionResult> CancelPortingRequest([FromQuery]CancelPortingRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.CancelPortingRequest(model);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: CancelPortingRequest, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetSwitchingInformation")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSwitchingInformation([FromQuery]GetSwitchingInformationRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetSwitchingInformation(model.msisdn);
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: GetSwitchingInformation, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("PortOutBySms")]
        [AllowAnonymous]
        public async Task<IActionResult> PortOutBySms([FromQuery]PortOutBySmsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.PortOutBySms(model);
                return Ok(response.text);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: PortOutBySms, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Route("GetSwitchingInformationBySms")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSwitchingInformationBySms([FromQuery]PortOutBySmsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var response = await Bl.GetSwitchingInformationBySms(model.sender.ToString());
                return Ok(response.text);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: PortingController, Method: GetSwitchingInformationBySms, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }
    }
}