using DC.Api.Controllers.Common;
using DC.Core.Features.Notifications.Requests;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DC.Api.Controllers.V1;
public class NewRegisteredMsisdnController : BaseApiController
{
    
    [Route("api/data")]
    [HttpGet, AllowAnonymous]

    public async Task<ActionResult> GetBundles()
    {
        //var request = new NewRegisteredMsisdnRequest();
        //var result = await Mediator.Send(request);
        //if (result.IsSuccess)
        //{
        //    return Ok(result);
        //}
        //return NotFound(result);
        return default;

    }
}
