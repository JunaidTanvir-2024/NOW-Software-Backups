namespace Application.Features.Bundle.DataBundle;

public sealed class DataBundleRequestValidator : AbstractValidator<DataBundleRequest>
{
    public DataBundleRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}
