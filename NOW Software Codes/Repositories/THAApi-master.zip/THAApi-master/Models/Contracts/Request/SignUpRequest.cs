﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class UserInf
    {
        public AppInf appInf { get; set; }
        public DeviceInf deviceInf { get; set; }
        public string Msisdn { get; set; }
        public string AuthTx { get; set; }
        public int signupVer { get; set; }
    }
    public class SignUpRequest
    {
        public AppInfo AppInfo { get; set; }
        public string Msisdn { get; set; }
        public bool IsAndroid { get; set; }
        public bool isTrusted { get; set; }
        public string ProductCode { get; set; }
        public string ProductItemCode { get; set; }

    }
}
