using FH.Core.DependencyResolver;
using FH.Core.DTOs.Database;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;

public interface ICountryRepository : ServiceType.IScoped
{
    Task<IEnumerable<CountryEntity>> GetCountries();
    //Task<IEnumerable<GetCountryResponseDto>> GetCountriesAsync();
    Task<(IEnumerable<CountryDto.Response> countries, DatabasePaginationDto Pagination)> GetCountries(CountryDto.Request getCountryRequest);
    Task<CountryDto.Response?> GetCountryByIsoCode(CountryByIsoCodeDto.Request getCountryByIsoCodeRequest);
}
