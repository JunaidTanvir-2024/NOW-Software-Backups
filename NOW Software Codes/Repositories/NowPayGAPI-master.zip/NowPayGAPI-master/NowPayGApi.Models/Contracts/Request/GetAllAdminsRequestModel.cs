﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetAllAdminsRequestModel
    {
        public DBAdmin adminData { get; set; }
    }
}
