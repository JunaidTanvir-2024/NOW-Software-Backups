﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using Models.Database;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
	[ApiVersion("2.0")]
	[Route("v{v:apiVersion}")]
	public class UserAccountV2Controller : Controller
    {
        private readonly ILogger Logger;
        private readonly IUserAccount_BL UserAccountBL;
        private readonly IBundle_BL Bundle_BL;
		private readonly preAuthConfig _preAuthConfig;
		private readonly IHistory_BL History_BL;
        public UserAccountV2Controller(
            ILogger logger,
            IUserAccount_BL userAccountBL,
            IHistory_BL historyDL,
            IBundle_BL bundle_BL,
            IOptions<preAuthConfig> preAuthConfig)
        {
            Logger = logger;
            UserAccountBL = userAccountBL;
            History_BL = historyDL;
            Bundle_BL = bundle_BL;
			this._preAuthConfig = preAuthConfig.Value;
		}

        [HttpGet]
        [Route("useraccount/subscriptions")]
        public async Task<IActionResult> GetAccountSubscriptionV2()
        {
            var result = await Bundle_BL.GetAccountSubscriptionsViaSQLV2(User.Msisdn(), User.Email());
            if (result != null)
            {
                return Ok(GenericApiResponse<AccountSubscriptionDetailsV2>.Success(result, "Success"));
            }

            return Ok(GenericApiResponse<AccountSubscriptionDetailsV2>.Failure("Failure", ApiStatusCodes.InternalServerError));
        }

        [HttpGet]
        [Route("useraccount/bundles")]
        public async Task<IActionResult> GetAccountBundlesV2()
        {
            try
            {
                var msisdn = User.Msisdn();
                var currency = User.Currency();
                var account = User.Account();
                var result = await Bundle_BL.GetAccountBundlesViaSQLV2(msisdn, currency, account);
                if (result != null)
                {
                    return Ok(GenericApiResponse<List<AccountBundleDetailsV2>>.Success(result.ToList(), "Success"));
                }

                return Ok(GenericApiResponse<List<AccountBundleDetailsV2>>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BundleController, Method: GetAccountBundles, ErrorMessage: " + ex.Message);
                return StatusCode(500, GenericApiResponse<List<AccountBundleDetails>>.Failure("Failure", ApiStatusCodes.InternalServerError));
            }
        }
        [HttpPost]
        [Route("useraccount/updateProfile")]
        public async Task<IActionResult> UpdateUserProfile([FromForm] UpdateUserProfileRequestV2 request)
        {
            var response = await UserAccountBL.UpdateUserProfileV2(request, User.Msisdn());
            return Ok(response);
        }
        [HttpGet]
        [Route("useraccount/getEntirePaymentHistory")]
        public async Task<IActionResult> GetEntirePaymentHistory()
        {
            return Ok(await History_BL.GetEntirePaymentHistoryV2(User.Msisdn(), User.Account()));
        }
    }
}