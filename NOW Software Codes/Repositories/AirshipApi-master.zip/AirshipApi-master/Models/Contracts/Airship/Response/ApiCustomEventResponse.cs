﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiCustomEventResponse
    {
        [JsonProperty("ok")]
        public bool Ok { get; set; }

        [JsonProperty("operationId")]
        public string OperationId { get; set; }

        [JsonProperty("error")]
        public string Error { get; set; }
    }
}
