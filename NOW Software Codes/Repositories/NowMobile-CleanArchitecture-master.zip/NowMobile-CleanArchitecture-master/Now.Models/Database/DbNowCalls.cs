﻿
namespace Now.Models.Database;

public class DbNowCalls
{
    public long Id { get; set; }
    public string? CallingNumber { get; set; }
    public string? CalledNumber { get; set; }
    public bool Roaming { get; set; }
}
