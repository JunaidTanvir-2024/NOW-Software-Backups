﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface IPromotionService
    {
        Task<GenericApiResponse<GetPromotionsResponseModel>> GetAccountPromotions(string msisdn);
        Task<PromotionPaymentDetails> CheckAnyActivePromotions(
                                                                    float Amount,
                                                                    string msisdn,
                                                                    PaymentMethodTypes paymentMethod,
                                                                    PromotionDependentTypes[] dependentTypes,
                                                                    bool IsAutoTopup);
    }
}
