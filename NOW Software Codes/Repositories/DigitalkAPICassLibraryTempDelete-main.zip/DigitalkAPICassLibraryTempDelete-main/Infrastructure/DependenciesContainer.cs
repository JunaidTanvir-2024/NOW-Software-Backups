﻿

namespace Infrastructure;
public static class DependenciesContainer
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration config)
    {
        services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        services.AddSingleton(PhoneNumberUtil.GetInstance());
        services.AddHttpClient();      
        services.AddCachingServices(config);
        services.AddPersistenceServices(config);
        services.AddLocalizationServices();
        return services;
    }
}