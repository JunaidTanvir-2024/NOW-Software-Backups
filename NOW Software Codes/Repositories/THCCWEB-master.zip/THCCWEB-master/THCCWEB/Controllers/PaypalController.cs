﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using THCCWEB.Configurations;
using THCCWEB.ExtendedContoller;
using THCCWEB.Extension;
using THCCWEB.Models.ApiContracts;
using THCCWEB.Models.ApiContracts.Request.Account;
using THCCWEB.Models.ApiContracts.Request.Paypal;
using THCCWEB.Models.ApiContracts.Response;
using THCCWEB.Models.ViewModels;
using THCCWEB.Models.ViewModels.Account;
using THCCWEB.Models.ViewModels.Paypal;
using THCCWEB.Resources;
using THCCWEB.Utilities;
using THCCWEB.Utilities.Extension;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Controllers
{
    public class PaypalController : ExtendedController
    {
        private readonly string _thccWebApiEndPoint = "";
        private readonly BasicAuthConfig _basicAuthConfig;
        private readonly string baseAouthString = string.Empty;
        private readonly ILogger _logger;
        public PaypalController(ILogger logger, IOptions<EndPointsConfig> endPoints, IOptions<BasicAuthConfig> basicAuthConfig) :
             base(logger)
        {
            _logger = logger;
            _thccWebApiEndPoint = endPoints.Value.THCCWebApiEndPoint;
            _basicAuthConfig = basicAuthConfig.Value;
            baseAouthString = Bas64Convertor.Base64Encode(_basicAuthConfig.Username + ":" + _basicAuthConfig.Password);
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendPaypalRequest(PaypalViewModel paypal)
        {
            try
            {
                string email = "";
                if (User.Identity.IsAuthenticated)
                {
                    email = GetProfile().Email;
                }
                else
                {
                    email = paypal.EmailAddress;
                }
                PaypalRequest paypalRequest = new PaypalRequest();
                paypalRequest.CustomerEmail = string.IsNullOrEmpty(paypal.RechargePIN) && paypal.ProductItemCode == "THRCC" ? paypal.EmailAddress : email;
                paypalRequest.CustomerName = email;
                paypalRequest.CustomerUniqueRef = email;
                paypalRequest.Transaction.Amount.Total = paypal.CallingCardPrice;
                paypalRequest.Transaction.Amount.Currency = "GBP";
                paypalRequest.ProductCode = "THCC";
                paypalRequest.Amount = paypal.CallingCardPrice;
                paypalRequest.PageRedirect = getProdcutType(paypal);
                paypalRequest.ipAddress = HttpContext.GetRemoteIPAddress();
                paypalRequest.Pin = paypal.RechargePIN;
                paypalRequest.Transaction.Description = "PayPal Transaction for Customer Unique Reference:" + email;
                paypalRequest.Basket.Add(new ProductBasket
                {
                    Amount = int.Parse(ValidateCallingCardPrice(paypal.CallingCardPrice.ToString())),
                    ProductItemCode = paypal.ProductItemCode,
                    ProductRef = paypal.ProductItemCode == "THRCC" ? paypal.RechargePIN : paypal.EmailAddress
                });
                var response = await Api.CallApi(_thccWebApiEndPoint + "PayPal/payPalStartPayment", User, ApiCallType.BasicAuth, paypalRequest, false, false, null, baseAouthString);
                if (response.IsSuccessStatusCode)
                {
                    GenericApiResponse<PaypalResponse> responseJson = JsonConvert.DeserializeObject<GenericApiResponse<PaypalResponse>>(JObject.Parse(response.Content.ReadAsStringAsync().Result).ToString());
                    if (responseJson.errorCode == 0)
                    {
                        return Redirect(responseJson.payload.RedirectUrl);
                        //  return Json(new { errorCode = 0, redirectLink = responseJson.payload.RedirectUrl });
                    }
                    else
                    {
                        return HandleErrorResponse<PaypalViewModel>(paypal, responseJson.errorCode, responseJson.message);
                    }
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaypalController, Method: SendPaypalRequest, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }

        }

        [HttpGet]
        public async Task<IActionResult> PurchaseSuccessReturn(SuccessReturnPayPalViewModel model)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "PayPal/purchaseSuccessReturn", User, ApiCallType.BasicAuth, model, false, false, null, baseAouthString);
                if (response.IsSuccessStatusCode)
                {
                    GenericApiResponse<BasketItemsResponseforTrackingscript> responseJson = JsonConvert.DeserializeObject<GenericApiResponse<BasketItemsResponseforTrackingscript>>(JObject.Parse(response.Content.ReadAsStringAsync().Result).ToString());
                    if (responseJson.errorCode == 0)
                    {
                        var sucssresponse = new SuccessMessageViewModel
                        {
                            Key = model.PageRedirect,
                            CardNumber = responseJson.payload.card,
                            Pin = responseJson.payload.Pin,
                            ProductItemCode = responseJson.payload.ProductItemCode,
                            TransectionAmmount = model.TransectionAmmount,
                            TransactionID = model.paymentId
                        };
                        if (responseJson.payload.ProductItemCode == "THRCC")
                        {
                            var result = await Api.CallApi(_thccWebApiEndPoint + "Account/AccountSummaryByAccountNumber/" + responseJson.payload.card, User, ApiCallType.BasicAuth, null, true, basicauthtoken: baseAouthString);
                            if (response.IsSuccessStatusCode)
                            {
                                var resultJson = JObject.Parse(result.Content.ReadAsStringAsync().Result);
                                int errorCode = resultJson.GetValue("errorCode").ToObject<int>();
                                if (errorCode == 0)
                                {
                                    var payload = resultJson.GetValue("payload").ToObject<AccountSummery>();
                                    if (payload != null)
                                    {
                                        sucssresponse.NewBalnce = payload.credit;
                                        sucssresponse.TotalPoints = payload.points;
                                    }
                                }
                            }
                        }
                        TempData.Put("SuccessModel", sucssresponse);
                        return RedirectToAction("SuccessMessage", "Home", new { key = sucssresponse.Key });
                    }
                    else
                    {
                        return HandleErrorResponse<SuccessReturnPayPalViewModel>(model, responseJson.errorCode, responseJson.message);
                    }
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaypalController, Method: PurchaseSuccessReturn, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
        [HttpGet]
        public async Task<IActionResult> PurchaseSuccessReturnPay360(PaypalPay360SuccessReturn model)
        {
            try
            {
                var response = await Api.CallApi(_thccWebApiEndPoint + "PayPal/Pay360purchaseSuccessReturn", User, ApiCallType.BasicAuth, model, false, false, null, baseAouthString);

                if (response.IsSuccessStatusCode)
                {
                    GenericApiResponse<BasketItemsResponseforTrackingscript> responseJson = JsonConvert.DeserializeObject<GenericApiResponse<BasketItemsResponseforTrackingscript>>(JObject.Parse(response.Content.ReadAsStringAsync().Result).ToString());

                    if (responseJson.errorCode == 0)
                    {
                        var sucssresponse = new SuccessMessageViewModel
                        {
                            Key = model.PageRedirect,
                            CardNumber = responseJson.payload.card,
                            Pin = responseJson.payload.Pin,
                            ProductItemCode = responseJson.payload.ProductItemCode,
                            TransectionAmmount = model.TransectionAmmount,
                            TransactionID = responseJson.payload.Transactionid,
                            IsAutoProductAttached = responseJson.payload.IsAutoProductAttached

                        };
                        if (model.ProductItemCode == "THRCC")
                        {
                            var result = await Api.CallApi(_thccWebApiEndPoint + "Account/AccountSummaryByAccountNumber/" + responseJson.payload.card, User, ApiCallType.BasicAuth, null, true, basicauthtoken: baseAouthString);
                            if (result.IsSuccessStatusCode)
                            {
                                var resultJson = JObject.Parse(result.Content.ReadAsStringAsync().Result);
                                int errorCode = resultJson.GetValue("errorCode").ToObject<int>();
                                if (errorCode == 0)
                                {
                                    var payload = resultJson.GetValue("payload").ToObject<AccountSummery>();
                                    if (payload != null)
                                    {
                                        sucssresponse.NewBalnce = payload.credit;
                                        sucssresponse.TotalPoints = payload.points;
                                    }
                                }
                            }
                        }
                        TempData.Put("SuccessModel", sucssresponse);
                        return RedirectToAction("SuccessMessage", "Home", new { key = sucssresponse.Key });
                    }
                    else
                    {
                        return HandleErrorResponse<PaypalPay360SuccessReturn>(model, responseJson.errorCode, responseJson.message);
                    }
                }
                else
                {
                    return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Class: PaypalController, Method: PurchaseSuccessReturnPay360, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return RedirectToAction("ErrorMessage", "Home", new { key = "InternalServerError" });
            }
        }
        [HttpGet]
        public async Task<IActionResult> CancelReturn(CancelReturnPayPalViewModel model)
        {

            TempData["Message"] = "Payment was cancelled";
            return RedirectToAction("ErrorMessage", "Home", new { key = "PaymentError" });

        }
        private string getProdcutType(PaypalViewModel paypal)
        {
            if (paypal.RechargePIN != null)
            {
                return ProductType.TopUp.ToString();
            }
            else if (paypal.ProductItemCode == "THRCC")
            {
                return ProductType.THRCCNC.ToString();
            }
            return ProductType.THCC.ToString();

        }
        private string ValidateCallingCardPrice(string value)
        {
            string val = "10";
            switch (value)
            {
                case "5": val = "5"; break;
                case "10": val = "10"; break;
                case "20": val = "20"; break;
                default:
                    break;
            }
            return val;
        }
    }
}
