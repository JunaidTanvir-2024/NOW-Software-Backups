﻿using Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request.CountryDestination
{
	public class CountryBundleDetails
	{
		public class CountryDestinationDetails
		{
			public CountryDestinationDetails()
			{
				Rate = new CountryDestinationRate();

				Bundles = new List<CountryDestinationBundle>();
			}

			public CountryDestinationRate Rate { get; set; }

			public List<CountryDestinationBundle> Bundles { get; set; }
		}
		public CountryBundleDetails()
		{
			Bundles = new List<CountryDestinationBundle>();

			BundleDestinationRates = new BundleDestinationRates();
		}

		public IEnumerable<CountryDestinationBundle> Bundles { get; set; }
		public BundleDestinationRates BundleDestinationRates { get; set; }

		public string FlagImageUrl { get; set; }
	}
	public class CountryBundleDetailsV2
	{
		public class CountryDestinationDetails
		{
			public CountryDestinationDetails()
			{
				Rate = new CountryDestinationRate();

				Bundles = new List<CountryDestinationBundle>();
			}

			public CountryDestinationRate Rate { get; set; }

			public List<CountryDestinationBundle> Bundles { get; set; }
		}
		public CountryBundleDetailsV2()
		{
			Bundles = new List<CountryDestinationBundle>();

			BundleDestinationRates = new BundleDestinationRates();
		}

        public PopupInfo GlobalCreditPopup { get; set; }
        public PopupInfo WelcomeBundlePopup { get; set; }
        public PopupInfo PaygBundlePopup { get; set; }
        public CountryDestinationGlobalCredit GlobalCredit { get; set; }
		public IEnumerable<CountryDestinationBundle> Bundles { get; set; }
		public IEnumerable<CountryDestinationWelcomeBundle> WelcomeBundles { get; set; }
		public BundleDestinationRates BundleDestinationRates { get; set; }

		public string FlagImageUrl { get; set; }
	}


	public class BundleDestinationRates
	{
		public string Landline { get; set; }

		public string Mobile { get; set; }

		public string SMS { get; set; }
	}
	public class CountryDestinationGlobalCredit
	{
		public string Title { get; set; }
		public string Description { get; set; }
		public string MobileRate { get; set; }
		public string LandlineRate { get; set; }
		public IEnumerable<CountryDestinationTopup> Topups { get; set; }
    }
	public class CountryDestinationTopup
	{
		public string MobileMinutes { get; set; }
		public string LandlineMinutes { get; set; }
		public string Price { get; set; }
		public int RewardPoints { get; set; }
	}
}
