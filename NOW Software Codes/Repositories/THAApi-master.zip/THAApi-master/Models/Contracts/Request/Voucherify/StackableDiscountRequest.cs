﻿using Models.Common;
using Models.Enums;
using Newtonsoft.Json;

namespace Models.Contracts.Request.Voucherify
{
    public class StackableDiscountRequest
    {
        public decimal Amount { get; set; }
        public string BundleRef { get; set; }
        public string DiscountCode { get; set; }
        [JsonIgnore]
        public DiscountCodeType DiscountCodeType { get; set; }
        public CheckOutTypes CheckoutType { get; set; }
        public PaymentMethods PaymentMethod { get; set; }
        public string DestinationCountryISOCode { get; set; }
        public string Operator { get; set; }
    }
    public class StackableDiscountRequestV3
    {
        public decimal Amount { get; set; }
        public string BundleRef { get; set; }
        public string DiscountCode { get; set; }
        [JsonIgnore]
        public DiscountCodeType DiscountCodeType { get; set; }
        public CheckOutTypes CheckoutType { get; set; }
        public PaymentMethods PaymentMethod { get; set; }
        public string TransferNowtelRef { get; set; }
        public string TransferProduct { get; set; }
    }
    public enum DiscountCodeType
    {
        None = 0,
        Voucher = 1,
        Promotion_Tier = 2,
        Referral = 3
    }
    public class VoucherifyPromotionEventTemplates
    {
        public const string Topup = nameof(CheckOutTypes.TopUp) + "_Event_{0}";
        public const string Bundle = nameof(CheckOutTypes.Bundle) + "_Event_{0}";
        public const string SendCredit = nameof(CheckOutTypes.Transfer) + "_Event_{0}";
    }
}
