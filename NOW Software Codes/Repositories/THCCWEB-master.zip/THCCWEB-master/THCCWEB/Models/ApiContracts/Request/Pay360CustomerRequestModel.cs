﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request
{
    public class Pay360CustomerRequestModel
    {
        public string customerUniqueRef { get; set; }
        public string productCode { get; set; }
    }
}
