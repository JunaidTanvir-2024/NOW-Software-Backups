﻿namespace Application.Features.Bundle.SubscribedBundle;
public class SubscribedBundleRequestValidator : AbstractValidator<SubscribedBundleRequest>
{
    public SubscribedBundleRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull()
            .Must(p => commonService.IsValidMsisdn(p));
    }
}
