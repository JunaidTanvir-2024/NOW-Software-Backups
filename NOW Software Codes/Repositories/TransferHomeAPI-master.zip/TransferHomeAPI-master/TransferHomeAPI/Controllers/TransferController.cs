﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Models.Configurations;
using TransferHome.Models.Contracts.Request;

namespace TransferHomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransferController : ControllerBase
    {

        private readonly IBL_Transfer Bl;
        private readonly ILogger Logger;
        private readonly IConfiguration Configuration;
        private readonly TwoFactorAuthenticationConfig TwoFactorConfig;

        public TransferController(IBL_Transfer bl, ILogger logger, IConfiguration configuration, IOptions<TwoFactorAuthenticationConfig> twoFactorConfig)
        {
            Bl = bl;
            Logger = logger;
            Configuration = configuration;
            TwoFactorConfig = twoFactorConfig.Value;
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpPost]
        [Route("GetProducts")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> GetProducts([FromBody]GetProductsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string UserId = null;

                if (User.Identity.IsAuthenticated)
                {
                    UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                }

                var response = await Bl.GetProducts(model, UserId);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetProducts, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("GetProductsSecure")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetProductsSecure([FromBody]GetProductsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string UserId = null;

                if (User.Identity.IsAuthenticated)
                {
                    UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                }

                var response = await Bl.GetProducts(model, UserId);

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetProductsSecure, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }


        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("TransferFromAccountBalance")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> TransferFromAccountBalance([FromBody]TransferFromAccountBalanceRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;

                if (TwoFactorConfig.TwoFactorAuthentication)
                {
                    var response = await Bl.GenerateTwoFactorAuthenticationToken(int.Parse(userId), model.NowtelTransactionReference);
                    return Ok(response);
                }
                else
                {
                    var response = await Bl.TransferFromAccountBalance(model, int.Parse(userId));
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferFromAccountBalance, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("ResumeTransferTransaction")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> ResumeTransferTransaction([FromBody]ResumeTransferTransactionRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.ResumeTransferTransaction(model, int.Parse(userId));
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: TransferFromAccountBalanceTwoFactor, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpGet]
        [Route("GetUserAutoTransferNumbers")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetUserAutoTransferNumbers()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;
                var response = await Bl.GetUserAutoTransferNumbers(int.Parse(userId));
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: GetAutoTransferNumbers, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("UpdateAutoTransferStatus")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> UpdateAutoTransferStatus([FromBody]UpdateAutoTransferStatusRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;

                var response = await Bl.UpdateAutoTransferStatus(model, Convert.ToInt32(userId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: UpdateAutoTransferStatus, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("RemoveAutoTransferNumber")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> RemoveAutoTransferNumber([FromBody]RemoveAutoTransferNumberRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;

                var response = await Bl.RemoveAutoTransferNumber(model, Convert.ToInt32(userId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: RemoveAutoTransferNumber, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }

        /// <summary>
        /// Required Bearer
        /// </summary>
        [HttpPost]
        [Route("UpdateAutoTransferSettings")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> UpdateAutoTransferSettings([FromBody]UpdateAutoTransferSettingsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;

                var response = await Bl.UpdateAutoTransferSettings(model, Convert.ToInt32(userId));

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TransferController, Method: UpdateAutoTransferSettings, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server.");
            }
        }
    }
}