﻿using PaymentsApi.Infrastructure.Services.Interfaces;
using PhoneNumbers;
using Serilog;
using System;

namespace PaymentsApi.Infrastructure.Services.Implementation
{
    /// <summary>
    /// Gets the full and validated phone number 
    /// </summary>
    public class PhoneNumberService : IPhoneNumberService
    {
        private readonly PhoneNumberUtil _phoneNumberUtil;
        private readonly ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="phoneNumberUtil">Instance of PhoneNumberUtil</param>
        public PhoneNumberService(
            PhoneNumberUtil phoneNumberUtil,
            ILogger logger)
        {
            _phoneNumberUtil = phoneNumberUtil;
            _logger = logger;
        }

        /// <summary>
        /// Gets the region from a phone number
        /// </summary>
        /// <param name="originator">Phone number, this must be in E164 format</param>
        /// <returns>Country Code</returns>
        public string GetCountryISOCode(string originator)
        {
            try
            {
                originator = originator.Trim();

                if (!originator.StartsWith("+"))
                {
                    originator = $"+{originator}";
                }

                if (originator.StartsWith("+1"))
                {
                    string countryCode = null;
                    string[] countries = { "US", "CA" };
                    String phoneNumber = originator;

                    foreach (var c in countries)
                    {
                        bool isValid = _phoneNumberUtil.IsPossibleNumber(phoneNumber, c);
                        if (isValid)
                        {
                            try
                            {
                                var number = _phoneNumberUtil.Parse(phoneNumber, c);
                                isValid = _phoneNumberUtil.IsValidNumberForRegion(number, c);
                                if (isValid)
                                {
                                    countryCode = c;
                                }
                            }
                            catch (Exception e)
                            {
                                countryCode = null;
                            }
                        }
                    }

                    if (string.IsNullOrEmpty(countryCode))
                    {
                        var number = _phoneNumberUtil.Parse(originator, "");
                        return _phoneNumberUtil.GetRegionCodeForNumber(number);
                    }

                    return countryCode;
                }
                else
                {
                    var number = _phoneNumberUtil.Parse(originator, "");
                    return _phoneNumberUtil.GetRegionCodeForNumber(number);
                }
            }
            catch (NumberParseException ex)
            {
                _logger.Error(ex, ex.Message);
                return null;
            }
        }
    }
}
