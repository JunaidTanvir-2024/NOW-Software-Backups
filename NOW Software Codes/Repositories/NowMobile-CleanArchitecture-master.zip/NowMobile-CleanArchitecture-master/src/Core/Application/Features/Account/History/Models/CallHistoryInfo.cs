namespace Application.Features.Account.History.Models;

public sealed class CallHistoryInfo
{
    public DateTime DateStarted { get; set; }
    public string? CallingPartyNumber { get; set; }
    public string? CalledPartyNumber { get; set; }
    public string? Duration { get; set; }
    public string? SubscriberCharge { get; set; }
    public bool InBound { get; set; }
    [JsonIgnore]
    public int TotalCount { get; set; }
}