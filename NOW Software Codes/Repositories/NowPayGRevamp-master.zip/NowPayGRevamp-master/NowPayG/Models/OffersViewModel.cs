﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models
{
    public class OffersViewModel : BaseViewModel
    {
        public string OfferName { get; set; }
    }
}
