﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Repositories
{
    public interface IPointsRepository : ServiceType.ITransient
    {
        Task<bool> Redeempoints(string cardnumber, decimal points, string subscriberid);
        Task<int> GetPoints(string account);
    }
}
