﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ApiContracts.Request;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class VerifyPinRequestModel
    {
        public string PhoneNumber { get; set; }

        public string PhoneNumberCountryCode { get; set; }

        public string PinNumber { get; set; }
        public string IpAddress { get; set; }
		public SignUpRequestModel SignupRequest { get; set; }
	}
}
