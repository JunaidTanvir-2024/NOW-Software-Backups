using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Rewards;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class StackableDiscount
{
    [JsonPropertyName("object")]
    public string? DiscountType { get; set; }

    [JsonPropertyName("id")]
    public string? DiscountCode { get; set; }

    [JsonPropertyName("reward")]
    public Reward? Reward { get; set; }
}
