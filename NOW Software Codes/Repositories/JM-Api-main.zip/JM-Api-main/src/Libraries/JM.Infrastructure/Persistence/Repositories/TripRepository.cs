using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.EntityFrameworkCore;

using Serilog;

using static JM.Core.Utilities.Definitions.AppEnum;


namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class TripRepository(AppDbContext context, ILogger logger) : ITripRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;

	public async Task<Trip> AddTrip(Trip trip)
	{
		try
		{
			var addedTrip = await _context.Set<Trip>().AddAsync(trip);
			await _context.Entry(addedTrip.Entity).Reference(f => f.Currency).LoadAsync();
			return addedTrip.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(TripRepository), nameof(AddTrip));
			return default!;
		}
	}
	public async Task<TripPlace> AddPlaceToTrip(TripPlace trip)
	{
		try
		{
			var addedTrip = await _context.Set<TripPlace>().AddAsync(trip);
			return addedTrip.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(TripRepository), nameof(AddPlaceToTrip));
			return default!;
		}
	}
	public void UpdateTrip(Trip trip)
	{
		try
		{
			_context.Entry(trip).CurrentValues.SetValues(trip);
			_context.Entry(trip).State = EntityState.Modified;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(TripRepository), nameof(UpdateTrip));
		}
	}
	public async Task<Trip?> GetTrip(Expression<Func<Trip, bool>> expression)
	{
		try
		{
			return await _context.Set<Trip>()
				.Where(expression)
				.Include(x => x.Media)
				.Include(x => x.Currency)
				.Include(x => x.Travelers).ThenInclude(x => x.User).ThenInclude(x => x.UserDetail)
				.Include(x => x.Expenses).ThenInclude(x => x.Category)
				.Include(x => x.TripPlaces).ThenInclude(x => x.Place)
				.FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(TripRepository), nameof(GetTrip));
			return default!;
		}
	}
	public async Task<IEnumerable<Trip>> GetTripList(
	Expression<Func<Trip, bool>> expression,
	OrderByDirection orderByDirection,
	TripType tripType,
	long userId)
	{
		try
		{
			var query = _context.Set<Trip>()
								.Where(expression);

			switch (tripType)
			{
				case TripType.Personal:
					query = query.Where(t => t.CreatorId == userId);
					break;
				case TripType.Shared:
					query = query.Where(t => t.Travelers!.Any(x => x.Id == userId));
					break;
				default:
					break;
			}

			switch (orderByDirection)
			{
				case OrderByDirection.Ascending:
					query = query.OrderBy(t => t.Id);
					break;
				case OrderByDirection.Descending:
					query = query.OrderByDescending(t => t.Id);
					break;
				default:
					break;
			}
			return await query
			.Include(x => x.Media)
			.Include(x => x.Travelers)
			.Include(x => x.Expenses)
			.Include(x => x.TripPlaces)
			.ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(TripRepository), nameof(GetTripList));
			return Enumerable.Empty<Trip>();
		}
	}
}
