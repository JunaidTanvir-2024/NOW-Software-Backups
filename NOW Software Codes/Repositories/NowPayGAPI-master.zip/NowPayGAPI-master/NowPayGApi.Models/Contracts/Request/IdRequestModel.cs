﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class IdRequestModel
    {
        public int Id { get; set; }
    }
}
