﻿using SC.Core.Models.Dtos;

namespace SC.Core.Interfaces.Repositories
{
    public interface IFaqRepository
    {
        Task<(IEnumerable<GetFaqsbyOperatorDto.Response> operatorFaqs, DatabasePaginationDto pagination)> GetFaqsbyOperator(GetFaqsbyOperatorDto.Request request);
    }
}