﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NowPayG.Configurations;
using NowPayG.Models;
using NowPayG.Models.ApiContracts.Request;
using NowPayG.Models.ViewModels;
using NowPayG.Resources;
using NowPayG.Utility;
using System;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using NowPayG.Models.ApiContracts.Response;
using Newtonsoft.Json;
using PhoneNumbers;
using Microsoft.AspNetCore.Mvc.Rendering;
using NowPayG.Services.Interfaces;
using NowPayG.Models.Porting;
using NowPayG.Models.Pay360ApiContracts;
using Serilog;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NowPayG.Controllers
{
    public class AccountController : Controller
    {
        public string NowPayGApiEndPoint { get; set; }
        private readonly ILogger Logger;
        private readonly IPortService PortService;
        private readonly IPay360Service Pay360Service;

        public AccountController(IOptions<EndPoints> endPoints, ILogger logger, IPortService portService, IPay360Service pay360Service)
        {
            NowPayGApiEndPoint = endPoints.Value.NowPaygApiEndPoint;
            Logger = logger;
            PortService = portService;
            Pay360Service = pay360Service;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("Register")]
        public async Task<IActionResult> Register(RegisterUserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/Register", User, model);
                if (objUser != null)
                {
                    if (objUser is Error)
                    {
                        if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserAlreadyExist)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.UserAlreadyExist, status = false, message = MessagesResource.ResourceManager.GetString(Messages.UserAlreadyExist.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var result = objUser.GetValue("payload").ToObject<bool>();
                        if (result)
                        {
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.SuccesfullRegistration.ToString());
                            return Json(new { errorCode = 0, status = true, message = MessagesResource.ResourceManager.GetString(Messages.SuccesfullRegistration.ToString()) });
                        }
                        else
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = "Registration Failed." });
                        }
                    }
                }
                else
                {
                    return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = "Registration Failed." });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: Register, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on Server.");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("successful-register")]
        public async Task<IActionResult> SuccessfulRegister()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);

                ViewBag.HeadMsg = "Registration Successfull";
                ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.SuccesfullRegistration.ToString());

                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: SuccessfulRegister, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }


        [HttpGet]
        [AllowAnonymous]
        [Route("successful-sim-order/{id}")]
        public async Task<IActionResult> SuccessfulSImOrder(int id)
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);

                if (id > 0)
                {
                    ViewBag.HeadMsg = "Your order has been successful!";
                    ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.ExistingUserSimOrder.ToString());
                }
                else
                {
                    ViewBag.HeadMsg = "SIM Order & Registration have been successful!";
                    ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.NewUserSimOrder.ToString());
                }

                return View("~/Views/account/successfulsimorder.cshtml", Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: successful-sim-order, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("login")]
        public async Task<IActionResult> Login(string ReturnURL)
        {
            try
            {
                ViewBag.ReturnURL = ReturnURL;

                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: Login, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/Login", User, model);
                if (objUser != null)
                {
                    if (objUser is Error)
                    {
                        if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.EmailNotVerified)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.EmailNotVerified, status = false, message = MessagesResource.ResourceManager.GetString(Messages.EmailNotVerified.ToString()) });
                        }
                        else if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.InvalidEmailPassword)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.InvalidEmailPassword, status = false, message = MessagesResource.ResourceManager.GetString(Messages.InvalidEmailOrPassword.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var userModel = objUser.GetValue("payload").ToObject<BaseViewModel>();
                        AuthenticationProperties authProperties;
                        ClaimsIdentity claimsIdentity = userModel.SetClaims(LoginTypes.Normal, out authProperties, model.RememberMe);
                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
                        return Json(new { errorCode = 0, status = true, message = MessagesResource.ResourceManager.GetString(Messages.LoginSuccessful.ToString()) });
                    }
                }
                else
                {
                    return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = "Login Failed." });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: Login, Parameters=> model: {JsonConvert.SerializeObject(model)}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("verify-email")]
        public async Task<IActionResult> VerifyEmail(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return BadRequest("Token is required");
            }
            try
            {
                VerifyEmailRequestModel model = new VerifyEmailRequestModel()
                {
                    Token = token,
                    TokenTypeId = UserTokenTypes.SignUpVerificationToken
                };
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/VerifyEmail", User, model);

                if (objUser != null)
                {
                    if (objUser is Error)
                    {
                        if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.ExpiredToken)
                        {
                            await Global.BaseModel.SetSharedDataAsync(User);
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.EmailVerificationTokenExpired.ToString());
                            ViewBag.VerificationPending = false;
                            return View("ResendVerificationEmail", Global.BaseModel);
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var IsVerified = objUser.GetValue("payload").ToObject<bool>();
                        if (IsVerified)
                        {
                            await Global.BaseModel.SetSharedDataAsync(User);
                            ViewBag.SuccessMessage = MessagesResource.ResourceManager.GetString(Messages.EmailVerificationSuccess.ToString());
                            return View("Login", Global.BaseModel);
                        }
                        else
                        {
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.EmailVerificationTokenExpired.ToString());
                            await Global.BaseModel.SetSharedDataAsync(User);
                            return View("ResendVerificationEmail", Global.BaseModel);
                        }
                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: VerifyEmail, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("password-recovery")]
        public async Task<IActionResult> PasswordRecovery(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return BadRequest("Token is required");
            }
            try
            {
                VerifyEmailRequestModel model = new VerifyEmailRequestModel()
                {
                    Token = token,
                    TokenTypeId = UserTokenTypes.ForgotPasswordVerificationToken
                };
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/VerifyEmail", User, model);

                if (objUser is Error)
                {
                    if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.ExpiredToken)
                    {
                        await Global.BaseModel.SetSharedDataAsync(User);
                        ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.ForgotPasswordVerificationTokenExpired.ToString());
                        ViewBag.VerificationPending = false;
                        return View("Login", Global.BaseModel);
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                    }
                }

                if (objUser != null)
                {
                    var IsVerified = objUser.GetValue("payload").ToObject<bool>();
                    if (IsVerified)
                    {
                        await Global.BaseModel.SetSharedDataAsync(User);
                        ViewBag.Token = token;
                        return View("UpdatePassword", Global.BaseModel);
                    }
                    else
                    {
                        ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.ForgotPasswordVerificationTokenExpired.ToString());
                        await Global.BaseModel.SetSharedDataAsync(User);
                        return View("Login", Global.BaseModel);
                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PasswordRecovery, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("UpdatePassword")]
        public async Task<IActionResult> UpdatePassword(UpdatePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/UpdateUserPassword", User, model);

                if (objUser is Error)
                {
                    if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                    {
                        return Json(new { errorCode = (int)ApiStatusCodes.ExpiredToken, status = false, message = MessagesResource.ResourceManager.GetString(Messages.ForgotPasswordVerificationTokenExpired.ToString()) });
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                    }
                }

                if (objUser != null)
                {
                    var IsUpdated = objUser.GetValue("payload").ToObject<bool>();
                    if (IsUpdated)
                    {
                        return Json(new { errorCode = 0, status = true, message = MessagesResource.ResourceManager.GetString(Messages.PasswordUpdatedSuccessfully.ToString()) });
                    }
                    else
                    {
                        return RedirectToAction("Error", "Error");
                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: UpdatePassword, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                ForgotPasswordRequestModel model = new ForgotPasswordRequestModel()
                {
                    Email = viewModel.Email
                };
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/ForgotPassword", User, model);

                if (objUser != null)
                {
                    if (objUser is Error)
                    {
                        if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.UserNotFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.UserNotFoundbyEmail.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var IsSent = objUser.GetValue("payload").ToObject<bool>();
                        if (IsSent)
                        {
                            return Json(new { errorCode = 0, status = false, message = MessagesResource.ResourceManager.GetString(Messages.PasswordResetEmail.ToString()) });
                        }
                        else
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = "Something went wrong on server" });
                        }
                    }
                }
                else
                {
                    return Json(new { errorCode = (int)ApiStatusCodes.DBError, status = false, message = "Something went wrong on server" });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: ForgotPassword, Parameters=> model: {JsonConvert.SerializeObject(viewModel)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong on server");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("resend-verification-email")]
        public async Task<IActionResult> ResendVerificationEmail()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: ResendVerificationEmail, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("resend-verification-email")]
        public async Task<IActionResult> ResendVerificationEmail(ReSendTokenViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(ModelState);
            }
            try
            {
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/ReSendToken", User, model);

                if (objUser != null)
                {
                    if (objUser is Error)
                    {
                        if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                        {
                            await Global.BaseModel.SetSharedDataAsync(User);
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.UserNotFoundbyEmail.ToString());
                            return View("ResendVerificationEmail", Global.BaseModel);
                        }
                        else if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.EmailAlreadyVerified)
                        {
                            await Global.BaseModel.SetSharedDataAsync(User);
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.EmailAlreadyVerified.ToString());
                            return View("Login", Global.BaseModel);
                        }
                        else
                        {
                            await Global.BaseModel.SetSharedDataAsync(User);
                            ViewBag.Message = (objUser as Error).ErrorMessage;
                            return View("ResendVerificationEmail", Global.BaseModel);
                        }
                    }
                    else
                    {
                        var IsSent = objUser.GetValue("payload").ToObject<bool>();
                        if (IsSent && User.Identity.IsAuthenticated)
                        {
                            return RedirectToAction("Index", "Home");
                        }
                        else if (IsSent)
                        {
                            ViewBag.Message = MessagesResource.ResourceManager.GetString(Messages.EmailNotVerified.ToString());
                            return View("Login", Global.BaseModel);
                        }
                        else
                        {
                            return RedirectToAction("Error", "Error");
                        }
                    }
                }
                else
                {
                    return RedirectToAction("Error", "Error");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: ForgotPassword, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("Account/IsUserExist")]
        [Route("IsUserExist")]
        public async Task<IActionResult> IsUserExist(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("Email is required");
            }
            try
            {
                IsUserExistRequestModel model = new IsUserExistRequestModel()
                {
                    Email = email,
                };
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/IsUserExist", User, model);

                if (objUser is Error)
                {
                    if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                    {
                        await Global.BaseModel.SetSharedDataAsync(User);
                        return Json(false);
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                    }
                }

                if (objUser != null)
                {
                    var result = objUser.GetValue("payload").ToObject<bool>();
                    if (result)
                    {
                        return Json(true);
                    }
                    else
                    {
                        return Json(false);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: IsUserExist, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [Route("checkout")]
        [Route("topup")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(CheckOutViewModel model)
        {
            try
            {
                var respons = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetCountries", User, null, true);
                if (respons != null)
                {
                    var CountrieslList = respons.GetValue("payload").ToObject<CountriesResponseModel>();
                    model.ListOfCountries = CountrieslList;
                }
                await model.SetSharedDataAsync(User);

                if (model.CheckoutType == CheckOutTypes.Bundle)
                {
                    var response = await GetPlansByID(model.SelectedPlan.Id);
                    if (response != null)
                    {
                        model.SelectedPlan = response;
                    }
                    else
                    {
                        return RedirectToAction("Error", "Error");
                    }
                }

                if (model.CheckoutType == CheckOutTypes.FastTopUp)
                {
                    var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                    model.FastTopUp.Msisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.FastTopUp.Msisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();
                }

                if (User.Identity.IsAuthenticated)
                {
                    //Check User Products
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    if (!string.IsNullOrEmpty(products))
                    {
                        model.UserProducts = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Select(item => new SelectListItem()
                        {
                            Text = item.ProductRef,
                            Value = item.ProductRef,
                            Selected = item.ProductRef.Equals(model.Msisdn) ? true : false
                        });
                    }
                    else
                    {
                        return RedirectToAction("AddProduct");
                    }

                    if (model.CheckoutType == CheckOutTypes.TopUp)
                    {
                        var topupResponse = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).FirstOrDefault();
                        if (topupResponse != null)
                        {
                            var settingResponse = await Pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest() { Msisdn = topupResponse.ProductRef, Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, ProductCode = ProductCode.NOWPAYG.ToString() });
                            if (settingResponse != null && settingResponse.errorCode == 0 && settingResponse.payload != null)
                            {
                                model.IsAutoToupEnabled = settingResponse.payload.Status;
                            }
                        }
                    }

                    //Get User Pay360 Cards
                    var response = await Pay360Service.Pay360GetCards(new Pay360CustomerRequestModel()
                    {
                        customerUniqueRef = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value,
                        productCode = ProductCode.NOWPAYG.ToString(),

                    });

                    if (response != null
                        && response.errorCode == 0
                        && response.payload != null)
                    {
                        model.UserPay360Cards = response.payload;
                    }
                }
                ModelState.Clear();
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: Checkout, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("addProduct")]
        [Authorize]
        public async Task<IActionResult> AddProduct()
        {
            try
            {
                var model = new AddProductViewModel();
                await model.SetSharedDataAsync(User);

                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: AddProduct, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [Route("accountSummary")]
        [Authorize]
        public async Task<IActionResult> AccountSummary(string Msisdn)
        {
            try
            {
                ViewBag.ProductRef = Msisdn;
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: SaveUserProduct,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        private async Task<PlanResponseModel> GetPlansByID(int id)
        {
            try
            {
                var response = await Api.CallApi(NowPayGApiEndPoint + "CommonServices/GetPlanById", User, new GetPlanByIdRequestModel() { Id = id });
                if (response != null)
                {
                    if (response is Error)
                    {
                        return null;
                    }
                    else
                    {
                        return response.GetValue("payload").ToObject<PlanResponseModel>();
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ValidateMsisdn([Bind(include: "Msisdn")] FastTopUpViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var phoneNumberUtil = PhoneNumbers.PhoneNumberUtil.GetInstance();
                    var Msisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.Msisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "");

                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/ValidateMsisdn", User, new ValidateMsisdnRequestModel() { Msisdn = Msisdn });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            if ((response as Error).ErrorCode == (int)ApiStatusCodes.InvalidMsisdn)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.InvalidMsisdn, status = false, message = MessagesResource.ResourceManager.GetString(Messages.InvalidMsisdn.ToString()) });
                            }
                            else
                            {
                                return Json(new { errorCode = (response as Error).ErrorCode, status = false, message = "Something went wrong on server." });
                            }
                        }
                        else
                        {
                            int responseStatus = 0;

                            var data = response.GetValue("payload").ToObject<bool>();
                            if (data)
                            {
                                if (User.Identity.IsAuthenticated)
                                {
                                    //Check User Products
                                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                                    if (!string.IsNullOrEmpty(products))
                                    {
                                        var isUsernumber = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Select(x => x.ProductRef).SingleOrDefault(x => x == Msisdn);
                                        if (isUsernumber != null)
                                        {
                                            var settingResponse = await Pay360Service.GetAutoTopUp(new Pay360GetAutoTopUpRequest() { Msisdn = Msisdn, Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value, ProductCode = ProductCode.NOWPAYG.ToString() });
                                            if (settingResponse != null && settingResponse.errorCode == 0 && settingResponse.payload != null)
                                            {
                                                if (settingResponse.payload.Status)
                                                {
                                                    responseStatus = 6;  //On AutoTopUp
                                                }
                                                else
                                                {
                                                    responseStatus = 5; //Off AutoTopUp
                                                }
                                            }
                                            else
                                            {
                                                return StatusCode((int)HttpStatusCode.InternalServerError);
                                            }
                                        }
                                        else
                                        {
                                            responseStatus = 4; //Not User Number
                                        }
                                    }
                                    else
                                    {
                                        responseStatus = 3; //No Products
                                    }
                                }
                                else
                                {
                                    responseStatus = 2; //Not Logged In
                                }
                            }
                            else
                            {
                                responseStatus = 1; // Not Valid
                            }

                            return Json(new { errorCode = 0, status = true, message = string.Empty, Data = responseStatus });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: AddProduct, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        public async Task<IActionResult> Cart()
        {
            await Global.BaseModel.SetSharedDataAsync(User);
            return View(Global.BaseModel);
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> SaveUserProduct(AddProductViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var phoneNumberUtil = PhoneNumbers.PhoneNumberUtil.GetInstance();
                    model.MobileNumber = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.MobileNumber, "GB"), PhoneNumberFormat.E164).Replace("+", "");

                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/SaveUserProduct", User, new SaveUserProductRequestModel() { ProductRef = model.MobileNumber, PUKCode = model.PUKCode });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            if ((response as Error).ErrorCode == (int)ApiStatusCodes.MobileNumberAlreadyAttached)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.MobileNumberAlreadyAttached, status = false, message = MessagesResource.ResourceManager.GetString(Messages.MobileNumberAlreadyAttached.ToString()) });
                            }
                            else if ((response as Error).ErrorCode == (int)ApiStatusCodes.InvalidMsisdnOrPUK)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.InvalidMsisdnOrPUK, status = false, message = MessagesResource.ResourceManager.GetString(Messages.InvalidMsisdnOrPUK.ToString()) });
                            }
                            else
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                            }
                        }
                        else
                        {
                            var data = response.GetValue("payload").ToObject<bool>();
                            if (data)
                            {
                                await ReloginUser();
                            }
                            return Json(new { errorCode = 0, status = true, message = string.Empty, Data = data, MobileNumber = model.MobileNumber });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: SaveUserProduct, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> GetUserSummary(GetUserSummaryModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;

                var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.ProductRef).FirstOrDefault().AccountId;

                if (!string.IsNullOrEmpty(AccountId))
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/UserSummary", User, new GetUserSummaryRequestModel() { AccountId = AccountId });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError);
                        }
                        else
                        {
                            var UserSummary = response.GetValue("payload").ToObject<GetUserSummaryResponseModel>();
                            return Json(new { errorCode = 0, status = true, message = string.Empty, Data = UserSummary });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserSummary, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetUserCallHistory(GetUserHistoryModel model)
        {
            try
            {
                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;

                var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.ProductRef).FirstOrDefault().AccountId;

                if (!string.IsNullOrEmpty(AccountId))
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetUserCallHistory", User, new GetUserCallHistoryRequestModel() { AccountId = AccountId });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError);
                        }
                        else
                        {
                            var historyResponse = response.GetValue("payload").ToObject<GetUserCallHistoryResponseModel>();
                            return Json(new { data = historyResponse.CallingHistory });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserCallHistory, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetUserSmsHistory(GetUserHistoryModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;

                var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.ProductRef).FirstOrDefault().AccountId;

                if (!string.IsNullOrEmpty(AccountId))
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetUserSmsHistory", User, new GetUserSmsHistoryRequestModel() { AccountId = AccountId });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError);
                        }
                        else
                        {
                            var historyResponse = response.GetValue("payload").ToObject<GetUserSmsHistoryResponseModel>();
                            return Json(new { data = historyResponse.SmsHistory });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserSmsHistory, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetUserDataHistory(GetUserHistoryModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;

                var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.ProductRef).FirstOrDefault().AccountId;

                if (!string.IsNullOrEmpty(AccountId))
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetUserDataHistory", User, new GetUserDataHistoryRequestModel() { AccountId = AccountId });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError);
                        }
                        else
                        {
                            var historyResponse = response.GetValue("payload").ToObject<GetUserDataHistoryResponseModel>();
                            return Json(new { data = historyResponse.DataHistory });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserDataHistory, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetUserPaymentHistory(GetUserHistoryModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }

                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;

                var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.ProductRef).FirstOrDefault().AccountId;

                if (!string.IsNullOrEmpty(AccountId))
                {
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetUserPaymentHistory", User, new GetUserPaymentHistoryRequestModel() { AccountId = AccountId });
                    if (response != null)
                    {
                        if (response is Error)
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError);
                        }
                        else
                        {
                            var historyResponse = response.GetValue("payload").ToObject<GetUserPaymentHistoryResponseModel>();
                            return Json(new { data = historyResponse.PaymentHistory });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserDataHistory, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [Route("accountDetail")]
        [Authorize]
        public async Task<IActionResult> AccountDetail()
        {
            try
            {
                var model = new AccountDetailViewModel();
                await model.SetSharedDataAsync(User);
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: AccountDetail,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        [Route("porting-detail")]
        [Authorize]
        public async Task<IActionResult> PortingDetail()
        {
            try
            {
                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(products))
                {
                    var list = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products);
                    var model = new PortingViewModel()
                    {
                        UserProductsList = list.Select(x => new SelectListItem() { Text = x.ProductRef, Value = x.ProductRef })
                    };

                    await model.SetSharedDataAsync(User);
                    return View(model);
                }
                else
                {
                    return RedirectToAction("AddProduct");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PortingDetails ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> GetUserPortDetials(string Number)
        {
            try
            {
                if (!string.IsNullOrEmpty(Number))
                {
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    var list = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products);

                    string NTMsisdn = list.FirstOrDefault(s => s.ProductRef == Number).ProductRef;
                    string Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;

                    if (NTMsisdn != null)
                    {
                        var response = await PortService.GetPortRequests(new GetPortingDetailsRequestModel() { Email = Email, Msisdn = NTMsisdn });
                        return Json(response);
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.BadRequest);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PortingDetails ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PortIn(PortinViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    var list = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products);

                    string NTMsisdn = list.FirstOrDefault(s => s.ProductRef == model.NTMsisdn).ProductRef;

                    var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                    model.PortMsisdn = phoneNumberUtil.Format(phoneNumberUtil.Parse(model.PortMsisdn, "GB"), PhoneNumberFormat.E164).Replace("+", "").Trim();

                    if (NTMsisdn != null)
                    {
                        var request = new PortInRequestModel()
                        {
                            Email = User.Claims.FirstOrDefault(c => c.Type == "Email").Value,
                            PortMsisdn = model.PortMsisdn,
                            NTMsisdn = NTMsisdn,
                            UserPortingDate = model.UserPortingDate,
                            Code = model.Code
                        };
                        var response = await PortService.PortIn(request, PortTypes.PortIn);
                        return Json(new { Data = response, StatusCode = 1 });
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.BadRequest);
                    }
                }
                else
                {
                    return Json(new { Data = ModelState.Select(x => x.Value.Errors).Where(y => y.Count > 0).ToList(), StatusCode = 0 });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PortIn, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PortOut(PortOutViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    var list = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products);

                    string NTMsisdn = list.FirstOrDefault(s => s.ProductRef == model.NTMsisdn).ProductRef;
                    if (NTMsisdn != null)
                    {

                        var request = new PortOutRequestModel()
                        {
                            Email = User.Claims.FirstOrDefault(c => c.Type == "Email").Value,
                            NTMsisdn = NTMsisdn,
                            UserPortingDate = model.UserPortingDate,
                            CodeType = model.CodeType,
                            ReasonId = model.ReasonId
                        };
                        var response = await PortService.PortOut(request);
                        return Json(new { Data = response, StatusCode = 1 });
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.BadRequest);
                    }
                }
                else
                {
                    return Json(new { Data = ModelState.Select(x => x.Value.Errors).Where(y => y.Count > 0).ToList(), StatusCode = 0 });
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PortIn, Parameters=> model: {JsonConvert.SerializeObject(model)} ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CancelPortingRequest(string RequestID)
        {
            try
            {
                if (!string.IsNullOrEmpty(RequestID))
                {
                    var request = new CancelPortingRequestModel()
                    {
                        RequestID = RequestID
                    };
                    var response = await PortService.CancelPortingRequest(request);
                    return Json(response);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: PortingDetails ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> GetSwitchingInfo(string Number)
        {
            try
            {
                if (!string.IsNullOrEmpty(Number))
                {
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    var list = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products);

                    string NTMsisdn = list.FirstOrDefault(s => s.ProductRef == Number).ProductRef;

                    if (NTMsisdn != null)
                    {
                        var request = new GetSwitchingInformationRequestModel()
                        {
                            msisdn = NTMsisdn
                        };
                        var response = await PortService.GetSwitchingInfo(request);
                        return Json(response);
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.BadRequest);
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetSwitchingInfo ,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetUserDetails()
        {
            try
            {
                var email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetUserByEmail", User, new GetUserByEmailRequestModel() { Email = email });

                if (response != null)
                {
                    if (response is Error)
                    {
                        if ((response as Error).ErrorCode == (int)ApiStatusCodes.UserNotFound)
                        {
                            return Json(new { errorCode = (int)ApiStatusCodes.UserNotFound, status = false, message = MessagesResource.ResourceManager.GetString(Messages.UserNotFoundbyEmail.ToString()) });
                        }
                        else
                        {
                            return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                        }
                    }
                    else
                    {
                        var UserData = response.GetValue("payload").ToObject<GetUserByEmailResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = UserData });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: AccountDetail,ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> UpdateMailSubscription(bool Status)
        {
            try
            {
                var UserID = int.Parse(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
                var response = await Api.CallApi(NowPayGApiEndPoint + "User/UpdateMailSubscription", User, new UpdateMailSubscriptionRequestModel() { UserID = UserID, MailSubscription = Status });

                if (response != null)
                {
                    if (response is Error)
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                    }
                    else
                    {
                        var payload = response.GetValue("payload").ToObject<bool>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = payload });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: UpdateMailListStatus, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ChangeAccountPasword(AccountDetailViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var UserID = int.Parse(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);

                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/ChangeAccountPasword", User, new ChangePasswordRequestModel() { UserID = UserID, NewPassword = model.NewPassword, OldPassword = model.OldPassword });

                    if (response != null)
                    {
                        if (response is Error)
                        {
                            if ((response as Error).ErrorCode == (int)ApiStatusCodes.InvalidOldPassword)
                            {
                                return Json(new { errorCode = (int)ApiStatusCodes.InvalidOldPassword, status = false, message = MessagesResource.ResourceManager.GetString(Messages.InvalidOldPassword.ToString()) });
                            }
                            else
                            {
                                return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                            }
                        }
                        else
                        {
                            var payload = response.GetValue("payload").ToObject<bool>();
                            return Json(new { errorCode = 0, status = true, message = string.Empty, Data = payload });
                        }
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError);
                    }

                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: ChangeAccountPasword, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [Route("accountSettings")]
        [Authorize]
        public async Task<IActionResult> AccountSettings()
        {
            try
            {
                var model = new AutoTopupSettingsViewModel();
                await model.SetSharedDataAsync(User);
                return View(model);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: AccountSettings, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        [HttpGet]
        public async Task<ActionResult> GoogleLogin(string accessToken)
        {

            try
            {
                ExternalLoginRequest model = new ExternalLoginRequest() { accessToken = accessToken, socialLoginType = Utility.LoginTypes.Google };
                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/ExternalLogin", User, model);

                if (objUser is Error)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                }

                if (objUser != null)
                {
                    var userModel = objUser.GetValue("payload").ToObject<BaseViewModel>();
                    AuthenticationProperties authProperties;
                    ClaimsIdentity claimsIdentity = userModel.SetClaims(LoginTypes.Google, out authProperties, false);
                    //await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
                    return Content("{\"status\":\"Success\"}");
                }
                else
                {
                    return Content("{\"status\":\"error\"}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GoogleLogin, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Content("{\"status\":\"error\"}");
            }
        }

        [HttpGet]
        public async Task<ActionResult> FacebookLogin(string accessToken, string User_Id)
        {
            try
            {
                ExternalLoginRequest model = new ExternalLoginRequest() { accessToken = accessToken, socialLoginType = Utility.LoginTypes.Facebook };

                var objUser = await Api.CallApi(NowPayGApiEndPoint + "User/ExternalLogin", User, model);

                if (objUser is Error)
                {
                    if ((objUser as Error).ErrorCode == (int)ApiStatusCodes.UnableToFetchSocialAppUser)
                    {
                        return StatusCode((int)HttpStatusCode.BadRequest, (objUser as Error).ErrorMessage);
                    }
                    else
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (objUser as Error).ErrorMessage);
                    }
                }

                if (objUser != null)
                {
                    var userModel = objUser.GetValue("payload").ToObject<BaseViewModel>();

                    AuthenticationProperties authProperties;
                    ClaimsIdentity claimsIdentity = userModel.SetClaims(LoginTypes.Facebook, out authProperties, false);
                    //await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
                    return Content("{\"status\":\"Success\"}");

                }
                else
                {
                    return Content("{\"status\":\"error\"}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: FacebookLogin, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return Content("{\"status\":\"error\"}");
            }
        }

        [HttpGet]
        [Route("GetUserProducts")]
        [Authorize]
        public async Task<IActionResult> GetUserProducts()
        {
            try
            {
                var UserId = int.Parse(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
                var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetAllProductsByUserID", User, new GetAllProductsByUserIDRequestModel() { UserId = UserId });
                if (response != null)
                {
                    if (response is Error)
                    {
                        return StatusCode((int)HttpStatusCode.InternalServerError, (response as Error).ErrorMessage);
                    }
                    else
                    {
                        var UserSummary = response.GetValue("payload").ToObject<GetAllProductsByUserIDResponseModel>();
                        return Json(new { errorCode = 0, status = true, message = string.Empty, Data = UserSummary });
                    }
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: GetUserProducts, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        private async Task<IEnumerable<UserProductsResponseModel>> AllUserProducts()
        {
            var UserId = int.Parse(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);
            var response = await Api.CallApi(NowPayGApiEndPoint + "User/GetAllProductsByUserID", User, new GetAllProductsByUserIDRequestModel() { UserId = UserId });
            if (response != null)
            {
                if (response is Error)
                {
                    return null;
                }
                else
                {
                    return response.GetValue("payload").ToObject<GetAllProductsByUserIDResponseModel>().ProductList;
                }
            }
            else
            {
                return null;
            }
        }

        private async Task ReloginUser()
        {

            var LoginType = (LoginTypes)(Convert.ToInt16(User.Claims.FirstOrDefault(x => x.Type == "LoginType").Value));

            BaseViewModel usermodel = new BaseViewModel()
            {
                Id = int.Parse(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value),
                FirstName = User.Claims.Where(x => x.Type == "FirstName").FirstOrDefault().Value,
                LastName = User.Claims.Where(x => x.Type == "LastName").FirstOrDefault().Value,
                Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value,
                Token = User.Claims.Where(x => x.Type == "Token").FirstOrDefault().Value,
                ProductList = await AllUserProducts(),
            };

            AuthenticationProperties authProperties;
            ClaimsIdentity claimsIdentity = usermodel.SetClaims(LoginType, out authProperties, true);

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

        }

        [HttpGet]
        [Route("userProducts")]
        [Authorize]
        public async Task<IActionResult> UserProducts()
        {
            try
            {
                await Global.BaseModel.SetSharedDataAsync(User);
                return View(Global.BaseModel);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: UserProducts, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> AddBundleViaSimCredit(AddBundleViaSimCreditViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                    if (!string.IsNullOrEmpty(products))
                    {
                        var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.Msisdn).FirstOrDefault().AccountId;
                        var productCode = ProductCode.NOWPAYG.ToString(); ;
                        var email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                        if (!string.IsNullOrEmpty(AccountId))
                        {
                            var response = await Api.CallApi(NowPayGApiEndPoint + "User/AddBundleViaSimCredit", User, new AddBundleViaSimCreditRequestModel() { Uuid = model.UUID, AccountId = AccountId });

                            if (response != null)
                            {
                                if (response is Error)
                                {
                                    TempData["Heading"] = "Payment Failed";
                                    TempData["Message"] = (response as Error).ErrorMessage;
                                }
                                else
                                {
                                    var payload = response.GetValue("payload").ToObject<AddBundleViaSimCreditResponseModel>();
                                    if (payload != null)
                                    {
                                        TempData["Heading"] = "Success";
                                        TempData["Message"] = "Plan of £" + model.Amount + " is purchased successfully. Your remaining balance is £" + payload.Balance.ToString("0.##");

                                        Dictionary<string, string> bundleDetail = new Dictionary<string, string>();
                                        bundleDetail.Add("Id", model.Msisdn);
                                        bundleDetail.Add("name", model.BundleName);
                                        bundleDetail.Add("amount", model.Amount.ToString());
                                        bundleDetail.Add("category", CheckOutTypes.Bundle.ToString());
                                        TempData["BundleDetail"] = bundleDetail;

                                        response = await Api.CallApi(NowPayGApiEndPoint + "User/SetBundleAutoRenewal", User, new BundleAutoRenewalRequestModel() { Uuid = model.UUID, AccountId = AccountId, isAutoRenew = model.isAutoRenew, Msisdn = model.Msisdn, BundleAmount = int.Parse(model.Amount), ProductCode = productCode, Email = email });
                                        return RedirectToAction("PaymentSuccessful", "Pay360");
                                    }
                                }
                            }
                        }
                    }
                    return RedirectToAction("Error", "Error");
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: AccountController, Method: ChangeAccountPasword, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task<IActionResult> SetBundleAutoRenewal(BundleAutoRenewalRequestModel model)
        {

            try
            {
                var products = User.Claims.Where(x => x.Type == "Products").FirstOrDefault().Value;
                if (!string.IsNullOrEmpty(products))
                {
                    var AccountId = JsonConvert.DeserializeObject<IEnumerable<UserProductsResponseModel>>(products).Where(x => x.ProductRef == model.Msisdn).FirstOrDefault().AccountId;
                    model.ProductCode = ProductCode.NOWPAYG.ToString(); ;
                    model.Email = User.Claims.Where(x => x.Type == "Email").FirstOrDefault().Value;
                    var response = await Api.CallApi(NowPayGApiEndPoint + "User/SetBundleAutoRenewal", User, new Models.ApiContracts.Request.BundleAutoRenewalRequestModel() { Uuid = model.Uuid, AccountId = AccountId, isAutoRenew = model.isAutoRenew, Msisdn = model.Msisdn, ProductCode = model.ProductCode, Email = model.Email, BundleAmount = model.BundleAmount });

                    if (response != null)
                    {
                        if (response is Error)
                        {
                            var message = response.GetValue("message").ToObject<string>();
                            return Json(new { status = false, message = message });

                        }
                        else
                        {
                            var message = response.GetValue("message").ToObject<string>();
                            return Json(new { status = true, message = message });
                        }
                    }

                }
            }
            catch
            {

            }
            return Json(new { status = false, message = "Auto Plan Renewal Error" });
        }

        [HttpGet]
        [Route("unsubscribe")]
        public IActionResult Unsubscribe()
        {
            return View();
        }
    }
}
