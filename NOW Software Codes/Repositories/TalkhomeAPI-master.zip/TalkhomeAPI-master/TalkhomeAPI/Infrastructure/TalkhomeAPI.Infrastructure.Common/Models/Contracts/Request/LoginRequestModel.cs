﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class LoginRequestModel
    {
        [Required(ErrorMessage = "phone number is required")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "country code is required")]
        public string PhoneNumberCountryCode { get; set; }

        [Required]
        [MaxLength(50)]
        public string IpAddress { get; set; }
    }
}
