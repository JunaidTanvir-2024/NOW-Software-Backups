﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Settings;

public class AirShipSettings
{
    public const string SectionName = "AirShipSettings";
    public static AirShipSettings Bind = new AirShipSettings();
    public string? ApiEndpoint { get; set; }
    public bool IsActive { get; set; }
    public string ActivityTagGroupName { get; set; } = string.Empty;
    public string TransactionTagGroupName { get; set; } = string.Empty;
    public string ProductTagGroupName { get; set; } = string.Empty;
}