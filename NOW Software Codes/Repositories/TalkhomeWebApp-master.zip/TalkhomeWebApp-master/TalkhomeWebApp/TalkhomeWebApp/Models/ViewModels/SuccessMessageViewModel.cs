﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class SuccessMessageViewModel
    {
        public string Key { get; set; }
        public string PaymentMethod { get; set; }
    }
    public class SuccessViewModel
    {
        public string Key { get; set; }
        public TopupTransactionModel Topup { get; set; }
        public SetAutoTopupTransactionModel SetAutoTopup { get; set; }
        public MobileTopupTransactionModel MobileTopup { get; set; }
        public BundleTransactionModel Bundle { get; set; }
    }
    public class SetAutoTopupResultViewModel
    {
        public string Key { get; set; }
        public SetAutoTopupTransactionModel SetAutoTopup { get; set; }
    }
    public class SetAutoRenewalResultViewModel
    {
        public string Key { get; set; }
    }
    public class SendMobileTopupResultViewModel
    {
        public string Key { get; set; }
    }

    public class TransactionErrorViewModel
    {
        public string Key { get; set; }
        public string CheckoutType { get; set; }
        public TopupTransactionModel Topup { get; set; }
        public MobileTopupTransactionModel MobileTopup { get; set; }
        public BundleTransactionModel Bundle { get; set; }
        public SetAutoTopupTransactionModel SetAutoTopup { get; set; }

    }
    public class TopupTransactionModel
    {
        public string Payment { get; set; }
        public bool AutoTopup { get; set; }
        public string Amount { get; set; }
        public string Origin { get; set; }
        public string From { get; set; }
        public string Id { get; set; }
    }
    public class SetAutoTopupTransactionModel
    {
        public float MaxSpendLimit { get; set; }
        public float ThresholdAmount { get; set; }
        public float TopupAmount { get; set; }
        public string CurrencySymbol { get; set; }
    }
    public class BundleTransactionModel
    {
        public string Payment { get; set; }
        public string Amount { get; set; }
        public bool AutoRenew { get; set; }
        public string Bundle { get; set; }
        public string Type { get; set; }
        public string Destination { get; set; }
        public string Origin { get; set; }
        public string From { get; set; }
        public string Id { get; set; }
    }
    public class MobileTopupTransactionModel
    {
        public string Payment { get; set; }
        public string Amount { get; set; }
        public string Destination { get; set; }
        public string Network { get; set; }
        public string Origin { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string Id { get; set; }
    }
}
