﻿
namespace THCC.Application.Interfaces.Services.Tracking;

public interface ICallingCardConsumptionService : ServiceType.ITransient
{
    Task ClassicCardConsumptionJob();
    Task RechargeableCardConsumptionAndCallJob();
    Task ClassicCardCallingJob();
}
