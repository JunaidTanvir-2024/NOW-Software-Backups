using Application.Features.Bundle.Bundle;
using Application.Features.Bundle.Model;
using Application.Features.Rate.Extensions;
using Application.Features.Rate.Model;

namespace Application.Features.Rate.InternationalWithBundle;

public class InternationalRatesWithBundleRequestHandler : IRequestHandler<InternationalRatesWithBundleRequest, Result<InternationalRatesWithBundleInfo>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<InternationalRatesWithBundleRequestHandler> _localizer;
    private readonly IMapper _mapper;

    public InternationalRatesWithBundleRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<InternationalRatesWithBundleRequestHandler> localizer,
        IMapper mapper)
    {
        _uow = uow;
        _localizer = localizer;
        _mapper = mapper;
    }

    public async Task<Result<InternationalRatesWithBundleInfo>> Handle(InternationalRatesWithBundleRequest request, CancellationToken cancellationToken)
    {
        var ratesWithBundles = new InternationalRatesWithBundleInfo();
        var rates = await _uow.RateRepo.GetInternationalRates();
        if (rates?.Count > 0)
        {

            ratesWithBundles.RateInfo = rates.First(x => x.IsoCode == request.CountryCode!);

            ratesWithBundles.RateInfo.Landline = ratesWithBundles.RateInfo.Landline?.GetRate();
            ratesWithBundles.RateInfo.Mobile = ratesWithBundles.RateInfo.Mobile?.GetRate();
            ratesWithBundles.RateInfo.Sms = ratesWithBundles.RateInfo.Sms?.GetRate();
            ratesWithBundles.RateInfo.LandlineStandard = ratesWithBundles.RateInfo.LandlineStandard?.GetRate();
            ratesWithBundles.RateInfo.MobileStandard = ratesWithBundles.RateInfo.MobileStandard?.GetRate();
            ratesWithBundles.RateInfo.SmsStandard = ratesWithBundles.RateInfo.SmsStandard?.GetRate();

            // var result = (await _uow.BundleRepo.GetBundles(new BundlesRequest())).Where(x => x.CountryCode == request.CountryCode);
            var result = await _uow.BundleRepo.GetBundles(new BundlesRequest());
            ratesWithBundles.BundleInfo = _mapper.Map<List<BundleInfo>>(result);
        }
        return Result<InternationalRatesWithBundleInfo>.Success(ratesWithBundles, _localizer[CustomStatusKey.Success]);
    }
}
