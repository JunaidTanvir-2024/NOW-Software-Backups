﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class GetUserByIdRequest
    {
        [JsonProperty("Named_user_id")]
        [Required]
        public string Named_user_id { get; set; }

        [JsonProperty("ProductCode")]
        [Required]
        public string ProductCode { get; set; }
    }
}
