﻿using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IAppConfig_DL
    {
        Task<List<CarouselContent>> GetCarouselDynamic(string msisdn, int na_service_id, string language);
        Task<List<CarouselMenu>> GetCarouselMenu(string msisdn, int na_service_id);
        Task<List<CarouselMenu>> GetCarouselMenuV1(string msisdn, int na_service_id, int version, string itVersion);
        Task<List<CarouselMenu>> GetCarouselMenuV1(string msisdn, int na_service_id, int version);
        Task<string> getBundleSMS(string msisdn);
        Task<List<AirtimeConfig>> GetAirtimeConfig(string msisdn);
        Task<List<string>> getReferralMsgs(string msisdn);
    }
}
