﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{ 
    public class ParseMSISDNResponse
    {
        public string original { get; set; }
        public string normalized { get; set; }
        public bool isValid { get; set; }
        public bool isFormallyValid { get; set; }
        public OperatorInfoAndAlternatives @operator { get; set; }
        public CountryInfo country { get; set; }
    }


    public class OperatorInfoAndAlternatives
    {
        public string id { get; set; }
        public string name { get; set; }
        public int brandid { get; set; }
        public int fullprefix { get; set; }
        public string prefix { get; set; }
        public string number { get; set; }
        public Dictionary<string, OperatorAlternative> alt { get; set; }
    }


    public class OperatorAlternative
    {
        public int id { get; set; }
        public string name { get; set; }
        public int brandId { get; set; }
    }


    public class CountryInfo
    {
        public string id { get; set; }
        public string name { get; set; }
        public int prefix { get; set; }
        public int hasLeadingZero { get; set; }
        public MsisdnLength msisdnLength { get; set; }
        public List<string> productTypes { get; set; }
    }


    public class MsisdnLength
    {
        public int min { get; set; }
        public int max { get; set; }
    }


}
