﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class ExistingCardPaymentRequestModel
    {
        public string cardToken { get; set; }
        public string securityCode { get; set; }
        public string ipAddress { get; set; }
        public string EmailAddress { get; set; }
        public string Msisdn { get; set; }
        public string CustomerUniqueRef { get; set; }
        public int TopUpAmount { get; set; }
        public string BundleId { get; set; }
        public CheckOutTypes CheckoutType { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }
        public bool IsAutoBundleRenew { get; set; }
        public bool IsAutoTopUp { get; set; }
    }
}
