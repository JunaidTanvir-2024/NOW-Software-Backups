﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransferToCountriesListByServices
    {
        public List<Country> countries { get; set; }
    }

    public class Country
    {
        public int country_id { get; set; }
        public string country { get; set; }
    }
}
