﻿using Infrastructure.DAL;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.DAO;
using Models.Enums;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Infrastructure.Services;
using Newtonsoft.Json;
using Infrastructure.Utilities;
using Models.Contracts.Request.ApiContracts;
using Models.Contracts.Response.ApiContracts;
using System.Net;

namespace Infrastructure.BLL
{
    public class BL_Porting : IBL_Porting
    {
        private IDL_Porting Db;
        private DigitalkConfig DigitalkConfigurations;
        private IDigitalkPortingService DigitalkPortingService;
        private readonly LoginLinks LoginLinks;
        private ISmsService SmsService;

        public BL_Porting(IDL_Porting db, IOptions<DigitalkConfig> digitalkConfig, IOptions<LoginLinks> loginLinks, IDigitalkPortingService digitalkPortingService, ISmsService smsService)
        {
            Db = db;
            DigitalkConfigurations = digitalkConfig.Value;
            DigitalkPortingService = digitalkPortingService;
            LoginLinks = loginLinks.Value;
            SmsService = smsService;
        }

        public async Task<GenericApiResponse<bool>> PortIn(PortInRequestModel model, PortTypes portType, int? OrderReferenceId = null)
        {
            try
            {
                if (portType == PortTypes.PortIn)
                {
                    var response = await ValidatePortingRequest(new ValidatePortingRequestModel() { Email = model.Email, PortType = portType, Product = model.Product, Msisdn = model.NTMsisdn });
                    if (response.errorCode != 0)
                    {
                        return response;
                    }
                }

                if (portType == PortTypes.PortInNew)
                {
                    GetTempMsisdnDbResponse GetTempMsisdn = await Db.GetTempMsisdn((int)OrderReferenceId, model.Product);

                    if (GetTempMsisdn != null && GetTempMsisdn.ErrorCode == 0)
                    {
                        model.NTMsisdn = GetTempMsisdn.Msisdn;
                    }
                    else
                    {
                        return GenericApiResponse<bool>.Failure("unable to retrieve the temporary msisdn from the pool");
                    }
                }

                string SubscriberId = "";
                SubscriberId = await Db.GetSubscriberId(model.NTMsisdn);
                if (string.IsNullOrEmpty(SubscriberId))
                {
                    return GenericApiResponse<bool>.Failure("Subscriber Id not found against this msisdn", 3);
                }

                Port port = new Port()
                {
                    Code = model.Code,
                    Email = model.Email,
                    NTMsisdn = model.NTMsisdn,
                    UserPortingDate = model.UserPortingDate,
                    PortMsisdn = model.PortMsisdn,
                    PortType = portType,
                    ProductId = model.Product,
                    RequestMediumType = model.Medium,
                    SubscriberId = Convert.ToInt32(SubscriberId),
                };
                int result = await Db.InsertPortRequest(port);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Number Port-In request generted successfully.");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Number Port-In request failed.");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> PortOut(PortOutRequestModel model, CodeTypes codeType, PortTypes portType)
        {
            string SubscriberId = "";
            SubscriberId = await Db.GetSubscriberId(model.NTMsisdn);
            try
            {
                var response = await ValidatePortingRequest(new ValidatePortingRequestModel() { Email = model.Email, PortType = portType, Product = model.Product, Msisdn = model.NTMsisdn });
                if (response.errorCode != 0)
                {
                    return response;
                }
                Port port = new Port()
                {
                    Email = model.Email,
                    NTMsisdn = model.NTMsisdn,
                    CodeType = codeType,
                    PortType = PortTypes.PortOut,
                    ProductId = model.Product,
                    ReasonId = model.ReasonId,
                    RequestMediumType = model.Medium,
                    SubscriberId = Convert.ToInt32(SubscriberId),
                    UserPortingDate = model.UserPortingDate,
                };
                int result = await Db.InsertPortRequest(port);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Number Port-Out request generted successfully.");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Number Port-Out request failed.");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<GetPortingRequestsResponseModel>> GetPortingRequests(GetPortingRequestsRequestModel model)
        {
            try
            {
                var result = await Db.GetPortingRequests(new Port() { Email = model.Email, ProductId = model.Product, NTMsisdn = model.Msisdn });
                if (result != null)
                {
                    if (result.Count() > 0)
                    {
                        var list = new GetPortingRequestsResponseModel()
                        {
                            PortingRequestList = result.Select(Port => new PortResponseModel()
                            {
                                Id = Port.Id,
                                Email = Port.Email,
                                NTMsisdn = Port.NTMsisdn,
                                PortMsisdn = Port.PortMsisdn,
                                Code = Port.Code,
                                CodeType = Port.CodeType,
                                Status = Port.Status,
                                StatusNote = Port.Status,
                                UserPortingDate = Port.UserPortingDate,
                                PortDate = Port.PortDate,
                                ExpiryDate = Port.ExpiryDate,
                                PortType = Port.PortType,
                                Product = Port.ProductId,
                                RequestMediumType = Port.RequestMediumType,
                                IsProcessed = Port.IsProcessed,
                                SwitchingInfo = Port.SwitchingInfo,
                                IsCancelled = Port.IsCancelled,
                                IsError = Port.IsError,
                                CancelledDateTime = Port.CancelledDateTime,
                                DaemonErrorMessage = Port.DaemonErrorMessage,
                                DaemonPortInRequestJson = Port.DaemonPortInRequestJson,
                                DaemonPortInResponseJson = Port.DaemonPortInResponseJson,
                                DaemonPortOutRequestJson = Port.DaemonPortOutRequestJson,
                                DaemonPortOutResponseJson = Port.DaemonPortOutResponseJson,
                                ProcessedDateTime = Port.ProcessedDateTime,
                                UserId = Port.UserId
                            })
                        };
                        return GenericApiResponse<GetPortingRequestsResponseModel>.Success(list, "Found Porting Requests.");
                    }
                    else
                    {
                        return GenericApiResponse<GetPortingRequestsResponseModel>.Success(new GetPortingRequestsResponseModel(), "No Porting Requests Found.");
                    }
                }
                else
                {
                    return GenericApiResponse<GetPortingRequestsResponseModel>.Failure(null, "Some Error Occured.");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdateUserPortingDate(UpdateUserPortingDateRequestModel model)
        {
            try
            {
                int result = await Db.UpdateUserPortingDate(new Port() { PortDate = model.PortingDate, PortMsisdn = model.PortMsisdn });
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Porting Date Scuccessfully Updated.");
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Failure!");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> ValidatePortingRequest(ValidatePortingRequestModel model)
        {
            try
            {
                int result = await Db.ValidatePortingRequest(new Port() { Email = model.Email, PortType = model.PortType, ProductId = model.Product, NTMsisdn = model.Msisdn });
                if (result == 1)
                {
                    return GenericApiResponse<bool>.Success(true, "Valid Request");
                }
                else if (result == 0)
                {
                    return GenericApiResponse<bool>.Failure($"{model.PortType} not allowed before the previous request completes.", 4);
                }
                else
                {
                    return GenericApiResponse<bool>.Failure(false, "Some Error Occured While Processing your Request.");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<bool>> CancelPortingRequest(CancelPortingRequestModel model)
        {
            try
            {
                var response = await Db.GetPortingRequestsbyID(int.Parse(model.RequestID));
                if (response != null)
                {
                    if (response.IsProcessed)
                    {
                        var cancelResponse = await DigitalkPortingService.CancelPortOut(response.SubscriberId, (int)response.CodeType);
                        //if ((cancelResponse != null) && (cancelResponse.StatusCode == System.Net.HttpStatusCode.OK || cancelResponse.StatusCode == System.Net.HttpStatusCode.Created)) //Success
                        //{

                        int result = await Db.CancelPortingRequest(new Port() { Id = model.RequestID });
                        if (result > 0)
                        {
                            return GenericApiResponse<bool>.Success(true, "Reqeust cancelled successfully.");
                        }

                        return GenericApiResponse<bool>.Failure(false, "Cancellation request failed.");
                        //}
                        //return GenericApiResponse<bool>.Failure(false, "Cancellation request failed.");
                    }
                    else
                    {
                        int result = await Db.CancelPortingRequest(new Port() { Id = model.RequestID });
                        if (result > 0)
                        {
                            return GenericApiResponse<bool>.Success(true, "Reqeust cancelled successfully.");
                        }
                        return GenericApiResponse<bool>.Failure(false, "Cancellation request failed.");
                    }
                }
                return GenericApiResponse<bool>.Failure(false, "No data found against this request.");
            }
            catch
            {
                throw;
            }
        }

        public async Task<GenericApiResponse<SwitchingInformationApiResponseModel>> GetSwitchingInformation(string msisdn)
        {
            try
            {
                string SubscriberId = "";
                SubscriberId = await Db.GetSubscriberId(msisdn);
                if (string.IsNullOrEmpty(SubscriberId))
                {
                    return GenericApiResponse<SwitchingInformationApiResponseModel>.Failure("Subscriber Id not found against this msisdn", 3);
                }
                var apiHttpResponse = await DigitalkPortingService.GetSwitchingInformation(SubscriberId);
                if (apiHttpResponse != null)
                {
                    if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.OK || apiHttpResponse.StatusCode == System.Net.HttpStatusCode.Created) //Success
                    {
                        string jsonResponse = apiHttpResponse.Content.ReadAsStringAsync().Result;
                        SwitchingInformationApiResponseModel apiResponseModel = JsonConvert.DeserializeObject<SwitchingInformationApiResponseModel>(jsonResponse);
                        apiResponseModel.TerminateDate = Utility.ConvertMicrosoftJsonDate(apiResponseModel.TerminateDate);
                        return GenericApiResponse<SwitchingInformationApiResponseModel>.Success(apiResponseModel, "success");
                    }
                    else  //Failure 
                    {
                        string jsonResponse = apiHttpResponse.Content.ReadAsStringAsync().Result;
                        string reasonMessage = Utility.GetJsonObjectValueByKey("Message", jsonResponse);
                        return GenericApiResponse<SwitchingInformationApiResponseModel>.Failure(reasonMessage);
                    }
                }
                else
                {
                    return GenericApiResponse<SwitchingInformationApiResponseModel>.Failure("Digitalk is not responding at the moment");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PortOutBySmsResponseModel> PortOutBySms(PortOutBySmsRequestModel model)
        {
            try
            {

                Product prod = await Db.GetProduct(model.sender.ToString());
                Products product = (prod != null && prod.product_code == "THM") ? Products.TalkHome : Products.NowPayg;
                string SubscriberId = "";
                SubscriberId = (prod != null && prod.error_code == 0) ? prod.subscriber_id.ToString() : null;
                if (string.IsNullOrEmpty(SubscriberId))
                {
                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                        text = $"Invalid Number Provided"
                    };
                    return resp;
                }

                if (!(model.text.ToLower().Equals("pac") || model.text.ToLower().Equals("stac")))
                {
                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                        text = $"Invalid PortOut Type"
                    };
                    return resp;
                }

                CodeTypes portType = (model.text == "PAC") ? CodeTypes.PAC : CodeTypes.STAC;

                //int result = await Db.ValidatePortingRequest(new Port() { PortType = PortTypes.PortOut, ProductId = product, NTMsisdn = model.sender.ToString() });
                //if (result != 1)
                var portingCodeInfo = await Db.ValidatePortingBySMSRequest(new Port() { PortType = PortTypes.PortOut, ProductId = product, NTMsisdn = model.sender.ToString() });
                if (portingCodeInfo.IsValid != 1)
                {

                    var text = "";
                    if (portingCodeInfo.CodeType.ToString() == model.text)
                    {
                        text = $"I’m sorry you want to leave us. Your {model.text} code is {portingCodeInfo.Code} and will expire {portingCodeInfo.ExpiryDate.ToString("M/d/yyyy")}.";
                    }
                    else
                    {
                        text = $"You have already requested a {portingCodeInfo.CodeType.ToString()} for this number, your {portingCodeInfo.CodeType.ToString()} is {portingCodeInfo.Code} and will expire {portingCodeInfo.ExpiryDate.ToString("M/d/yyyy")}.";
                    }

                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                        text = text
                        //"A Pac is already open on your number, please request your switching info using 85075 for a reminder."

                    };
                    return resp;
                }

                int CodeType = model.text == "PAC" ? (int)CodeTypes.PAC : (int)CodeTypes.STAC;
                var response = await DigitalkPortingService.PortOut(Convert.ToInt32(SubscriberId), CodeType);
                if (response.StatusCode == System.Net.HttpStatusCode.OK || response.StatusCode == System.Net.HttpStatusCode.Created) //Success
                {
                    if (response != null)
                    {
                        string jsonResponse = response.Content.ReadAsStringAsync().Result;
                        PortOutResponse apiResponseModel = JsonConvert.DeserializeObject<PortOutResponse>(jsonResponse);
                        if (apiResponseModel != null)
                        {
                            apiResponseModel.ExpiryDate = Utility.ConvertMicrosoftJsonDate(apiResponseModel.ExpiryDate);
                            DateTime ExpiryDate = DateTime.UtcNow;
                            DateTime.TryParse(apiResponseModel.ExpiryDate, out ExpiryDate);
                            await Db.InsertApiPortingRequest(new Port
                            {
                                Code = apiResponseModel.Code,
                                CodeType = (model.text == "PAC") ? CodeTypes.PAC : CodeTypes.STAC,
                                ReasonId = 0,
                                NTMsisdn = model.sender.ToString(),
                                ExpiryDate = ExpiryDate,
                                PortType = PortTypes.PortOut,
                                ProductId = product,
                                RequestMediumType = MediumTypes.Sms,
                                SubscriberId = Convert.ToInt32(SubscriberId),
                                APIPortOutResponseJson = jsonResponse
                            });
                            var text = "";
                            try
                            {
                                text = $"I’m sorry you want to leave us. Your {model.text} code is {apiResponseModel.Code} and will expire {Convert.ToDateTime(apiResponseModel.ExpiryDate).ToString("M/d/yyyy")}.";
                            }
                            catch
                            {
                                text = $"I’m sorry you want to leave us. Your {model.text} code is {apiResponseModel.Code} and will expire {apiResponseModel.ExpiryDate}.";
                            }

                            PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                            {
                                keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                                text = text
                            };
                            //SmsService.SendXeebiSms(model.sender.ToString(), resp.text);
                            return resp;
                        }
                        else
                        {
                            await Db.InsertApiPortingRequest(new Port
                            {
                                Code = null,
                                CodeType = (model.text == "PAC") ? CodeTypes.PAC : CodeTypes.STAC,
                                ReasonId = 0,
                                NTMsisdn = model.sender.ToString(),
                                UserPortingDate = null,
                                PortType = PortTypes.PortOut,
                                ProductId = product,
                                RequestMediumType = MediumTypes.Sms,
                                SubscriberId = Convert.ToInt32(SubscriberId),
                                APIPortOutResponseJson = "Digitalk Api Error: Null response received"
                            });
                            PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                            {
                                keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                                text = $"Service not responding at the moment. Please contact Customer Services"
                            };
                            //SmsService.SendXeebiSms(model.sender.ToString(), resp.text);
                            return resp;
                        }
                    }
                    else // Null Response
                    {
                        await Db.InsertApiPortingRequest(new Port
                        {
                            Code = null,
                            CodeType = (model.text == "PAC") ? CodeTypes.PAC : CodeTypes.STAC,
                            ReasonId = 0,
                            NTMsisdn = model.sender.ToString(),
                            UserPortingDate = null,
                            PortType = PortTypes.PortOut,
                            ProductId = product,
                            RequestMediumType = MediumTypes.Sms,
                            SubscriberId = Convert.ToInt32(SubscriberId),
                            APIPortOutResponseJson = "Digitalk Api Error: Null response received"
                        });
                        PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                        {
                            keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                            text = $"Service not responding at the moment. Please contact Customer Services"
                        };
                        //SmsService.SendXeebiSms(model.sender.ToString(), resp.text);
                        return resp;
                    }
                }
                else  //Failure 
                {
                    string jsonResponse = response.Content.ReadAsStringAsync().Result;
                    string reasonMessage = Utility.GetJsonObjectValueByKey("Message", jsonResponse);
                    await Db.InsertApiPortingRequest(new Port
                    {
                        Code = null,
                        CodeType = (model.text == "PAC") ? CodeTypes.PAC : CodeTypes.STAC,
                        ReasonId = 0,
                        NTMsisdn = model.sender.ToString(),
                        UserPortingDate = null,
                        PortType = PortTypes.PortOut,
                        ProductId = product,
                        RequestMediumType = MediumTypes.Sms,
                        SubscriberId = Convert.ToInt32(SubscriberId),
                        APIPortOutResponseJson = "Digitalk Api Error: Service not responding at the moment"
                    });
                    var alreadyProgressText = "";


                    if (portingCodeInfo.CodeType.ToString() == model.text)
                    {
                        alreadyProgressText = $"I’m sorry you want to leave us. Your {model.text} code is {portingCodeInfo.Code} and will expire {portingCodeInfo.ExpiryDate.ToString("M/d/yyyy")}.";
                    }
                    else
                    {
                        alreadyProgressText = $"You have already requested a {portingCodeInfo.CodeType.ToString()} for this number, your {portingCodeInfo.CodeType.ToString()} code is {portingCodeInfo.Code} and will expire {portingCodeInfo.ExpiryDate.ToString("M/d/yyyy")}.";
                    }


                    string text = (reasonMessage.Contains("Cannot start port out, one is already in progress")) ? alreadyProgressText : reasonMessage + ". Please contact Customer Services.";
                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = model.text == "PAC" ? CodeTypes.PAC.ToString() : CodeTypes.STAC.ToString(),
                        text = text
                    };
                    //SmsService.SendXeebiSms(model.sender.ToString(), resp.text);
                    return resp;
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<PortOutBySmsResponseModel> GetSwitchingInformationBySms(string msisdn)
        {
            try
            {
                Product prod = await Db.GetProduct(msisdn);
                Products product = (prod != null && prod.product_code == "THM") ? Products.TalkHome : Products.NowPayg;
                string LoginLink = (product == Products.NowPayg) ? LoginLinks.NowPayGLink : LoginLinks.TalkhomeLink;
                string SubscriberId = (prod != null && prod.error_code == 0) ? prod.subscriber_id.ToString() : null;
                if (string.IsNullOrEmpty(SubscriberId))
                {
                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = "info",
                        text = $"Invalid Number Provided"
                    };
                    return resp;
                }
                var apiHttpResponse = await DigitalkPortingService.GetSwitchingInformation(SubscriberId);
                if (apiHttpResponse != null)
                {
                    if (apiHttpResponse.StatusCode == System.Net.HttpStatusCode.OK || apiHttpResponse.StatusCode == System.Net.HttpStatusCode.Created) //Success
                    {
                        string jsonResponse = apiHttpResponse.Content.ReadAsStringAsync().Result;
                        SwitchingInformationApiResponseModel apiResponseModel = JsonConvert.DeserializeObject<SwitchingInformationApiResponseModel>(jsonResponse);
                        apiResponseModel.TerminateDate = Utility.ConvertMicrosoftJsonDate(apiResponseModel.TerminateDate);
                        var Text = $"Your current balance is £{apiResponseModel.Balance.ToString().Trim()}.";
                        if (prod.bundle_Count > 0)
                        {
                            if (prod.bundle_Count == 1)
                            {
                                Text += $" You have {prod.bundle_Count} active bundle,to see your bundle go to {LoginLink}";
                            }
                            else
                            {
                                Text += $" You have {prod.bundle_Count} active bundles,to see your bundles go to {LoginLink}";
                            }

                        }
                        else
                        {
                            Text += " You don’t have any active bundles.";
                        }
                        PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                        {
                            keyword = "info",
                            text = Text
                        };
                        //SmsService.SendXeebiSms(msisdn, resp.text);
                        return resp;
                    }
                    else  //Failure 
                    {
                        PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                        {
                            keyword = "info",
                            text = $"Service not responding at the moment. Please contact Customer Services"
                        };
                        //SmsService.SendXeebiSms(msisdn, resp.text);
                        return resp;
                    }
                }
                else
                {
                    PortOutBySmsResponseModel resp = new PortOutBySmsResponseModel()
                    {
                        keyword = "info",
                        text = $"Service not responding at the moment. Please contact Customer Services"
                    };
                    //SmsService.SendXeebiSms(msisdn, resp.text);
                    return resp;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
