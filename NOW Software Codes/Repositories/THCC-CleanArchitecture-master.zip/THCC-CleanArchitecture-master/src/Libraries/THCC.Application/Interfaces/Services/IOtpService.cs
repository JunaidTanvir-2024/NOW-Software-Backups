﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services;

public interface IOtpService : ServiceType.ITransient
{
    Task<string> SaveToken(string email, string token, OtpType Type);
    Task<string> GetTokenAgainstOtp(string email, string otp, OtpType type);
}