﻿using Domain.Entities;

namespace Application.Features.Account.Product.Get;
public class GetProductRequestHandler : IRequestHandler<GetProductRequest, Result<IEnumerable<UserProductInfo>>>
{
    #region Fields

    private readonly IStringLocalizer<GetProductRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ICurrentUser _currentUser;

    #endregion

    #region Ctor

    public GetProductRequestHandler(
        IStringLocalizer<GetProductRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        IMapper mapper,
        ICurrentUser currentUser)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    #endregion

    #region Method

    public async Task<Result<IEnumerable<UserProductInfo>>> Handle(GetProductRequest request, CancellationToken cancellationToken)
    {
        var products = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (products.Any())
        {
            var userProducts = _mapper.Map<IEnumerable<UserProductInfo>>(products).ToList();
            return Result<IEnumerable<UserProductInfo>>.Success(userProducts.OrderByDescending(x => x.IsDefault), _localizer[CustomStatusKey.Success]);
        }
        return Result<IEnumerable<UserProductInfo>>.Success(Enumerable.Empty<UserProductInfo>(), _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
