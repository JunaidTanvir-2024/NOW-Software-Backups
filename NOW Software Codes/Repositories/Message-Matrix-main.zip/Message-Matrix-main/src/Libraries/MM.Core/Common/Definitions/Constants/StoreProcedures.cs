namespace MM.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class StoreProcedures
    {
        public const string AppLogUpsert = "mm_app_log_uppsert";
        public const string VendorLogInsert = "vndr_vendor_log_insert";
        public const string InsertSmsLog = "usp_InsertSmsLog";
        public const string InsertSmsLogging = "InsertSmsLogging";
        public const string GetMessageCount = "get_message_count";
        public const string GetMessageSent = "GetMessageSent";
    }
}
