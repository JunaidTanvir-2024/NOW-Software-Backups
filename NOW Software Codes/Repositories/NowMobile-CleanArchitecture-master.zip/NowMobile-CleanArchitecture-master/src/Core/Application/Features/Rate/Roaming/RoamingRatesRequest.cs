﻿using Application.Features.Rate.Model;
namespace Application.Features.Rate.Roaming;
public class RoamingRatesRequest : IRequest<Result<RoamingRate>>
{
    public int FromCountryCode { get; set; } = default!;
    public int ToCountryCode { get; set; } = default!;
}
