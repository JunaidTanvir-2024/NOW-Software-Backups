using System.Data;

using Dapper;

using FH.Core.Definitions;
using FH.Core.DTOs.Database;
using FH.Core.Entities;
using FH.Core.Extensions;
using FH.Core.Interfaces.Database;

using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

using Serilog;

namespace FH.Infrastructure.Persistence.Repositories;

internal sealed class CountryRepository(IConfiguration configuration, ILogger logger) : ICountryRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private readonly ILogger _logger = logger;

    public async Task<IEnumerable<CountryEntity>> GetCountries()
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var result = await connection.QueryAsync<CountryEntity>(AppConstants.Database.StoreProcedure.CountriesGetAll, commandType: CommandType.StoredProcedure);

                return result;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CountryRepository), nameof(GetCountries));
            return default!;
        }
    }

    public async Task<(IEnumerable<CountryDto.Response> countries, DatabasePaginationDto Pagination)> GetCountries(CountryDto.Request getCountryRequest)
    {

        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var table = new DataTable();
                table.Columns.Add("name", typeof(string));
                table.Columns.Add("calling_code", typeof(int));
                table.Columns.Add("iso_code2", typeof(string));
                table.Columns.Add("iso_code3", typeof(string));

                table.Rows.Add(getCountryRequest?.CountryFilters?.CountryName, getCountryRequest?.CountryFilters?.CountryCallingCode, getCountryRequest?.CountryFilters?.IsoCode2, getCountryRequest?.CountryFilters?.IsoCode3);

                var CountryParameters = new DynamicParameters();

                CountryParameters.Add("CountryFilters", value: table.AsTableValuedParameter(AppConstants.Database.TableType.CountryFilter));

                CountryParameters.Add("is_active", getCountryRequest?.IsActive);
                CountryParameters.Add("is_deleted", getCountryRequest?.IsDeleted);
                CountryParameters.Add("page", getCountryRequest?.Page);
                CountryParameters.Add("records_per_page", getCountryRequest?.RecordsPerPage);
                CountryParameters.Add("total_records", 0, direction: ParameterDirection.Output);
                CountryParameters.Add("total_pages", 0, direction: ParameterDirection.Output);

                var countries = await connection.QueryAsync<CountryDto.Response>(AppConstants.Database.StoreProcedure.CountriesGet, CountryParameters, commandType: CommandType.StoredProcedure);

                // Read the output parameters 
                var totalRecords = CountryParameters.Get<int>("total_records");
                var totalPages = CountryParameters.Get<int>("total_pages");

                return (countries, new DatabasePaginationDto() { TotalPages = totalPages, TotalRecords = totalRecords });
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, className: nameof(CountryRepository), methodName: nameof(GetCountries));
            return default!;
        }
    }

    public async Task<CountryDto.Response?> GetCountryByIsoCode(CountryByIsoCodeDto.Request getCountryByIsoCodeRequest)
    {
        try
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.Database.Name.FusionHub)))
            {
                var OperatorParameters = new DynamicParameters();
                OperatorParameters.Add("is_active", getCountryByIsoCodeRequest.IsActive);
                OperatorParameters.Add("is_deleted", getCountryByIsoCodeRequest.IsDeleted);
                OperatorParameters.Add("country_iso_code", getCountryByIsoCodeRequest.IsoCode);

                var country = await connection.QueryFirstOrDefaultAsync<CountryDto.Response>(AppConstants.Database.StoreProcedure.CountryByIsoCode, OperatorParameters, commandType: CommandType.StoredProcedure);

                return country;
            }
        }
        catch (Exception ex)
        {
            _logger.ErrorLog(ex, nameof(CountryRepository), methodName: nameof(GetCountries));
            return default!;
        }
    }
}
