﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Contracts
{
    public class GenericApiResponse<T>
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public T payload { get; set; }
    }
}
