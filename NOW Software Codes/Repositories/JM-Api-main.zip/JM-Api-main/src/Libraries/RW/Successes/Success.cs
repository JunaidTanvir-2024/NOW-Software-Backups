using RW.Common;
using RW.Models;

namespace RW.Successes;

public sealed class Success<T> : IResultWrapper<T>
{
    public Success(T? payload, string successMessage, int successCode, PaginationDto? pagination)
    {
        Payload = payload;
        Message = successMessage;
        Code = successCode;
        Pagination = pagination;
        ((IResultWrapper)this).Payload = payload;
    }
    bool IResultStatus.IsSuccess { get; set; } = true;
    public string Message { get; set; }
    public int Code { get; set; }
    public T? Payload { get; set; }
    public PaginationDto? Pagination { get; set; }
    T? IResultWrapper<T>.Errors { get; set; }
    object? IResultWrapper.Payload { get; set; }
    object? IResultWrapper.Errors { get; set; }
}
