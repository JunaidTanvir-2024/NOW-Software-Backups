﻿using Application.Features.Payment.Card.Models;
using Domain.Aggregate;
using System.Data;

namespace Application.Common.Interfaces.Repositories;

public interface IPaymentRepository : ISerivcesType.IScopedService
{
    Task<int> SaveOrderHistory(Order order, int MediumType);
    Task<int> UpdateOrderHistoryStatus(OrderStatusDetails orderStatus);
    Task<(bool, OrderDetails, IEnumerable<OrderItemDetails>)> GetOrderDetails(int orderId);


    Task<int> SaveFulfillmentRecord(List<FulfillmentItem> basket, string email, string transactionId, string msisdn);
    Task<IEnumerable<FulfillmentItem>> GetFulfillmentRecord(string transactionId);
    Task<FulfillmentResponse> DirectPaypalFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productCode);
    Task<FulfillmentResponse> Pay360paypalFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productItemCode);
    Task<FulfillmentResponse> CardFullfilment(string transactionId, string bundleRef, string amount, string productRef, string customerEmail, string productCode);
    Task<int> UpdateFulfillmentItems(int id, string msg, bool isemailsent);
    Task<bool> AnyActiveAutoRenewal(string account);
    Task<bool> AnyActiveMonthlyAutoRenewal(string account);
    Task<bool> ValidateRemoveCard(string account, string msisdn, string cardPanMasked);
    Task<bool> SetOffAllAutoTopupAutoRenewalWithCard(string account, string msisdn);
    Task<bool> ApplyInAppPurchaseCredit(decimal amount, string transactionId, string accountID);
}
