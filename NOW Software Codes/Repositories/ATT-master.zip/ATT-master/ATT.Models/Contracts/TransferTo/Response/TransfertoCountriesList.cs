﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransfertoCountriesList
    {
        public int authentication_key { get; set; }
        public int error_code { get; set; }
        public string error_txt { get; set; }
        public List<string> country { get; set; }
        public List<int> countryid { get; set; }
    }
}
