﻿using Microsoft.AspNetCore.Http;
using RW.Models;
using SC.Core.Features.Notification.Request;
using SC.Core.Features.Operators;
using SC.Core.Vendors.FusionHub;
using SC.Core.Vendors.Notification;
using SC.Core.Vendors.Notification.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Notification;
internal sealed class SendNotificationHandler : IRequestHandler<SendNotificationRequest, SendNotificationResponse>
{
    private readonly IMessageMatrixService _messageMatrixService;
    public SendNotificationHandler(IMessageMatrixService messageMatrixService, IHttpContextAccessor httpContextAccessor)
    {
        _messageMatrixService = messageMatrixService;

    }
    public async Task<SendNotificationResponse> Handle(SendNotificationRequest request, CancellationToken cancellationToken)
    {
        var response = await _messageMatrixService.SendEmailAsync(request);

        return response;
    }
}

