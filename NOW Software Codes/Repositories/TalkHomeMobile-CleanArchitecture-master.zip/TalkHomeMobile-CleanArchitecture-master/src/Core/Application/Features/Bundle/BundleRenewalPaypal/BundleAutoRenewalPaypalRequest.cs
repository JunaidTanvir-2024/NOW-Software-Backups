namespace Application.Features.Bundle.BundleRenewalPaypal;

public sealed class BundleAutoRenewalPaypalRequest : IRequest<Result<BundleAutoRenewalPaypalResponse>>
{
    public string Msisdn { get; set; } = default!;
    public int BundleId { get; set; } = default!;
    [JsonIgnore]
    public bool IsAutoRenew { get; set; } = default!;
    [JsonIgnore]
    public string? IpAddress { get; set; } = default!;
}

public class BundleAutoRenewalPaypalResponse
{
    public string? RedirectUrl { get; set; }
}