﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class LoginRequest
    {        
        public AppInfo AppInfo { get; set; }
        //public string Msisdn { get; set; }
        public bool IsAndroid { get; set; }
        public bool IsIOS { get; set; }
        public string IOSAllowedVersion { get; set; }
        public string AndroidAllowedVersion { get; set; }

    }
}
