﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    
    public enum TokenType
    {
        Basic = 1,
        Bearer = 2
    }
}
