﻿using Dapper;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.DAO;
using Models.DbConnections;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL
{
    public class DL_Porting : IDL_Porting
    {
        private readonly IDbConnectionSettings DbMNP;
        private readonly IDbConnectionSettings DbNowMobile;

        public DL_Porting(IOptions<ConnectionStrings> connectionString)
        {
            DbMNP = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            DbNowMobile = new DbConnectionSettings(new SqlConnection(connectionString.Value.NowMobileConnection));
        }
        public async Task<IEnumerable<Port>> GetPortingRequests(Port port)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@pEmail", port.Email);
                parameters.Add("@product", port.ProductId);
                parameters.Add("@Msisdn", port.NTMsisdn);

                var result = await DbMNP.SqlConnection.QueryAsync<Port, SwitchingInfo, Port>("MNP_Api_GetPortingRequests", (ports, switching) =>
                {
                    ports.SwitchingInfo = ports.SwitchingInfo ?? new SwitchingInfo();
                    ports.SwitchingInfo = switching;
                    return ports;
                }, parameters, splitOn: "PortingId", commandType: CommandType.StoredProcedure);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> InsertPortRequest(Port port)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", port.Email);
                parameters.Add("@Code", port.Code);
                parameters.Add("@CodeType", (int)port.CodeType);
                parameters.Add("@ReasonId", port.ReasonId);
                parameters.Add("@NTMsisdn", port.NTMsisdn);
                parameters.Add("@UserPortingDate", port.UserPortingDate);
                parameters.Add("@PortMsisdn", port.PortMsisdn);
                parameters.Add("@PortType", (int)port.PortType);
                parameters.Add("@ProductId", port.ProductId);
                parameters.Add("@RequestMediumType", (int)port.RequestMediumType);
                parameters.Add("@SubscriberId", port.SubscriberId);


                result = await DbMNP.SqlConnection.QueryFirstOrDefaultAsync<int>("MNP_Api_AddPortTransaction", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> UpdateUserPortingDate(Port port)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@PortingDate", port.PortDate);
                parameters.Add("@PortMsisdn", port.PortMsisdn);

                result = await DbMNP.SqlConnection.ExecuteAsync("MNP_Api_UpdateUserPortingDate", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<string> GetSubscriberId(string msisdn)
        {
            Product product = new Product();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Msisdn", msisdn);

                product = await DbNowMobile.SqlConnection.QueryFirstOrDefaultAsync<Product>("mnp_check_msisdn_v1", parameters, commandType: CommandType.StoredProcedure);
                if (product != null && product.error_code == 0)
                {
                    return product.subscriber_id.ToString();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GetTempMsisdnDbResponse> GetTempMsisdn(int orderReferenceId, Products product)
        {
            GetTempMsisdnDbResponse result = new GetTempMsisdnDbResponse();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@product_code", (product == Products.TalkHome) ? "thm" : ((product == Products.NowPayg) ? "nowpag" : ""));
                parameters.Add("@order_reference_id", orderReferenceId);
                parameters.Add("@msisdn", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 50);
                parameters.Add("@errorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@errorMessage", null, dbType: DbType.String, direction: ParameterDirection.Output, size: 100);

                await DbNowMobile.SqlConnection.QueryFirstOrDefaultAsync<GetTempMsisdnDbResponse>("porting_select_msisdn", parameters, commandType: CommandType.StoredProcedure);
                result.Msisdn = parameters.Get<string>("@msisdn");
                result.ErrorCode = parameters.Get<int>("@errorCode");
                result.ErrorMessage = parameters.Get<string>("@errorMessage");
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> ValidatePortingRequest(Port port)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", port.Email);
                parameters.Add("@PortType", (int)port.PortType);
                parameters.Add("@ProductId", port.ProductId);
                parameters.Add("@Msisdn", port.NTMsisdn);
                parameters.Add("@ValidationCode", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await DbMNP.SqlConnection.ExecuteAsync("MNP_Api_ValidatePortingRequest", parameters, commandType: CommandType.StoredProcedure);
                result = parameters.Get<int>("@ValidationCode");
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PortingCodeInfo> ValidatePortingBySMSRequest(Port port)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductId", port.ProductId);
                parameters.Add("@Msisdn", port.NTMsisdn);

               var resp= await DbMNP.SqlConnection.QueryFirstOrDefaultAsync<PortingCodeInfo>("MNP_Api_ValidatePortingBySMSRequest", parameters, commandType: CommandType.StoredProcedure);
                return resp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> CancelPortingRequest(Port port)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@RequestID", int.Parse(port.Id));

                result = await DbMNP.SqlConnection.ExecuteAsync("MNP_Api_CancelPortingRequest", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> InsertApiPortingRequest(Port port)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Code", port.Code);
                parameters.Add("@CodeType", (int)port.CodeType);
                parameters.Add("@ReasonId", port.ReasonId);
                parameters.Add("@NTMsisdn", port.NTMsisdn);
                parameters.Add("@UserPortingDate", DateTime.UtcNow);
                parameters.Add("@PortDate", port.PortDate);
                parameters.Add("@ExpiryDate", port.ExpiryDate);
                parameters.Add("@PortMsisdn", port.PortMsisdn);
                parameters.Add("@PortType", (int)port.PortType);
                parameters.Add("@ProductId", port.ProductId);
                parameters.Add("@RequestMediumType", (int)port.RequestMediumType);
                parameters.Add("@SubscriberId", port.SubscriberId);

                parameters.Add("@APIErrorMessage", port.APIErrorMessage);
                parameters.Add("@APIPortInRequestJson", port.APIPortInRequestJson);
                parameters.Add("@APIPortInResponseJson", port.APIPortInResponseJson);
                parameters.Add("@APIPortOutRequestJson", port.APIPortOutRequestJson);
                parameters.Add("@APIPortOutResponseJson", port.APIPortOutResponseJson);

                result = await DbMNP.SqlConnection.QueryFirstOrDefaultAsync<int>("MNP_Api_AddSmsPortingRequests", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<Product> GetProduct(string Msisdn)
        {
            Product product = new Product();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Msisdn", Msisdn);

                product = await DbNowMobile.SqlConnection.QueryFirstOrDefaultAsync<Product>("mnp_check_msisdn_v2", parameters, commandType: CommandType.StoredProcedure);
                if (product != null && product.error_code == 0)
                {
                    return product;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Port> GetPortingRequestsbyID(int id)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Id", id);

                var response = await DbMNP.SqlConnection.QueryFirstOrDefaultAsync<Port>("MNP_Api_GetPortingRequestsbyID", parameters, commandType: CommandType.StoredProcedure);
                return response;
            }
            catch
            {
                throw;
            }
        }
    }
}
