﻿var isMovePurchaseCallingCard = false;
//loadValidation();
function ValidationEmailProduct() {
    isMovePurchaseCallingCard = false;
    var email = $("#Email").val();
    $("#ErrorDiv").empty();
    $("#ordercard").prop('disabled', false);
    if (!email && !email.trim()) {
        return
    }
    $.ajax({
        beforeSend: function () {
            loader.mainloaderShow();
        },
        type: "GET",
        url: "/EmailProductVerification/" + email,
        async: true,
        success: function (json) {
            loader.mainloaderHide();
            if (json && json.errorCode == 0) {
                if (json.payload.isEmailExist && !json.payload.isProductExist) {

                    $("#passwordSection").hide();
                    $("#thrccsignupform").rules("remove", "ConfirmEmail Password ConfirmPassword ");
                    isMovePurchaseCallingCard = true;
                }
                else if (json.payload.isEmailExist && json.payload.isProductExist) {
                    $("#ErrorDiv").html($('#IsAuthenticated').val() == "True" ? '<label class="label"> Your email already registred with card' :'<label class="label"> Your email already registred with card, please <a href="/login">Login</a>'+ '</label>');
                    $("#ordercard").prop('disabled', true);
                } else {
                    $("#passwordSection").show();
                    //loadValidation();
                }
            }
        },
        complete: function () {
            loader.mainloaderHide();
        },
        error: function (error) {
        }
    });

} 


$("#thrccsignupform").on("submit", function (e) {
    e.preventDefault();
    $("#emailErrorDiv").hide();
    if ($("#thrccsignupform").valid() !== true) {
        return;
    }
    else {
        if (isMovePurchaseCallingCard) {
            
            $("#Password").val('');
           // window.location.href = "/buy-rechargeable-calling-card/" + $("#balance").val() + "/" + $("#Email").val();
            SubmitVirtulForm($("#Email").val(), $("#balance").val());
            return;
        }
        var model = {};
        model.Email = $("#Email").val();
        model.ConfirmEmail = $("#ConfirmEmail").val();
        model.FirstName = $("#FirstName").val();
        model.LastName = $("#LastName").val();
        model.Password = $("#Password").val();
        model.ConfirmPassword = $("#ConfirmPassword").val();
        $.ajax({
            beforeSend: function () {
                loader.mainloaderShow();
            },
            type: "POST",
            url: "/Account/Register",
            data: model,
            async: true,
            success: function (json) {
                if (json && json.errorCode == 4) {
                    if (json && json.errorCode == 4) {
                        window.location.href = "/login?isexist=true"
                    } 
                } else if (json && json.errorCode == 0) {
                    //window.location.href = "/buy-rechargeable-calling-card/" + $("#balance").val() +"/"+ $("#Email").val();
                    THCC_AirShip.AttachNamedUser($("#Email").val(), (val) => {
                        if (val) {
                            SubmitVirtulForm($("#Email").val(), $("#balance").val());
                        }
                        THCC_AirShip.AddTag(
                            THCC_AirShip.Tags.names.thrcc_signup_purchase_web,
                            THCC_AirShip.Tags.types.payment, true,
                            () => {
                                SubmitVirtulForm($("#Email").val(), $("#balance").val());
                            });
                    });
                }
            },
            complete: function () {
                loader.mainloaderHide();
            },
            error: function (error) {
            }
        });
    }
    return false;
});
function SubmitVirtulForm(email, id) {
    $('<form action="/buy-rechargeable-calling-card" method="POST"></form>')
        .append('<input name="ammount" value="' + id + '" />')
        .append('<input name="Email" value="' + email + '" />')
        .appendTo($('body')).submit();
}


(function ($) {
     $.validator.unobtrusive.adapters.add("comparestrings", ["otherprop", "ignorecase"],
        function (options) {
            options.rules["comparestrings"] = {
                otherPropName: options.params.otherprop,
                ignoreCase: options.params.ignorecase == "true"
            };
            options.messages["comparestrings"] = options.message;
        });
    $.validator.addMethod("comparestrings", function (value, element, params) {
        var value = $("#ConfirmEmail").val();
        var otherPropValue = $("#Email").val();
        //compare the values
        if (otherPropValue && value)
            var isMatch = value.toLowerCase() == otherPropValue.toLowerCase();

        return isMatch;
    });
  
}(jQuery));