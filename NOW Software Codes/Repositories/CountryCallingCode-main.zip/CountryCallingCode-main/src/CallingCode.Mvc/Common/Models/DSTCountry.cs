﻿namespace CallingCode.Mvc.Common.Models;

public class DSTCountry
{
    public bool HasDayLightSaving { get; set; }
    public bool IsDayLightSavingActive { get; set; }
}