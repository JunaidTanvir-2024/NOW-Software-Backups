﻿using System.Collections.Generic;


namespace ATT.Models.Contracts.Sochitel.Response
{
    public class GetTransaction
    {
        public OperatorInfo value { get; set; }     //Object containing operator’s details
        public string msisdn { get; set; }          //Only for Mobile Top Up and Mobile Data products. Phone number in international format, without leading 0 or +
        public OperatorUserFloat amount { get; set; }    //Object containing the amount’s details
        public OperatorUserString currency { get; set; }  //Object containing the currency’s details
        public IDName country { get; set; }   //Object containing country’s details
        public int productId { get; set; }          //Transaction’s product ID
        public bool simulation { get; set; }        //true if the transaction was only a simulation    false if this is real transaction
        public int id { get; set; }                 //ARTX transaction ID
        public string userReference { get; set; }   //User reference ID (only if set by the user in the request)
        public TransactionBalance balance { get; set; }     //Object containing all the balance’s details
        public Pin pin { get; set; }        //Only for Mobile PIN products. Object containing PIN’s details
        public List<string> alternativeProducts { get; set; }   //Set only if the transaction fails with error code 52 (A mbiguous product, please specify productId ) containing the IDs of the products that match with the amount specificed in the request
    }
}

