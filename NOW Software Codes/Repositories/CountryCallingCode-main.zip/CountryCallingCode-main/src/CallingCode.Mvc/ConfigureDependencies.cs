﻿using CallingCode.Mvc.Common.Services.GeoLocation;
using CallingCode.Mvc.Common.Services.OpenMeteo;
using CallingCode.Mvc.Persistence;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace CallingCode.Mvc;

public static class ConfigureDependencies
{

    public static WebApplicationBuilder AddWebDependencies(this WebApplicationBuilder builder)
    {
        // Add services to the container.
        builder.Services.AddControllersWithViews();
        builder.Services.AddLogging();
        builder.Services.AddHttpClient();
        //builder.Services.AddSession();
        //builder.Services.AddSingleton<ITempDataProvider, SessionStateTempDataProvider>();
        builder.Services.AddHttpContextAccessor();
        builder.Services.AddTransient<IGeoLocation, GeoLocation>();
        builder.Services.AddTransient<IOpenMeteoImplementation, OpenMeteoImplementation>();
        builder.BindCountries();
        return builder;
    }

}
