﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;

namespace TalkhomeAPI.Infrastructure.Common.Services.Implementations
{
    public class ATTService : IATTService
    {
        private readonly HttpClient _httpClient;
        private readonly IHelperService _helperService;
        private readonly ATTConfig _attConfig;

        public ATTService(HttpClient httpClient,
                            IOptions<ATTConfig> attConfig,
                            IHelperService helperService)
        {
            _httpClient = httpClient;
            this._helperService = helperService;
            _attConfig = attConfig.Value;
        }

        public async Task<GetProductResponse> GetProducts(string fromMsisdn, string toMsisdn, string currencyAccount)
        {
            string endpoint = "";
            if (_attConfig.IsDToneEndpoint == true)
            {
                endpoint = $"{_attConfig.ApiEndPoint}DTOneProducts?fromMSISDN={fromMsisdn}&destinationMSISDN={toMsisdn}&account={currencyAccount}&product=THA&productItemCode={ProductItemCode.THADTW}";
            }
            else
            {
                endpoint = $"{_attConfig.ApiEndPoint}THAGetOperatorProductsMSISDN?fromMSISDN={fromMsisdn}&destinationMSISDN={toMsisdn}&account={currencyAccount}&productCode=THA&productItemCode={ProductItemCode.THADTW}";
            }

            var output = await _httpClient.GetAsync(endpoint);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<GetProductResponse>(outputData);
            }

            return null;
        }

        public async Task<ExecuteDataResponse> Execute(ExecuteDataRequest request)
        {

            string endPoint = "";
            if (_attConfig.IsDToneEndpoint == true)
            {
                endPoint = $"{_attConfig.ApiEndPoint}DTOneExecute";
            }
            else
            {
                endPoint = $"{_attConfig.ApiEndPoint}THAExecute";
            }
            var Json = JsonConvert.SerializeObject(request);

            var content = new StringContent(Json, Encoding.UTF8, "application/json");

            var output = await _httpClient.PostAsync(endPoint, content);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<ExecuteDataResponse>(outputData);
            }
            return null;
        }
        public async Task<TransferCountriesResponse> GetDTOneCountriesAsync(string continent)
        {
            var model = new TransferCountriesResponse();
            string endPoint = $"{_attConfig.ApiEndPoint}TransferToCountriesWithOperatorNames?continent={continent}";

            var output = await _httpClient.GetAsync(endPoint);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                var dtOneCountries = JsonConvert.DeserializeObject<AttResponse<CountriesWithOperatorNamesPayloadResponse>>(outputData);
                model.Countries = (from c in dtOneCountries.payLoad.Countries
                                   select new TransferCountriesResponse.TransferCountry()
                                   {
                                       CountryId = c.CountryCode,
                                       Name = c.CountryName,
                                       Code = c.CountryCode,
                                       OperatorsCount = c.OperatorCount,
                                       OperatorsName = c.OperatorNames,
                                       Continent = c.Continent
                                   }).ToList();
                model.Promotions = dtOneCountries.payLoad.Promotions;
                return model;
            }

            return null;
        }
        public async Task<TransferOperatorsByCountryResponse> GetDTOneOperatorsByCountryAsync(string currency, string countryName)
        {
            var model = new TransferOperatorsByCountryResponse();
            string endPoint = $"{_attConfig.ApiEndPoint}TransferToOperatorsWithPromotions?countryName={countryName}";

            var output = await _httpClient.GetAsync(endPoint);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                var dtOneOperators = JsonConvert.DeserializeObject<AttResponse<DTOneOperatorsPayloadResponse>>(outputData);
                if (dtOneOperators.errorCode == 0)
                {
                    model.Operators = dtOneOperators.payLoad.operators;
                    model.Promotions = dtOneOperators.payLoad.promotions;
                    return model;
                }
                return null;
            }

            return null;
        }
        //public async Task<TransferOperatorDetailsResponse> GetDTOneOperatorDetailsAsync(string currency,string operatorId)
        //{
        //    var model = new TransferOperatorDetailsResponse();
        //    string endPoint = $"{_attConfig.ApiEndPoint}transferToOperatorPriceList?currency={currency}&OperatorID={operatorId}";

        //    var output = await _httpClient.GetAsync(endPoint);

        //    if (output.IsSuccessStatusCode)
        //    {
        //        string outputData = await output.Content.ReadAsStringAsync();
        //        var dtOneOperators = JsonConvert.DeserializeObject<AttResponse<DTOneOperatorDetailsResponse>>(outputData);
        //        var operatorDetailsXml = dtOneOperators.payLoad.data;
        //        //Parse XML details
        //        XmlSerializer serializer = new XmlSerializer(typeof(DTOneOperatorDetails));
        //        using (StringReader reader = new StringReader(operatorDetailsXml))
        //        {
        //            var operatorDetails = serializer.Deserialize(reader);
        //            model.Details = (DTOneOperatorDetails)operatorDetails;
        //        }
        //        return model;
        //    }

        //    return null;
        //}
        public async Task<TransferOperatorDetailsResponse> GetTransferToOperatorDetailsAsync(string countryName, string operatorName)
        {
            var model = new TransferOperatorDetailsResponse();
            string endPoint = $"{_attConfig.ApiEndPoint}TransferToOperatorDetails?countryName={countryName}&operatorName={operatorName}";

            var output = await _httpClient.GetAsync(endPoint);

            if (output.IsSuccessStatusCode)
            {
                string outputData = await output.Content.ReadAsStringAsync();
                var dtOneOperators = JsonConvert.DeserializeObject<AttResponse<DTOneOperatorDetailsResponse>>(outputData);
                if (dtOneOperators.errorCode == 0)
                {
                    model.Details = dtOneOperators.payLoad.OperatorDetails;
                    model.Operators = dtOneOperators.payLoad.Operators;
                    model.Promotions = dtOneOperators.payLoad.Promotions;
                    return model;
                }
                return null;
            }

            return null;
        }
    }
}
