﻿using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.TwelveMonthBundle;
public class TwelveMonthBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}