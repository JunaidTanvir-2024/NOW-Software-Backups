﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Models.Contracts.Request
{
    public class ValidateBundleRequest
    {
        [Required,StringLength(36)]
        public string BundleId { get; set; }
    }
}
