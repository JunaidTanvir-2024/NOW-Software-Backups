﻿using System;
using System.Collections.Generic;
using System.Text;

namespace THM.Models.Database
{
    public class DbFullfilmentResult
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
}
