﻿//International Rates List
var InternationalRatesList_home = [];

$(document).ready(function () {

    $("#FastTopUp_Msisdn").val('');

    /****
     * Calling  Get International Rates
     * Calling  Get All Countries
     *******/

    GetAllCountires_home();
    GetAllInternationalRates_home();


    /****
    * Detect Enter Button
    *******/

    $(document).keypress(function (e) {
        if (e.which == 13) {
            if ($('.mfp-content').is(":visible")) {       //Detect Login/Register Modal 

                if ($('#register-form').is(":visible")) {     //Detect Register Form
                    $('#RegisterBtn').click();
                }
                else {                          //SignIn Form
                    $('#LoginBtn').click();
                }

            }
            else {

                if ($('#topup-tab').hasClass('active')) {    // Detect AutoTop
                    $('#btnFastTopUp').click();
                }
                else {                                  // Detect FreeSim
                    $('#btnFreeSim_home').click();
                }

            }
        }
    });


    /****
    * On KeyUp FastTopuUp button
    *******/
    var IsValidNumber = false;

    var FastTopUpNumber = (function () {
        var timer = 0;
        return function (callback, ms) {
            clearTimeout(timer);
            timer = setTimeout(callback, ms);
        };
    })();

    $("#FastTopUp_Msisdn").keyup(function () {

        IsValidNumber = false;

        if ($('#FastTopUpForm').valid()) {
            FastTopUpNumber(function () {

                $.ajax({
                    url: "/Account/ValidateMsisdn",
                    type: "POST",
                    data: { Msisdn: $('#FastTopUp_Msisdn').val() },
                    beforeSend: function (xhr) {
                        $('#switch-normal1').bootstrapToggle('off');
                        $('.home-loading-bar').fadeIn();
                        $('#btnFastTopUp_home').attr('disabled', true);
                        $("#FastTopUp_Msisdn").attr('disabled', true);
                        $('#FastTopUp_Msisdn_ValidCheck').hide();
                        $('#FastTopUp_Msisdn_Error').text('').hide();
                        $('#FastTopUp_Msisdn').removeClass('input-validation-error');
                        $('#home_AutoTopUpSection').hide();
                    },
                    success: function (response) {
                        if (response != null) {
                            if (response.status == true && response.errorCode == 0) {

                                //Not Valid
                                if (response.data == 1) {
                                    $('#FastTopUp_Msisdn').addClass('input-validation-error');
                                    $('#FastTopUp_Msisdn_Error').text('Invalid number').show();
                                }
                                else if (response.data == 2 || response.data == 3 || response.data == 4) {
                                    $('#FastTopUp_Msisdn_ValidCheck').show();
                                    IsValidNumber = true;
                                }
                                else if (response.data == 5) {
                                    $("#home_AutoTopUpSection").show();
                                    IsValidNumber = true;
                                }
                                else if (response.data == 6) {
                                    $("#home_AutoTopUpSection").show();
                                    IsValidNumber = true;
                                    $('#switch-normal1').bootstrapToggle('on');
                                    $('#switch-normal1').val(true);
                                }
                            }
                            else {
                                $('#FastTopUp_Msisdn').addClass('input-validation-error');
                                $('#FastTopUp_Msisdn_Error').text(response.message).show();
                            }
                        }
                        else {
                            $('#FastTopUp_Msisdn_Error').text('Something went wrong on server').show();
                        }
                    },
                    complete: function (xhr, status) {
                        $('#btnFastTopUp_home').attr('disabled', false);
                        $("#FastTopUp_Msisdn").attr('disabled', false);
                        $('.home-loading-bar').fadeOut();
                    },
                    error: function (xhr, status, error) {
                        $('#FastTopUp_Msisdn_Error').text('Something went wrong on server').show();
                        $('#FastTopUp_Msisdn').addClass('input-validation-error');
                    }
                });

            }, 500);
        }
        else {
            $('#switch-normal1').bootstrapToggle('off');
            $("#home_AutoTopUpSection").hide();
            return false;
        }
    });

    $('#btnFastTopUp_home').click(function () {

        if ($('#FastTopUpForm').valid()) {
            if (IsValidNumber) {
                var toggleval = $('#switch-normal1').is(':checked');

                if (toggleval) {
                    $('#FastTopUpIsAutoTopUp').val(true);
                }
                else {
                    $('#FastTopUpIsAutoTopUp').val(false);
                }

                $('#FastTopUpForm').submit();
            }
            else {
                $.ajax({
                    url: "/Account/ValidateMsisdn",
                    type: "POST",
                    data: { Msisdn: $('#FastTopUp_Msisdn').val() },
                    beforeSend: function (xhr) {
                        $('.home-loading-bar').fadeIn();
                        $('#btnFastTopUp_home').attr('disabled', true);
                        $("#FastTopUp_Msisdn").attr('disabled', true);
                        $('#FastTopUp_Msisdn_ValidCheck').hide();
                        $('#FastTopUp_Msisdn_Error').text('').hide();
                        $('#FastTopUp_Msisdn').removeClass('input-validation-error');
                        $('#home_AutoTopUpSection').hide();
                    },
                    success: function (response) {
                        if (response != null) {
                            if (response.status == true && response.errorCode == 0) {

                                //Not Valid
                                if (response.data == 1) {
                                    $('#FastTopUp_Msisdn').addClass('input-validation-error');
                                    $('#FastTopUp_Msisdn_Error').text('Invalid number').show();
                                }
                                else if (response.data == 2 || response.data == 3 || response.data == 4) {
                                    $('#FastTopUp_Msisdn_ValidCheck').show();
                                    IsValidNumber = true;
                                }
                                else if (response.data == 5) {
                                    $("#home_AutoTopUpSection").show();
                                    IsValidNumber = true;
                                }
                                else if (response.data == 6) {
                                    $("#home_AutoTopUpSection").show();
                                    IsValidNumber = true;
                                    $('#switch-normal1').bootstrapToggle('on');
                                    $('#switch-normal1').val(true);
                                }
                            }
                            else {
                                $('#FastTopUp_Msisdn').addClass('input-validation-error');
                                $('#FastTopUp_Msisdn_Error').text(response.message).show();
                            }
                        }
                        else {
                            $('#FastTopUp_Msisdn_Error').text('Something went wrong on server').show();
                        }
                    },
                    complete: function (xhr, status) {
                        $('#btnFastTopUp_home').attr('disabled', false);
                        $("#FastTopUp_Msisdn").attr('disabled', false);
                        $('.home-loading-bar').fadeOut();
                    },
                    error: function (xhr, status, error) {
                        $('#FastTopUp_Msisdn_Error').text('Something went wrong on server').show();
                        $('#FastTopUp_Msisdn').addClass('input-validation-error');
                    }
                });
            }
       
        }
        else {
            return false;
        }
    });


    /****
    * Remove Custom Validation Error From Msisdn Field In FastTopup Form
    *******/
    $('#FastTopUp_Msisdn').keyup(function () {
        $('#FastTopUp_Msisdn_Error').text('').hide();
        $('#FastTopUp_Msisdn').removeClass('input-validation-error');
    });

});


/****
 * Get International Rates
 * Get All Countries
 *******/

function GetAllCountires_home() {

    $.ajax({
        url: "/Home/GetAllCountries",
        type: "GET",
        beforeSend: function (xhr) {

        },
        success: function (response) {
            var options = $("#dpl_InternationalCountry");
            $.each(response.data.countries, function () {
                options.append(new Option(this.name, this.id));
            });
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

        }
    });

}

function GetAllInternationalRates_home() {
    $.ajax({
        url: "/Home/GetInternationalRates",
        type: "GET",
        beforeSend: function (xhr) {

        },
        success: function (response) {
            InternationalRatesList_home = response.data.internationalRatesList;
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {
        }
    });

}

function GetSpecificInternationalRates_home() {

    var CountryID = $('#dpl_InternationalCountry').val();
    var InternationalRatesData = InternationalRatesList_home.filter(function (x) { return x.countryId === parseInt(CountryID) });

    if (InternationalRatesData != undefined) {
        $('#Rates_IR_Landline').html(parseFloat(parseFloat(InternationalRatesData[0].landlineRate) * 100).toFixed(0) + "p");
        $('#Rates_IR_Mobile').html(parseFloat(parseFloat(InternationalRatesData[0].mobileRate) * 100).toFixed(0) + "p");
        $('#Rates_IR_Text').html(parseFloat(parseFloat(InternationalRatesData[0].smsRate) * 100).toFixed(0) + "p");
        $('.IRduration').show();
    }
    else {
        $('#Rates_IR_Landline').text('');
        $('#Rates_IR_Mobile').html('');
        $('#Rates_IR_Text').html('');
        $('.IRduration').hide();
    }
}

/****
 * Validate Msisdn 
 *******/
function MsisdnValidation_home(evt) {

    var TotalLength = $("#" + evt.currentTarget.id).val().length;
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }

    // Regex
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
    // length
    if (TotalLength >= 12) {
        theEvent.returnValue = false;
        theEvent.preventDefault();
    }
}


/****
 * Buy Plan from homepage
 *******/
function BuyPlan_home(current) {
    $('#SelectedPlan_Id').val(current.dataset.id);
    $('#BundleBuyForm').submit();
}