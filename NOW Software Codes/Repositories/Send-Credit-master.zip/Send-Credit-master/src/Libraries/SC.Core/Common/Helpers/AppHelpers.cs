﻿using System.Net.Mail;
using System.Text.RegularExpressions;

namespace SC.Core.Common.Helpers;
public abstract class AppHelpers
{
    public static string GetCorrelationId()
    {
        return Guid.NewGuid().ToString();
    }
    public static bool IsValidEmail(string email)
    {
        return  Regex.IsMatch(email, @"^[^\W_](?:[\w.-]*[^\W_])?@(?:\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.|(?:[\w-]+\.)+)(?:[a-zA-Z]{2,3}|[0-9]{1,3})\]?$");
    }
}

