﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static THCCWEB.Utilities.Enum;

namespace THCCWEB.Models.ApiContracts.Response
{
    public class UserProductsResponseModel
    {
        public int Id { get; set; }
        public ProductType ProductName { get; set; }
        public int UserId { get; set; }
        public string ProductRef { get; set; }
        public DateTime DateCreated { get; set; }
        public bool IsActive { get; set; }
        public string AccountId { get; set; }
        public string ProductCode { get; set; }
        public string Reference { get; set; }
    }
}
