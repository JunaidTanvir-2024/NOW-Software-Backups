namespace Application.Common.Enums;

public enum BundleType
{
    PAYG = 1,
    Rolling,
    BoltOn,
    PennyPro
}
public enum BundleCategory
{
    National = 1,
    International,
    DataOnly
}
public enum CheckoutJourneyTypes
{
    FreeSim = 1,
    PlanFreeSim = 2,
    TopupFreeSim = 3,
    MyPlan = 4,
    FastBuy = 5,
    MyTopup = 6,
    FastTopup = 7,
    SimLandingPage = 8,
    SimOrderingLandingPage = 9,
    CreditSim
}
