namespace Application.Features.Rate.Uk;

public class UkRatesRequestValidator : IRequest<Result<object>>
{

}
