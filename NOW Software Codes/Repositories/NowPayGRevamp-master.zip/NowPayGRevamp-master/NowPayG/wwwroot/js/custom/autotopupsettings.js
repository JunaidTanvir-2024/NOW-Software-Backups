﻿
$(document).ready(function () {

    ShowAutoTopUpSettings($('#dplUserProducts').val());

    $('#dplUserProducts').change(function () {
        ShowAutoTopUpSettings($(this).val());
    });

    $('#BtnSavSettings_topup').click(function () {

        if (!$('#AutoTopUpSettingsForm').valid()) {
            returun;
        }
        else {
            $.ajax({
                url: "/Pay360/SetAutoTopup",
                type: "POST",
                data: {
                    productRef: $('#dplUserProducts').val(),
                    topupAmount: $('#topupAmount').val(),
                    thresholdBalanceAmount: $('#thresholdBalanceAmount').val(),
                    isAutoTopup: $('#isAutoTopup').is(":checked")
                },
                beforeSend: function (xhr) {
                    $('#SavSettingsFailureAlert_topup, #SavSettingsSuccessAlert_topup, #NoCardsFailureAlert_topup').hide();
                    $('#BtnSavSettings_topup').attr('disabled', true);
                    $('#Spinner_SavSettings_topup').fadeIn();
                },
                success: function (response) {

                    if (response != null) {
                        if (response.cards == false) {
                            $('#NoCardsFailureAlert_topup').slideDown();
                        }
                        else {
                            if (response.status == true) {
                                $('#SavSettingsSuccessMessage_topup').text(response.message);
                                $('#SavSettingsSuccessAlert_topup').slideDown().delay(3000).slideUp();
                            }
                            else {
                                $('#SavSettingsFailureMessage_topup').text(response.message);
                                $('#SavSettingsFailureAlert_topup').slideDown().delay(5000).slideUp();
                            }
                        }
                    }
                    else {
                        $('#SavSettingsFailureMessage_topup').text('Something went wrong on server.');
                        $('#SavSettingsFailureAlert_topup').slideDown().delay(3000).slideUp();
                    }
                },
                complete: function (xhr, status) {

                    $('#BtnSavSettings_topup').attr('disabled', false);
                    $('#Spinner_SavSettings_topup').hide();
                },
                error: function (xhr, status, error) {
                    $('#SavSettingsFailureMessage_topup').text('Something went wrong on server.');
                    $('#SavSettingsFailureAlert_topup').slideDown().delay(3000).slideUp();
                }
            });
        }
    });
});

function ShowTopUpForm_AutoTopUp() {
    $('#TopupForm-AutoTopUp').submit();
}

function ShowAutoTopUpSettings(ID) {
    $.ajax({
        url: "/Pay360/GetAutoTopup",
        type: "POST",
        data: { productRef: ID },
        beforeSend: function (xhr) {
            $('#SavSettingsFailureAlert_topup, #SavSettingsSuccessAlert_topup').hide();
            $('.loading-bar').show();
        },
        success: function (response) {
            if (response != null) {
                if (response.status == true) {
                    $('#thresholdBalanceAmount').val(response.data.thresHold);
                    $('#topupAmount').val(response.data.topup);
                    $('#isAutoTopup').prop("checked", response.data.status);
                    $('.AutoTopUpContent_topup').show();
                }
                else {
                    $('.AutoTopUpContent_topup').hide();
                    $('#SavSettingsFailureMessage_topup').text(response.message);
                    $('#SavSettingsFailureAlert_topup').show();
                }
            }
            else {
                $('.AutoTopUpContent_topup').hide();
                $('#SavSettingsFailureMessage_topup').text('Something went wrong on server.');
                $('#SavSettingsFailureAlert_topup').show();
            }
        },
        complete: function (xhr, status) {
            $('.loading-bar').hide();
        },
        error: function (xhr, status, error) {
            $('.AutoTopUpContent_topup').hide();
            $('#SavSettingsFailureMessage_topup').text('Something went wrong on server.');
            $('#SavSettingsFailureAlert_topup').show();
        }
    });
}

function NumberValidation_autotopup(evt) {

    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]/;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}
