﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    public class FullfilmentResponse
    {

        public string ErrorMessage { get; set; }
        public int ErrorCode { get; set; }
        public int? audit_id { get; set; }
        public int new_balance { get; set; }
        public string Pin { get; set; }
        public string productRef { get; set; }
        public string BundleName { get; set; }
        public FullfilmentAudit Audit { get; set; }
        public string Card { get; set; }
    }
    public enum TransactionsPaymentType
    {
        Card = 1,
        Paypal = 2,
        Points,
        Referee,
        Referrer
    }
    public class FullfilmentAudit
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
    public class AccountBalance
    {
        public float new_balance { get; set; }

        public int audit_id { get; set; }

    }
}
