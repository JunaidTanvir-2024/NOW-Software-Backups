﻿using System.ComponentModel.DataAnnotations;

namespace SenderService.Core.Features.Email.Request;

public class ValidateEmailRequest
{
    [EmailAddress]
    public string Email { get; set; } = default!;
    public string ProductCode { get; set; } = default!;
    public string? IpAddress { get; set; }
}