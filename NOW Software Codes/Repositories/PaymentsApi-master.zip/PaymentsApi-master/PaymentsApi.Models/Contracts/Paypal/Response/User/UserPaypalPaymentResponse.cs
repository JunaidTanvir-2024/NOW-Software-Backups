﻿using Newtonsoft.Json;
using PaymentsApi.Models.Contracts.Pay360.Response.Api;
using PaymentsApi.Models.Contracts.Pay360.Response.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Contracts.Paypal.Response.User
{
    public class UserPaypalPaymentResponse
    {
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }
        [JsonProperty("transactionId")]
        public string TransactionId { get; set; }
        [JsonProperty("transactionAmount")]
        public string TransactionAmount { get; set; }
       
        [JsonProperty("outcome")]
        public OutcomeModel OutcomeModel { get; set; }
        //[JsonProperty("processing")]
        //public ProcessingModel Processing { get; set; }
        [JsonProperty("clientRedirectUrl")]
        public string ClientRedirectUrl { get; set; }

        [JsonProperty("checkoutToken")]
        public string CheckoutToken { get; set; }

        //[JsonProperty("basketResponse")]
        //public List<BasketItemsResponse> BasketResponse { get; set; }
    }
}
