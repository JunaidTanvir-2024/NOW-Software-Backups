﻿using SC.Core.Features.Contacts.Requests;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.Contacts
{
    internal class DeleteContactPersonHandler : IRequestHandler<DeleteContactPersonRequest, IResultWrapper>
    {
        private readonly IContactPersonRepository _contactPersonRepository;

        public DeleteContactPersonHandler(IContactPersonRepository contactPersonRepository)
        {
            this._contactPersonRepository = contactPersonRepository;
        }

        public async Task<IResultWrapper> Handle(DeleteContactPersonRequest request, CancellationToken cancellationToken)
        {
            var res = await _contactPersonRepository.DeleteContactPerson(request.Id);
            return ResultWrapper.Success(res);
        }
    }
}