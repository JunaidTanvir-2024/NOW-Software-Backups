﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Response
{
    public class OperatorMinMaxPrice
    {
        public OperatorUserString min { get; set; }
        public OperatorUserString max { get; set; }

        public string @operator { get; set; }
        public string user { get; set; }
    }
}
