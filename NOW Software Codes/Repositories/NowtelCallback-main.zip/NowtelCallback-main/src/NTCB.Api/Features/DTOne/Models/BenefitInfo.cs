﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class BenefitInfo
{
    [JsonPropertyName("additional_information")]
    public object? AdditionalInformation { get; set; }
    
    [JsonPropertyName("amount")]
    public AmountInfo? Amount { get; set; }
    
    [JsonPropertyName("type")]
    public string? Type { get; set; }
    
    [JsonPropertyName("unit")]
    public string? Unit { get; set; }
    
    [JsonPropertyName("unit_type")]
    public string? UnitType { get; set; }
}
