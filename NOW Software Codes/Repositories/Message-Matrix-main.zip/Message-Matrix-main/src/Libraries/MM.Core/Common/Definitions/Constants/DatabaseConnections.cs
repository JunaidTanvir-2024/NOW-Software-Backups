namespace MM.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class DatabaseConnections
    {
        public const string MessageMatrix = "MessageMatrix";
    }
}
