﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class SuccessReturnPayPalViewModel
    {
        public string uRef { get; set; }
        public string paymentId { get; set; }
        public string token { get; set; }
        public string PayerID { get; set; }
        public string ProductCode { get; set; }
        public string bundleId { get; set; }
        public string bundleName { get; set; }
        public string Amount { get; set; }
        public string Msisdn { get; set; }
        public CheckOutTypes CheckOutType { get; set; }
    }
}
