﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class CustomerRatingConfig 
    {
        public string ApiURL { get; set; }
    }
}
