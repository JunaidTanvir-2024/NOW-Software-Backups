﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.InAppModels
{
    public class InAppSecure3DTopUpViewModel
    {
        public string MD { get; set; }
        public string PaRes { get; set; }

        public int UserId { get; set; }
        public string Currency { get; set; }
    }
}
