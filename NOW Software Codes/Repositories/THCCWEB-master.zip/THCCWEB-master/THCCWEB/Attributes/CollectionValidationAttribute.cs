﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Attributes
{
    public class CollectionValidationAttribute : ValidationAttribute
    {
        private readonly int[] values;

        public CollectionValidationAttribute(int[] values)
        {
            this.values = values;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (!values.Contains((int)value))
                return new ValidationResult("Invalid amount");

            return ValidationResult.Success;
        }
    }
}
