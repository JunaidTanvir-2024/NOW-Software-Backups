﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Services.Interfaces;

namespace TalkhomeAPI.Services.Services
{
    public class CommonService : ICommonService
    {
        private readonly IAddressService _addressService;

        public CommonService(IAddressService addressService)
        {
            _addressService = addressService;
        }

        public async Task<GenericApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(
            GetAddressByPostCodeRequestModel model)
        {
            var addressRespons = new GetAddressByPostCodeResponseModel();

            var response = await _addressService.GetAddress(model.PostCode);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                var addresseslist = await response.Content.ReadAsStringAsync();
                addressRespons.AddressData = JsonConvert.DeserializeObject<AddressModel>(addresseslist);

                return GenericApiResponse<GetAddressByPostCodeResponseModel>.Success(
                                                                addressRespons, "Found addresses successfully");

            }
            else if (response.StatusCode == HttpStatusCode.NotFound
                || response.StatusCode == HttpStatusCode.BadRequest)
            {
                return GenericApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                                                null,"No address found",ApiStatusCodes.NoAddressFound);
            }
            else if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                //send email + message to management


                return GenericApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                                    null, "No address found", ApiStatusCodes.NoAddressFound);
            }

            return GenericApiResponse<GetAddressByPostCodeResponseModel>.Failure(
                                             null, "Something went wrong on server", ApiStatusCodes.InternalServerError);
        }
    }
}
