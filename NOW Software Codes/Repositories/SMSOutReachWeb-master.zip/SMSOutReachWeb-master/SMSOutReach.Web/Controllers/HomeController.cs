﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Modal.Xeebi;
using SMSOutReach.Web.Models;
using System.Data;
using System.IO;
using Microsoft.AspNetCore.Http;
using OfficeOpenXml;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Threading;
using SMSOutReach.Modal.Configurations;

namespace SMSOutReach.Web.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private ISMSCarrier SMSCarrier;
        private ISenderProduct SenderProduct;
        private ISMSJob SMSJob;

        public static List<ViewSmsJob> PendingJobIds { get; set; }

        public HomeController(ISMSCarrier smsCarrier, ISenderProduct senderProduct, ISMSJob smsJob)
        {
            SMSCarrier = smsCarrier;
            SenderProduct = senderProduct;
            SMSJob = smsJob;
        }


        public IActionResult Default()
        {
            return View();
        }


        [HttpGet]
        public IActionResult Index()
        {

            var productlist = SenderProduct.GetSenderProducts();

            var carrierlist = SMSCarrier.GetAllSMSCarriers();

            SMSJobViewModel model = new SMSJobViewModel();

            model.SMSCarriers = carrierlist.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.ID.ToString()
            }).ToList();

            model.SenderProducts = productlist.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.ID.ToString()
            }).ToList();

            return View(model);
        }



        /// <summary>
        /// Create SMS job's  , this methid create jobs which have to start now or schedule for future 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        /// 

        [HttpPost]
        public async Task<IActionResult> AddSMSJob(SMSJobViewModel model)
        {

            try
            {
                var user = User.FindFirst(ClaimTypes.NameIdentifier).Value;
                model.UserName = user;
                // var userId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);


                if (ModelState.IsValid)
                {
                    string Msisdns = Regex.Replace(model.MSISDN, @"\t|\n|\r", "");
                    string[] MSISDNList = Msisdns.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    MSISDNList = MSISDNList.Distinct<string>().ToArray();
                    DataTable tblMSISDN = new DataTable();
                    tblMSISDN.Columns.Add("UserMsisdn", typeof(string));
                    tblMSISDN.Columns.Add("MessageId", typeof(string));
                    for (int i = 0; i < MSISDNList.Length; i++)
                    {
                        DataRow row = tblMSISDN.NewRow();
                        DateTime date = DateTime.UtcNow;
                        string messageId = "SmsOutReach_" + date.Day.ToString() + date.Month.ToString() + date.Year.ToString() + date.Hour.ToString() + date.Minute.ToString() + date.Second.ToString() + date.Millisecond.ToString();
                        row["UserMsisdn"] = MSISDNList[i];
                        row["MessageId"] = messageId;
                        tblMSISDN.Rows.Add(row);
                        Thread.Sleep(1);
                    }


                    string datetime = model.datetimepicker;

                    DateTime StartTime;
                    if (datetime == null || datetime == string.Empty)
                    {
                        StartTime = DateTime.UtcNow;
                    }
                    else  // scheduled jobs
                    {
                        var localdt = DateTime.ParseExact(datetime, "yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture);

                        // convert to UTC
                        var utcdt = TimeZoneInfo.ConvertTimeToUtc(localdt, TimeZoneInfo.Local);

                        StartTime = utcdt;

                    }



                    SMSJob jobViewModel = new SMSJob
                    {
                        Campaign = model.Campaign,
                        Message = model.Message,
                        CarrierId = int.Parse(model.CarrierId),
                        CreatedDate = DateTime.UtcNow,
                        Index = 1,
                        SenderProductID = int.Parse(model.ProductId),
                        UserId = model.UserName,
                        StartTime = StartTime,
                        FirstJobIndex = -1,
                        SecondJobIndex = 1,
                        FirstPendingJobId = -1,
                        SecondPendingJobId = -1,
                        SmsCount = MSISDNList.Length
                    };




                    TimeSpan diff = StartTime - DateTime.UtcNow;

                    // check starttime of job should greater or equal than current utc time.
                    if (diff.Minutes >= 0)
                    {
                        // get pending jobs 

                        int carrier = int.Parse(model.CarrierId);
                        var pendingjobs = await SMSJob.GetPendingSMSJobs(StartTime, carrier);

                        if (pendingjobs != null && pendingjobs.Count() > 0)
                        {
                            // sort pending jobs w.r.t Job Index

                            var sortedjobs = pendingjobs.OrderBy(x => x.JobIndex);


                            if (sortedjobs.Count() < 3)
                            {
                                PendingJobIds = sortedjobs.ToList();
                                //ViewBag.JobIndexMessage = "Manage Jobs Index";

                                bool isindexupdate = model.JobIndexUpdate;

                                int first = -1;
                                string firstindex = "-1";
                                int second = -1;
                                string secondindex = "-1";
                                secondindex = PendingJobIds.LastOrDefault().JobIndex;

                                if (isindexupdate)
                                {
                                    // update exisitng job index priority

                                    if (PendingJobIds.Count() == 1)
                                    {
                                        first = PendingJobIds.FirstOrDefault().Id;
                                        firstindex = PendingJobIds.FirstOrDefault().JobIndex;

                                        jobViewModel.FirstPendingJobId = first;
                                        jobViewModel.FirstJobIndex = int.Parse(firstindex) + 1;
                                    }
                                    else if (PendingJobIds.Count() == 2)
                                    {
                                        first = PendingJobIds.FirstOrDefault().Id;
                                        firstindex = PendingJobIds.FirstOrDefault().JobIndex;

                                        jobViewModel.FirstPendingJobId = first;
                                        jobViewModel.FirstJobIndex = int.Parse(firstindex) + 1;

                                        second = PendingJobIds.LastOrDefault().Id;
                                        secondindex = PendingJobIds.LastOrDefault().JobIndex;

                                        jobViewModel.SecondPendingJobId = second;
                                        jobViewModel.SecondJobIndex = int.Parse(secondindex) + 1;
                                    }

                                }
                                else
                                {


                                    jobViewModel.Index = int.Parse(secondindex) + 1;
                                }

                                // save new job
                               DBResult result = await SMSJob.InsertSmsJob(jobViewModel, tblMSISDN);
                                if (result.DBStatus == 1)
                                {

                                    ViewBag.Message = "Job has been saved successfully.";
                                }
                                else
                                {
                                    ViewBag.Message = "Error: " + result.DBErrorMessage;
                                }
                            }
                            else
                            {
                                ViewBag.Message = "Schedule Later , Already 3 jobs scheduled in selected time duration.";
                            }


                        }
                        else
                        {


                            // save new job
                            DBResult result = await SMSJob.InsertSmsJob(jobViewModel, tblMSISDN);
                            if (result.DBStatus == 1)
                            {

                                ViewBag.Message = "Job has been saved successfully.";
                            }
                            else
                            {
                                ViewBag.Message = "Error: " + result.DBErrorMessage;
                            }

                        }

                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Invalid Selected DateTime.");
                    }





                }

                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid attempt.");
                    // return View(nameof(HomeController.Index), model);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
                //   return View(nameof(HomeController.Index), model);
            }


            var productlist = SenderProduct.GetSenderProducts();

            var carrierlist = SMSCarrier.GetAllSMSCarriers();

            model.SMSCarriers = carrierlist.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.ID.ToString()
            }).ToList();


            model.SenderProducts = productlist.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.ID.ToString()
            }).ToList();


            // clear modal 

            model.Message = string.Empty;
            model.datetimepicker = string.Empty;
            return View(nameof(HomeController.Index), model);

        }


        /// <summary>
        /// View List of created current sms jobs , it will not show remove or archieve jobs
        /// </summary>
        /// <returns></returns>

        public async Task<IActionResult> ViewSMSJobs()
        {

            List<ViewSmsJob> response = new List<ViewSmsJob>();
            try
            {
                response = await SMSJob.GetSMSJobs();
            }
            catch (Exception ex)
            {

            }

           
            return View(response);
        }


        /// <summary>
        /// View List of created current sms jobs , it will also show remove or archieve jobs
        /// </summary>
        /// <returns></returns>

        public async Task<IActionResult> ViewAllSMSJobs()
        {

            List<ViewSmsJob> response = new List<ViewSmsJob>();
            try
            {
                response = await SMSJob.GetAllSMSJobs();
            }
            catch (Exception ex)
            {

            }
            
            return View(response);
        }



        /// <summary>
        /// This method allow to change status of exisitngs jobs 
        /// </summary>
        /// <param name="JobId">1</param>
        /// <param name="JobStatus">1</param>
        /// <returns></returns>

        public async Task<IActionResult> UpdateJobStatus(string JobId, string NewJobStatus,string CurrentJobStatus, string ActionMethod)
        {
            if (!String.IsNullOrEmpty(JobId) && !String.IsNullOrEmpty(NewJobStatus) && !String.IsNullOrEmpty(CurrentJobStatus))
            {
                var result = await SMSJob.UpdateSmsJobStatus(int.Parse(JobId), int.Parse(NewJobStatus), int.Parse(CurrentJobStatus));
                if (result.DBStatus == 1)
                {
                    TempData["Message"] = "Job status  has been Updated Successfully.";
                }
                else
                {
                    TempData["Message"] = result.DBErrorMessage;
                }

            }
            
            return RedirectToAction(ActionMethod);
        }

        /// <summary>
        /// 
        /// This method allow to load details of selected sms job and display details in list and
        /// graph formate
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IActionResult> GraphSmsReport(int Id)
        {
            ViewBag.JobId = Id;

            var result = await SMSJob.GetSelectedSMSJobDetail(Id);

            int dispatched = result.SmsCount;
            int delivered = result.SmsProcessed;
            int undelivered = dispatched - delivered;

            ViewBag.JobId = Id;
            ViewBag.Dispatched = dispatched;
            ViewBag.Delivered = delivered;
            ViewBag.UnDelivered = undelivered;

            return View();
        }


        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public ActionResult GetUploadedFileData()
        {

            string result = "";

            if (Request.Form.Files.Count > 0 && Request.Form.Files[0].Length > 0)
            {
                string FileName = Request.Form.Files[0].FileName;
                if (FileName.Contains(".csv") || FileName.Contains(".txt"))
                {
                    using (var reader = new StreamReader(Request.Form.Files[0].OpenReadStream()))
                    {
                        result = reader.ReadToEnd();

                    }
                }
                else
                {
                    result = "Invalid File Format";
                }

            }
            return Json(result);
        }

    }
}


//        byte[] arr;

//            using (Stream SourceStream = Request.Body)
//            {
//                arr = new byte[SourceStream.Length];
//                SourceStream.Read(arr, 0, (int) SourceStream.Length);
//    ExcelPackage package = new ExcelPackage(SourceStream);
//    ExcelWorksheet workSheet = package.Workbook.Worksheets[1];

//                for (int i = workSheet.Dimension.Start.Row;
//                         i <= workSheet.Dimension.End.Row;
//                         i++)
//                {
//                    object cellValue = workSheet.Cells[i, 0].Value;
//}
//            }