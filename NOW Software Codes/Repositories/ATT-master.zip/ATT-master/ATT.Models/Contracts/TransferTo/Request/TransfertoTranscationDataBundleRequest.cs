﻿using ATT.Models.Contracts.TransferTo.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Request
{
    public class TransfertoTranscationDataBundleRequest
    {       
        
        public string sender_number { get; set; }
        public int operator_id { get; set; }
        public string productType { get; set; }
        public string productValue { get; set; } //product_id
        public string nowtelTransactionReference { get; set; } // external_id        
        public string sender_sms_notification { get; set; }
        public string sender_sms_text { get; set; }
        public string recipient_sms_notification { get; set; }
        public string recipient_sms_text { get; set; }
        public Sender sender { get; set; }
        public Recipient recipient { get; set; }
    }


    public class TransfertoTranscationDataBundleGSRequest
    {
        public string currency { get; set; }
        public string account_number { get; set; } // account_number 
        public string sender_number { get; set; }        
        public string product_id { get; set; } //product_id      
        public string external_id { get; set; }
        public string simulation { get; set; }
        public string sender_sms_notification { get; set; }
        public string sender_sms_text { get; set; }
        public string recipient_sms_notification { get; set; }
        public string recipient_sms_text { get; set; }
        public Sender sender { get; set; }
        public Recipient recipient { get; set; }
    }
}
