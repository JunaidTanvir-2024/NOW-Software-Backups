﻿var IsUserAlreadyExists = true;

$(document).ready(function () {

    //changing button text
    $("#BtnOrderSim").html("Continue");


    $('#BtnOrderSim').click(function () {
        ValidateSimOrderForm();
    });

    $('#btnLookup_Order').click(function () {
        $('#lblAlert_OrderSim').hide();
        $('#lblAlert_Msg_OrderSim').text('');
        $('#postcodeerror').hide();
        AddressLookup(function (output) {
            return;
        });
    });

    $('#chk_PortIn_sim').change(function () {
        if ($(this).is(':checked')) {
            $('#numberPortingSection_sim').slideDown();
        }
        else {
            $('#numberPortingSection_sim').slideUp();
        }
    });

    $('#PostCode').change(function () {
        $('#dpl_SimOrderAddresses').empty();

        //$("#dpl_SimOrderAddresses").append(new Option("No Address Found", 0));

        $('#dpl_SimOrderAddresses_sec').hide();


        $('#AddressL1').val('');
        $('#AddressL2').val('');
        $('#City').val('');
        $('#County').val('');
    });

    //Detect Enter Button 
    $(document).keypress(function (e) {
        if (e.which == 13) {
            $('#BtnOrderSim').click();
        }
    });

    //To disable validation
    var settngs = $.data($('#OrderFreeSimForm')[0], 'validator').settings;
    settngs.ignore = ".ignore,:hidden";

});

function ValidateSimOrderForm() {

    if (!$('#OrderFreeSimForm').valid()) {
        $('#BtnOrderSim').attr('disabled', false);
        return false;
    }
    else if ($("#dpl_SimOrderAddresses").is(':visible') === false) {
        AddressLookup(function (output) {
            return;
        });
    }
    else {
        SimOrder();
        //if ($('#UserEmail').is('[readonly]')) 
        //{
        //    SimOrder();
        //    return;
        //}
        //ValidateUserEmail();
    }
}

function SimOrder() {

    var data = {
        UserFirstName: $('#UserFirstName').val(),
        UserLastName: $('#UserLastName').val(),
        UserEmail: $('#UserEmail').val(),
        PostCode: ($(".AddressSection ").is(':visible') === true ? null : $('#PostCode').val()),
        AddressL1: $('#AddressL1').val(),
        AddressL2: $('#AddressL2').val(),
        City: $('#City').val(),
        County: $('#County').val(),
        CountryID: $('#Country').val(),
        UserPassword: $('#UserPassword').val(),
        UserConfirmPassword: $('#UserConfirmPassword').val(),
        MailSubscription: $('#MailSubscriptionSimOrder').is(':checked') ? true : false,
        IsReplace: $('#chk_ReplaceSim_sim').is(':checked'),
        IsPortIn: $('#chk_PortIn_sim').is(':checked'),
        IsUserExist: IsUserAlreadyExists,
        PortMsisdn: $('#PortMsisdn').val(),
        Code: $('#Code').val(),
        isuserverified: $('#isverifieduser').val(),
        otp: $('#digit-1').val() + $('#digit-2').val() + $('#digit-3').val() + $('#digit-4').val(),
    };

    $.ajax({
        url: "/Home/SimOrder",
        type: "POST",
        data: { model: data },
        beforeSend: function (xhr) {
            $('#OrderFreeSimForm').addClass("now-loading");
            $('#BtnOrderSimSpinner').show();
            $('#BtnOrderSimLabel').hide();
            $('#lblAlert_OrderSim').hide();
            $('#lblAlert_Msg_OrderSim').text('');
            $('#btnLookup_Order, #BtnOrderSim').attr('disabled', true);

            $('#email_verificationmessage').hide()

        },
        success: function (response) {
            if (response != null)
            {
                if (response.data > 0) {
                    $('#OrderFreeSimForm')[0].reset();
                    window.location.href = "../successful-sim-order" + (IsUserAlreadyExists ? "/1" : "/0");
                }

                else if (response.isValid == false) {

                    if (response.errorcode == 1 || response.errorcode == 4 || response.errorcode == 5) {
                        $('#email_verificationmessage').html(response.errormessage).show();
                    }
                    if (response.errorcode == 2 || response.errorcode == 3) {
                        $('#email_verificationmessage').html(response.errormessage).show();
                    }
                    return;
                }

                else if (response.regsitered == false && response.confirmed == false) {

                    $('#otp_verification').show();
                    $('#PasswordSection').show();
                    $("#BtnOrderSim").html("Send me a SIM");
                    $("#BtnOrderSim").attr("disabled", true);
                    $("#btnLookup_Order").attr("disabled", true);                    
                    $("#UserEmail").attr("readonly", true);
                    $("#PostCode").attr("readonly", true);
                    $("#dpl_SimOrderAddresses").attr("disabled", true);
                    starttimer();
                    $("#sendOTP").attr("disabled", true);
                    return;
                }

                else if (response.regsitered == true && response.confirmed == false) {

                    $('#otp_verification').show();
                    $("#btnLookup_Order").attr("disabled", true);      
                    $("#BtnOrderSim").html("Send me a SIM");
                    $("#BtnOrderSim").attr("disabled", true);
                    $("#UserEmail").attr("readonly", true);
                    $("#PostCode").attr("readonly", true);
                    $("#dpl_SimOrderAddresses").attr("disabled", true);
                    starttimer();
                    $("#sendOTP").attr("disabled", true);
                    return;
                }

                else if (response.regsitered == true && response.confirmed == true && response.isValid == true) {
                    $("#BtnOrderSim").html("Send me a SIM");
                    $("#BtnOrderSim").attr("disabled", true);
                    SimOrder()
                    return;
                }

                else if (response.otpValidation == false)
                {

                    $('#otp_verification').show();
                    $('#otp_verificationmessage').html("Invalid PIN.<br>Please Enter valid PIN or Resend OTP.").show();
                    $('#digit-1').val("").focus(),
                    $('#digit-2').val("").attr('disabled', 'disabled'),
                    $('#digit-3').val("").attr('disabled', 'disabled'),
                    $('#digit-4').val("").attr('disabled', 'disabled')

                    $("#BtnOrderSim").attr("disabled", true);

                }

                else {
                    $('#lblAlert_Msg_OrderSim').text(response.message);
                    $('#lblAlert_OrderSim').slideDown().delay(5000).slideUp();
                    $('#dpl_SimOrderAddresses_sec').hide();
                    $('.AddressSection').hide();
                    if ($('#chk_PortIn_sim').is(':checked')) {
                        $('#numberPortingSection_sim').hide();
                        $('#chk_PortIn_sim').bootstrapToggle('off');
                    }
                    $('#chk_ReplaceSim_sim').bootstrapToggle('off');
                    $('#PasswordSection').hide();
                    ResetForm('OrderFreeSimForm');
                }
            }
            else {
                $('#lblAlert_Msg_OrderSim').text('Some Error Occured. Please Contact Customer Services');
                $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();
            }
        },
        complete: function (xhr, status) {

            $('#BtnOrderSimSpinner').hide();
            $('#BtnOrderSimLabel').show();

            $('#BtnOrderSim').attr('disabled', false);
            $('#OrderFreeSimForm').removeClass("now-loading");
            
        },
        error: function (xhr, status, error) {
            $('#OrderFreeSimForm').removeClass("now-loading");
            $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please Contact Customer Services");
            $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();
        }
    });

}


//function ValidateUserEmail() {
//    $.ajax({
//        type: "POST",
//        url: "Verifyusersimorder",
//        beforeSend: function () {
//            $('#email_verificationmessage').hide()
//            $('#OrderFreeSimForm').addClass("now-loading");
//        },
//        data: {
//            PostCode: ($(".AddressSection").is(':visible') === true ? null : $('#PostCode').val()),
//            Address:  $('#AddressL1').val(),
//            Email: $('#UserEmail').val()
//        },
//        success: function (result) {

//            if (result.isValid == false) {

//                if (result.isValid == false && result.errorcode == 1) {
//                    $('#email_verificationmessage').html("You have reached the maximum number of SIM orders for this month. Please contact customer services via hello@talkhomemobile.com for further assistance").show();
//                }
//                if (result.isValid == false && result.errorcode == 2) {
//                    $('#email_verificationmessage').html("You have reached the maximum number of SIM orders for this account. Please contact customer services via hello@talkhomemobile.com for further assistance").show();
//                }
//                if (result.isValid == false && result.errorcode == 3) {
//                    $('#email_verificationmessage').html("You have reached the maximum number of SIM orders for this account. Please contact customer services via hello@talkhomemobile.com for further assistance").show();
//                }
//                if (result.isValid == false && result.errorcode == 4) {
//                    $('#email_verificationmessage').html("You have reached the maximum number of SIM orders for this month. Please contact customer services via hello@talkhomemobile.com for further assistance").show();
//                }
//                if (result.isValid == false && result.errorcode == 5) {
//                    $('#email_verificationmessage').html("You have reached the maximum number of SIM orders for this month. Please contact customer services via hello@talkhomemobile.com for further assistance").show();
//                }
//                return;
//            }
//            if (result.regsitered == false && result.confirmed == false) {

//                $('#otp_verification').show();
//                //$("#resendsendOTP").trigger("click");
//                $('#PasswordSection').show();
//                $("#BtnOrderSim").html("Send me a SIM");
//                $("#BtnOrderSim").attr("disabled", true);
                
//                $("#UserEmail").attr("readonly", true);
//                $("#PostCode").attr("readonly", true);
//                $("#dpl_SimOrderAddresses").attr("disabled", true);
//                //$(".AddressSection").attr("readonly", true);
//                //$("#AddressL1").attr("readonly", true);
//                //$("#AddressL1").attr("disabled", true);

//                starttimer();
//                $("#sendOTP").attr("disabled", true);
//                return;
//            }
//            if (result.regsitered == true && result.confirmed == false) {

//                $('#otp_verification').show();
//                //$("#resendsendOTP").trigger("click");
//                $('#PasswordSection').show();
//                $("#BtnOrderSim").html("Send me a SIM");
//                $("#BtnOrderSim").attr("disabled", true);

//                $("#UserEmail").attr("readonly", true);
//                $("#PostCode").attr("readonly", true);
//                $("#dpl_SimOrderAddresses").attr("disabled", true);

//                starttimer();
//                $("#sendOTP").attr("disabled", true);
//                return;


//            }
//            if (result.regsitered == true && result.confirmed == true && result.isValid == true) {


//                $("#BtnOrderSim").html("Send me a SIM");
//                $("#BtnOrderSim").attr("disabled", true);
//                SimOrder()
//                return;

//            }
//        },
//        complete: function () {
//            $('#OrderFreeSimForm').removeClass("now-loading");
//        },
//        error: function (xhr, error, status) {
//            $('#OrderFreeSimForm').removeClass("now-loading");
//            $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please Contact Customer Services");
//            $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();
//        }
//    });
//}


$("#digit-4,#digit-3,#digit-2,#digit-1").keyup(function () {


    var otpdata = {
        digit1: $('#digit-1').val(),
        digit2: $('#digit-2').val(),
        digit3: $('#digit-3').val(),
        digit4: $('#digit-4').val(),
    };

    if (!otpdata.digit1 || !otpdata.digit2 || !otpdata.digit3 || !otpdata.digit4) {
        return;
    }

    $('#otp_verificationmessage').hide();
    $('#otp_verificationsucessmessage').hide();
    $("#BtnOrderSim").attr("disabled", true);

    ValidateSimOrderForm();



    //$.ajax({
    //    type: "POST",
    //    url: "/Home/SimOrder",
    //    beforeSend: function () {
    //        $('#OrderFreeSimForm').addClass("now-loading");
    //        $('#otp_verificationsucessmessage').hide();
    //        $('#otp_verificationmessage').hide();
    //    },
    //    data: { model: data },
    //    success: function (result) {

    //        if (result.response == true) {

    //            $('#otp_verification').hide();

    //            $('#isverifieduser').val("true");

    //            $('#otp_verificationsucessmessage').html("Verified Sucessfully!").show();

    //            $("#BtnOrderSim").attr("disabled", false);

    //            if (!$('#OrderFreeSimForm').valid()) {
    //                return false;
    //            }
    //            else {
    //                SimOrder();
    //            }
    //        }

    //        else {

    //            $('#otp_verification').show();
    //            $('#otp_verificationmessage').html("Invalid PIN.<br>Please Enter valid PIN or Resend OTP.").show();
    //            $('#digit-1').val("").focus(),
    //                $('#digit-2').val("").attr('disabled', 'disabled'),
    //                $('#digit-3').val("").attr('disabled', 'disabled'),
    //                $('#digit-4').val("").attr('disabled', 'disabled')

    //            $("#BtnOrderSim").attr("disabled", true);

    //        }

    //    },
    //    error: function (xhr, error, status) {
    //        $('#OrderFreeSimForm').removeClass("now-loading");
    //        $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please Contact Customer Services");
    //        $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();

    //    },
    //    complete: function () {
    //        $('#OrderFreeSimForm').removeClass("now-loading");
    //    }
    //});

});

$("#sendOTP").click(function (e) {

    $.ajax({
        type: "POST",
        url: "Send_otp_to_user",
        data: {
            email: $('#UserEmail').val()
        },
        success: function (result) {
            $('#isverifieduser').val("true");
            starttimer();
            return;

        },

        error: function (xhr, error, status) {
            $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please Contact Customer Services");
            $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();
        }
    });

});

function starttimer() {
    mins = 10;
    secs = 0;
    let btn = $("#sendOTP");
    btn.addClass("disabled");
    interval = setInterval(function () {
        if (mins >= 0 && secs >= 0) {
            btn.text("Resend OTP in " + pad(mins, 2) + ":" + pad(secs, 2));
            if (secs > 0) {
                secs--;
            } else {
                secs = 59;
                mins--;
            }
            if (mins < 0) {
                clearInterval(interval);
                btn.removeClass("disabled").text("Resend OTP");
                return true;
            }
        }
       
    }, 1000);
}

function pad(num, size) {
    let s = num + "";
    while (s.length < size) s = "0" + s;
    return s;
}

$('.digit-group').find('input').each(function () {
    $(this).attr('maxlength', 1);
    $(this).attr('disabled', 'disabled');
    $('#digit-1').removeAttr('disabled')

    $(this).on('keyup', function (e) {

        let parent = $($(this).parent());
        let prev = parent.find('input#' + $(this).data('previous'));
        let next = parent.find('input#' + $(this).data('next'));

        if ($(this).prev)
        {

            if (e.keyCode === 8 || e.keyCode === 37) {
                if (prev.length) {
                    $(prev).select();
                    $(this).attr('disabled', 'disabled');
                }

            } else if (e.type == "keyup" && (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {

                next.removeAttr('disabled');

                if (e.currentTarget.value.length >= 1) {
                    $(e.currentTarget).next('input').focus();
                } else {
                    if (parent.data('autosubmit')) {
                        parent.submit();
                    }
                }
            }
        }
    });
});

function ValidateSimOrderEmail(SimData) {

    IsUserAlreadyExists = true;

    $.ajax({
        url: "/Home/ValidateOrderSimEmail",
        type: "GET",
        data: { Email: $('#UserEmail').val().trim() },
        beforeSend: function (xhr) {

        },
        success: function (result) {
            if (result != null) {
                if (result.data.userId > 0 && result.data.numberOfSimOrders >= 2) {

                    $('#lblAlert_Msg_OrderSim').text("Sorry your number of orders exceeded against this email. Please contact Customer Services");
                    $('#lblAlert_OrderSim').slideDown().delay(4000).slideUp();

                    SimData(false);
                }
                else if (result.data.userId == 0 && $("#PasswordSection").is(':visible') == false) {

                    $('#lblAlert_Msg_OrderSim').text("To Complete your order. Please Choose Password to Signup.");
                    $('#lblAlert_OrderSim').slideDown().delay(4000).slideUp();

                    ShowHidePasswordSection(true);
                    SimData(false);
                }
                else {
                    if (result.data.userId == 0) {
                        IsUserAlreadyExists = false;
                    }
                    SimData(true);
                }
            }
            else {

                $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please Contact Customer Services");
                $('#lblAlert_OrderSim').slideDown().delay(4000).slideUp();

                SimData(false);
            }
        },
        complete: function (xhr, status) {

        },
        error: function (xhr, status, error) {

            $('#lblAlert_Msg_OrderSim').text("Some Error Occured. Please contact Customer Services");
            $('#lblAlert_OrderSim').slideDown().delay(4000).slideUp();
            SimData(false);
        }
    });
}

function AddressLookup(AddressCallBack) {
    $('#postcodeerror').hide();
    if (!$('#PostCode').valid()) {
        return false;
    }
    $('.AddressSection').hide();
    $.ajax({
        async: false,
        url: "/Home/GetAddresses",
        type: "GET",
        data: { PostCode: $('#PostCode').val().trim() },
        beforeSend: function (xhr) {
            $('#btnLookup_OrderSpinner').show();
            $('#btnLookup_OrderLabel').hide();
            $('#btnLookup_Order, #BtnOrderSim').attr('disabled', true);
        },
        success: function (response) {
            if (response != null) {
                if (response.errorCode == 0) {

                    $('#dpl_SimOrderAddresses').empty();

                    if (response.data.addresses.length > 0) {
                        $.each(response.data.addresses, function (key, val) {
                            if (key == 0) {

                                //var pageURL = $(location).attr("href");
                                //if (pageURL.indexOf('topUp') == -1 || pageURL.indexOf('checkout') != -1)
                                //    $('.AddressSection').removeClass('d-block').addClass('d-none');

                                var Address = val.split(',');
                                $('#AddressL1').val(Address[0] + " " + Address[1]);
                                $('#AddressL2').val(Address[2] + " " + Address[3]);
                                $('#City').val(Address[5]);
                                $('#County').val(Address[6]);
                            }

                            var newaddress = RemoveCommaFromAddress(val).slice(0, -1);

                            $("#dpl_SimOrderAddresses").append(new Option(newaddress, val));

                            //$("#dpl_SimOrderAddresses").append(new Option(newaddress, "Add new address.."));
                        });
                        

                        var pageURL = $(location).attr("href");
                        if (pageURL.indexOf('topUp') != -1 || pageURL.indexOf('checkout') != -1) {
                            $("#dpl_SimOrderAddresses").append(new Option("Add new address", "NewAddress"));
                            //$("#dpl_SimOrderAddresses").append(new Option("No Address Found", 0));

                           
                        } $('#dpl_SimOrderAddresses_sec').show();
                        AddressCallBack(true);
                    }
                    else {
                        NoAddressesFoound_Order();
                        AddressCallBack(false);
                    }
                }
                else {
                    NoAddressesFoound_Order();
                    AddressCallBack(false);
                }
            }
            else {
                NoAddressesFoound_Order();
                AddressCallBack(false);
            }
        },
        complete: function (xhr, status) {
            $('#btnLookup_OrderSpinner').hide();
            $('#btnLookup_OrderLabel').show();
            $('#btnLookup_Order,#BtnOrderSim').attr('disabled', false);
        },
        error: function (xhr, status, error) {
            ShowAddressError_Order();
            AddressCallBack(false);
            NoAddressesFoound_Order();
        }
    });
}

function RemoveCommaFromAddress(address) {

    var splitaddress = address.split(',');

    var newaddresss = "";
    if (splitaddress[0] != " ") {
        newaddresss += splitaddress[0] + ",";
    }
    if (splitaddress[1] != " ") {
        newaddresss += splitaddress[1] + ",";
    }
    if (splitaddress[2] != " ") {
        newaddresss += splitaddress[2] + ",";
    }
    if (splitaddress[3] != " ") {
        newaddresss += splitaddress[3] + ",";
    }
    if (splitaddress[4] != " ") {
        newaddresss += splitaddress[4] + ",";
    }
    if (splitaddress[5] != " ") {
        newaddresss += splitaddress[5] + ",";
    }
    if (splitaddress[6] != " ") {
        newaddresss += splitaddress[6];
    }
    return newaddresss;
}

function dpl_SetAddresses(AddressDropDown) {

    var Address = $(AddressDropDown).val();


    if ($(AddressDropDown).val() == 'NewAddress') {
        $('.AddressSection').show('');
        $('#AddressL1').val('');
        $('#AddressL2').val('');
        $('#City').val('');
        $('#County').val('');
    }
    else if ($(AddressDropDown).val() == 0) {

        $('#AddressL1').val('');
        $('#AddressL2').val('');
        $('#City').val('');
        $('#County').val('');

        //$('.AddressSection').removeClass('d-none').addClass('d-block');

    }
    else {
      
        //$('.AddressSection').removeClass('d-block').addClass('d-none');
        $('.AddressSection').hide();
        Address = $(AddressDropDown).val().split(',');
        $('#AddressL1').val(Address[0] + " " + Address[1]);
        $('#AddressL2').val(Address[2] + " " + Address[3]);
        $('#City').val(Address[5]);
        $('#County').val(Address[6]);
    }
}

//function NoAddressesFoound_Order() {

//    $('#dpl_SimOrderAddresses').empty();

//    $("#dpl_SimOrderAddresses").append(new Option("No Address Found", 0));

//    $('#dpl_SimOrderAddresses_sec').show();


//    $('#AddressL1').val('');
//    $('#AddressL2').val('');
//    $('#City').val('');
//    $('#County').val('');

//    $('.AddressSection').show();

//}

function NoAddressesFoound_Order() {

    $('#dpl_SimOrderAddresses').empty();

    //$("#dpl_SimOrderAddresses").append(new Option("No Address Found", 0));

    //$('#dpl_SimOrderAddresses_sec').show();

    $("#dpl_SimOrderAddresses").append(new Option("Add new address", "NewAddress"));
    var pageURL = $(location).attr("href");
    if (pageURL.indexOf('topUp') != -1 || pageURL.indexOf('checkout') != -1) {
        //$('#dpl_SimOrderAddresses_sec').show();
        $('.AddressSection').show();
        $('#AddressL1').val('');
        $('#AddressL2').val('');
        $('#City').val('');
        $('#County').val('');
        $('#postcodeerror').show();
        $('#dpl_SimOrderAddresses_sec').hide();
        $('#dpl_SimOrderAddresses').empty();
    }

    //$('#AddressL1').val('');
    //$('#AddressL2').val('');
    //$('#City').val('');
    //$('#County').val('');

    $('#lblAlert_OrderSim').show();
    $('#lblAlert_Msg_OrderSim').text('SIM cards can only be delivered to addresses in the UK. Please enter a valid UK postcode to continue.');

}

function ShowAddressError_Order() {

    //Address Section
    $('#AddressL1').val('');
    $('#AddressL2').val('');
    $('#City').val('');
    $('#County').val('');

    $('.AddressSection').hide();

    //Address DropDown
    $('#dpl_SimOrderAddresses').empty();
    $('#dpl_SimOrderAddresses_sec').hide();


    $('#lblAlert_Msg_OrderSim').text('Some Error Occured. Please Contact Customer Services');
    $('#lblAlert_OrderSim').slideDown().delay(3000).slideUp();
}

function ShowHidePasswordSection(show) {

    $('#Password').val('');
    $('#ConfirmPassword').val('');

    if (show) {
        $('#PasswordSection').show();
    } else {
        $('#PasswordSection').hide();
    }
}

