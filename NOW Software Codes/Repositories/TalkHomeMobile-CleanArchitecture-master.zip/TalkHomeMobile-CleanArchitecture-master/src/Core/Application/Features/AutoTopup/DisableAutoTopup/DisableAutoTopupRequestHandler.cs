﻿using Application.Common.Interfaces.Payment;
using Application.Common.Interfaces.Repositories;
using Application.Common.Interfaces.Shared;
using Application.Common.Interfaces;
using Application.Common.Settings;
using Application.Features.AutoTopup.Paypal;
using Application.Features.Payment.Models;
using Application.Features.Payment.Paypal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.AutoTopup.DisableAutoTopup;
public class DisableAutoTopupRequestHandler : IRequestHandler<DisableAutoTopupRequest, Result<object>>
{
    private readonly IUserService _userService;
    private readonly IStringLocalizer<DisableAutoTopupRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IPayPalService _payPalService;

    public DisableAutoTopupRequestHandler(IUserService userService,
        IStringLocalizer<DisableAutoTopupRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        ICommonService commonService,
        IPayPalService payPalService)
    {
        _userService = userService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _commonService = commonService;
        _payPalService = payPalService;
    }
    public async Task<Result<object>> Handle(DisableAutoTopupRequest request, CancellationToken cancellationToken)
    {
        if (!await _userService.IsUserMsisdn(request.Msisdn))
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }
        var responseMessage = _localizer[CustomStatusKey.SetAutoTopupSuccess].ToString();

        var autoTopupStatus = await _unitOfWork.TopupRepo.GetAutoTopup(request.Msisdn, _currentUser.GetUserEmail()!);
        if (autoTopupStatus?.Status==true && autoTopupStatus?.PaymentMethod?.Equals("Paypal", StringComparison.InvariantCultureIgnoreCase) == true)
        {
            var isAppRequest = _commonService.IsAppRequest();
            //Stop autotopup
            var subscriptionSuspendRequest = new PaypalSuspendSubscriptionRequest
            {
                SubscriptionId = autoTopupStatus.InitialTransactionId!
            };
            var paypalSuspendSubscriptionResponse = await _payPalService.PayPalCancelSubscription(subscriptionSuspendRequest);
            if (paypalSuspendSubscriptionResponse != null)
            {
                //disable autotopup
                await _unitOfWork.TopupRepo.SetAutoTopup(
                                                 false,
                                                 request.Msisdn,
                                                 _currentUser.GetUserEmail()!,
                                                 autoTopupStatus.Topup,
                                                 "GBP",
                                                 1,
                                                 PaymentMethod.Paypal
                                                 );
                return Result<object>.Success(null, responseMessage.Replace("{status}", "disabled"));
            }
            else
            {
                return Result<object>.Failure(
                _localizer[CustomStatusKey.SetAutoTopupFailure], CustomStatusCode.InternalServerError);
            }
        }
        else
        {
            await _unitOfWork.TopupRepo.SetAutoTopup(
                                                 false,
                                                 request.Msisdn,
                                                 _currentUser.GetUserEmail()!,
                                                 autoTopupStatus.Topup,
                                                 "GBP",
                                                 1,
                                                 PaymentMethod.Paypal
                                                 );
            return Result<object>.Success(null, responseMessage.Replace("{status}", "disabled"));
        }
    }
}
