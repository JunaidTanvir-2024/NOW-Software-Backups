﻿using Models.Common;
using System.ComponentModel;

namespace Infrastructure.BLL.Services.Voucherify.Models.MetadataModels
{
    public class CustomerMetadata
	{
		public bool TransactionDone { get; set; }
        public bool FirstInternationalTopup { get; set; }
        public bool FirstTopup { get; set; }
    }
    public static class MetadataExtensionMethods
	{
		public static Metadata ToMetadata(this object entity)
		{
			var metadata = new Metadata();
			foreach (PropertyDescriptor property in TypeDescriptor.GetProperties(entity))
			{
				metadata.Add(property.Name, property.GetValue(entity));
			}
			return metadata;
		}
	}
}
