﻿namespace THCC.Domain.Aggregates;

public class CardCallHistory
{
    public DateTime? DateTime { get; set; }
    public string? Dialed_Number { get; set; }
    public int Duration { get; set; }
    public string? ADA { get; set; }
    public string? AOA { get; set; }
}


