﻿using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.CallingCard.GuestCheckout.NewCard;

public class GuestCheckoutTHCCNewCardPaymentRequestHandler : IRequestHandler<GuestCheckoutTHCCNewCardPaymentRequest, object>
{
    #region Fields

    private readonly IPaymentService _paymentService;
    private readonly ICurrentUser _currentUser;
    private readonly IUserRepository _userRepository;
    private readonly IUserService _userService;
    private readonly IOtpService _otpService;

    #endregion

    #region Ctors

    public GuestCheckoutTHCCNewCardPaymentRequestHandler(
        IPaymentService paymentService,
        ICurrentUser currentUser,
        IUserRepository userRepository,
        IUserService userService,
        IOtpService otpService)
    {
        _paymentService = paymentService;
        _currentUser = currentUser;
        _userRepository = userRepository;
        _userService = userService;
        _otpService = otpService;
    }

    #endregion

    #region Methods

    public async Task<object> Handle(GuestCheckoutTHCCNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        #region Trim Request

        request.PaymentCardInfo.NameOnCard = request.PaymentCardInfo.NameOnCard.Trim();
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber.Trim();
        request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();
        request.PaymentCardInfo.ExpiryMonth = request.PaymentCardInfo.ExpiryMonth.Trim();
        request.PaymentCardInfo.ExpiryYear = request.PaymentCardInfo.ExpiryYear.Trim();

        request.PaymentAddressInfo.AddressL1 = request.PaymentAddressInfo.AddressL1!.Trim();
        request.PaymentAddressInfo.City = request.PaymentAddressInfo.City!.Trim();
        request.PaymentAddressInfo.PostCode = request.PaymentAddressInfo.PostCode!.Trim();
        request.PaymentAddressInfo.CountryCode = request.PaymentAddressInfo.CountryCode!.Trim();

        request.Email = request.Email!.Trim();
        #endregion


        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        //get confirmation token
        var emailToken = await _otpService.GetTokenAgainstOtp(
                        request.Email, request.EmailOtp!, OtpType.SignUp);
        if (string.IsNullOrEmpty(emailToken))
        {
            return ErrorResult.Failure(CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        //Make sure card is not save when the user is not logged-in
        if (!_currentUser.IsAuthenticated())
        {
            request!.PaymentCardInfo.SaveCard = false;
            request!.PaymentCardInfo.MakeDefault = false;
        }
        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: request.PaymentAddressInfo,
            paymentExistingCardInfo: null!,
            autoTopupInfo: null!,
            userInfo: new UserDto()
            {
                Id = user.Id,
                Email = user.Email!,
            },
            productType: ProductType.CallingCard,
            amount: request.Amount,
            cardNumber: null!);
    }

    #endregion
}