﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Utilities.Extension
{
    public static class UserExtensions
    {
        public static string PhoneNumber(this ClaimsPrincipal user)
        {
            return user.Claims.FirstOrDefault(i => i.Type == "phone_number")?.Value ?? "";
        }
        public static string Currency(this ClaimsPrincipal user)
        {
            return user.Claims.FirstOrDefault(i => i.Type == "currency")?.Value ?? "";
        }
        public static string AccountId(this ClaimsPrincipal user)
        {
            return user.Claims.FirstOrDefault(i => i.Type == "account_id")?.Value ?? "";
        }
        public static string CountryCode(this ClaimsPrincipal user)
        {
            return user.Claims.FirstOrDefault(i => i.Type == "iso_two_country")?.Value ?? "";
        }
    }
}
