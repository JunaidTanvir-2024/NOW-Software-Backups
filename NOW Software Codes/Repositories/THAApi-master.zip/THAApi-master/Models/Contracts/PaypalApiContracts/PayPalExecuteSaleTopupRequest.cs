﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Models.Contracts.PaypalApiContracts
{
	public class PayPalExecuteSaleTopupRequest
	{
		[JsonProperty("payer_id")]
		[Required]
		public string PayerId { get; set; }


		[JsonProperty("payment_id")]
		[Required]
		public string PaymentId { get; set; }
	}
}
