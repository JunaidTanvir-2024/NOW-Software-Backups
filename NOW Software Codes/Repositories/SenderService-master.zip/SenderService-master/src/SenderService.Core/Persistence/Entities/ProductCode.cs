﻿using SenderService.Core.Common.Enums;
using SenderService.Core.Features.Email.Request;
using SenderService.Core.Services.Mailing;
using System.Net.Http;

namespace SenderService.Core.Persistence.Entities;

//public class ProductCode
//{
//    public long Id { get; set; }
//    public string Code { get; set; } = null!;
//    public virtual ICollection<ProductItemCode> ProductItemCodes { get; } = new List<ProductItemCode>();
//}


public class ProductCode
{
    public long Id { get; set; }

    public string Code { get; set; } = null!;

    public string ItemCode { get; set; } = null!;

    public virtual ICollection<EmailValidation> EmailValidations { get; } = new List<EmailValidation>();

    public virtual ICollection<Email> Emails { get; } = new List<Email>();
}