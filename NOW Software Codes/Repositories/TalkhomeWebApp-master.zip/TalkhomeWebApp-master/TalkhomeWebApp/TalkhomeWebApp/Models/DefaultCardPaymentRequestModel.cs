﻿using System.ComponentModel.DataAnnotations;
using TalkhomeWebApp.Models.ViewModels;

namespace TalkhomeWebApp.Models
{
    public class DefaultCardPaymentRequest
    {

        [Required(ErrorMessage = "Number is required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Please enter a valid Number")]
        public string CustomerUniqueRef { get; set; }

        [CollectionValidation(values: new int[] { 0, 5, 10, 15, 20, 25 })]
        public string BundleId { get; set; }
        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }

    }
    public class DefaultCardPaymentRequestModel
    {
        public string ipAddress { get; set; }
        public string Msisdn { get; set; }
        public string CustomerUniqueRef { get; set; }
        public string BundleId { get; set; }
        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }

    }
}
