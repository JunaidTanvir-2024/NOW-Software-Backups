using CancelBundleApi.Models.HTTPModels;

namespace CancelBundleApi.Helpers.HttpService;

public interface IHttpService
{
    Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> DeleteAsync(string requestUri, object? data = default, string? correlationGuid = null);
    IHttpService EnableLogging();
    Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> GetAsync(string requestUri, object? data = default, string? correlationGuid = null);
    Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> PostAsync(string requestUri, object? data = default);
    Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> PutAsync(string requestUri, object? data = default);
    Task<(bool IsSuccessStatusCode, string ResponseBody, int StatusCode)> NoRequestDataFound(string requestUri, string noDataFound, object? data = null, string? correlationGuid = null);
    IHttpService WithBasicAuth(string username, string password);
    IHttpService WithBearerAuth(string token);
    IHttpService WithHeaders(IEnumerable<HttpServiceKeyValues> headers);
}
