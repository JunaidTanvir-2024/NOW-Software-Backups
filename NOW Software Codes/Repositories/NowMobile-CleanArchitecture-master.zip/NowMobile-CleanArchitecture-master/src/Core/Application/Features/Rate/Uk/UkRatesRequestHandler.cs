using Application.Features.Rate.Model;

namespace Application.Features.Rate.Uk;

public class UkRatesRequestHandler : IRequestHandler<UkRatesRequest, Result<List<UkRate>>>
{
    private readonly IUnitOfWork _uow;
    private readonly IStringLocalizer<UkRatesRequestHandler> _localizer;

    public UkRatesRequestHandler(
        IUnitOfWork uow,
        IStringLocalizer<UkRatesRequestHandler> localizer)
    {
        _uow = uow;
        _localizer = localizer;
    }

    public async Task<Result<List<UkRate>>> Handle(UkRatesRequest request, CancellationToken cancellationToken)
    {
        var ukRates = await _uow.RateRepo.GetUKRates();
        return Result<List<UkRate>>.Success(ukRates, _localizer[CustomStatusKey.Success]);
    }
}
