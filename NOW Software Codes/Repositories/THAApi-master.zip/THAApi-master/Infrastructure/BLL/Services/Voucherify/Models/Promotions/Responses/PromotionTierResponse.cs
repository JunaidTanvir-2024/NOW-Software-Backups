﻿using Google.Protobuf.WellKnownTypes;
using Infrastructure.BLL.Services.Voucherify.Definations;
using Models.Common;
using Models.Enums;
using System;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses
{
    public class PromotionTierResponse
    {
        [JsonPropertyName("promotionId")]
        public string PromotionId { get; set; }

        [JsonPropertyName("campaignId")]
        public string CampaignId { get; set; }

        [JsonPropertyName("campaignStartDate")]
        public DateTime? CampaignStartDate { get; set; }

        [JsonPropertyName("campaignExpirationDate")]
        public DateTime? CampaignExpirationDate { get; set; }

        [JsonPropertyName("isCampaignActive")]
        public bool IsCampaignActive { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("banner")]
        public string Banner { get; set; }

        [JsonPropertyName("amountOff")]
        public long? AmountOff { get; set; }

        [JsonPropertyName("percentOff")]
        public decimal? PercentOff { get; set; }

        [JsonPropertyName("unitOff")]
        public decimal? UnitOff { get; set; }

        [JsonPropertyName("unitType")]
        public string UnitType { get; set; }

        [JsonPropertyName("discountEffect")]
        public string DiscountEffect { get; set; }

        [JsonPropertyName("discountType")]
        public string DiscountType { get; set; }

        [JsonPropertyName("amountLimit")]
        public long? AmountLimit { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("categoryId")]
        public string CategoryId { get; set; }

        [JsonPropertyName("metadata")]
        public Metadata Metadata { get; set; }
    }
    public class GetCustomerSpecificPromotionsResult
    {
        public PromotionsInfo Promotions { get; set; }
        public RewardsInfo Rewards { get; set; }
        public OrderDetail OrderDetails { get; set; } 
        public class OrderDetail
        {
            public decimal ServiceFee { get; set; }
            public decimal ServiceFeeDiscount { get; set; }
            public decimal TotalServiceFee { get; set; }
        }
        public class PromotionsInfo
        {
            public string DiscountCode { get; set; }
            public string Banner { get; set; }
            public decimal Value { get; set; }
            public decimal DiscountAmount { get; set; }
            public decimal Amount { get; set; }
            public DiscountType DiscountType { get; set; }
        }
        public class RewardsInfo
        {
            public int RewardPoints { get; set; }
        }
    }
}
