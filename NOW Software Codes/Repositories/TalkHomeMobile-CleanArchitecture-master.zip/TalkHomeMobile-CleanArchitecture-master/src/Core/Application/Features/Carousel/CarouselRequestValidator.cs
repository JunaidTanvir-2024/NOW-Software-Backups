﻿
namespace Application.Features.Carousel;
public class CarouselRequestValidator : AbstractValidator<CarouselRequest>
{
    public CarouselRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).Must(p => commonService.IsValidMsisdn(p!)).WithMessage("Invalid Msisdn").When(p => !string.IsNullOrEmpty(p.Msisdn));
    }
}
