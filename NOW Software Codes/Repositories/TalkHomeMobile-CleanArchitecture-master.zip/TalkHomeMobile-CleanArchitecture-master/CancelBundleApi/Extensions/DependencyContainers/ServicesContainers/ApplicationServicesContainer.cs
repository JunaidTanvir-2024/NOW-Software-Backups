﻿using CancelBundleApi.Services.Implementation;
using CancelBundleApi.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CancelBundleApi.Extensions.DependencyContainers.ServicesContainers;

internal static class ApplicationServicesContainer
{
    public static IServiceCollection RegisterApplicationServices(this IServiceCollection services, IConfiguration config)
    {
        #region          
        services.AddScoped<IUnsubscribeBundleService, UnsubscribeBundleService>();
        services.AddScoped<IUnSubscribeBundlesRequestService, UnSubscribeBundlesRequestService>();
        services.AddScoped<IDigitalkService, DigitalkService>();
       
        #endregion
        return services;
    }
}
