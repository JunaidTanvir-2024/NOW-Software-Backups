﻿

namespace Application.Features.Bundle.Model;
public class CancelBundleDetails
{
    public int SubscriberBundleId { get; set; }
    public int CancelStatusType { get; set; }
    public RefundDetail RefundDetail { get; set; }
    public EarlyTerminationDetail EarlyTerminationDetail { get; set; }
    public BundleInfo BundleDetails { get; set; }
}

public class EarlyTerminationDetail
{
    public int TotalMonths { get; set; }
    public int ConsumedMonths { get; set; }
    public int RemainingMonths { get; set; }
    public decimal TerminationCharges { get; set; }
}

public class RefundDetail
{
    public decimal DataConsume { get; set; }
    public decimal MinConsume { get; set; }
    public decimal SmsConsume { get; set; }
    public decimal TotalConsume { get; set; }
    public string VatPercentage { get; set; } = "20%";
    public decimal VAT { get; set; } = 0;
    public decimal TotalConsumeAmount { get; set; }
    public decimal TotalRefundAmount { get; set; }
}




