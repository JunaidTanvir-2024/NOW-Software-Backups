using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Extensions;

using Microsoft.AspNetCore.Http;

using RW;

using Serilog;

namespace JM.Infrastructure.Common.Middlewares;

internal sealed class ConfigureGlobalException
{
    internal sealed class Middleware(RequestDelegate next, ILogger logger)
    {
        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                // Handle the exception and generate an appropriate response
                context.Response.ContentType = AppConstant.ContentType.ApplicationJson;
                context.Response.StatusCode = AppConstant.StatusCode.InternalServerError;

                logger.ErrorLog(ex);
                await context.Response.WriteAsJsonAsync(ResultWrapper.Failure(ex.StackTrace!.ToString(), AppConstant.StatusCode.InternalServerError));
            }
        }
    }
}
