using Microsoft.AspNetCore.Mvc;

using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Api.Features.Orders;

public static class OrdersEndpoints
{
    public static void AddOrdersEndpoints(this WebApplication app)
    {
        var vouchersEndpoints = app.MapGroup("/api/customers").WithTags("Customers Endpoints");

        vouchersEndpoints.MapGet("", GetOrders);
        vouchersEndpoints.MapGet("/{customerId}", GetOrder);
        vouchersEndpoints.MapPost("/", AddOrder);
        vouchersEndpoints.MapPut("/{customerId}", UpdateOrder);
    }

    private static async Task<IResult> GetOrders(IOrdersHandler ordersHandler, [FromQuery] int pageNumber, [FromQuery] int pageSize)
    {
        var result = await ordersHandler.GetOrders(pageNumber, pageSize);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> GetOrder(IOrdersHandler ordersHandler, [FromQuery] string orderId, [FromBody] Order order)
    {
        var result = await ordersHandler.GetOrder(orderId, order);

        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> AddOrder(IOrdersHandler ordersHandler, OrderCreate order)
    {
        var result = await ordersHandler.CreateOrder(order);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
    private static async Task<IResult> UpdateOrder(IOrdersHandler ordersHandler, [FromQuery] string orderId, [FromBody] OrderUpdate orderUpdate)
    {
        var result = await ordersHandler.UpdateOrder(orderId, orderUpdate);
        return result.IsSuccess
            ? Results.Ok(result)
            : Results.NotFound(result);
    }
}
