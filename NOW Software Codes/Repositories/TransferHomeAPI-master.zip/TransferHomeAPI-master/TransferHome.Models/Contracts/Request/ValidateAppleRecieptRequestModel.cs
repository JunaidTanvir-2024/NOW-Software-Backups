﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class ValidateAppleRecieptRequestModel
    {
        public string UDID { get; set; }
        public int UserId { get; set; }
        [Required]
        public string Token { get; set; }
    }
}
