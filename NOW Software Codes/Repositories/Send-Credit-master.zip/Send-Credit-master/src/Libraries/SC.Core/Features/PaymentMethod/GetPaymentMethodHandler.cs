﻿using MapsterMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.PaymentMethod;
internal sealed class GetPaymentMethodHandler : IRequestHandler<GetPaymentMethodRequest, IResultWrapper>
{
    private readonly ICustomerCartRespository _customerCartRespository;
    private readonly IMapper _mapper;
    public GetPaymentMethodHandler(ICustomerCartRespository customerCartRespository,IMapper mapper)
    {
        _customerCartRespository = customerCartRespository;
        _mapper = mapper;
    }
    public async Task<IResultWrapper> Handle(GetPaymentMethodRequest request, CancellationToken cancellationToken)
    {
        var result = await _customerCartRespository.GetPaymentMethods();
        var paymentmethods = _mapper.Map<List<GetPaymentMethodResponse>>(result);
        return ResultWrapper.Success(paymentmethods);
    }
}


