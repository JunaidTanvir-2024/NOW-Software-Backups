﻿using System;
using System.Collections.Generic;

namespace SenderService.Core.Persistence.Entities;


public class BlockDomain
{
    public long Id { get; set; }

    public string Domain { get; set; } = null!;

    public DateTimeOffset BlockDate { get; set; }
}
