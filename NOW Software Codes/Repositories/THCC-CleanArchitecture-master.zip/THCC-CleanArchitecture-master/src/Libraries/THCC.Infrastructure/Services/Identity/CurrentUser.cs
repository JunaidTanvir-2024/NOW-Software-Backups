﻿using System.Security.Claims;

using Microsoft.AspNetCore.Http;

using THCC.Application.Interfaces.Identity;

namespace THCC.Infrastructure.Services.Identity
{
    public sealed class CurrentUser : ICurrentUser
    {
        private readonly ClaimsPrincipal? _user;

        public CurrentUser(IHttpContextAccessor httpContextAccessor)
        {
            _user = httpContextAccessor.HttpContext!.User;
        }

        public string GetUserId() =>
            IsAuthenticated()
                ? _user?.GetUserId() ?? ""
                : "";

        public string GetUserEmail() =>
            IsAuthenticated()
                ? _user!.GetEmail()!
                : string.Empty;

        public bool IsAuthenticated() =>
            _user?.Identity?.IsAuthenticated is true;
    }

    public static class ClaimsPrincipalExtensions
    {
        public static string? GetEmail(this ClaimsPrincipal principal)
            => principal.FindFirstValue(ClaimTypes.Email);

        public static string? GetFirstName(this ClaimsPrincipal principal)
            => principal?.FindFirst(ClaimTypes.Name)?.Value;

        public static string? GetSurname(this ClaimsPrincipal principal)
            => principal?.FindFirst(ClaimTypes.Surname)?.Value;

        public static string? GetUserId(this ClaimsPrincipal principal)
           => principal.FindFirstValue(ClaimTypes.NameIdentifier);
    }
}
