﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrasnferHome.Models.Utility
{
    public enum ApiStatusCodes
    {
        DBError = 1,
        EmailAlreadyRegistered = 2,
        EmailNotExist = 3,
        InvalidNumber = 4,
        PhoneNumberAlreadyRegistered = 5,
        TokenExpiredorInvalid = 6,
        MobilePinExpiredorInvalid = 7,
        UserNotFound = 8,
        EmailAlreadyVerified = 9,
        UnableToFetchSocialAppUser = 10,
        EmailNotVerified = 11,
        InvalidEmailPassword = 12,
        DTOneServiceError = 13,
        InvalidProduct = 14,
        InsufficientBalanceInAccount = 15,
        AccountBalanceTransactionFailed = 16,
        PaymentApiNotResponding = 17,
        PaymentFailure = 18,
        CreditHistoryNotFound = 19,
        TransferCreditHistoryNotFound = 20,
        TopUpAmountsNotFound = 21,
        FavouriteTransactionNumbersNotFound = 22,
        TransferPendingTwoFactorAuthentication = 23,
        EmailVerificationPending = 24,
        NumberAlreadyExistInFavourites = 25,
        AutoTransferNumbersNotFound = 26,
        ApplePayTopUpFailed = 27,
        TopupNumberLimitExceed = 28,
        TopupAmountLimitExceed = 29,
        DenominationsNotAvailable = 30,
        DenominationBlocked = 31,
        OperatorBlocked = 32,
        CardCustomerNotExist = 33,
        Pay360ServiceError = 34,
        RecordNotFound = 35
    }
}
