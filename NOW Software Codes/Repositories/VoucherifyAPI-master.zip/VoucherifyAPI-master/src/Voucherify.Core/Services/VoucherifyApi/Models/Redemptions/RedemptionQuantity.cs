using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Redemptions;

public class RedemptionQuantity
{
    [JsonPropertyName("quantity")]
    public int? Quantity { get; private set; }
}
