﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.Contracts.Service;
using Twilio.Rest.Api.V2010.Account;

namespace TransferHome.Infrastructure.Services.Interfaces
{
    public interface ISmsService
    {
        //Task<SmsServiceModels.XeebiSendSmsResponse> SendXeebiSms(string to, string textMessage);
        //Task<MessageResource> SendTwilioSms(string from, string to, string textMessage);
        Task SendSms(string to, string textMessage);
        Task ReSendSms(int phoneCountryCode, string to, string textMessage);
    }
}
