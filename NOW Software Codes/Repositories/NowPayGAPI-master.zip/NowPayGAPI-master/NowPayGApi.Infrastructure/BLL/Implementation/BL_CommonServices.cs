﻿using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.Utility;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using NowPayGApi.Models.Configurations;
using Microsoft.Extensions.Options;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.DAOs.Digitalk;

namespace NowPayGApi.Infrastructure.BLL.Implementation
{
    public class BL_CommonServices : IBL_CommonServices
    {
        private readonly IDL_CommonServices DL;
        private readonly IDL_Digitalk DDL;
        private readonly AddressApiConfig AddressApiConfig;

        public BL_CommonServices(IDL_CommonServices dl, IDL_Digitalk ddl, IOptions<AddressApiConfig> addressApiConfig)
        {
            DL = dl;
            DDL = ddl;
            AddressApiConfig = addressApiConfig.Value;
        }

        public async Task<GenericApiResponse<GetPlansResponseModel>> GetAllActivePlans()
        {
            try
            {
                var result = await DL.GetAllActivePlans();
                if (result != null && result.Count() > 0)
                {
                    GetPlansResponseModel model = new GetPlansResponseModel()
                    {
                        Plans = result,
                    };
                    return GenericApiResponse<GetPlansResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetPlansResponseModel>.Failure("Plans not found.", ApiStatusCodes.NoPlanFound);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetPlansResponseModel>> GetAllPlans()
        {
            try
            {
                var result = await DL.GetAllPlans();
                if (result != null && result.Count() > 0)
                {
                    GetPlansResponseModel model = new GetPlansResponseModel()
                    {
                        Plans = result,
                    };
                    return GenericApiResponse<GetPlansResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetPlansResponseModel>.Failure("Plans not found.", ApiStatusCodes.NoPlanFound);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetCountriesResponseModel>> GetCountries()
        {
            try
            {
                var result = await DL.GetCountry();
                if (result != null && result.Count() > 0)
                {
                    GetCountriesResponseModel model = new GetCountriesResponseModel()
                    {
                        Countries = result,
                    };
                    return GenericApiResponse<GetCountriesResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetCountriesResponseModel>.Failure("Countries not found.", ApiStatusCodes.NoCountryFound);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetPlanCategoriesResponseModel>> GetPlanCategories()
        {
            try
            {
                var result = await DL.GetPlanCategories();
                if (result != null && result.Count() > 0)
                {
                    GetPlanCategoriesResponseModel model = new GetPlanCategoriesResponseModel()
                    {
                        PlanCategories = result,
                    };
                    return GenericApiResponse<GetPlanCategoriesResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetPlanCategoriesResponseModel>.Failure("Categories not found.", ApiStatusCodes.DBError);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetProductResponseModel>> GetProduct()
        {
            try
            {
                var result = await DL.GetProduct();
                if (result != null && result.Count() > 0)
                {
                    GetProductResponseModel model = new GetProductResponseModel()
                    {
                        Products = result,
                    };
                    return GenericApiResponse<GetProductResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetProductResponseModel>.Failure("Products not found.", ApiStatusCodes.DBError);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetCurrencyResponseModel>> GetCurrency()
        {
            try
            {
                var result = await DL.GetCurrency();
                if (result != null && result.Count() > 0)
                {
                    GetCurrencyResponseModel model = new GetCurrencyResponseModel()
                    {
                        Currencies = result,
                    };
                    return GenericApiResponse<GetCurrencyResponseModel>.Success(model, "Success");
                }
                else
                {
                    return GenericApiResponse<GetCurrencyResponseModel>.Failure("Currencies not found.", ApiStatusCodes.DBError);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetPlanResponseModel>> GetPlanById(IdRequestModel model)
        {
            try
            {
                var result = await DL.GetPlanById(model);
                if (result != null)
                {
                    return GenericApiResponse<GetPlanResponseModel>.Success(result, "Success");
                }
                else
                {
                    return GenericApiResponse<GetPlanResponseModel>.Failure("Plans not found.", ApiStatusCodes.NoPlanFound);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetAllInternationalRatesResponseModel>> GetAllInternationalRates()
        {
            try
            {
                var result = await DL.GetAllInternationalRates();
                if (result != null && result.Count() > 0)
                {
                    var InternationalRatesList = new GetAllInternationalRatesResponseModel()
                    {
                        InternationalRatesList = result.Select(rates => new InternationalRatesResponseModel()
                        {
                            Id = rates.Id,
                            LandlineRate = rates.LandlineRate,
                            SmsRate = rates.SmsRate,
                            CountryId = rates.CountryId,
                            MobileRate = rates.MobileRate,
                            LandlineRateOffpeak = rates.LandlineRateOffpeak,
                            MobileRateOffpeak = rates.MobileRateOffpeak,
                            SmsRateOffpeak = rates.SmsRateOffpeak,
                            TopRateIndex = rates.TopRateIndex,
                            TopRates = rates.TopRates,
                            CreatedBy = rates.CreatedBy,
                            LastUpdatedBy = rates.LastUpdatedBy,
                            isActive = rates.IsActive,
                            Name = rates.Name,
                            IsoTwoCharacterCode = rates.IsoTwoCharacterCode,
                            PhoneCode = rates.PhoneCode,
                            IsNational = rates.IsNational
                        }).AsEnumerable()
                    };
                    return GenericApiResponse<GetAllInternationalRatesResponseModel>.Success(InternationalRatesList, "Found international rates data.");
                }
                return GenericApiResponse<GetAllInternationalRatesResponseModel>.Failure("International rates not found.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetRoamingRatesResponseModel>> GetRoamingRates(GetRoamingRatesRequestModel model)
        {
            try
            {
                var result = await DL.GetRoamingRates(model.FromCountryId, model.ToCountryId);
                if (result != null)
                {
                    var data = new GetRoamingRatesResponseModel()
                    {
                        RoamingRates = new RoamingRatesResponseModel()
                        {
                            DataRate = result.DataRate,
                            SmsRate = result.SmsRate,
                            VoiceRate = result.VoiceRate
                        }
                    };
                    return GenericApiResponse<GetRoamingRatesResponseModel>.Success(data, "Found roaming rates data.");
                }
                return GenericApiResponse<GetRoamingRatesResponseModel>.Failure("Roaming rates not found.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetAllUKRatesResponseModel>> GetAllUKRates()
        {
            try
            {
                var result = await DL.GetAllUKRates();
                if (result != null && result.Count() > 0)
                {
                    var UKRatesList = new GetAllUKRatesResponseModel()
                    {
                        UKRatesList = result.Select(rates => new UKRatesResponseModel()
                        {
                            Id = rates.Id,
                            Data = rates.Data,
                            Landline = rates.Landline,
                            Mobile = rates.Mobile,
                            Text = rates.Text,
                            CreatedBy = rates.CreatedBy,
                            LastUpdatedBy = rates.LastUpdatedBy,
                            isActive = rates.IsActive
                        }).AsEnumerable()
                    };
                    return GenericApiResponse<GetAllUKRatesResponseModel>.Success(UKRatesList, "Found UK rates data.");
                }
                return GenericApiResponse<GetAllUKRatesResponseModel>.Failure("UK rates not found.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetAllCountriesWithPlansResponseModel>> GetAllCountriesWithPlans()
        {
            try
            {
                var result = await DL.GetAllCountriesWithPlans();
                if (result != null && result.Count() > 0)
                {
                    var CountriesList = new GetAllCountriesWithPlansResponseModel()
                    {
                        CountriesList = result.Select(plans => new CountryResponseModel()
                        {
                            Id = plans.Id,
                            Name = plans.Name,
                            IsNational = plans.IsNational,
                            IsoNumericCode = plans.IsoNumericCode,
                            PhoneCode = plans.PhoneCode,
                            IsoTwoCharacterCode = plans.IsoTwoCharacterCode,
                            IsoThreeCharacterCode = plans.IsoThreeCharacterCode
                        }).AsEnumerable()
                    };
                    return GenericApiResponse<GetAllCountriesWithPlansResponseModel>.Success(CountriesList, "Found countries which have plans.");
                }
                return GenericApiResponse<GetAllCountriesWithPlansResponseModel>.Failure("Countries not found.", ApiStatusCodes.NoCountryFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetAddressResponseModel>> GetAddresses(GetAddressesRequestModel model)
        {
            try
            {
                var result = await GetAddressesFromApi(model.postCode);
                if (result != null && result.Addresses.Count() > 0)
                {
                    return GenericApiResponse<GetAddressResponseModel>.Success(result, "address found against postal code.");
                }
                return GenericApiResponse<GetAddressResponseModel>.Failure("address not found against postal code.", ApiStatusCodes.NoAddressFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetSimOrdersNoByEmailResponseModel>> GetSimOrdersNoByEmail(GetSimOrdersNoByEmailRequestModel model)
        {
            try
            {
                var result = await DL.GetSimOrderNoByEmail(model.Email);
                if (result != null)
                {
                    return GenericApiResponse<GetSimOrdersNoByEmailResponseModel>.Success(result, "Success");
                }
                return GenericApiResponse<GetSimOrdersNoByEmailResponseModel>.Failure("failure", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task<GetAddressResponseModel> GetAddressesFromApi(string postCode)
        {

            var Result = await Get(AddressApiConfig.ApiEndpoint + postCode);

            if (Result != null)
            {
                return JsonConvert.DeserializeObject<GetAddressResponseModel>(Result);
            }
            else
            {
                return null;
            }
        }

        private async Task<string> Get(string baseUri)
        {
            try
            {
                using (var client = new HttpClient { BaseAddress = new Uri(baseUri), Timeout = TimeSpan.FromSeconds(60) })
                {
                    String encodedBaiscAuthToken = Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(AddressApiConfig.ApiKey));

                    client.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedBaiscAuthToken);
                    HttpResponseMessage response = await client.GetAsync("");
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    if (!response.IsSuccessStatusCode || response.Content == null)
                        throw new WebException();

                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch
            {
                return null;
            }
        }

        public async Task<GenericApiResponse<string>> GetFirstUseDate(string msisdn)
        {
            var accountResult = await DDL.GetUserAccount(msisdn);
            if (accountResult == null)
            {
                return GenericApiResponse<string>.Failure("Invalid msisdn", ApiStatusCodes.InvalidMsisdn);
            }

            var summaryResult = await DDL.GetUserAccountByAccountID(accountResult.AccountID);
            if (summaryResult == null)
            {
                return GenericApiResponse<string>.Failure("Invalid msisdn", ApiStatusCodes.InvalidMsisdn);
            }

            return GenericApiResponse<string>.Success(summaryResult.FirstDate, "Success");
        }
    }
}
