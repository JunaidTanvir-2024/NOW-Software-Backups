﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Response
{
    public class Pay360Resume3DResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }
    public class SetAutoTopupWithCardPay360Resume3DResponseModel
    {
        public AutoTopupInfo AutoTopupInfo { get; set; }
    }
    public class SetAutoRenewalWithCardPay360Resume3DResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
    }
    public class AutoTopupInfo
    {
        public float MaxSpendLimit { get; set; }
        public float TopupAmount { get; set; }
        public float ThresholdAmount { get; set; }
        public string Currency { get; set; }
    }
    public class TopupInfo
    {
        public string TransactionId { get; set; }
        public string TopupAmount { get; set; }
        public string Msisdn { get; set; }
        public string Currency { get; set; }
        public bool shouldSave { get; set; }
        public string origination { get; set; }
        public PaymentMethodTypes PaymentMethod { get; set; }
        public bool AutoTopup { get; set; }
    }
}
