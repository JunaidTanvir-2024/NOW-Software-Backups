﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Configurations
{

    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }

}
