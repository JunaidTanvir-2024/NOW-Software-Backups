﻿namespace SC.Core.Features.Users;
internal class GetLoginFailedAttempsHandler : IRequestHandler<GetLoginFailedAttempsRequest, IResultWrapper>
{
    private readonly IUserRepository _userRepository;
    public GetLoginFailedAttempsHandler(
     IUserRepository IUserRepository)
    {
        _userRepository = IUserRepository;
    }

    public async Task<IResultWrapper> Handle(GetLoginFailedAttempsRequest request, CancellationToken cancellationToken)
    {
        var response = await _userRepository.GetLoginFailedAttemps(request.UserID, request.ConsecutivePeriod);
        return ResultWrapper.Success(response);
    }
}

