﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Request
{
    public class ApiAddNUserTagsRequest
    {
        public ApiAddNUserTagsAudience audience { get; set; }
        public Dictionary<string, List<string>> add { get; set; }
       
    }
    public class ApiAddNUserTagsAudience
    {
        public List<string> named_user_id { get; set; }
    }       

    
}
