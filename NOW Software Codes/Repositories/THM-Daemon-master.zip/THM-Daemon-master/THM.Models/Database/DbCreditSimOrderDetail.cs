﻿using System;
using System.Collections.Generic;
using System.Text;
using THM.Models.Enums;

namespace THM.Models.Database
{
    public class DbCreditSimOrderDetail
    {
        public PaymentType payment_type { get; set; }
        public string payment_tran_id { get; set; }
        public long id { get; set; }
        public string amount { get; set; }
        public string bundleId { get; set; }
        public bool isProcessed { get; set; }
        public string fullName { get; set; }
        public string email { get; set; }
        public CreditSimType creditSim_type { get; set; }
    }
}
