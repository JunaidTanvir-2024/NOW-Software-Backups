using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace JM.Infrastructure.Services.Mailing;

public static class ConfigureSmtp
{
    #region Smtp Mail Dependency Extension
    internal static IServiceCollection AddSmtpConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        return services
                    .Configure<SmtpMailSetting>(configuration.GetSection(SmtpMailSetting.SectionName));
    }
    #endregion

    #region Smtp Mail Setting
    public sealed class SmtpMailSetting
    {
        public const string SectionName = nameof(SmtpMailSetting);
        public required string From { get; set; }
        public required string Host { get; set; }
        public required int Port { get; set; }
        public required string UserName { get; set; }
        public required string Password { get; set; }
        public required string DisplayName { get; set; }
    }
    #endregion
}
