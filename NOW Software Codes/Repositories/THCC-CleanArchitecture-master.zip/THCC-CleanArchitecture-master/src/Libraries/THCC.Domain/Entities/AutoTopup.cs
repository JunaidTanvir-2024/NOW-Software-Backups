﻿namespace THCC.Domain.Entities;

public class AutoTopup
{
    public string? Account { get; set; }
    public float ThresHold { get; set; }
    public float Topup { get; set; }
    public string? Currency { get; set; }
    public bool Status { get; set; }
    public string? MaskedPan { get; set; }
}