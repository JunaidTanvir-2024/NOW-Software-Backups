﻿namespace THCC.Domain.Entities
{
    public class OrderPoint
    {
        public long OrderId { get; set; }
        public decimal PointsReceived { get; set; }
        public decimal PointsRedeemed { get; set; }
        public decimal OpeningPoints { get; set; }
        public decimal ClosingPoints { get; set; }
        public decimal OpeningBalance { get; set; }
        public decimal ClosingBalance { get; set; }
    }
}