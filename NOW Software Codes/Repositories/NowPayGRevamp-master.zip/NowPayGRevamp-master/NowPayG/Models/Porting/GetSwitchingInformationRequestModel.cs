﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.Porting
{
    public class GetSwitchingInformationRequestModel
    {
        public string msisdn { get; set; }
    }
}
