using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;
namespace JM.Core.Features.ExpenseCategory;

public abstract class GetExpenseCategory
{
	#region Query
	public sealed record Query : IRequest<IResultWrapper>
	{
		public long Id { get; set; }
	}
	#endregion

	#region Validator
	public sealed class Validator : AbstractValidator<Query>
	{
		public Validator()
		{
			RuleFor(x => x.Id).GreaterThan(0);
		}
	}
	#endregion

	#region Response
	public sealed record Response
	{
		public long Id { get; set; }
		public required string Name { get; set; }
	}
	#endregion

	#region Handler
	internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
	{
		private readonly IUnitOfWork _unitOfWork = unitOfWork;

		public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
		{
			var expenseCategory = await _unitOfWork.ExpenseRepository.GetExpenseCategory(x => x.Id.Equals(query.Id));
			if (expenseCategory is not null)
			{
				return ResultWrapper.Success(new Response()
				{
					Name = expenseCategory.Name,
					Id = expenseCategory.Id
				});
			}

			return ResultWrapper.Failure(AppConstant.StatusKey.BadRequest, AppConstant.StatusCode.BadRequest);
		}
	}
	#endregion
}
