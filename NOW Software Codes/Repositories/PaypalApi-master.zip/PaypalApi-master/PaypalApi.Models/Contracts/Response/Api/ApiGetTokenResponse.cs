﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Response.Api
{
    
    public class ApiGetTokenResponse
    {
        [JsonProperty("scope")]
        public string Scope { get; set; }

        [JsonProperty("nonce")]
        public string Nonce { get; set; }

        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("token_type")]
        public string TokenType { get; set; }

        [JsonProperty("app_id")]
        public string AppId { get; set; }

        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }
        
    }
}
