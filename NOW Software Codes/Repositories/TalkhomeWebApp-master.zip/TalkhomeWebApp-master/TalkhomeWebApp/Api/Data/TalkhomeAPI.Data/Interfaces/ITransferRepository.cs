﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;

namespace TalkhomeAPI.Data.Interfaces
{
    public interface ITransferRepository
    {
        Task<InternationalTopupProduct> GetProductByNowtelTransactionReference(string guid, string product);
        Task<DBAccountBalance> UpdateAccountBalance(decimal amount, string accountID, string reference);
        Task CreateTransactionLogAsync(InternationalTopupTransactionLog transaction);

		Task UpdateTransactionLog(InternationalTopupTransactionLog transaction);
		Task<InternationalTopupTransactionLog> GetTransactionLog(string nowtelRef, string product);

		Task<PromotionBalanceDedutionDetails> InsertSpecialPromotionLogs(decimal amount, string accountID, string reference,string paymentMethod);
        Task<PromotionBalanceDedutionDetails> GetSpecialPromotionBalanceToDeduct(decimal amount, string accountID);
        Task SaveTransaction(DBTransferTransaction transaction);
        Task<TransferValidationResponse> ValidateTransferRequest(DBValidateTransferRequest request);
        Task<int> IsFirstInternationTopup(string account);
        Task<ValidateCustomer> ValidateNowtelCustomerNew(string frommsisdn, string nowtelreference, string product, decimal amount);
    }
}