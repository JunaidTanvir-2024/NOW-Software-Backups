using FluentValidation;

using Voucherify.Api.Features.Customers.Requests;

namespace Voucherify.Api.Features.Promotions.Requests;

public class RedeemPromotionTierRequest
{
    public string PromotionTierId { get; set; } = null!;
    public AddCustomerRequest Customer { get; set; } = null!;
}
internal class RedeemPromotionTierRequestValidator : AbstractValidator<RedeemPromotionTierRequest>
{
    public RedeemPromotionTierRequestValidator()
    {
        RuleFor(p => p.PromotionTierId).NotNull().NotEmpty();
        RuleFor(p => p.Customer).NotNull().NotEmpty();
    }
}