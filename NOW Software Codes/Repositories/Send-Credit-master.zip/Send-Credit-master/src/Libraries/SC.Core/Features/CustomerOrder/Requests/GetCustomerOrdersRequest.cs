﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class GetCustomerOrdersRequest : IRequest<IResultWrapper>
{

}
public sealed class GetCustomerOrdersRequestValidator : AbstractValidator<GetCustomerOrdersRequest>
{
    public GetCustomerOrdersRequestValidator() { }
}

