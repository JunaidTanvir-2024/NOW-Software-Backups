﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Infrastructure.BLL.MobiFin
{
    public interface IMobiFin_BL
    {
    }
}
