﻿using System.Text.Json.Serialization;
namespace NTCB.Api.Features.DTOne.Models;

public class CountryInfo
{
    [JsonPropertyName("iso_code")]
    public string? IsoCode { get; set; }
    
    [JsonPropertyName("name")]
    public string? Name { get; set; }
    
    [JsonPropertyName("regions")]
    public object? Regions { get; set; }
}
