﻿namespace THCC.Application.Features.User.History.PaymentHistory
{
    public class PaymentHistoryRequest : IRequest<object>
    {
        public int ProductType { get; set; }
        public int PageSize { get; set; } = 10;
        public int PageNo { get; set; } = 1;
    }

    public class OrderHistoryRequestValidator : AbstractValidator<PaymentHistoryRequest>
    {
        public OrderHistoryRequestValidator()
        {
            RuleFor(p => p.ProductType).Must(x => x == 0
                    || x == (int)ProductType.CallingCard
                    || x == (int)ProductType.RechargeableCallingCard);
            RuleFor(p => p.PageNo).Must(x => x >= 1);
        }
    }
}