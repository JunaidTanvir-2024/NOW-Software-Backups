﻿using THCC.Application.Extensions.DependencyResolver;

namespace THCC.Application.Interfaces.Services;

public interface IDiscountService : ServiceType.ITransient
{
    decimal GetDiscount(decimal amount);
}
