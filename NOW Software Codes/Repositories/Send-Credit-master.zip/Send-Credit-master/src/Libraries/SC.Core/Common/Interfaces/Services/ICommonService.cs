﻿

namespace SC.Core.Common.Interfaces.Services;

public interface ICommonService
{
    string GetRequestID();
    string GenerateRequestID();
    string GetUserID();
    string GetUserEmail();
    string GetDefaultCountryISO();
    string GetDefaultCurrency();
    string[] GetAllowedCurrencies();
    string GetIpAddress();
     string GetUserAgent();
    bool Do3DSecure();
}

