﻿using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IPush_BL
    {
        Task<GenericApiResponse<ApiPushResponse>> SendPushToTags(SendPushToTagsRequest request);
        Task<GenericApiResponse<ApiPushResponse>> SendPushToNamedUser(SendPushToNamedUserRequest request);
    }
}
