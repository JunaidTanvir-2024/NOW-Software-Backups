using Microsoft.Extensions.Options;

using Voucherify.Api.Features.Campaigns;
using Voucherify.Api.Features.Customers;
using Voucherify.Api.Features.EarningRules;
using Voucherify.Api.Features.Loyalties;
using Voucherify.Api.Features.Products;
using Voucherify.Api.Features.Promotions;
using Voucherify.Api.Features.Rewards;
using Voucherify.Api.Features.StackableDiscounts;
using Voucherify.Api.Features.Utility;
using Voucherify.Api.Features.Vouchers;
using Voucherify.Core.Commons.Extensions;
using Voucherify.Core.Commons.Middlewares;
using Voucherify.Core.Commons.Settings;

namespace Voucherify.Api;

public static class ConfigureMiddlewares
{
    public static WebApplication AddApiMiddlewares(this WebApplication app)
    {
        // Configure the HTTP request pipeline.
        app.UseExceptionMiddleware();
        app.UseSentryTracing();
        app.UseSwagger();
        app.UseSwaggerUI();
        app.UseHttpsRedirection();

        // Bind Api endpoints to the application
        app.EndpointsBinder();

        return app;
    }

    public static WebApplication EndpointsBinder(this WebApplication app)
    {
        var endpoint = app.Services.GetRequiredService<IOptions<EndpointsSettings>>().Value;

        // API Logging
        app.UseAppLoggingMiddleware();

        EnableOrDisableEndpoints(app, endpoint);
        return app;
    }

    private static void EnableOrDisableEndpoints(WebApplication app, EndpointsSettings endpoint)
    {
        if (endpoint.EnableVouchersEndpoint)
        {
            app.AddVouchersEndpoints();
        }
        if (endpoint.EnableCustomersEndpoint)
        {
            app.AddCustomersEndpoints();
        }
        if (endpoint.EnablePromotionsEndpoint)
        {
            app.AddPromotionsEndpoints();
        }
        if (endpoint.EnableCampaignsEndpoint)
        {
            app.AddCampaignsEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddEarningRulesEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddRewardsEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddUtilityEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddProductsEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddStackableDiscountsEndpoints();
        }
        if (endpoint.EnableEarningRulesEndpoint)
        {
            app.AddLoyaltiesEndpoints();
        }
    }
}
