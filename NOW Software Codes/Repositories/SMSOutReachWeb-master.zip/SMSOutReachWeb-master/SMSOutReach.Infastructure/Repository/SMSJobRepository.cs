﻿using Dapper;
using Microsoft.Extensions.Options;
using SMSOutReach.Infastructure.Interface;
using SMSOutReach.Modal.Configurations;
using SMSOutReach.Modal.Xeebi;
using SMSOutReach.Model.Configurations;
using SMSOutReach.Model.Connections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;


namespace SMSOutReach.Infastructure.Repository
{
    public class SMSJobRepository : ISMSJob
    {

        private IDbConnectionSettings DbConnection;
        private readonly IOptions<ApplicationSetting> settings;

        public SMSJobRepository(IOptions<ConnectionString> connectionString, IOptions<ApplicationSetting> _settings)
        {

            DbConnection = new DbConnectionSettings(new SqlConnection(connectionString.Value.DefaultConnection));
            settings = _settings;
        }

        // get jobs which dont have status of remove or archieve 
        public async Task<List<ViewSmsJob>> GetSMSJobs()
        {
            List<ViewSmsJob> response = null;
            try
            {
                var result = await DbConnection.SqlConnection.QueryAsync<ViewSmsJob>("Sp_Ui_GetCurrentSmsJobs", commandType: CommandType.StoredProcedure);
                response = result.AsList();
                return response;

            }
            catch (Exception ex)
            {
                return response;
            }
        }

        // get all jobs which  have status of remove or archieve 
        public async Task<List<ViewSmsJob>> GetAllSMSJobs()
        {
            List<ViewSmsJob> response = null;
            try
            {
                var result = await DbConnection.SqlConnection.QueryAsync<ViewSmsJob>("Sp_Ui_GetAllSmsJobs", commandType: CommandType.StoredProcedure);
                response = result.AsList();
                return response;

            }
            catch (Exception ex)
            {
                return response;
            }
        }


        public async Task<List<ViewSmsJob>> GetPendingSMSJobs(DateTime jobStartDate, int carrierId)
        {
            List<ViewSmsJob> response = null;
            try
            {
                var p = new DynamicParameters();
                p.Add("@JobStartDate", jobStartDate, DbType.Date);
                p.Add("@CarrierId", carrierId, DbType.Int16);
                var result = await DbConnection.SqlConnection.QueryAsync<ViewSmsJob>("Sp_Ui_GetPendingSmsJobsXeebi", p, commandType: CommandType.StoredProcedure);
                response = result.AsList();
                return response;

            }
            catch (Exception ex)
            {
                return response;
            }
        }


        public async Task<ViewSmsJob> GetSelectedSMSJobDetail(int SelectedJobId)
        {
            ViewSmsJob response = null;
            try
            {
                var p = new DynamicParameters();
                p.Add("@JobId", SelectedJobId, DbType.Int16);
                var result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<ViewSmsJob>("Sp_Ui_GetJobAndDetailsByJobId", p, commandType: CommandType.StoredProcedure);
                response = result;
                return response;

            }
            catch (Exception ex)
            {
                return response;
            }
        }

        public async Task<DBResult> InsertSmsJob(SMSJob job, DataTable JobDetails)
        {
            DBResult result = null;
            try
            {

                var priority = settings.Value.JobPriority;
                var parameters = new
                {
                    SenderProductId = job.SenderProductID,
                    JobPriority = priority,
                    JobIndex = job.Index,
                    CarrierId = job.CarrierId,
                    UserId = job.UserId,
                    Campaign = job.Campaign,
                    Message = job.Message,
                    StartDate = job.StartTime,
                    SmsCount = job.SmsCount,
                    FirstPendingJobId = job.FirstPendingJobId,
                    FirstJobIndex = job.FirstJobIndex,
                    SecondPendingJobId = job.SecondPendingJobId,
                    SecondJobIndex = job.SecondJobIndex,
                    TblSmsJob = JobDetails.AsTableValuedParameter("dbo.SmsJobDetailsType")
                };

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DBResult>("Sp_Ui_InsertSmsJobDetails", parameters, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                result = new DBResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }

        public async Task<DBResult> InsertSmsJobApi(SMSJob job, string UserMsisdn)
        {
            DBResult result = null;
            try
            {

                var parameters = new
                {
                    SenderProductId = job.SenderProductID,
                    CarrierId = job.CarrierId,
                    UserId = job.UserId,
                    Campaign = job.Campaign,
                    Message = job.Message,
                    StartDate = job.StartTime,
                    UserMsisdn = UserMsisdn,
                    SmsCount = job.SmsCount,
                    JobPriority = job.Priority
                };

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DBResult>("Sp_Ui_InsertSmsJobApi", parameters, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                result = new DBResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }

        public async Task<DBResult> UpdateSmsJobStatus(int jobId, int newJobStatusid, int currentJobstatusId )
        {
            DBResult result = null;
            try
            {

                var parameters = new
                {

                    JobId = jobId,
                    NewJobStatusId = newJobStatusid,
                    OldJobStatusId = currentJobstatusId
                };

                result = await DbConnection.SqlConnection.QueryFirstOrDefaultAsync<DBResult>("Sp_Ui_UpdateJobStatus", parameters, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                result = new DBResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }
    }
}
