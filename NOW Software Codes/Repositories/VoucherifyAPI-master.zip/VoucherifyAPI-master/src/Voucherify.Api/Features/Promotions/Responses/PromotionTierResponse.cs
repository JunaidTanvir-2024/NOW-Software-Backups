﻿using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Responses;

public class PromotionTierResponse
{
    public string? PromotionId { get; set; }

    public string? CampaignId { get; set; }

    public DateTime? CampaignStartDate { get; set; }

    public DateTime? CampaignExpirationDate { get; set; }

    public bool? IsCampaignActive { get; set; }

    public string? Name { get; set; }

    public string? Banner { get; set; }

    public long? AmountOff { get; set; }

    public double? PercentOff { get; set; }

    public double? UnitOff { get; set; }

    public string? UnitType { get; set; }

    public string? DiscountEffect { get; set; }

    public string? DiscountType { get; set; }

    public long? AmountLimit { get; set; }

    public string? Category { get; set; }

    public string? CategoryId { get; set; }

    public Metadata? Metadata { get; set; }
}
