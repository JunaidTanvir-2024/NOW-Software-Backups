﻿using Models.Common;

namespace Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Common
{
    public class StackableDiscountInfo
    {
        public string DiscountCode { get; set; }
        public string DiscountType { get; set; }
        public string RewardId { get; set; }
        public Metadata Metadata { get; set; }
    }
}
