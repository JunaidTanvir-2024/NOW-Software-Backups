﻿using System;
using System.Threading.Tasks;
using Infrastructure.BLL.Implementation;
using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using Serilog;

namespace AirShipApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {

        private readonly ILogger Logger;
        private IEmail_BL EmailBl;

        public EmailController(ILogger logger, IEmail_BL emailBl)
        {
            Logger = logger;
            EmailBl = emailBl;
        }

        [HttpPost]
        [Route("GetChannelByEmail")]
        public async Task<IActionResult> GetChannelByEmail(GetChannelByEmailRequest request)
        {
            try
            {
                var response = await EmailBl.GetChannelByEmail(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: NamedUserController, Method: GetChannelByEmail, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<ApiGetChannelByEmailResponse>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }

        [HttpPost]
        [Route("AddEmailChannel")]
        public async Task<IActionResult> AddEmailChannel(AddEmailChannelRequest request)
        {
            try
            {
                var response = await EmailBl.AddEmailChannel(request);
                return Ok(response);

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: EmailController, Method: AddEmailChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return Ok(GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException));
            }
        }
    }
}