﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class RemoveFavouriteTransactionNumberRequestModel
    {
        public string Number { get; set; }
    }
}
