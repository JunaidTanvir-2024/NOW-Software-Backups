﻿using System.Data;

using Dapper;

using Microsoft.Extensions.Configuration;

using THCC.Application.Interfaces.Repositories;
using THCC.Infrastructure.Persistence.DapperConfigurations;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Persistence.Repositories;
public class OtpRepository : IOtpRepository
{
    private readonly IConfiguration _configuration;

    public OtpRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task SaveToken(string otp, string uniqueRef, string token, OtpType type)
    {
        var p = new DynamicParameters();
        p.Add("@otp", otp);
        p.Add("@email", uniqueRef);
        p.Add("@type", (int)type);
        p.Add("@token", token);

        await DapperWrapper.ExecuteAsync(StoredProcedures.SaveToken, p, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
    }

    public async Task<string> GetToken(string otp, string uniqueRef, OtpType type)
    {
        var p = new DynamicParameters();
        p.Add("@email", uniqueRef);
        p.Add("@otp", otp);
        p.Add("@type", type);

        return await DapperWrapper.QueryFirstOrDefaultAsync<string>(StoredProcedures.GetConfirmationToken, p, commandType: CommandType.StoredProcedure, _configuration.GetConnectionString(ConnectionStrings.DefaultConnection));
    }
}
