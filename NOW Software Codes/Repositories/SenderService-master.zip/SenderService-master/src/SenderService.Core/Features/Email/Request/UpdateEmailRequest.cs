﻿using SenderService.Core.Features.Email.Models;
using System.ComponentModel.DataAnnotations;

namespace SenderService.Core.Features.Email.Request;

public class UpdateEmailRequest
{
    [EmailAddress]
    public string Email { get; set; } = default!;
    public string Subject { get; set; } = default!;
    public string Body { get; set; } = default!;
    [EmailAddress]
    public string FromEmail { get; set; } = default!;
    public string FromName { get; set; } = default!;
    public byte Priority { get; set; }
    public byte ProcessingStatus { get; set; }
    //public string? AttachmentFilePath { get; set; }
    public DateTimeOffset ScheduledDateTimeUtc { get; set; }
    public List<RecipientsInfo> Recipients { get; set; } = new List<RecipientsInfo>();
    public long ProductCodeId { get; set; }
}