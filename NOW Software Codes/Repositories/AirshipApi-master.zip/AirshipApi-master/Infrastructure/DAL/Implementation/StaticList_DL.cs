﻿using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.DbConnections;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using Serilog;
using Microsoft.Extensions.Options;
using Models.Contracts;
using Models.Contracts.Airship.Response;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Dapper;
using System.Data;
using Models.Enums;
using Models.Contracts.Request;

namespace Infrastructure.DAL.Implementation
{
   public class StaticList_DL: IStaticList_DL
    {
        private IDbConnectionSettings DefaultConnection;
        private ILogger Logger;

        public StaticList_DL(IOptions<ConnectionStrings> connectionConfig, ILogger logger)
        {

            DefaultConnection = new DbConnectionSettings(new SqlConnection(connectionConfig.Value.DefaultConnection));
            Logger = logger;
        }

        public async Task<GenericResult<bool>> AddList(AddListRequest list, string productCode)
        {
            string logParameters = $" productCode: {productCode}, {JsonConvert.SerializeObject(list)} ";
            try
            {

                var parameter = new DynamicParameters();
                parameter.Add("@productCode", productCode);
                parameter.Add("@name", list.name);
                parameter.Add("@description",list.description);
                parameter.Add("@extra", list.extra.ToString());
               

                var result = await DefaultConnection.SqlConnection.QueryFirstOrDefaultAsync<GenericResult<bool>>("Api_AddStaticList", parameter, commandType: CommandType.StoredProcedure);

                return result;

            }
            catch (Exception ex)
            {
                var errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class: StaticList_DL, Method: AddList, Parameters => {logParameters}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return new GenericResult<bool> { Status = Status.Failure, ErrorMessage = errorMessage, ErrorCode = 2 };
            }

        }
    }
    
}
