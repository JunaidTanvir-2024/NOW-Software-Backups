namespace MM.Core.Common.Definitions.Constants;

public static partial class AppConstants
{
    public static class StatusCodes
    {
        // Commonly Used Status Codes
        public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;
        public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
        public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
        public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
        public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
    }
}
