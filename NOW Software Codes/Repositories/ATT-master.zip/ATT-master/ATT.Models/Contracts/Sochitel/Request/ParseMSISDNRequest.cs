﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ATT.Models.Contracts.Sochitel.Request
{
    public class ParseMSISDNRequest : BaseRequest 
    {
        public string command = "parseMsisdn";

        public string msisdn { get; set; }
    }
}
