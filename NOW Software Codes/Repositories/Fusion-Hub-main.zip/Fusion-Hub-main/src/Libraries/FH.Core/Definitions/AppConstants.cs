namespace FH.Core.Definitions;

public static class AppConstants
{
    public static class ContentType
    {
        public const string ApplicationJson = "application/json";
        public const string ApplicationOctetStream = "application/octet-stream";
        public const string ApplicationXml = "application/xml";
        public const string XlsxFile = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }

    public static class Database
    {
        public static class StoreProcedure
        {
            public const string CountriesGet = "dbo.fh_countries_get";
            public const string CountriesGetAll = "dbo.fh_countries_getall";
            public const string CountryByIsoCode = "dbo.fh_country_by_iso_code_get";
            public const string AppLogUpsert = "dbo.fh_app_log_upsert";
            public const string VendorLogInsert = "dbo.fh_vendor_log_insert";
            public const string VendorOperatorBulkInsert = "dbo.fh_vendor_operator_bulk_insert";
            public const string OperatorsBulkInsert = "dbo.fh_operator_bulk_insert";
            public const string ProductsGet = "dbo.fh_product_get";
            public const string ProductDetailGet = "dbo.fh_product_details_get";
            public const string ProductCategoryBulkInsert = "dbo.fh_product_category_bulk_insert";
            public const string ProductSubCategoryBulkInsert = "dbo.fh_product_subcategory_bulk_insert";
            public const string CurrencyUnitBulkInsert = "dbo.fh_currency_unit_bulk_insert";
            public const string ProductBulkInsert = "dbo.fh_product_bulk_insert";
            public const string ProductPriceBulkInsert = "dbo.fh_product_price_bulk_insert";
            public const string ProductBenefitBulkInsert = "dbo.fh_product_benefit_bulk_insert";
            public const string VendorDataHashGet = "dbo.fh_vendor_data_hash_get";
            public const string VendorDataHashInsert = "dbo.fh_vendor_data_hash_insert";
            public const string OperatorByNameGet = "dbo.fh_operator_by_name_get";
            public const string OperatorByVendorCodeGet = "dbo.fh_operator_by_vendor_code_get";
            public const string OperatorsGet = "dbo.fh_operator_get";
            public const string ProductTransactionInsert = "dbo.fh_product_transaction_insert";
            public const string ProductTransactionUpdate = "dbo.fh_product_transaction_status_update";
            public const string ProductStatusGet = "dbo.fh_product_status_get";
            public const string ProductAliasesUpdate = "dbo.fh_product_aliases_update";
            public const string OperatorAliasesUpdate = "dbo.fh_operator_aliases_update";
            public const string SubCategoryGet = "dbo.fh_sub_category_get";
            public const string ProductsByOperatorGet = "dbo.fh_product_operator_get";
            public const string ProductSubCategoryByCategory = "dbo.fh_product_each_subcategory_get";
            public const string OperatoryByProductCategoryGet = "dbo.fh_operator_by_Category_get";
            public const string OperatoryBySubCategoryGet = "dbo.fh_operator_by_sub_category_get";
        }

        public static class TableType
        {
            public const string CurrencyUnit = "dbo.currency_unit_type";
            public const string Operator = "dbo.operator_type";
            public const string VendorOperator = "dbo.vendor_operator_type";
            public const string ProductCategory = "dbo.product_category_type";
            public const string ProductSubCategory = "dbo.product_subcategory_type";
            public const string Product = "dbo.product_type";
            public const string ProductPrice = "dbo.product_price_type";
            public const string ProductBenefit = "dbo.product_benefit_type";
            public const string CountryFilter = "country_filters_type";
            public const string OperatorFilter = "operator_filters_type";
            public const string ProductFilter = "product_filters";
            public const string ProductStatusType = "product_status_type";
            public const string ProductAliasType = "product_alias_type";
            public const string OperatorAliasType = "operator_alias_type";
            public const string ProductByCategoryType = "product_subcategory_filters_type";
        }

        public static class Name
        {
            public const string FusionHub = "FusionHub";
            public const string MessageBroker = "MessageBroker";
        }
    }

    public static class SecurityHeader
    {
        public const string XFrameOptions = "X-FrameOptions";
        public const string XContentTypeOptions = "X-Content-Type-Options";
        public const string ReferrerPolicy = "Referrer-Policy";
        public const string PermissionsPolicy = "Permissions-Policy";
        public const string SameSite = "SameSite";
        public const string XXSSProtection = "X-XSS-Protection";
        public const string ContentPolicy = "ContentPolicy";
    }

    public static class StatusKey
    {
        public const string Success = "Congratulations! Your request was fulfilled successfully.";
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Whoops! Something went wrong on our end. Please try again later.";

        // Transaction
        public const string TransactionCreated = "CREATED";

        public const string TransactionCancelled = "CANCELLED";
        public const string TransactionRejected = "REJECTED";
        public const string TransactionDeclined = "DECLINED";
        public const string TransactionCompleted = "COMPLETED";
        public const string TransactionReversed = "REVERSED";
        public const string TransactionConfirmed = "CONFIRMED";
        public const string TransactionSubmitted = "SUBMITTED";
    }

    public static class StatusCode
    {
        // Commonly Used Status Codes
        public const int Success = Microsoft.AspNetCore.Http.StatusCodes.Status200OK;

        public const int BadRequest = Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest;
        public const int Forbidden = Microsoft.AspNetCore.Http.StatusCodes.Status403Forbidden;
        public const int NotFound = Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound;
        public const int Unauthorized = Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized;
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
    }
}
