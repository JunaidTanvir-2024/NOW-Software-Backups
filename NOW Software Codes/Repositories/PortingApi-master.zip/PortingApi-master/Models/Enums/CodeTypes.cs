﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Enums
{
    public enum CodeTypes
    {
        PAC = 1,
        STAC = 2
    }
}
