﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ViewModels
{
    public class FastTopUpViewModel
    {
        [Required(ErrorMessage = "Enter Number"), MaxLength(length: 12, ErrorMessage = "Maximum 12 characters allowed."), MinLength(length: 10, ErrorMessage = "Minimum 10 characters allowed.")]
        public string Msisdn { get; set; }
        public int TopUpAmount { get; set; }
        public bool IsAutoTopUp { get; set; }
    }
}
