﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeAPI.Data.Interfaces;
using TalkhomeAPI.Enums;
using TalkhomeAPI.Infrastructure.Common.Configurations;
using TalkhomeAPI.Infrastructure.Common.ExtensionMethods;
using TalkhomeAPI.Infrastructure.Common.Models;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Implementations;
using TalkhomeAPI.Infrastructure.Common.Services.Interfaces;
using TalkhomeAPI.Infrastructure.Common.Services.Models.Airship;
using TalkhomeAPI.Infrastructure.Common.Services.Models.ATTApiContracts;
using TalkhomeAPI.Infrastructure.Common.Services.Models.PaypalApiContracts;
using TalkhomeAPI.Models.Configurations;
using TalkhomeAPI.Models.Pay360ApiContracts;
using TalkhomeAPI.Models.PaypalApiContracts;
using TalkhomeAPI.Services.Interfaces;
namespace TalkhomeAPI.Services.Services
{
    public class TransferService : ITransferService
    {
        private readonly IATTService _aTTService;
        private readonly IPayPalService _payPalService;
        private readonly IPay360Service _pay360Service;
        private readonly ILogger _logger;
        private readonly ITransferRepository _transferRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IAppsFlyerService _appsFlyerService;
        private readonly IAirShipService _airShipService;
        private readonly IEmailService _emailService;

        private readonly Pay360Config _pay360Config;
        private readonly PayPalConfig _payPalConfig;

        private readonly bool TransferIsAuthorization;

        public TransferService(IEmailService emailService,
                                IATTService aTTService,
                                IPayPalService payPalService,
                                IPay360Service pay360Service,
                                ILogger logger,
                                ITransferRepository transferRepository,
                                IAccountRepository accountRepository,
                                IAppsFlyerService appsFlyerService,
                                IOptions<PayPalConfig> paypalConfig,
                                IOptions<Pay360Config> pay360Config,
                                IAirShipService airShipService)
        {
            _emailService = emailService;
            _aTTService = aTTService;
            _payPalService = payPalService;
            _pay360Service = pay360Service;
            _logger = logger;
            _transferRepository = transferRepository;
            _accountRepository = accountRepository;
            _appsFlyerService = appsFlyerService;
            _airShipService = airShipService;
            _pay360Config = pay360Config.Value;
            _payPalConfig = paypalConfig.Value;
            TransferIsAuthorization = pay360Config.Value.TransferIsAuthorization;
        }

        public async Task<GenericApiResponse<GetProductsResponseModel>> GetProducts(
            string toMsisdn, string fromMsisdn, string currency)
        {
            var productsResponse = await _aTTService.GetProducts(fromMsisdn, toMsisdn.Trim(), currency);

            if (productsResponse == null)
            {
                return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. Please, try again later.",
                        ApiStatusCodes.DTOneServiceError);
            }

            if (productsResponse.errorCode == 0
                    && productsResponse.errorCodeDtOne == 0
                    && productsResponse.payload != null
                    && productsResponse.payload.operators != null
                    && productsResponse.payload.operators.Count > 0)
            {
                var responseData = productsResponse.payload.operators.FirstOrDefault();

                if (responseData.products != null)
                {
                    var response = new GetProductsResponseModel()
                    {
                        Operator = new ATTOperator()
                        {
                            Accessid = responseData.accessid,
                            Country = responseData.country,
                            IconUri = responseData.iconUri,
                            Id = responseData.id,
                            Name = responseData.name,
                            NowtelTransactionReference = responseData.nowtelTransactionReference
                        }
                    };

                    if (responseData.products.Count > 0)
                    {
                        response.Products = responseData.products.Select(item => new ATTProduct()
                        {
                            ClientCurrecny = item.clientccy,
                            ItemPriceClientCurrency = item.itemPriceClientccy,
                            Product = item.product,
                            ReceiverCurrecny = item.receiverccy,
                            TotalPriceClientCurrency = item.totalPriceClientccy,
                            TransactionFeeClientCurrency = item.transactionfeeClientccy
                        });
                    };

                    return GenericApiResponse<GetProductsResponseModel>.Success(response, "products successfully found");
                }
                else
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. Please, try again later.",
                        ApiStatusCodes.DTOneServiceError);
                }
            }
            else
            {
                if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationsNotAvailable)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                       "Transfer service for this country is not available at the moment. " +
                       "Pease try again later.", ApiStatusCodes.DenominationsNotAvailable);
                }

                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DenominationBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                        "Transfer service for this number is not available at the moment. " +
                        "Pease try again later.", ApiStatusCodes.DenominationBlocked);
                }
                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.OperatorBlocked)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                         "Transfer service for this number is not available at the moment. " +
                         "Pease try again later.", ApiStatusCodes.OperatorBlocked);
                }

                else if (productsResponse.errorCodeDtOne == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                {
                    return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                       "Destination number is invalid", ApiStatusCodes.DestinationMsisdnOutOfRange);
                }

                _logger.Error($"Class: TransferService, Method: GetProducts, " +
                    $"Parameters=> Model : {JsonConvert.SerializeObject(toMsisdn + fromMsisdn + currency)}, " +
                    $"ErrorMessage: {JsonConvert.SerializeObject(productsResponse)}");

                return GenericApiResponse<GetProductsResponseModel>.Failure(null,
                    "Transfer service for this number is not available at the moment. Please, try again later.",
                    ApiStatusCodes.DTOneServiceError);
            }
        }

        public async Task<GenericApiResponse<TransferByAccountBalanceResponseModel>> TransferByAccountBalance(
           TransferByAccountBalanceRequestModel model, string msisdn, string currency)
        {
            var packageDetails = await _transferRepository.
                        GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());

            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }
            //Validate trasnfer request 
            var validationResponse = await ValidateTransferRequest(
                    accountResponse.AccountID,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }

            if (accountResponse.Balance < amountToCharge)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                            "Balance is insufficient", ApiStatusCodes.InsufficientBalance);
            }

            //Deduct Balance passing actual value because sp is deducting the promo amount already in case of credit 
            var paymentResponse = await _transferRepository.UpdateAccountBalance(
                                            -Convert.ToDecimal(packageDetails.CustomerChargeValue), accountResponse.AccountID, "");

            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }
            else if (string.IsNullOrEmpty(paymentResponse.audit_id))
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                        $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(paymentResponse)}");

                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            //Send Credit
            var transferResponse = await _aTTService.Execute(new ExecuteDataRequest()
            {
                fromMSISDN = packageDetails.fromMsisdn,
                messageToRecipient = string.Empty,
                nowtelTransactionReference = packageDetails.GUID,
                operatorid = model.operatorId.ToString(),
                product = model.product.ToString()
            });

            //Save transaction
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber ToNumber = phoneNumberUtil.Parse(packageDetails.tomsisdn.StartsWith("+") ?
                                        packageDetails.tomsisdn.Trim() : "+" + packageDetails.tomsisdn.Trim(), "");
            string toNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(ToNumber);

            PhoneNumber FromNumber = phoneNumberUtil.Parse(packageDetails.fromMsisdn.StartsWith("+") ?
                            packageDetails.fromMsisdn.Trim() : "+" + packageDetails.fromMsisdn.Trim(), "");
            string FromNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(FromNumber);

            await _transferRepository.SaveTransaction(new DBTransferTransaction()
            {
                AccountId = accountResponse.AccountID,
                ClientCurrecny = packageDetails.fromCurrency,
                CountryCode = toNumberCountryCode,
                FromMsisdn = packageDetails.fromMsisdn,
                ToMsisdn = packageDetails.tomsisdn,
                ItemPrice = amountToCharge,
                TotalPrice = amountToCharge,
                NowtelRef = packageDetails.GUID,
                OperatorCountryName = packageDetails.operatorCountryName,
                OperatorLogoUrl = packageDetails.operatorLogoUrl,
                OperatorName = packageDetails.operatorName,
                Product = Convert.ToDecimal(packageDetails.product),
                ReceiverCurrecny = packageDetails.toCurrency,
                PaymentTypeId = PaymentType.AccountBalance,

                PaymentRef = paymentResponse != null && !string.IsNullOrEmpty(paymentResponse.audit_id)
                            ? paymentResponse.audit_id : null,

                TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                            ? transferResponse.reference : null,

                StatusId = transferResponse != null && transferResponse.errorCode == "0"
                            ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
            });

            if (transferResponse == null)
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(transferResponse)}, Need to Refund");

                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Something went wrong on server",
                                                        ApiStatusCodes.InternalServerError);
            }

            if (transferResponse.errorCode != "0")
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(model)}, Error:{JsonConvert.SerializeObject(transferResponse)},  Need to Refund");

                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                {
                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Transfer service for this country is not available at the moment.",
                            ApiStatusCodes.DenominationsNotAvailable);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.OperatorBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                    {
                        return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                            "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                    }
                }

                return GenericApiResponse<TransferByAccountBalanceResponseModel>.Failure(null,
                                "Transfer service is not responding at the moment", ApiStatusCodes.DTOneServiceError);
            }

            //Need to send email



            try
            {
                int isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountResponse.AccountID);
                var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);


#pragma warning disable CS4014

                #region AppsFlyer
                if (_appsFlyerService.IsActive)
                {
                    _appsFlyerService.CreateEvent(msisdn, "success_int_topup", model.IpAddress, eventValue: new
                    {
                        amount = amountToCharge,
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "account_balance"
                    });

                    _appsFlyerService.CreateEvent(msisdn, "intopup_any", model.IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "account_balance"
                    });

                    _appsFlyerService.CreateEvent(msisdn, "intopup_" + GetCountryNameByCountryCode(toNumberCountryCode) + "", model.IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "account_balance"
                    });

                    _appsFlyerService.CreateEvent(msisdn, "intopupfrom_" + FromNumberCountryCode.ToLower() + "", model.IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "account_balance"
                    });

                    _appsFlyerService.CreateEvent(msisdn, "last_int_topup", model.IpAddress, eventValue: new
                    {
                        type = "account_balance"
                    });

                    if (isFirstiTopup == 1)
                    {
                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "first_int_topup", model.IpAddress, eventValue: new
                        {
                            type = "account_balance"
                        });
                    }
                }
                #endregion

                #region AirShip
                FireAirShipIntTopupEvents(packageDetails.fromMsisdn, packageDetails.tomsisdn, packageDetails.fromAmount, packageDetails.fromAmount,
                                               packageDetails.fromCurrency, packageDetails.toCurrency, transferResponse.reference, isFirstiTopup == 1,
                                               PaymentType.AccountBalance, FromNumberCountryCode, toNumberCountryCode, customerResponse.Balance);
                #endregion

#pragma warning restore CS4014

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferService, Method: TransferByAccountBalance-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            //Send Response
            return GenericApiResponse<TransferByAccountBalanceResponseModel>.Success(
                new TransferByAccountBalanceResponseModel()
                {
                    RemainingBalance = paymentResponse.new_balance / 100,
                    TransferData = new TransferData()
                    {
                        TransactionId = transferResponse.reference,
                        fromAmount = amountToCharge.ToString(),
                        toAmount = packageDetails.product,
                        fromCurrency = packageDetails.fromCurrency,
                        fromMsisdn = packageDetails.fromMsisdn,
                        toCurrency = packageDetails.toCurrency,
                        toMsisdn = packageDetails.tomsisdn,
                        toCountry = toNumberCountryCode,
                        fromCountry = FromNumberCountryCode
                    }
                }, "Successfull top-up");
        }

        public async Task<GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>> GetSpecialPromotionBalanceToDeduct(
            string msisdn, decimal amount)
        {

            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Failure(null,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }


            //Deduct Balance
            var promoResponse = await _transferRepository.GetSpecialPromotionBalanceToDeduct(
                                            amount, accountResponse.AccountID);

            if (promoResponse == null)
            {
                return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Failure(null,
                                            "Service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            //Send Response
            return GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>.Success(
                new GetSpecialPromotionBalanceToDeductResponseModel()
                {
                    retAmount = promoResponse.retAmount,
                    retcreditReason = promoResponse.retcreditReason
                }, "Successfull");
        }

        public async Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPal(
                        TransferByPayPalRequestModel model, string msisdn, string currency, string account)
        {

            //Get package details
            var packageDetails = await _transferRepository.
                            GetProductByNowtelTransactionReference(model.nowtelRef, model.product.ToString());

            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                            "Invalid product/reference",
                                    ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Validate trasnfer request 
            var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }


            //Get user details
            var userResponse = await _accountRepository.GetUserByPhoneNumber(msisdn);

            if (_payPalConfig.IsPaypalByPay360)
            {

                //Get User Registration Date
                var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(account);

                var request = new PayPalByPay360CSPaymentRequest()
                {
                    Basket = new List<PayPalByPay360Basket>() {
                            new PayPalByPay360Basket()
                            {
                                amount = Convert.ToSingle(amountToCharge),
                                bundleRef = "",
                                productItemCode = ProductItemCode.THADTW.ToString(),
                                productRef = ""
                            }
                        },
                    ipAddress = model.ipAddress,

                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname)
                                                                    ? userResponse.firstname : msisdn : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerEmail = userResponse != null ? !string.IsNullOrEmpty(userResponse.email)
                                                                    ? userResponse.email : string.Empty : string.Empty,
                    transactionCurrency = currency,
                    transactionAmount = Convert.ToSingle(amountToCharge),
                    PaymentMethod = new PayPalByPay360PaymentMethod()
                    {
                        Paypal = new PayPalByPay360Urls()
                        {
                            returnUrl = _payPalConfig.TransferSettings.PayPalByPay360ReturnUrl +
                                        "nowtelRef=" + model.nowtelRef +
                                        "&product=" + model.product + "&operatorId=" + model.operatorId,

                            cancelUrl = _payPalConfig.TransferSettings.CancelUrl
                        }
                    },
                    CustomFields = new PayPalByPay360CustomField()
                    {
                        fieldState = new List<PayPalByPay360FieldState>()
                            {
                                new PayPalByPay360FieldState() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "ProductItemCode", value = ProductItemCode.THADTW.ToString(), transient = false },
                                new PayPalByPay360FieldState() { name = "FirstUseDate",
                                    value = userRegistrationDate.ToString("yyyy-MM-dd"), transient = false },
                                new PayPalByPay360FieldState() { name = "ANumber", value = packageDetails.fromMsisdn, transient = false },
                                new PayPalByPay360FieldState() { name = "BNumber", value = packageDetails.tomsisdn, transient = false }
                            }
                    },
                    CustomerUniqueRef = msisdn,
                    ProductCode = ProductCode.THA.ToString(),
                };

                var paymentResponse = await _payPalService.PayPalByPay360CS(request);

                if (paymentResponse == null)
                {
                    return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                            "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                                paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                return GenericApiResponse<TransferByPayPalResponseModel>.Success(
                    new TransferByPayPalResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.clientRedirectUrl
                    }, "Payment created successfully");

            }
            else
            {
                var baskets = new List<ProductBasket>();
                var basket = new ProductBasket()
                {
                    Amount = Convert.ToSingle(amountToCharge),
                    BundleRef = "",
                    ProductItemCode = ProductItemCode.THADTW.ToString(),
                    ProductRef = ""
                };

                baskets.Add(basket);

                var request = new PayPalCreateSalePaymentRequest
                {
                    CustomerName = userResponse != null ? !string.IsNullOrEmpty(userResponse.firstname)
                                                                                        ? userResponse.firstname : msisdn : msisdn,
                    CustomerMsisdn = msisdn,
                    CustomerUniqueRef = msisdn,
                    CustomerEmail = userResponse != null ? !string.IsNullOrEmpty(userResponse.email)
                                                                                        ? userResponse.email : string.Empty : string.Empty,
                    ProductCode = ProductCode.THA.ToString(),
                    Transaction = new Transactions()
                    {
                        Amount = new Amounts()
                        {
                            Total = Convert.ToSingle(amountToCharge),
                            Currency = currency
                        },
                        Description = "Transfer payment request from THA-Home"
                    },
                    RedirectUrl = new RedirectUrls
                    {
                        ReturnUrl = _payPalConfig.TransferSettings.PayPalReturnUrl +
                                           "nowtelRef=" + model.nowtelRef +
                                           "&product=" + model.product + "&operatorId=" + model.operatorId,

                        CancelUrl = _payPalConfig.TransferSettings.CancelUrl
                    },
                    Basket = baskets
                };

                var paymentResponse = await _payPalService.PayPalCreateSalePayment(request);

                if (paymentResponse == null)
                {
                    return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                  "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

                if (paymentResponse.errorCode > 0)
                {
                    _logger.Error($"Class: TransferService, Method: TransferByPayPal - PaymentResponse - V1, " +
                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                    if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                            "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                    }
                    else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                                paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                    }
                    else
                    {
                        return GenericApiResponse<TransferByPayPalResponseModel>.Failure(null,
                                            "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                    }
                }

                return GenericApiResponse<TransferByPayPalResponseModel>.Success(
                    new TransferByPayPalResponseModel()
                    {
                        clientRedirectUrl = paymentResponse.payload.RedirectUrl
                    }, "Payment created successfully");
            }
        }

        public async Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV1(
            TransferByPayPalCallBackV1RequestModel model, string msisdn, string currency)
        {

            //Complete Payment
            var paymentResponse = await _payPalService.PayPalExecuteSalePayment(new PayPalExecuteSalePaymentRequest()
            {
                CustomerUniqueRef = msisdn,
                PayerId = model.PayerID,
                PaymentId = model.PaymentId,
                ProductCode = ProductCode.THA.ToString()
            });

            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV1 - PaymentResponse, " +
                                             $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                             $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                                    paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }

            //Get package details
            var packageDetails = await _transferRepository.
                            GetProductByNowtelTransactionReference(model.NowtelRef, model.Product.ToString());

            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Get account details
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            return await SendTransferByPayPal(
                paymentResponse.payload.PaypalTransactionId,
                packageDetails,
                model.OperatorId.ToString(),
                model.Product.ToString(),
                accountResponse.AccountID,
                PayPalPaymentType.Direct,
                model.IpAddress,
                amountToCharge);
        }

        public async Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV2(
            TransferByPayPalCallBackV2RequestModel model, string msisdn, string currency)
        {
            //Complete Payment
            var paymentResponse = await _payPalService.PayPalByPay360ES(new PayPalByPay360ESPaymentRequest()
            {
                PaypalCheckoutToken = model.Token
            });

            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByPayPalCallBackV2 - PaymentResponse, " +
                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }

            }

            //Get package details
            var packageDetails = await _transferRepository.
                            GetProductByNowtelTransactionReference(model.NowtelRef, model.Product.ToString());

            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Invalid product/reference",
                            ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Get account details
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + msisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                           "User is not registered",
                           ApiStatusCodes.UserNotRegistered);
            }

            return await SendTransferByPayPal(
                            paymentResponse.payload.transactionId,
                            packageDetails,
                            model.OperatorId.ToString(),
                            model.Product.ToString(),
                            accountResponse.AccountID,
                            PayPalPaymentType.ViaPay360,
                            model.IpAddress,
                            amountToCharge);
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCard(
            TransferByExistingCardRequestModel model, string msisdn, string currency, string account)
        {
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(
                                                                                        model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference",
                                                                                         ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Validate trasnfer request 
            var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                SecurityCode = model.SecurityCode,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.Token,
                CardToken = model.cardToken,
                accountNumber = account,
            }), Pay360PaymentType.Token);


            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Payment service not responding",
                                                                                                ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByExistingCard - PaymentResponse, " +
                                                  $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                  $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                                            model.operatorId.ToString(),
                                            model.product.ToString(),
                                            account, model.ipAddress, amountToCharge);

        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCustomer(
            TransferByNewCustomerRequestModel model, string msisdn, string currency, string account)
        {
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(
                                                                                        model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference",
                                                                                         ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Validate trasnfer request 
            var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.New,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account
            }), Pay360PaymentType.New);


            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByNewCustomer - PaymentResponse , " +
                                                     $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                     $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                            paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                model.operatorId.ToString(),
                model.product.ToString(),
                account, model.ipAddress,
                amountToCharge);
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCard(
            TransferByNewCardRequestModel model, string msisdn, string currency, string account)
        {
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(
                                                                                        model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference",
                                                                                         ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(msisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Validate trasnfer request 
            var validationResponse = await ValidateTransferRequest(
                    account,
                    amountToCharge,
                    packageDetails.fromMsisdn,
                    packageDetails.tomsisdn,
                    currency
                );

            if (validationResponse == TransferValidationResponse.DailyLimitExceeded)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "Your daily limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
            }
            else if (validationResponse == TransferValidationResponse.Unauthorized)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                             "transfer not authorized", ApiStatusCodes.TransferNotAuthorized);
            }

            var paymentResponse = await _pay360Service.Pay360Payment(await CreatePay360PaymentRequest(new Pay360PaymentRequestData()
            {
                CustomerMsisdn = msisdn,
                Amount = Convert.ToSingle(amountToCharge),
                IpAddress = model.ipAddress,
                Currency = currency,
                toMsisdn = packageDetails.tomsisdn,
                Pay360PaymentType = Pay360PaymentType.ExistingNew,
                CustomerAddressData = new AddressData()
                {
                    AddressL1 = model.billingAddressData.AddressL1,
                    AddressL2 = model.billingAddressData.AddressL2,
                    AddressL3 = model.billingAddressData.AddressL3,
                    AddressL4 = model.billingAddressData.AddressL4,
                    PostCode = model.billingAddressData.PostCode,
                    City = model.billingAddressData.City,
                    Region = model.billingAddressData.Region,
                    CountryCode = model.billingAddressData.CountryCode
                },
                CustomerCardData = new CardData()
                {
                    CardNumber = model.cardData.CardNumber,
                    NameOnCard = model.cardData.NameOnCard,
                    SecurityCode = model.cardData.SecurityCode,
                    ExpiryMonth = model.cardData.ExpiryMonth,
                    ExpiryYear = model.cardData.ExpiryYear
                },
                ShouldSaveCard = model.cardData.ShouldSaveCard,
                accountNumber = account
            }), Pay360PaymentType.ExistingNew);


            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {
                _logger.Error($"Class: TransferService, Method: TransferByNewCard - PaymentResponse, " +
                                                           $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                           $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                model.operatorId.ToString(),
                model.product.ToString(),
                account, model.ipAddress, amountToCharge);
        }

        public async Task<GenericApiResponse<TransferByCardResponseModel>> TransferByCard3dSecureCallBack(
            TransferByCardCallBackRequestModel model)
        {
            //Get package details
            var packageDetails = await _transferRepository.GetProductByNowtelTransactionReference(
                                                                                        model.nowtelRef, model.product.ToString());
            if (packageDetails == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Invalid product/reference",
                                                                                         ApiStatusCodes.InvalidNowtelReferenceOrProduct);
            }

            var amountToCharge = Convert.ToDecimal(packageDetails.CustomerChargeValue);
            var promoResponse = await GetSpecialPromotionBalanceToDeduct(packageDetails.fromMsisdn, Convert.ToDecimal(packageDetails.CustomerChargeValue));
            if (promoResponse != null && promoResponse.payload != null)
            {
                amountToCharge = promoResponse.payload.retAmount;
            }

            //Get user account response
            var accountResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);
            if (accountResponse == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "User is not registered",
                                                                                        ApiStatusCodes.UserNotRegistered);
            }

            //payment response 
            var paymentResponse = await _pay360Service.Resume3DTransaction(new Pay360Resume3DRequest()
            {
                pareq = model.PaRes,
                pay360TransactionId = model.MD,
                customerEmail = model.customerEmail
            });


            if (paymentResponse == null)
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Payment service not responding",
                                                                                         ApiStatusCodes.PaymentServiceError);
            }

            if (paymentResponse.errorCode > 0)
            {

                _logger.Error($"Class: TransferService, Method: TransferByCard3dSecureCallBack - PaymentResponse, " +
                                                            $"Request =>  Model : {JsonConvert.SerializeObject(model)}" +
                                                            $"Response => Model : {JsonConvert.SerializeObject(paymentResponse)}");


                if (paymentResponse.errorCode == (int)Pay360StatusCodes.DailyLimitExceed)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "You daily payment limit is exceeded", ApiStatusCodes.DailyLimitExceeded);
                }
                else if (paymentResponse.errorCode == (int)Pay360StatusCodes.TransactionUnSuccessful)
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        paymentResponse.message, ApiStatusCodes.PaymentServiceError);
                }
                else
                {
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                        "Payment service is not responding", ApiStatusCodes.PaymentServiceError);
                }
            }


            return await SendTransferByCard(paymentResponse.payload, packageDetails,
                                                     model.operatorId.ToString(),
                                                     model.product.ToString(),
                                                     accountResponse.AccountID.ToString(), model.IpAddress, amountToCharge);
        }

        private async Task<GenericApiResponse<TransferByCardResponseModel>> SendTransferByCard(
            Pay360PaymentResponse paymentResponse, DBProduct packageDetails, string operatorId, string product, string accountId, string IpAddress, decimal amountToCharge)
        {
            if (paymentResponse.outcome.reasonCode == "U100") //3d Secure Scenario
            {
                var userResponse = await _accountRepository.GetUserByPhoneNumber(packageDetails.fromMsisdn);

                string customerEmail = userResponse != null && !string.IsNullOrEmpty(userResponse.email) ? userResponse.email : "";

                //Send Response
                return GenericApiResponse<TransferByCardResponseModel>.Failure(
                                                new TransferByCardResponseModel()
                                                {
                                                    threeDSecureData = new ThreeDSecureData()
                                                    {
                                                        pareq = paymentResponse.clientRedirect.pareq,
                                                        redirectUrl = paymentResponse.clientRedirect.url,
                                                        transactionId = paymentResponse.transactionId,
                                                        returnUrl = _pay360Config.TransferSettings.ReturnUrl +
                                                                        "nowtelRef=" + packageDetails.GUID +
                                                                        "&product=" + packageDetails.product +
                                                                        "&operatorId=" + operatorId +
                                                                        "&customerEmail=" + customerEmail
                                                    }

                                                }, "Pending 3d secure", ApiStatusCodes.Pending3dSecure);

            }
            else if (paymentResponse.outcome.reasonCode == "S100")
            {
                //Send Credit
                var transferResponse = await _aTTService.Execute(new ExecuteDataRequest()
                {
                    fromMSISDN = packageDetails.fromMsisdn,
                    messageToRecipient = string.Empty,
                    nowtelTransactionReference = packageDetails.GUID,
                    operatorid = operatorId,
                    product = product
                });

                //Save transaction
                var phoneNumberUtil = PhoneNumberUtil.GetInstance();
                PhoneNumber ToNumber = phoneNumberUtil.Parse(packageDetails.tomsisdn.StartsWith("+") ?
                                            packageDetails.tomsisdn.Trim() : "+" + packageDetails.tomsisdn.Trim(), "");
                string toNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(ToNumber);

                PhoneNumber FromNumber = phoneNumberUtil.Parse(packageDetails.fromMsisdn.StartsWith("+") ?
                                        packageDetails.fromMsisdn.Trim() : "+" + packageDetails.fromMsisdn.Trim(), "");
                string FromNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(FromNumber);

                await _transferRepository.SaveTransaction(new DBTransferTransaction()
                {
                    AccountId = accountId,
                    ClientCurrecny = packageDetails.fromCurrency,
                    CountryCode = toNumberCountryCode,
                    FromMsisdn = packageDetails.fromMsisdn,
                    ToMsisdn = packageDetails.tomsisdn,
                    ItemPrice = amountToCharge,
                    TotalPrice = amountToCharge,
                    NowtelRef = packageDetails.GUID,
                    OperatorCountryName = packageDetails.operatorCountryName,
                    OperatorLogoUrl = packageDetails.operatorLogoUrl,
                    OperatorName = packageDetails.operatorName,
                    Product = Convert.ToDecimal(packageDetails.product),
                    ReceiverCurrecny = packageDetails.toCurrency,
                    PaymentTypeId = PaymentType.Card,

                    PaymentRef = paymentResponse.transactionId,

                    TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                                            ? transferResponse.reference : null,

                    StatusId = transferResponse != null && transferResponse.errorCode == "0"
                                            ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
                });

                if (transferResponse == null)
                {
                    _logger.Error($"Class: TransferService, Method: SendTransferByCard, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                $"Error:{JsonConvert.SerializeObject(transferResponse)}, Response: NULL, Need to Refund");

                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                                "Something went wrong on server", ApiStatusCodes.InternalServerError);
                }

                if (transferResponse.errorCode != "0")
                {
                    _logger.Error($"Class: TransferService, Method: SendTransferByCard, Parameters=> Model :" +
                                                                    $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                                                    $"Error:{JsonConvert.SerializeObject(transferResponse)}");

                    await CardPaymentRefund(paymentResponse.transactionId);

                    if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                    {
                        int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                        if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Transfer service for this country is not available at the moment.",
                                ApiStatusCodes.DenominationsNotAvailable);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Transfer service for this number is not available at the moment.",
                                ApiStatusCodes.DenominationBlocked);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Transfer service for this number is not available at the moment.",
                                ApiStatusCodes.OperatorBlocked);
                        }
                        else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                        {
                            return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                        }
                    }
                    return GenericApiResponse<TransferByCardResponseModel>.Failure(null,
                                                                "", ApiStatusCodes.DTOneServiceError);
                }


                if (transferResponse.errorCode == "0")
                {
                    //CapturePayment
                    if (TransferIsAuthorization == true)
                    {
                        try
                        {
                            CaptureTransactionRequestModel capturetransmodel = new CaptureTransactionRequestModel();
                            capturetransmodel.transactionId = paymentResponse.transactionId.ToString();
                            var CapturePaymentResponse = _pay360Service.CaptureTransaction(capturetransmodel);


                            if (CapturePaymentResponse == null || CapturePaymentResponse.Result.errorCode > 0)
                            {
                                string messageBody = " Payment Captured Fail! , Transfered Sucessfully! Transaction id : " + paymentResponse.transactionId.ToString();
                                await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Balance Transfer");
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Class: TransferService, Method: transferpayment-capturepayment, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");

                            string messageBody = " Payment Captured Failed! , Transfered Sucessfully! Transaction id : " + paymentResponse.transactionId.ToString();
                            await _emailService.SendEmail("usama.kiyani@now.net.pk", messageBody, false, "Balance Transfer");
                        }

                    }
                }

                //Events
                await _transferRepository.InsertSpecialPromotionLogs(-Decimal.Parse(packageDetails.CustomerChargeValue), accountId, "", "Balance Transfer Card");


                try
                {
                    int isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountId);
                    var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

#pragma warning disable CS4014

                    #region AppsFlyer
                    if (_appsFlyerService.IsActive)
                    {
                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "success_int_topup", IpAddress, packageDetails.fromCurrency, amountToCharge, new
                        {
                            amount = amountToCharge,
                            origination = FromNumberCountryCode.ToLower(),
                            destination = toNumberCountryCode.ToLower(),
                            type = "card"
                        });

                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopup_any", IpAddress, eventValue: new
                        {
                            origination = FromNumberCountryCode.ToLower(),
                            destination = toNumberCountryCode.ToLower(),
                            type = "card"
                        });

                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopup_" + GetCountryNameByCountryCode(toNumberCountryCode) + "", IpAddress, eventValue: new
                        {
                            origination = FromNumberCountryCode.ToLower(),
                            destination = toNumberCountryCode.ToLower(),
                            type = "card"
                        });

                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopupfrom_" + FromNumberCountryCode.ToLower() + "", IpAddress, eventValue: new
                        {
                            origination = FromNumberCountryCode.ToLower(),
                            destination = toNumberCountryCode.ToLower(),
                            type = "card"
                        });

                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "last_int_topup", IpAddress, eventValue: new
                        {
                            type = "card"
                        });

                        if (isFirstiTopup == 1)
                        {
                            _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "first_int_topup", IpAddress, eventValue: new
                            {
                                type = "card"
                            });
                        }
                    }
                    #endregion

                    #region AirShip
                    FireAirShipIntTopupEvents(packageDetails.fromMsisdn, packageDetails.tomsisdn, packageDetails.fromAmount, packageDetails.fromAmount,
                                                   packageDetails.fromCurrency, packageDetails.toCurrency, transferResponse.reference, isFirstiTopup == 1,
                                                   PaymentType.Card, FromNumberCountryCode, toNumberCountryCode, customerResponse.Balance);
                    #endregion

#pragma warning restore CS4014

                }
                catch (Exception ex)
                {
                    _logger.Error($"Class: TransferService, Method: SendTransferByCard-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
                }

                //Send Response
                return GenericApiResponse<TransferByCardResponseModel>.Success(
                                                new TransferByCardResponseModel()
                                                {
                                                    transferData = new TransferData()
                                                    {
                                                        TransactionId = transferResponse.reference,
                                                        fromAmount = amountToCharge.ToString(),
                                                        toAmount = packageDetails.product,
                                                        fromCurrency = packageDetails.fromCurrency,
                                                        toCurrency = packageDetails.toCurrency,
                                                        fromMsisdn = packageDetails.fromMsisdn,
                                                        toMsisdn = packageDetails.tomsisdn,
                                                        fromCountry = FromNumberCountryCode,
                                                        toCountry = toNumberCountryCode
                                                    }
                                                }, "Successfull top-up");
            }
            else
            {
                return GenericApiResponse<TransferByCardResponseModel>.Failure(null, "Payment service not responding", ApiStatusCodes.PaymentServiceError);
            }
        }

        private async Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> SendTransferByPayPal(
              string PaymentTransactionId, DBProduct packageDetails, string operatorId, string product, string accountId, PayPalPaymentType type, string IpAddress, decimal amountToCharge)
        {
            //Send Credit
            var transferResponse = await _aTTService.Execute(new ExecuteDataRequest()
            {
                fromMSISDN = packageDetails.fromMsisdn,
                messageToRecipient = string.Empty,
                nowtelTransactionReference = packageDetails.GUID,
                operatorid = operatorId,
                product = product
            });

            //Save transaction
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();
            PhoneNumber ToNumber = phoneNumberUtil.Parse(packageDetails.tomsisdn.StartsWith("+") ?
                                        packageDetails.tomsisdn.Trim() : "+" + packageDetails.tomsisdn.Trim(), "");
            string toNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(ToNumber);


            PhoneNumber FromNumber = phoneNumberUtil.Parse(packageDetails.fromMsisdn.StartsWith("+") ?
                packageDetails.fromMsisdn.Trim() : "+" + packageDetails.fromMsisdn.Trim(), "");
            string FromNumberCountryCode = phoneNumberUtil.GetRegionCodeForNumber(FromNumber);

            await _transferRepository.SaveTransaction(new DBTransferTransaction()
            {
                AccountId = accountId,
                ClientCurrecny = packageDetails.fromCurrency,
                CountryCode = toNumberCountryCode,
                FromMsisdn = packageDetails.fromMsisdn,
                ToMsisdn = packageDetails.tomsisdn,
                ItemPrice = amountToCharge,
                TotalPrice = amountToCharge,
                NowtelRef = packageDetails.GUID,
                OperatorCountryName = packageDetails.operatorCountryName,
                OperatorLogoUrl = packageDetails.operatorLogoUrl,
                OperatorName = packageDetails.operatorName,
                Product = Convert.ToDecimal(packageDetails.product),
                ReceiverCurrecny = packageDetails.toCurrency,
                PaymentTypeId = PaymentType.Paypal,

                PaymentRef = PaymentTransactionId,

                TransferRef = transferResponse != null && transferResponse.errorCode == "0"
                                        ? transferResponse.reference : null,

                StatusId = transferResponse != null && transferResponse.errorCode == "0"
                                        ? TransferTransactionStatus.Success : TransferTransactionStatus.Failure
            });

            if (transferResponse == null)
            {
                _logger.Error($"Class: TransferService, Method: SendTransferByPayPal, Parameters=> Model :" +
                            $" {JsonConvert.SerializeObject(packageDetails)}, " +
                            $"Error:{JsonConvert.SerializeObject(transferResponse)}, Response: NULL,  Need to Refund");

                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                    "Something went wrong on server", ApiStatusCodes.InternalServerError);
            }

            if (transferResponse.errorCode != "0")
            {
                _logger.Error($"Class: TransferService, Method: SendTransferByPayPal, Parameters=> Model :" +
                                $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                $"Error:{JsonConvert.SerializeObject(transferResponse)}");


                //Refund call
                if (type == PayPalPaymentType.ViaPay360)
                    await PaypalViaPay360Refund(PaymentTransactionId);
                else
                {
                    _logger.Error($"Class: TransferService, Method: SendTransferByPayPal, Parameters=> Model :" +
                                                        $" {JsonConvert.SerializeObject(packageDetails)}, " +
                                                        $"Error:{JsonConvert.SerializeObject(transferResponse)}, Need to refund");
                }


                if (!string.IsNullOrEmpty(transferResponse.errorCodeDtOne))
                {
                    int AttErrorCode = Convert.ToInt32(transferResponse.errorCodeDtOne);

                    if (AttErrorCode == (int)ATTStatusCodes.TopupNumberLimitExceed)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Recipient reached maximum topup number.", ApiStatusCodes.TopupNumberLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.TopupAmountLimitExceed)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Recipient reached maximum topup amount.", ApiStatusCodes.TopupAmountLimitExceed);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationsNotAvailable)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Transfer service for this country is not available at the moment.",
                            ApiStatusCodes.DenominationsNotAvailable);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DenominationBlocked)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.DenominationBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.OperatorBlocked)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Transfer service for this number is not available at the moment.",
                            ApiStatusCodes.OperatorBlocked);
                    }
                    else if (AttErrorCode == (int)ATTStatusCodes.DestinationMsisdnOutOfRange)
                    {
                        return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                            "Destination number is invalid.", ApiStatusCodes.DestinationMsisdnOutOfRange);
                    }
                }

                return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Failure(null,
                                "", ApiStatusCodes.DTOneServiceError);
            }


            //Promotion
            await _transferRepository.InsertSpecialPromotionLogs(
                                       -Decimal.Parse(packageDetails.CustomerChargeValue), accountId, "", "Balance Transfer Paypal");


            //Events
            try
            {
                var isFirstiTopup = await _transferRepository.IsFirstInternationTopup(accountId);
                var customerResponse = await _accountRepository.GetAccountDetailsBySipUsername("THA" + packageDetails.fromMsisdn);

#pragma warning disable CS4014
                #region AppsFlyer
                if (_appsFlyerService.IsActive)
                {
                    _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "success_int_topup", IpAddress, packageDetails.fromCurrency, amountToCharge, new
                    {
                        amount = amountToCharge,
                        origination = FromNumberCountryCode,
                        destination = toNumberCountryCode,
                        type = "paypal"
                    });

                    _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopup_any", IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "paypal"
                    });

                    _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopup_" + GetCountryNameByCountryCode(toNumberCountryCode) + "", IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "paypal"
                    });

                    _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "intopupfrom_" + FromNumberCountryCode.ToLower() + "", IpAddress, eventValue: new
                    {
                        origination = FromNumberCountryCode.ToLower(),
                        destination = toNumberCountryCode.ToLower(),
                        type = "paypal"
                    });

                    _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "last_int_topup", IpAddress, eventValue: new
                    {
                        type = "paypal"
                    });

                    if (isFirstiTopup == 1)
                    {
                        _appsFlyerService.CreateEvent(packageDetails.fromMsisdn, "first_int_topup", IpAddress, eventValue: new
                        {
                            type = "paypal"
                        });
                    }
                }
                #endregion

                #region AirShip
                FireAirShipIntTopupEvents(packageDetails.fromMsisdn, packageDetails.tomsisdn, packageDetails.fromAmount, packageDetails.fromAmount,
                                                   packageDetails.fromCurrency, packageDetails.toCurrency, transferResponse.reference, isFirstiTopup == 1,
                                                   PaymentType.Paypal, FromNumberCountryCode, toNumberCountryCode, customerResponse.Balance);
                #endregion

#pragma warning restore CS4014

            }
            catch (Exception ex)
            {
                _logger.Error($"Class: TransferService, Method: SendTransferByPayPal-Event, ErrorMessage: {ex.Message}, StackTrace: {ex.StackTrace}");
            }

            //Send Response
            return GenericApiResponse<TransferByPayPalCallBackResponseModel>.Success(
                new TransferByPayPalCallBackResponseModel()
                {
                    TransferData = new TransferData()
                    {
                        TransactionId = transferResponse.reference,
                        fromAmount = amountToCharge.ToString(),
                        toAmount = packageDetails.product,
                        fromCurrency = packageDetails.fromCurrency,
                        toCurrency = packageDetails.toCurrency,
                        fromMsisdn = packageDetails.fromMsisdn,
                        toMsisdn = packageDetails.tomsisdn,
                        fromCountry = FromNumberCountryCode,
                        toCountry = toNumberCountryCode
                    }
                }, "Successfull top-up");

        }

        private async Task<Pay360PaymentRequest> CreatePay360PaymentRequest(Pay360PaymentRequestData model)
        {

            //Get User-Info 
            var userResponse = await _accountRepository.GetUserByPhoneNumber(model.CustomerMsisdn);
            model.CustomerEmail = userResponse == null ? string.Empty : !string.IsNullOrEmpty(userResponse.email)
                                                                                                        ? userResponse.email : string.Empty;

            //Get User Registration Date
            var userRegistrationDate = await _accountRepository.GetUserRegistrationDate(model.accountNumber);

            List<fieldstate> _fieldState = new List<fieldstate>()
                {
                    new fieldstate() { name = "ProductCode", value = ProductCode.THA.ToString(), transient = false },
                    new fieldstate() { name = "ProductItemCode", value = ProductItemCode.THADTW.ToString(), transient = false },
                };

            _fieldState.Add(new fieldstate()
            {
                name = "FirstUseDate",
                value = userRegistrationDate.ToString("yyyy-MM-dd"),
                transient = false
            });
            _fieldState.Add(new fieldstate() { name = "ANumber", value = model.CustomerMsisdn, transient = false });
            _fieldState.Add(new fieldstate() { name = "BNumber", value = model.toMsisdn, transient = false });

            List<basket> baskets = new List<basket>();

            basket basket = new basket()
            {
                amount = model.Amount,
                bundleRef = "",
                productItemCode = ProductItemCode.THADTW.ToString(),
                productRef = model.CustomerMsisdn
            };

            baskets.Add(basket);

            Pay360PaymentRequest request = new Pay360PaymentRequest();
            switch (model.Pay360PaymentType)
            {
                case Pay360PaymentType.New:
                    request.Pay360PaymentRequestNew = new Pay360PaymentRequestNew();
                    request.Pay360PaymentRequestNew.basket = baskets;
                    request.Pay360PaymentRequestNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestNew.isDirectFullfilment = false;
                    request.Pay360PaymentRequestNew.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestNew.isDefaultCard = true;
                    request.Pay360PaymentRequestNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    if (_pay360Config.IsBillingAndCustomerAddressSame == true)
                        request.Pay360PaymentRequestNew.customerBillingAddress = request.Pay360PaymentRequestNew.billingAddress;
                    break;
                case Pay360PaymentType.Token:
                    request.Pay360PaymentRequestToken = new Pay360PaymentRequestToken();
                    request.Pay360PaymentRequestToken.basket = baskets;
                    request.Pay360PaymentRequestToken.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestToken.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestToken.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestToken.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestToken.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestToken.cardCv2 = model.SecurityCode;
                    request.Pay360PaymentRequestToken.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestToken.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestToken.isDirectFullfilment = false;
                    request.Pay360PaymentRequestToken.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestToken.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestToken.cardToken = model.CardToken;
                    break;
                case Pay360PaymentType.ExistingNew:
                    request.Pay360PaymentRequestExistingNew = new Pay360PaymentRequestExistingNew();
                    request.Pay360PaymentRequestExistingNew.basket = baskets;
                    request.Pay360PaymentRequestExistingNew.customerName = model.CustomerCardData.NameOnCard;
                    request.Pay360PaymentRequestExistingNew.customerMsisdn = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerUniqueRef = model.CustomerMsisdn;
                    request.Pay360PaymentRequestExistingNew.customerEmail = model.CustomerEmail;
                    request.Pay360PaymentRequestExistingNew.transactionCurrency = model.Currency;
                    request.Pay360PaymentRequestExistingNew.ipAddress = model.IpAddress;
                    request.Pay360PaymentRequestExistingNew.productCode = ProductCode.THA.ToString();
                    request.Pay360PaymentRequestExistingNew.cardCv2 = model.CustomerCardData.SecurityCode;
                    request.Pay360PaymentRequestExistingNew.transactionAmount = model.Amount;
                    request.Pay360PaymentRequestExistingNew.customFields = new customField() { fieldState = _fieldState };
                    request.Pay360PaymentRequestExistingNew.cardExpiryDate = model.CustomerCardData.ExpiryMonth + model.CustomerCardData.ExpiryYear;
                    request.Pay360PaymentRequestExistingNew.cardPan = model.CustomerCardData.CardNumber;
                    request.Pay360PaymentRequestExistingNew.isDirectFullfilment = false;
                    request.Pay360PaymentRequestExistingNew.isAuthorizationOnly = TransferIsAuthorization;
                    request.Pay360PaymentRequestExistingNew.isDefaultCard = true;
                    request.Pay360PaymentRequestExistingNew.do3DSecure = _pay360Config.Do3DSecure;
                    request.Pay360PaymentRequestExistingNew.saveCard = model.ShouldSaveCard;
                    request.Pay360PaymentRequestExistingNew.billingAddress = new billingAddress()
                    {
                        line1 = model.CustomerAddressData.AddressL1,
                        line2 = model.CustomerAddressData.AddressL2,
                        line3 = model.CustomerAddressData.AddressL3,
                        line4 = model.CustomerAddressData.AddressL4,
                        region = model.CustomerAddressData.Region,
                        city = model.CustomerAddressData.City,
                        postcode = model.CustomerAddressData.PostCode,
                        countryCode = model.CustomerAddressData.CountryCode
                    };
                    break;
            }

            return request;
        }

        private async Task<TransferValidationResponse> ValidateTransferRequest(string accountId, decimal Amount, string fromMsisdn, string toMsisdn, string currency)
        {
            var phoneNumberUtil = PhoneNumberUtil.GetInstance();

            PhoneNumber FromNumber = phoneNumberUtil.Parse(fromMsisdn.StartsWith("+") ? fromMsisdn : "+" + fromMsisdn, "");
            string fromMsisdnCountryCode = phoneNumberUtil.GetRegionCodeForNumber(FromNumber);

            PhoneNumber ToNumber = phoneNumberUtil.Parse(toMsisdn.StartsWith("+") ? toMsisdn : "+" + toMsisdn, "");
            string toMsisdnCountryCode = phoneNumberUtil.GetRegionCodeForNumber(ToNumber);

            return await _transferRepository.ValidateTransferRequest(new DBValidateTransferRequest()
            {
                AccountId = accountId,
                TotalAmount = Amount,
                FromCountryCode = fromMsisdnCountryCode,
                ToCountryCode = toMsisdnCountryCode,
                FromMsisdn = fromMsisdn,
                UserCurrency = currency
            });
        }

        private async Task PaypalViaPay360Refund(string transactionId)
        {
            try
            {
                //refund start
                var refundResponse = await _payPalService.PaypalRefund(new RefundFullPaymentRequestModel { transactionId = transactionId });
                if (refundResponse == null)
                {
                    _logger.Error($"Class: TransferService, Method: PaypalViaPay360Refund, " +
                        $"TransactionId => Model {transactionId}" +
                        $"refundResponse: null response");
                }

                else if (refundResponse.errorCode > 0)
                {
                    _logger.Error($"Class: TransferService, Method: PaypalViaPay360Refund, " +
                        $"TransactionId => Model {transactionId}" +
                        $"refundResponse: { JsonConvert.SerializeObject(refundResponse)}");
                }

                else
                {
                    //refund end
                    _logger.Error($"Class: TransferService, Method: PaypalViaPay360Refund " +
                                            $"Request =>  Model : {transactionId}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(refundResponse)}");
                }
            }
            catch (Exception ex)
            {
                //refund end
                _logger.Error($"Class: TransferService, Method: PaypalViaPay360Refund " +
                                        $"Request =>  Model : {transactionId}" +
                                        $"Exception => :{ex.Message}" +
                                        $"StackTrace: {ex.StackTrace}");
            }
        }

        private async Task CardPaymentRefund(string transactionId)
        {

            try
            {
                //refund start
                var refundResponse = await _pay360Service.RefundFullPayment(new RefundFullPaymentRequestModel { transactionId = transactionId });
                if (refundResponse == null)
                {
                    _logger.Error($"Class: TransferService, Method: CardPaymentRefund, " +
                        $"TransactionId => Model {transactionId}" +
                        $"refundResponse: null response");
                }

                else if (refundResponse.errorCode > 0)
                {
                    _logger.Error($"Class: TransferService, Method: CardPaymentRefund, " +
                        $"TransactionId => Model {transactionId}" +
                        $"refundResponse: { JsonConvert.SerializeObject(refundResponse)}");
                }

                else
                {
                    //refund end
                    _logger.Error($"Class: TransferService, Method: CardPaymentRefund " +
                                            $"Request =>  Model : {transactionId}" +
                                            $"Response => Model : {JsonConvert.SerializeObject(refundResponse)}");
                }
            }
            catch (Exception ex)
            {
                //refund end
                _logger.Error($"Class: TransferService, Method: CardPaymentRefund " +
                                        $"Request =>  Model : {transactionId}" +
                                        $"Exception => :{ex.Message}" +
                                        $"StackTrace: {ex.StackTrace}");
            }
        }

        private string GetCountryNameByCountryCode(string code)
        {
            //Get Countries List

            var completePath = Path.GetFullPath(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/CountriesName.json"));

            var json = System.IO.File.ReadAllText(completePath);

            var _countries = JsonConvert.DeserializeObject<CountriesData>(json);

            return _countries.countries.Where(x => x.IsoTwoCharacterCode.ToLower().Equals(code.ToLower())).First().Name.ToLower().Replace(" ", "").Trim();
        }

        private async Task FireAirShipIntTopupEvents(string fromMsisdn, string toMsisdn, string fromAmount, string toAmount, string fromCurrency, string toCurrency, string transactionId, bool isFirstIntTopup, PaymentType paymentType, string origination, string destination, decimal balance)
        {
            try
            {
#pragma warning disable CS4014
                if (_airShipService.IsActive)
                {
                    List<string> tags = new List<string>();

                    var customEventRequest = new CustomEventsRequest()
                    {
                        ProductCode = "THA",
                        ChannelIdentifier = CEventChannelIdentifier.named_user_id,
                        ChannelIdentifierValue = fromMsisdn,
                        InteractionType = "url",
                        InteractionId = paymentType == PaymentType.Card ? "InternationalTopup/Card" : paymentType == PaymentType.Paypal ? "InternationalTopup/Paypal" : "InternationalTopup/AccountBalance"
                    };

                    customEventRequest.Properties = new Dictionary<string, string>
                        {
                            { "FromAmount", fromAmount },
                            { "ToAmount", toAmount },
                            { "FromCurrency", fromCurrency },
                            { "FromCurrencySymbol", CommonExtentionMethods.GetCurrencySymbol(fromCurrency) },
                            { "ToCurrency", toCurrency },
                            { "ToCurrencySymbol", CommonExtentionMethods.GetCurrencySymbol(toCurrency) },
                            { "FromMsisdn", fromMsisdn },
                            { "ToMsisdn", toMsisdn },
                            { "TransactionId", transactionId },
                            { "OriginationCode", origination },
                            { "DestinationCode", destination },
                            { "OriginationName", GetCountryNameByCountryCode(origination) },
                            { "DestinationName", GetCountryNameByCountryCode(destination) }
                        };

                    if (paymentType == PaymentType.AccountBalance)
                    {
                        customEventRequest.Properties.Add("NewBalance", balance.ToString("0.00"));
                    }

                    //events    
                    if (isFirstIntTopup)
                    {
                        tags.Add("first_int_topup");
                        customEventRequest.CustomEventName = "first_int_topup";
                        _airShipService.AddCustomEvent(customEventRequest);
                    }

                    tags.Add("success_int_topup");
                    customEventRequest.CustomEventName = "success_int_topup";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("last_int_topup");
                    customEventRequest.CustomEventName = "last_int_topup";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add("intopup_any");
                    customEventRequest.CustomEventName = "intopup_any";
                    _airShipService.AddCustomEvent(customEventRequest);

                    tags.Add(paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "ab_buy");
                    customEventRequest.CustomEventName = paymentType == PaymentType.Card ? "cc_buy" : paymentType == PaymentType.Paypal ? "pp_buy" : "ab_buy";
                    _airShipService.AddCustomEvent(customEventRequest);


                    string destinationEventName = "intopup_" + GetCountryNameByCountryCode(destination);
                    tags.Add(destinationEventName);
                    customEventRequest.CustomEventName = destinationEventName;
                    _airShipService.AddCustomEvent(customEventRequest);


                    string originationEventName = "intopupfrom_" + origination.ToLower();
                    tags.Add(originationEventName);
                    customEventRequest.CustomEventName = originationEventName;
                    _airShipService.AddCustomEvent(customEventRequest);

                    //tags
                    if (tags.Count > 0)
                    {
                        _airShipService.AddNamedUserTags(new NamedUserTagsRequest()
                        {
                            NamedUser = fromMsisdn,
                            ProductCode = "THA",
                            TagGroup = _airShipService.PaymentTagGroupName,
                            Tags = tags
                        });
                    }
                }
#pragma warning restore CS4014
            }
            catch
            {
                throw;
            }
        }
    }
}