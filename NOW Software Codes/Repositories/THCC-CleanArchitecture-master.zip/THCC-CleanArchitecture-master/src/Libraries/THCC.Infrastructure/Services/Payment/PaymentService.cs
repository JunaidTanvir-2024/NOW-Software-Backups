﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Serilog;

using THCC.Application.Features.Payment.PayPal.Models;
using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Domain.Aggregates;
using THCC.Domain.Entities;

using static THCC.Domain.Constants.ThccConstants;
using static THCC.Domain.Constants.ThccEnums;

namespace THCC.Infrastructure.Services.Payment;

public class PaymentService : IPaymentService
{
    #region Fields

    private readonly IPaymentFulfillmentRepository _fulfillmentRepo;
    private readonly IPointsRepository _pointsRepository;
    private readonly ICommonService _commonService;
    private readonly IUserRepository _userRepo;
    private readonly ICardService _cardService;
    private readonly IPayPalService _payPalService;
    private readonly IPaymentRepository _paymentRepo;
    private readonly ITopupRepository _topupRepository;
    private readonly ILogger _logger;
    private readonly IDiscountService _discountService;
    private readonly ICurrentUser _currentUser;
    private readonly ICallingCardRepository _callingCardRepository;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IMailService _mailService;
    private readonly ILocationService _locationService;
    private readonly IWebHostEnvironment _webHostEnvironment;
    private readonly TopupSettings _topupSettings;

    #endregion

    #region Ctor

    public PaymentService(
        IOptions<TopupSettings> topupSettings,
        IPaymentFulfillmentRepository fulfillmentRepo,
        IPointsRepository pointsRepository,
        ICommonService commonService,
        IUserRepository userRepository,
        ICardService cardService,
        IPayPalService payPalService,
        IPaymentRepository paymentRepository,
        ITopupRepository topupRepository,
        ILogger logger,
        IDiscountService discountService,
        ICurrentUser currentUser,
        ICallingCardRepository callingCardRepository,
        IHttpClientFactory httpClientFactory,
        IMailService mailService,
        ILocationService locationService,
        IWebHostEnvironment webHostEnvironment)
    {
        _fulfillmentRepo = fulfillmentRepo;
        _pointsRepository = pointsRepository;
        _commonService = commonService;
        _userRepo = userRepository;
        _cardService = cardService;
        _payPalService = payPalService;
        _paymentRepo = paymentRepository;
        _topupRepository = topupRepository;
        _logger = logger;
        _discountService = discountService;
        _currentUser = currentUser;
        _callingCardRepository = callingCardRepository;
        _httpClientFactory = httpClientFactory;
        _mailService = mailService;
        _locationService = locationService;
        _webHostEnvironment = webHostEnvironment;
        _topupSettings = topupSettings.Value;
    }

    #endregion

    #region Methods

    #region Public

    #region Card

    public async Task<object> HandleCardPaymentRequest(
        PaymentNewCardDto paymentNewCardInfo,
        PaymentAddressDto paymentAddressInfo,
        PaymentExistingCardDto paymentExistingCardInfo,
        AutoTopupDto autoTopupInfo,
        UserDto userInfo,
        ProductType transactionType,
        decimal amount,
        string cardNumber)
    {
        #region Card Number Validation

        var pinInfo = new PinDetail();
        if (transactionType == ProductType.FastTopup
            || transactionType == ProductType.Topup
            || transactionType == ProductType.AutoTopupEnable)
        {
            pinInfo = await _callingCardRepository.GetCardInfo(cardNumber);
            if (pinInfo == null)
            {
                _logger.Error($"HandleCardPaymentRequest: Invalid card number:  {cardNumber} {JsonConvert.SerializeObject(userInfo)}");
                return ErrorResult.Failure(CustomStatusKey.InvalidCardNumnber!, CustomStatusCode.BadRequest);
            }
        }

        #endregion

        #region Calculate Discount

        var discount = transactionType == ProductType.RechargeableCallingCard
                                                    ? _discountService.GetDiscount(amount) : 0;
        #endregion

        #region Order History Record

        string paymentCardMaskedPan, paymentCardScheme, cardExpiry;

        if (paymentExistingCardInfo != null)
        {
            //Check if card is user own card
            var cards = await _cardService.GetCustomerCards(_currentUser.GetUserEmail()!);
            if (cards?.Any(x => x.CardToken.Equals(
                    paymentExistingCardInfo.CardToken,
                    StringComparison.InvariantCultureIgnoreCase)) != true)
            {
                //Add debug log here
                _logger.Error($"HandleCardPaymentRequest: Customer {_currentUser.GetUserEmail()} " +
                    "use different card" + paymentExistingCardInfo.CardToken);

                return ErrorResult.Failure(CustomStatusKey.BadRequest, CustomStatusCode.BadRequest);
            }

            var currentPayemntCard = cards!.First(x => x.CardToken.Equals(
                paymentExistingCardInfo.CardToken,
                StringComparison.InvariantCultureIgnoreCase));

            paymentCardMaskedPan = currentPayemntCard.MaskedPan;
            paymentCardScheme = currentPayemntCard.CardScheme;
            cardExpiry = currentPayemntCard.ExpiryDate;
        }
        else
        {
            if (transactionType == ProductType.AutoTopupEnable)
            {
                paymentNewCardInfo.SaveCard = true;
                paymentNewCardInfo.MakeDefault = true;
            }

            if ((transactionType == ProductType.Topup
                || transactionType == ProductType.RechargeableCallingCard
                || transactionType == ProductType.CallingCard)
                     && autoTopupInfo?.Status == true)
            {
                paymentNewCardInfo.SaveCard = true;
                paymentNewCardInfo.MakeDefault = true;
            }

            paymentCardMaskedPan = _commonService.GetCardMaskedPan(paymentNewCardInfo.CardNumber!);
            paymentCardScheme = _commonService.GetCardScheme(paymentNewCardInfo.CardNumber!);
            cardExpiry = $"{paymentNewCardInfo.ExpiryMonth}{paymentNewCardInfo.ExpiryYear}";
        }

        var location = await _locationService.GetLocationInfo();
        var order = new Order
        {
            UserId = userInfo.Id,
            Discount = discount,
            TotalAmount = amount - discount,
            Amount = amount,
            Description = null,
            IpAddress = location.IpAddress,
            OrderStatus = OrderStatus.Created,
            Device = location?.Device,
            DeviceLocation = location?.CountryName == null ? null : $"{location.CityName},{location.CountryName}",
        };
        var orderItem = new OrderItem
        {
            Discount = discount,
            TotalAmount = amount - discount,
            Amount = amount,
            CardNumber = (transactionType == ProductType.FastTopup
                            || transactionType == ProductType.Topup
                            || transactionType == ProductType.AutoTopupEnable) ? cardNumber : null,
            ProductType = transactionType
        };
        var orderPayment = new OrderPayment()
        {
            PaymentMethodId = PaymentMethod.Card,
            Stauts = PaymentStatus.Pending,
            PaymentUserId = transactionType == ProductType.FastTopup && _currentUser.IsAuthenticated()
                                                                    ? _currentUser.GetUserId() : userInfo.Id
        };
        var orderCardPayment = new OrderCardPayment()
        {
            CardNumber = paymentCardMaskedPan,
            CardExpiry = cardExpiry,
            CardType = paymentCardScheme,
            SaveCard = paymentNewCardInfo?.SaveCard == true,
            MakeDefault = paymentNewCardInfo?.MakeDefault == true,
            IsAutoPayment = autoTopupInfo?.Status == true,
            AutoPaymentAmount = autoTopupInfo == null ? 0 : autoTopupInfo.Amount,
            AutoPaymentThreshold = autoTopupInfo == null ? 0 : _topupSettings.AutoTopupSettings.ThresholdAmount
        };
        var orderPoint = new OrderPoint();
        if (orderItem.ProductType == ProductType.CallingCard)
        {
            orderPoint.OpeningBalance = order.Amount;
        }
        else if (orderItem.ProductType == ProductType.RechargeableCallingCard)
        {
            orderPoint.OpeningBalance = order.Amount;
            orderPoint.OpeningPoints = _topupSettings.Amounts!.Find(x => x.Amount == order.Amount)!.Points + _topupSettings.FirstRechargePoints;
        }
        else if (orderItem.ProductType == ProductType.Topup
                    || orderItem.ProductType == ProductType.AutoTopupEnable
                    || orderItem.ProductType == ProductType.FastTopup)
        {
            var accountDetail = await _userRepo.GetAccountDetails(orderItem.CardNumber!);
            int points = await _pointsRepository.GetPoints(orderItem.CardNumber!);
            orderPoint.OpeningBalance = decimal.Parse(accountDetail.Credit!);
            orderPoint.ClosingBalance = decimal.Parse(accountDetail.Credit!) + order.Amount;
            orderPoint.OpeningPoints = points;
            orderPoint.PointsReceived = orderItem.ProductType != ProductType.AutoTopupEnable
                                    ? _topupSettings.Amounts.Find(x => x.Amount == order.Amount)!.Points : 0;
            orderPoint.ClosingPoints = points + orderPoint.PointsReceived;
        }
        var orderHistory = new OrderHistory()
        {
            Description = "Order Created"
        };

        //Save order data
        long orderId = await _paymentRepo.SaveOrderDetails(
                            order: order,
                            orderItem: orderItem,
                            orderPayment: orderPayment,
                            orderCardPayment: orderCardPayment,
                            orderPaypalPayment: null!,
                            orderPoint: orderPoint,
                            orderHistory: orderHistory);
        if (orderId == 0)
        {
            return ErrorResult.Failure(CustomStatusKey.InternalServerError!, CustomStatusCode.InternalServerError);
        }

        #endregion

        #region Card Payment

        var cardPaymentRequest = new CardPaymentRequestDto()
        {
            PaymentExistingCardInfo = paymentExistingCardInfo,
            PaymentNewCardInfo = paymentNewCardInfo,
            Address = paymentAddressInfo,
            IpAddress = _commonService.GetIpAddress()!,
            CardPin = pinInfo?.Pin?.Trim(),
            CardNumber = cardNumber,
            Amount = order.TotalAmount,
            TransactionType = transactionType,
            IsRecurring = autoTopupInfo?.Status == true,
            Email = userInfo.Email
        };

        if (transactionType == ProductType.FastTopup && _currentUser.IsAuthenticated())
        {
            cardPaymentRequest.Email = _currentUser.GetUserEmail();
        }

        var paymentResponse = await _cardService.CardPayment(cardPaymentRequest);
        return await HandleCardPaymentResponse(orderId, paymentResponse!);

        #endregion
    }

    public async Task<object> HandleCardPaymentResume3dRequest(
        string transactionId,
        long orderId)
    {
        var response = await _cardService.Resume3dCardPayment(transactionId);
        return await HandleCardPaymentResponse(orderId, response);
    }

    #endregion

    #region PayPal

    public async Task<object> HandlePaypalPaymentRequest(
        ProductType transactionType,
        UserDto userInfo,
        decimal amount,
        string cardNumber)
    {
        #region Card Number Validation

        var pinInfo = new PinDetail();
        if (transactionType == ProductType.FastTopup
            || transactionType == ProductType.Topup
            || transactionType == ProductType.AutoTopupEnable)
        {
            pinInfo = await _callingCardRepository.GetCardInfo(cardNumber);
            if (pinInfo == null)
            {
                _logger.Debug($"HandlePaypalPaymentRequest: Invalid card number:  {cardNumber} {JsonConvert.SerializeObject(userInfo)}");
                return ErrorResult.Failure(CustomStatusKey.InvalidCardNumnber!, CustomStatusCode.BadRequest);
            }
        }

        #endregion

        #region Calculate Discount
        var discount = transactionType == ProductType.RechargeableCallingCard
                                                    ? _discountService.GetDiscount(amount) : 0;
        #endregion

        #region Order History Record

        var location = await _locationService.GetLocationInfo();
        var order = new Order
        {
            UserId = userInfo.Id,
            Discount = discount,
            TotalAmount = amount - discount,
            Amount = amount,
            Description = null,
            IpAddress = location.IpAddress,
            OrderStatus = OrderStatus.Created,
            Device = location?.Device,
            DeviceLocation = location?.CountryName == null ? null : $"{location.CityName},{location.CountryName}",
        };
        var orderItem = new OrderItem
        {
            Discount = discount,
            TotalAmount = amount - discount,
            Amount = amount,
            CardNumber = (transactionType == ProductType.FastTopup ||
                        transactionType == ProductType.Topup) ? cardNumber : null,
            ProductType = transactionType
        };
        var orderPayment = new OrderPayment()
        {
            PaymentMethodId = PaymentMethod.Paypal,
            Stauts = PaymentStatus.Pending,
            PaymentUserId = transactionType == ProductType.FastTopup && _currentUser.IsAuthenticated() ? _currentUser.GetUserId() : userInfo.Id
        };
        var orderPoint = new OrderPoint();
        if (orderItem.ProductType == ProductType.CallingCard)
        {
            orderPoint.OpeningBalance = order.Amount;
        }
        else if (orderItem.ProductType == ProductType.RechargeableCallingCard)
        {
            orderPoint.OpeningBalance = order.Amount;
            orderPoint.OpeningPoints = _topupSettings.Amounts!.Find(x => x.Amount == order.Amount)!.Points + _topupSettings.FirstRechargePoints;
        }
        else if (orderItem.ProductType == ProductType.Topup
            || orderItem.ProductType == ProductType.AutoTopupEnable
            || orderItem.ProductType == ProductType.FastTopup)
        {
            var accountDetail = await _userRepo.GetAccountDetails(orderItem.CardNumber!);
            int points = await _pointsRepository.GetPoints(orderItem.CardNumber!);
            orderPoint.OpeningBalance = decimal.Parse(accountDetail.Credit!);
            orderPoint.ClosingBalance = decimal.Parse(accountDetail.Credit!) + order.Amount;
            orderPoint.OpeningPoints = points;
            orderPoint.PointsReceived = orderItem.ProductType != ProductType.AutoTopupEnable
                                    ? _topupSettings.Amounts.Find(x => x.Amount == order.Amount)!.Points : 0;
            orderPoint.ClosingPoints = points + orderPoint.PointsReceived;
        }
        var orderHistory = new OrderHistory()
        {
            Description = "Order Created"
        };

        long orderId = await _paymentRepo.SaveOrderDetails(
                            order: order,
                            orderItem: orderItem,
                            orderPayment: orderPayment,
                            orderCardPayment: null!,
                            orderPaypalPayment: null!,
                            orderPoint: orderPoint,
                            orderHistory: orderHistory);
        if (orderId == 0)
        {
            return ErrorResult.Failure(CustomStatusKey.InternalServerError!, CustomStatusCode.InternalServerError);
        }

        #endregion

        var payPalRequest = new PaypalPaymentRequestDto()
        {
            Email = userInfo.Email,
            Amount = order.TotalAmount,
            IpAddress = _commonService.GetIpAddress(),
            CardNumber = cardNumber,
            CardPin = pinInfo?.Pin!?.Trim(),
            IsRecurring = false,
            OrderId = orderId
        };

        if (transactionType == ProductType.FastTopup && _currentUser.IsAuthenticated())
        {
            payPalRequest.Email = _currentUser.GetUserEmail();
        }

        var paymentResponse = await _payPalService.CreateSalePayment(payPalRequest);
        return await HandlePaypalPaymentResponse(orderId, paymentResponse);
    }

    public async Task<object> HandleDirectPaypalExecuteRequest(
        string payerId,
        string paymentId,
        string uniqueRef,
        long orderId)
    {
        var response = await _payPalService.ExecuteSalePayment(uniqueRef, payerId, paymentId);
        return await HandlePaypalPaymentResponse(orderId, response);
    }

    #endregion

    #endregion

    #region Private

    private async Task<object> HandleCardPaymentResponse(long orderId, CardPaymentResponseDto paymentResponse)
    {
        //Handle errors case
        if (!paymentResponse.IsSuccess)
        {
            //Update payment history status
            await _paymentRepo.UpdateOrderHistoryStatus(
                orderId,
                paymentResponse.TransactionId!,
                OrderStatus.Failure,
                PaymentStatus.Failure,
                errorMessage: paymentResponse.ErrorMessage! + "-" + paymentResponse.ErrorCode.ToString(),
                OrderHistoryConstants.PaymentFailed);

            return ErrorResult.Failure(paymentResponse.ErrorCode > 0
                ? paymentResponse.ErrorMessage
                ?? CustomStatusKey.OrderNotCompleted : CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
        }

        //Handle 3d secure return case
        if (paymentResponse.Require3dSecure)
        {
            //Update payment history status
            await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Created,
                    PaymentStatus.Pending,
                    null!,
                    OrderHistoryConstants.Payment3dSecureCardPending);

            if (paymentResponse.ThreeDSecureData!.Type!.Contains("V2", StringComparison.InvariantCultureIgnoreCase))
            {
                return new CardResponseDto()
                {
                    Require3dSecure = true,
                    Resume3dSecureData = new Resume3DV2Info()
                    {
                        TransactionId = paymentResponse.ThreeDSecureData.TransactionId,
                        ThreeDSServerTransId = paymentResponse.ThreeDSecureData.ThreeDSServerTransId,
                        Url = paymentResponse.ThreeDSecureData.RedirectUrl,
                    }
                };
            }
            else
            {
                _logger.Debug("Request contains form other than v2: " + JsonConvert.SerializeObject(paymentResponse));
                return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted!, CustomStatusCode.BadRequest);
            }
        }

        var orderDetails = await _paymentRepo.GetOrderDetails(orderId);
        var user = await _userRepo.GetUserByIdAsync(orderDetails.UserId!);

        if (orderDetails.OrderStatus != OrderStatus.Created)
        {
            _logger.Debug("Order status should be created orderId: " +
                $"{orderDetails.Id} PaymentData: {JsonConvert.SerializeObject(paymentResponse)}");
            return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
        }

        var fulfillmentResponse = new FullfilmentDto();

        //Handle Fulfillment Record
        if (orderDetails.ProductType != ProductType.AutoTopupEnable)
        {
            fulfillmentResponse = await PaymentFulfillment(orderDetails, user!);
            if (fulfillmentResponse.ErrorCode != 0)
            {
                //Update payment history status with failure
                await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Failure,
                    PaymentStatus.Success,
                    null!,
                    null!);

                //Cancel Payment
                var canelPaymentResponse = await _cardService.CancelPayment(paymentResponse.TransactionId!);
                if (!canelPaymentResponse)
                {
                    _logger.Error($"Payment cancelled failed: transactionID {paymentResponse.TransactionId!}");
                }
                await _paymentRepo.SaveOrderHistory(orderId, canelPaymentResponse
                     ? OrderHistoryConstants.PaymentCancelSuccess : OrderHistoryConstants.PaymentCancelFailed);

                return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
            }
            else
            {
                //Capture Payment
                var capturePayment = await _cardService.CapturePayment(paymentResponse.TransactionId!);
                if (!capturePayment)
                {
                    _logger.Error($"Payment capture failed: transactionID {paymentResponse.TransactionId!}");

                    //Update payment history status with failure
                    await _paymentRepo.UpdateOrderHistoryStatus(
                        orderId,
                        paymentResponse.TransactionId!,
                        OrderStatus.Failure,
                        PaymentStatus.Failure,
                        OrderHistoryConstants.PaymentCaptureFailed,
                        OrderHistoryConstants.PaymentCaptureFailed);

                    return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
                }

                _logger.Information($"Payment capture success: transactionID {paymentResponse.TransactionId!}");

                //Update payment history status with success
                await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Success,
                    PaymentStatus.Success,
                    null!,
                    OrderHistoryConstants.PaymentSuccess);
            }
        }
        else
        {
            //Capture Payment
            var capturePayment = await _cardService.CapturePayment(paymentResponse.TransactionId!);
            if (!capturePayment)
            {
                _logger.Error($"Payment capture failed: transactionID {paymentResponse.TransactionId!}");
                await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Failure,
                    PaymentStatus.Failure,
                    OrderHistoryConstants.PaymentCaptureFailed,
                    OrderHistoryConstants.PaymentCaptureFailed);
                return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
            }

            await _paymentRepo.SaveOrderHistory(orderId, OrderHistoryConstants.PaymentSuccess);

            //Refund Payment
            bool refundResponse = false;
            if (_webHostEnvironment.IsProduction())
            {
                _logger.Debug($"Started the RefundFullPayment: transactionID {paymentResponse.TransactionId!}");
                refundResponse = await _cardService.RefundFullPayment(paymentResponse.TransactionId!);
            }
            else
            {
                _logger.Debug($"Started the RefundPartialPayment: transactionID {paymentResponse.TransactionId!}");
                refundResponse = await _cardService.RefundPartialPayment(
                           paymentResponse.TransactionId!, Convert.ToDouble(orderDetails.TotalAmount));
            }
            if (!refundResponse)
            {
                _logger.Error($"Payment refund failed: transactionID {paymentResponse.TransactionId!}");
                await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Success,
                    PaymentStatus.Failure,
                    OrderHistoryConstants.PaymentRefundFailed,
                    OrderHistoryConstants.PaymentRefundFailed);
                return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
            }

            //Update payment history status with refunded
            await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Success,
                    PaymentStatus.Refunded,
                    null!,
                    OrderHistoryConstants.PaymentRefundSuccess);
        }

        //Get Latest Info
        orderDetails = await _paymentRepo.GetOrderDetails(orderId);

        //Add Product
        if (!string.IsNullOrEmpty(orderDetails.CardNumber)
                    && orderDetails.ProductType == ProductType.RechargeableCallingCard)
        {
            var (isSuccess, errorCode, errorMessage) = await _userRepo.CreateProduct(
                                        orderDetails?.CardNumber!, user?.Id!, DateTime.UtcNow);
            if (!isSuccess)
            {
                await _paymentRepo.SaveOrderHistory(orderId, OrderHistoryConstants.AddProductFailure);
                _logger.Debug(
                  "Class: PaymentService, " +
                  "Method: HandleCardPaymentResponse-CreateProduct, " +
                  $"Status Code: {errorCode}" +
                  $"Response: {errorMessage}");
            }
            await _paymentRepo.SaveOrderHistory(orderId, OrderHistoryConstants.AddProductSuccess);
        }

        //Handle Auto Topup
        if ((orderDetails?.ProductType == ProductType.Topup
                || orderDetails?.ProductType == ProductType.AutoTopupEnable
                || orderDetails?.ProductType == ProductType.RechargeableCallingCard)
             && !string.IsNullOrEmpty(orderDetails.CardNumber))
        {
            await _topupRepository.SetAutoTopup(
                isAutoTopup: orderDetails.IsAutoPayment,
                accountNumber: orderDetails.CardNumber,
                userEmail: user?.Email!,
                topupAmount: (decimal)orderDetails.AutoPaymentAmount,
                topupCurrency: nameof(Currency.GBP),
                topupTheresholdAmount: _topupSettings.AutoTopupSettings.ThresholdAmount,
                paymentMethod: nameof(PaymentMethod.Card),
                cardMaskedPan: orderDetails.CardMask!,
                cardInitialTransactionId: paymentResponse.TransactionId!);

            await _paymentRepo.SaveOrderHistory(orderId, orderDetails.IsAutoPayment
                    ? OrderHistoryConstants.AutoTopupEnableSuccess : OrderHistoryConstants.AutoTopupDisabledSuccess);
        }

        var response = new CardResponseDto
        {
            Require3dSecure = false,
            PaymentResponse = new PaymentResponse()
        };

        response.PaymentResponse.ProductType = orderDetails!.ProductType;
        response.PaymentResponse.Email = user!.Email;

        if (orderDetails.ProductType == ProductType.CallingCard)
        {
            response.PaymentResponse!.CardPin = fulfillmentResponse.PinNumber!.Trim();
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;

            orderDetails.CardPin = fulfillmentResponse.PinNumber;
            var isEmailSent = await _mailService.SendTHCCPurchaseEmail(orderDetails);
            await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                    ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
        }
        else if (orderDetails.ProductType == ProductType.RechargeableCallingCard)
        {
            response.PaymentResponse!.CardPin = fulfillmentResponse.PinNumber!.Trim();
            response.PaymentResponse!.CardNumber = fulfillmentResponse.CardNumber!.Trim();
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;
            response.PaymentResponse!.Points = $"{_topupSettings.FirstRechargePoints + _topupSettings.Amounts.First(x => x.Amount == orderDetails.Amount).Points} Points";

            //Send Email
            orderDetails.CardPin = fulfillmentResponse.PinNumber;
            orderDetails.CardNumber = fulfillmentResponse.CardNumber!;
            var isEmailSent = await _mailService.SendTHRCCPurchaseEmail(orderDetails);
            await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                    ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
        }
        else if (orderDetails.ProductType == ProductType.Topup
                        || orderDetails.ProductType == ProductType.FastTopup)
        {
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.Balance = $"{CurrencySymbol.GBP}{fulfillmentResponse.NewBalance}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;
            response.PaymentResponse!.Points = $"{_topupSettings.Amounts.First(x => x.Amount == orderDetails.Amount).Points} Points";

            //Send Email
            orderDetails.CardPin = fulfillmentResponse.PinNumber;
            if (orderDetails.ProductType == ProductType.Topup)
            {
                var isEmailSent = await _mailService.SendTHRCCRechargeEmail(orderDetails);
                await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                        ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
            }
            else if (orderDetails.ProductType == ProductType.FastTopup)
            {
                var isEmailSent = await _mailService.SendTHRCCFastRechargeEmail(orderDetails);
                await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                        ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
            }
        }
        else if (orderDetails.ProductType == ProductType.AutoTopupEnable)
        {
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.AutoPaymentAmount:0.00}";
            response.PaymentResponse!.ThresholdAmount = $"{CurrencySymbol.GBP}{_topupSettings.AutoTopupSettings.ThresholdAmount:0.00}";
            response.PaymentResponse!.MaxLimit = $"{CurrencySymbol.GBP}{_topupSettings.AutoTopupSettings.MaxLimit:0.00}";
            response.PaymentResponse!.PaymentMethod = PaymentMethod.Card;
            response.PaymentResponse!.CardInfo = new CardInfoDto()
            {
                CardMaskedPan = orderDetails.CardMask,
                CardType = orderDetails.CardType
            };
        }
        return response;
    }

    private async Task<object> HandlePaypalPaymentResponse(long orderId, PayPalPaymentResponseDto paymentResponse)
    {
        if (!paymentResponse!.IsSuccess)
        {
            await _paymentRepo.UpdateOrderHistoryStatus(
                orderId,
                paymentResponse.TransactionId!,
                OrderStatus.Failure,
                PaymentStatus.Failure,
                errorMessage: paymentResponse!?.ErrorMessage! + "-" + paymentResponse!?.ErrorCode!.ToString(),
                OrderHistoryConstants.PaymentFailed);

            return ErrorResult.Failure(paymentResponse!.ErrorCode > 0
                      ? paymentResponse.ErrorMessage
                      ?? CustomStatusKey.OrderNotCompleted : CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
        }

        //CallBack handling
        if (!string.IsNullOrEmpty(paymentResponse.RedirectUrl))
        {
            await _paymentRepo.UpdateOrderHistoryStatus(
                orderId,
                paymentResponse.TransactionId!,
                OrderStatus.Created,
                PaymentStatus.Pending,
                null!,
                OrderHistoryConstants.PaymentPaypalPending);

            return new PaypalPaymentResponse { RedirectUrl = paymentResponse.RedirectUrl };
        }

        //For Success Scnerio
        var orderDetails = await _paymentRepo.GetOrderDetails(orderId, null!);
        var user = await _userRepo.GetUserByIdAsync(orderDetails.UserId!);

        //Update the order with success payment
        await _paymentRepo.UpdateOrderHistoryStatus(
            orderId,
            paymentResponse.TransactionId!,
            OrderStatus.Created,
            PaymentStatus.Success,
            null!,
            OrderHistoryConstants.PaymentSuccess);

        //Handle Fulfillment Record
        var fulfillResponse = new FullfilmentDto();
        if (orderDetails.ProductType != ProductType.AutoTopupEnable)
        {
            fulfillResponse = await PaymentFulfillment(orderDetails, user!);
            if (fulfillResponse?.ErrorCode != 0)
            {
                _logger.Error(
                  "Class: PaymentService, " +
                  "Method: HandlePaypalPaymentResponse-PaymentFulfillment, " +
                  $"TransactionId:{paymentResponse.TransactionId}, OrderId: {orderDetails.Id}");

                //Update the order with success payment and failed fullfilment
                await _paymentRepo.UpdateOrderHistoryStatus(
                    orderId,
                    paymentResponse.TransactionId!,
                    OrderStatus.Failure,
                    PaymentStatus.Success,
                    null!,
                    null!);
                return ErrorResult.Failure(CustomStatusKey.OrderNotCompleted, CustomStatusCode.BadRequest);
            }

            //Update the order with success payment and success fullfilment
            await _paymentRepo.UpdateOrderHistoryStatus(
                orderId,
                paymentResponse.TransactionId!,
                OrderStatus.Success,
                PaymentStatus.Success,
                null!,
                null!);
        }

        //Add Product
        if (orderDetails.ProductType == ProductType.RechargeableCallingCard
                && !string.IsNullOrEmpty(fulfillResponse?.CardNumber)
                && !string.IsNullOrEmpty(fulfillResponse.PinNumber))
        {
            var (isSuccess, errorCode, errorMessage) = await _userRepo.CreateProduct(fulfillResponse?.CardNumber!, _currentUser.GetUserId(), DateTime.UtcNow);
            if (!isSuccess)
            {
                await _paymentRepo.SaveOrderHistory(orderId, OrderHistoryConstants.AddProductFailure);
                _logger.Debug(
                  "Class: PaymentService, " +
                  "Method: HandlePaypalPaymentResponse-CreateProduct, " +
                  $"Status Code: {errorCode}" +
                  $"Response: {errorMessage}");
            }
            await _paymentRepo.SaveOrderHistory(orderId, OrderHistoryConstants.AddProductSuccess);
        }

        var response = new PaypalResponseDto
        {
            PaymentResponse = new PaymentResponse()
        };

        response.PaymentResponse.Email = user!.Email;
        response.PaymentResponse.ProductType = orderDetails!.ProductType;

        if (orderDetails.ProductType == ProductType.CallingCard)
        {
            response.PaymentResponse!.CardPin = fulfillResponse!.PinNumber!.Trim();
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;

            //Send Email
            orderDetails.CardPin = fulfillResponse!.PinNumber;
            var isEmailSent = await _mailService.SendTHCCPurchaseEmail(orderDetails);
            await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                    ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
        }
        else if (orderDetails.ProductType == ProductType.RechargeableCallingCard)
        {
            response.PaymentResponse!.CardPin = fulfillResponse!.PinNumber!.Trim();
            response.PaymentResponse!.CardNumber = fulfillResponse.CardNumber!.Trim();
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;
            response.PaymentResponse!.Points = $"{_topupSettings.FirstRechargePoints + _topupSettings.Amounts.First(x => x.Amount == orderDetails.Amount).Points} Points";

            //Send Email
            orderDetails.CardPin = fulfillResponse!.PinNumber;
            orderDetails.CardNumber = fulfillResponse!.CardNumber!;
            var isEmailSent = await _mailService.SendTHRCCPurchaseEmail(orderDetails);
            await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                    ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
        }
        else if (orderDetails.ProductType == ProductType.Topup
                        || orderDetails.ProductType == ProductType.FastTopup)
        {
            response.PaymentResponse!.Amount = $"{CurrencySymbol.GBP}{orderDetails.Amount}";
            response.PaymentResponse!.Balance = $"{CurrencySymbol.GBP}{fulfillResponse!.NewBalance}";
            response.PaymentResponse!.TransactionId = orderDetails.OrderReference;
            response.PaymentResponse!.Points = $"{_topupSettings.Amounts.First(x => x.Amount == orderDetails.Amount).Points} Points";

            //Send Email
            orderDetails.CardPin = fulfillResponse.PinNumber;
            if (orderDetails.ProductType == ProductType.Topup)
            {
                var isEmailSent = await _mailService.SendTHRCCRechargeEmail(orderDetails);
                await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                        ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
            }
            else if (orderDetails.ProductType == ProductType.FastTopup)
            {
                var isEmailSent = await _mailService.SendTHRCCFastRechargeEmail(orderDetails);
                await _paymentRepo.SaveOrderHistory(orderId, isEmailSent
                        ? OrderHistoryConstants.EmailSentSuccess : OrderHistoryConstants.EmailSentFailed);
            }
        }

        return response;
    }

    private async Task<FullfilmentDto> PaymentFulfillment(OrderDetail orderDetails, User user)
    {
        if (orderDetails.PaymentMethodId == PaymentMethod.Card)
        {
            if (orderDetails.ProductType == ProductType.CallingCard)
            {
                var response = await _fulfillmentRepo.Pay360ThccCardFullfilment(
                        orderDetails.TransactionId!,
                        orderDetails.Amount.ToString(),
                        user?.Email!,
                        user?.FirstName!);

                var fulfillmentErrorMsg = response == null
                   ? "Null response received from stored procedure " + StoredProcedures.Pay360ThccCardFullfilment
                   : null;

                await _fulfillmentRepo.UpdateFulfillmentItems(
                  orderItemId: orderDetails.OrderItemId,
                  errorMsg: fulfillmentErrorMsg!,
                  cardnumber: null!,
                  cardpin: !string.IsNullOrEmpty(response?.pin) ? response.pin.Trim() : null!,
                  orderHistoryDescription: response != null && !string.IsNullOrEmpty(response.pin)
                                ? OrderHistoryConstants.FulfillmentSuccess : OrderHistoryConstants.FulfillmentFailed);

                return new FullfilmentDto()
                {
                    ErrorMessage = fulfillmentErrorMsg,
                    ErrorCode = response == null ? CustomStatusCode.BadRequest : 0,
                    PinNumber = response?.pin!
                };
            }
            else
            {
                var fullfillmentAmount = orderDetails.Amount * 100;
                var response = await _fulfillmentRepo.Pay360ThrccCardFullfilment(
                    user?.Email!,
                    user?.FirstName!,
                    orderDetails.TransactionId!,
                    fullfillmentAmount.ToString(),
                    orderDetails.CardNumber!);

                await _fulfillmentRepo.UpdateFulfillmentItems(
                    orderItemId: orderDetails.OrderItemId,
                    errorMsg: response.ErrorCode == 0 ? null! : response.ErrorMessage!,
                    cardnumber: response.CardNumber!.Trim(),
                    cardpin: response?.PinNumber!.Trim()!,
                    orderHistoryDescription: response!.ErrorCode == 0
                                ? OrderHistoryConstants.FulfillmentSuccess : OrderHistoryConstants.FulfillmentFailed);

                if (response!.ErrorCode == 0)
                {
                    var points = await _pointsRepository.GetPoints(response.CardNumber!);
                    response.Newpoints = points.ToString();
                }

                return response!;
            }
        }
        else
        {
            if (orderDetails.ProductType == ProductType.CallingCard)
            {
                var response = await _fulfillmentRepo.PaypalThccCardFullfilment(
                        orderDetails.TransactionId!,
                        orderDetails.Amount.ToString(),
                        user?.Email!,
                        user?.FirstName!);

                var fulfillmentErrorMsg = response == null
                   ? "Null response received from stored procedure " + StoredProcedures.PaypalThccCardFullfilment
                   : null;

                await _fulfillmentRepo.UpdateFulfillmentItems(
                  orderItemId: orderDetails.OrderItemId,
                  errorMsg: fulfillmentErrorMsg!,
                  cardnumber: null!,
                  cardpin: response?.pin!,
                  orderHistoryDescription: response != null && !string.IsNullOrEmpty(response.pin)
                                ? OrderHistoryConstants.FulfillmentSuccess : OrderHistoryConstants.FulfillmentFailed);

                return new FullfilmentDto()
                {
                    ErrorMessage = fulfillmentErrorMsg,
                    ErrorCode = response == null ? CustomStatusCode.BadRequest : 0,
                    PinNumber = response?.pin!
                };
            }
            else
            {
                var fullfillmentAmount = orderDetails.Amount * 100;
                var response = await _fulfillmentRepo.PaypalThrccCardFullfilment(
                    user?.Email!,
                    user?.FirstName!,
                    orderDetails.TransactionId!,
                    fullfillmentAmount.ToString(),
                    orderDetails.CardNumber!);

                await _fulfillmentRepo.UpdateFulfillmentItems(
                    orderItemId: orderDetails.OrderItemId,
                    errorMsg: response.ErrorCode == 0 ? null! : response.ErrorMessage!,
                    cardnumber: response.CardNumber!,
                    cardpin: response?.PinNumber!,
                    orderHistoryDescription: response!.ErrorCode == 0
                                ? OrderHistoryConstants.FulfillmentSuccess : OrderHistoryConstants.FulfillmentFailed);

                if (response!.ErrorCode == 0)
                {
                    var points = await _pointsRepository.GetPoints(response.CardNumber!);
                    response.Newpoints = points.ToString();
                }

                return response!;
            }
        }

    }

    #endregion

    #endregion
}
