﻿using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Products.Responses
{
    public class ProductSkusResponse
    {
        [JsonPropertyName("productId")]
        public string ProductId { get; set; }

        [JsonPropertyName("skuId")]
        public string SkuId { get; set; }

        [JsonPropertyName("sourceId")]
        public string SkuSourceId { get; set; }

        [JsonPropertyName("price")]
        public long Price { get; set; }

        [JsonPropertyName("currency")]
        public string Currency { get; set; }

        [JsonPropertyName("points")]
        public long Points { get; set; }
    }
}
