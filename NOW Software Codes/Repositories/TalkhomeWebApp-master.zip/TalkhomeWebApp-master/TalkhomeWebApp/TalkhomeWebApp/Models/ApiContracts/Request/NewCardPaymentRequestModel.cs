﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TalkhomeWebApp.Models.ViewModels;
using TalkhomeWebApp.Utilities;

namespace TalkhomeWebApp.Models.ApiContracts.Request
{
    public class NewCardPaymentRequestModel
    {
        public PaymentCardModel cardData { get; set; }
        public BillingAddressModel billingAddressData { get; set; }

        [CollectionValidation(values: new int[] { 0, 5, 10, 15, 20, 25 })]
        public int TopUpAmount { get; set; }
        public string BundleId { get; set; }

        [Required]
        [Range(1, 2)]
        public CheckOutTypes CheckoutType { get; set; }

        [Required]
        public string ipAddress { get; set; }

        public string EmailAddress { get; set; }
        public string Msisdn { get; set; }
        public string CustomerUniqueRef { get; set; }

        public string FromBundleISO2 { get; set; }
        public string ToBundleISO2 { get; set; }

        public bool IsAutoTopUp { get; set; }
        public bool IsAutoBundleRenew { get; set; }
    }
}
