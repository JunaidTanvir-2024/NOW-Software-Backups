﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentsApi.Models.Configurations
{
    public class SmsConfig
    {
        public string PoppayoutsApiEndPoint { get; set; }
        public string XeebiApiEndPoint { get; set; }
        public string LocalsmsApiEndPoint { get; set; }
        public string LocalsmsApiUsername { get; set; }
        public string LocalsmsApiPassword { get; set; }
        public string LocalsmsTHMFrom { get; set; }
        public string LocalsmsNowPGFrom { get; set; }
        public bool UsePoppayout { get; set; }
        public bool UseXeebi { get; set; }
        public string WtccIVRSmsText { get; set; }
        public string ThccIVRSmsText { get; set; }
        public string SafariTalkIVRSmsText { get; set; }
        public string BabyTalkIVRSmsText { get; set; }
        public string MaxiTalkIVRSmsText { get; set; }
        public string ThaIVRSmsText { get; set; }
        public string TalkDirectIVRSmsText { get; set; }
        public string ThmIVRSmsText { get; set; }
        public string NowPayGIVRSmsText { get; set; }
        public string Sid { get; set; }
        public string AuthToken { get; set; }
        public string [] TwilioFromNumberCountries { get; set; }
        public string TwilioNumber { get; set; }
        public string WtccIVRSmsProvider { get; set; }
        public string ThccIVRSmsProvider { get; set; }
        public string ThaIVRSmsProvider { get; set; }
        public string StccIVRSmsProvider { get; set; }
        public string BtccIVRSmsProvider { get; set; }
        public string MtccIVRSmsProvider { get; set; }
        public string TdccIVRSmsProvider { get; set; }
        public string ThmIVRSmsProvider { get; set; }
        public string NowPayGIVRSmsProvider { get; set; }

    }
}
