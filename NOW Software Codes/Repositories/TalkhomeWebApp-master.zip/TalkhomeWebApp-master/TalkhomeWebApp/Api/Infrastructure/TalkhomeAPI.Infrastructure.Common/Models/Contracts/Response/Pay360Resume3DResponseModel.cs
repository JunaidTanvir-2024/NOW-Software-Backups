﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response
{
    public class Pay360Resume3DResponseModel
    {
        public BundlePurchaseInfo bundlePurchaseInfo { get; set; }
        public TopupInfo topupInfo { get; set; }
    }
    public class SetAutoTopupWithCardPay360Resume3DResponseModel
    {
        public AutoTopupInfo AutoTopupInfo { get; set; }
    }
    public class SetAutoRenewalWithCardPay360Resume3DResponseModel
    {
    }
}
