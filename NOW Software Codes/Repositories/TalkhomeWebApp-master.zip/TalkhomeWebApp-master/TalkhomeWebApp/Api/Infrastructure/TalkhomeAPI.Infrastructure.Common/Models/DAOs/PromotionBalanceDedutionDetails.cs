﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.DAOs
{
   public class PromotionBalanceDedutionDetails
    {
        public decimal retAmount { get; set; }
        public string retcreditReason { get; set; }
    }
}
