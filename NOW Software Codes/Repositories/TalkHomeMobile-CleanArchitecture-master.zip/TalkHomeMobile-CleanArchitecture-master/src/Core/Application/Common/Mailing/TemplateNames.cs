﻿namespace Application.Common.Mailing;

public static class TemplateNames
{
    public const string EmailConfirmation = "EmailVerification";
    public const string ForgetPassword = "ForgotPassword";
    public const string SignUpEmail = "EmailVerification";
    public const string Topup = "Topup";
    public const string Bundle = "Bundle";
    public const string SendFreeSimOrderEmail = "Order_Sim_Free";
    public const string SendCreditSimOrderEmail = "Order_Sim_Credit";
}
