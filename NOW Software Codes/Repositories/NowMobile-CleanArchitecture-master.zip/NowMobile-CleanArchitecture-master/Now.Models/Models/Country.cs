﻿
namespace Now.Models.Models;

public class Country
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? PhoneCode { get; set; }
    public string? IsoTwoCharacterCode { get; set; }
    public string? IsoThreeCharacterCode { get; set; }
    public string? IsoNumericCode { get; set; }
    public bool IsNational { get; set; }
}

public class CountriesData
{
    public IList<Country> Countries { get; set; }=new List<Country>();
}
