﻿using Newtonsoft.Json;

using THCC.Infrastructure.Services.Payment.Models;

namespace THCC.Infrastructure.Services.Payment.PayPal.Models
{
    public class PayPalCreateSalePaymentRequest
    {
        public PayPalCreateSalePaymentRequest()
        {
            RedirectUrl = new RedirectUrls();
            Transactions = new Transactions();
            Basket = new List<ProductBasket>();
        }
        public string? CustomerName { get; set; }
        public string? CustomerUniqueRef { get; set; }
        public string? CustomerMsisdn { get; set; }
        [JsonProperty("CustomerEmail")]
        public string? CustomerEmail { get; set; }
        public string? ProductCode { get; set; }
        [JsonProperty("redirect_urls")]
        public RedirectUrls? RedirectUrl { get; set; }
        public Transactions? Transactions { get; set; }
        public List<ProductBasket>? Basket { get; set; }
    }

    public class RedirectUrls
    {
        [JsonProperty("return_url")]
        public string? ReturnUrl { get; set; }
        [JsonProperty("cancel_url")]
        public string? CancelUrl { get; set; }
    }
}
