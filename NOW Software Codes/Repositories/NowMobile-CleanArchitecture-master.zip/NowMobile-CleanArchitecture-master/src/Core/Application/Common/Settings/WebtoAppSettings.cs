﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Settings;
public class WebtoAppSettings
{
    public const string SectionName = "WebtoAppSettings";
    public static WebtoAppSettings Bind = new WebtoAppSettings();
    public bool IsActive { get; set; } = false;
}