using System.Linq.Expressions;

using JM.Core.Entities;
using JM.Core.Utilities.Extensions;
using JM.Core.Utilities.Interfaces.Database;

using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

using Serilog;

namespace JM.Infrastructure.Persistence.Repositories;

internal sealed class UserRepository(AppDbContext context, ILogger logger, SignInManager<User> signInManager,
	UserManager<User> userManager) : IUserRepository
{
	private readonly AppDbContext _context = context;
	private readonly ILogger _logger = logger;
	private readonly SignInManager<User> _signInManager = signInManager;
	private readonly UserManager<User> _userManager = userManager;

	public async Task<User?> GetUser(Expression<Func<User, bool>> expression)
	{
		try
		{
			return await _context.Set<User>()
			   .Where(expression)
			   .Include(x => x.UserDetail)
			   .ThenInclude(x => x.Country)
			   .FirstOrDefaultAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(GetUser));
			return default!;
		}
	}
	public async Task<User> AddUser(User user)
	{
		try
		{
			var addedUser = await _context.Set<User>().AddAsync(user);
			return addedUser.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(AddUser));
			return default!;
		}
	}
	public async Task<UserDetail> AddUserDetail(UserDetail userDetail)
	{
		try
		{
			var addedUserDetail = await _context.Set<UserDetail>().AddAsync(userDetail);
			await _context.Entry(addedUserDetail.Entity).Reference(x => x.Country).LoadAsync();

			return addedUserDetail.Entity;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(AddUserDetail));
			return default!;
		}
	}

	public async Task<IEnumerable<User>?> GetUsers(Expression<Func<User, bool>> expression)
	{
		try
		{
			return await _context.Set<User>()
			.Include(x => x.UserDetail)
			.ThenInclude(x => x.Country).ToListAsync();
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(GetUser));
			return default!;
		}
	}

	public void UpdateUser(User user)
	{
		try
		{
			_context.Entry(user).CurrentValues.SetValues(user);
			_context.Entry(user).State = EntityState.Modified;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(UpdateUser));
		}
	}
	public UserDetail UpdateUserDetail(UserDetail userDetail)
	{
		try
		{
			_context.Entry(userDetail).CurrentValues.SetValues(userDetail);
			_context.Entry(userDetail).State = EntityState.Modified;
			return userDetail!;
		}
		catch (Exception ex)
		{
			_logger.ErrorLog(ex, nameof(UserRepository), nameof(UpdateUserDetail));
			return default!;
		}
	}
}
