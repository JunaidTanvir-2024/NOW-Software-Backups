﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class SaveUserSimOrderRequestModel
    {
        public RegisterUserRequestModel UserInfo { get; set; }
        public bool IsUserExists { get; set; }
        public UserAddressRequestModel UserAddressInfo { get; set; }
        public UserSIMOrderRequestModel UserSimInfo { get; set; }
    }
}
