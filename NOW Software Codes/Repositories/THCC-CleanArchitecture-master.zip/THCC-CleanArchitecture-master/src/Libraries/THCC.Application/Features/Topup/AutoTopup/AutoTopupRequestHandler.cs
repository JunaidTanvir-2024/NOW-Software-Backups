﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;

namespace THCC.Application.Features.Topup.AutoTopup
{
    public class AutoTopupRequestHandler : IRequestHandler<AutoTopupRequest, object>
    {
        #region Fields 

        private readonly IMapper _mapper;
        private readonly ICurrentUser _currentUser;
        private readonly IUserRepository _userRepository;
        private readonly ITopupRepository _topupRepository;
        private readonly TopupSettings _topupSettings;

        #endregion

        #region Ctors

        public AutoTopupRequestHandler(
            IMapper mapper,
            ICurrentUser currentUser,
            IUserRepository userRepository,
            ITopupRepository topupRepository,
            IOptions<TopupSettings> topupSettings)
        {
            _mapper = mapper;
            _currentUser = currentUser;
            _userRepository = userRepository;
            _topupRepository = topupRepository;
            _topupSettings = topupSettings.Value;
        }

        #endregion

        #region Method

        public async Task<object> Handle(AutoTopupRequest request, CancellationToken cancellationToken)
        {
            var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
            if (userProduct == null)
            {
                return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
            }
            var autoTopup = await _topupRepository.GetAutoTopup(userProduct!.Product!, _currentUser.GetUserEmail()!);
            if (autoTopup != null)
            {
                autoTopup.ThresHold /= 100;
            }
            return autoTopup == null ? new AutoTopupResponseDto()
            {
                Status = false,
                Threshold = _topupSettings.AutoTopupSettings.ThresholdAmount
            } : _mapper.Map<AutoTopupResponseDto>(autoTopup!);
        }

        #endregion
    }
}