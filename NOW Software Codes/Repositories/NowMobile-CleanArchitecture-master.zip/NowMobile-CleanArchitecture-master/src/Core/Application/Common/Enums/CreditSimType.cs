﻿namespace Application.Common.Enums;

public enum CreditSimType
{
    Topup = 1,
    Bundle = 2,
    TopupBundle = 3
}