﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class LoginSignUpViewModel
    {
        public string[] BlockedCountries { get; set; }
    }
}
