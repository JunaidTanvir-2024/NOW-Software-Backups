﻿using Models.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class FCMPushRequest
    {
        //[JsonProperty("to")]
        //[Required]
        //public string To { get; set; }
        public string DeviceToken { get; set; }
        public List<string> DeviceTokens { get; set; }
        public FCMNotificationTypes NotificationType { get; set; }

        public string MessageTitle { get; set; }
    
        public string MessageBody { get; set; }
        public string sip_calling { get; set; }
        public string call_uuid { get; set; }
        public string xmpp_message { get; set; }
        public int CallType { get; set; }
        public string FromCaller { get; set; }
    }

    public class APNSPushRequest
    {
        //[JsonProperty("to")]
        //[Required]
        //public string To { get; set; }
        public ApnServerType server { get; set; }
        public string DeviceToken { get; set; }
        public List<string> DeviceTokens { get; set; }
        public APNSNotificationTypes NotificationType { get; set; }

 
        public string MessageTitle { get; set; }

   
        public string MessageBody { get; set; }
        public string sip_calling { get; set; }
        public string call_uuid { get; set; }

        public string xmpp_message { get; set; }
        public int CallType { get; set; }
        public string FromCaller { get; set; }
    }
}
