﻿using CancelBundleApi.Constants.Database;
using CancelBundleApi.Models.DbModels;
using CancelBundleApi.Repositories.Interfaces;
using CancelBundleApi.Settings.Database;
using Dapper;
using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;

namespace CancelBundleApi.Repositories.Implementations;

internal sealed class UserRepository : IUserRepository
{
    #region Fields

    private readonly IDbConnectionSettings _dbConnectionDigiTalk;


    #endregion

    #region Ctor

    public UserRepository(
        IOptions<DatabaseSettings> databaseSettings
     )
    {
        _dbConnectionDigiTalk = new DbConnectionSettings(new SqlConnection(databaseSettings.Value.DigiTalkConnection));
    }

    #endregion

    #region Methods

    /// <summary>
    /// get msisdn detail
    /// </summary>
    /// <param name="msisdn"></param>
    /// <returns></returns>
    public async Task<MsisdnDetails> GetMsisdnDetail(string msisdn)
    {
        var parameters = new DynamicParameters();
        parameters.Add("@msisdn", msisdn);

        return await _dbConnectionDigiTalk.SqlConnection.QueryFirstOrDefaultAsync<MsisdnDetails>(
                StoredProcedures.GetMsisdnDetails, parameters, commandType: CommandType.StoredProcedure);
    }
    #endregion
}