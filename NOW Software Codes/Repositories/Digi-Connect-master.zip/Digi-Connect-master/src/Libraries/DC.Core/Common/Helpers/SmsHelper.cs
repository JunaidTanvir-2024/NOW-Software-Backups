using System.Text.Json;

using DC.Core.Common.DependencyResolver;
using DC.Core.Common.DTOs.Vendors.DTOne;
using DC.Core.Common.Entities;
using DC.Core.Common.Interfaces.Database;
using DC.Core.Common.Interfaces.Services;


namespace DC.Core.Common.Helpers;
public interface ISmsHelper : ServiceType.IScoped
{
    Task<bool> sendSms(ActiveMsisdnLog activityLog, string messages, string category);
}
public class SmsHelper : ISmsHelper
{
    private readonly ISMSService _smsService;
    private readonly IDigiConnectRepository _digiConnect;
    public SmsHelper(ISMSService smsService,
        IDigiConnectRepository digiConnect)
    {
        _smsService = smsService;
        _digiConnect = digiConnect;
    }
    public async Task<bool> sendSms(ActiveMsisdnLog activityLog, string message, string category)
    {
        try
        {
            bool response = false;
            if ((activityLog.Msisdn.Length > 11) && activityLog.Msisdn.StartsWith("44"))
            {
                activityLog.Msisdn = $"+{activityLog.Msisdn}";
            }
            var request = new SMSSend.Request
            {
                Message = message,
                ProductCode = "THM",
                RequestID = Guid.NewGuid().ToString(),
                To = activityLog.Msisdn,
                RequestType = 1
            };
            response = await _smsService.SendSMS(request);
            await logSms(JsonSerializer.Serialize(request), activityLog, response, category);

            return response;
        }
        catch (Exception ex)
        {
            return default;
        }
    }
    private async Task logSms(string request, ActiveMsisdnLog activityLog, bool response, string category)
    {
        var log = new SendSMSLog
        {
            SmsRequest = request,
            SMSSentStatus = response.ToString(),
            CreatedBy = activityLog.CreatedBy,
            CreatedOn = DateTime.UtcNow,
            Cadence = activityLog.Cadence,
            Msisdn = activityLog.Msisdn
        };
        await _digiConnect.AddSendSMSLog(log);
    }
}
