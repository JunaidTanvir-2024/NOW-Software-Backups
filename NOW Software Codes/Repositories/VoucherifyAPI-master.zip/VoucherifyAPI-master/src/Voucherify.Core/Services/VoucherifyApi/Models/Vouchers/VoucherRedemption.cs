using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Definations;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

public class VoucherRedemption : BaseObject
{
    [JsonPropertyName("date")]
    public DateTime? Date { get; set; }

    [JsonPropertyName("quantity")]
    public long? Quantity { get; set; }

    [JsonPropertyName("customer_id")]
    public string? CustomerId { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }

    [JsonPropertyName("result")]
    public VoucherifyEnums.RedemptionResult? Result { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    [JsonPropertyName("customer")]
    public CustomerSimple? Customer { get; set; }
}
