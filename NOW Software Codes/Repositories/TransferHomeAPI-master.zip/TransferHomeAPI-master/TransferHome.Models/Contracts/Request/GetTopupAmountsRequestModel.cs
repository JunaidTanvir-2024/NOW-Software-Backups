﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetTopupAmountsRequestModel
    {
        public int UserId { get; set; }
    }
}
