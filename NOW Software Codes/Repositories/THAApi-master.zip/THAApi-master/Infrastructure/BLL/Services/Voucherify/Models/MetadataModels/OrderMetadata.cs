﻿using Models.Enums;

namespace Infrastructure.BLL.Services.Voucherify.Models.MetadataModels
{
	public class OrderMetadata
	{
		public string OperatorName { get; set; }
		public string[] PaymentMethod { get; set; }
		public string[] CheckoutType { get; set; }
		public string InternationalTopupDestination { get; set; }
    }
}
