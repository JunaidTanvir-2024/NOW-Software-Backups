﻿using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Common.Model;
using SC.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.Interfaces.Services;
public interface ICustomerOrderService
{
    Task<decimal> CalculateCustomerOrderPrice(string UserID);
    Task<ApiResult<PurchaseInventoryResponse>> PurchaseInventory(CustomerOrderDetailDto orderDetail);
    Task CreateOrderPaymentHistory(long OrderID, decimal orderAmount, string? transactionID, string action, bool? isFailure, bool? require3dSecure = false);
    Task<bool> UpdateOrder(CustomerOrderDetailDto orderDetail);
    Task<decimal> CalculateServiceFeeAmount(string productType, decimal? productSellingPrice);
}

