﻿using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace NowPayGApi.Models.Contracts.Request
{
    public class GetUserByEmailRequestModel
    {
        public string Email { get; set; }
    }
}
