﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class VerifyEmailRequestModel
    {
        [Required(ErrorMessage = "token is required")]
        public string Token { get; set; }
    }
}
