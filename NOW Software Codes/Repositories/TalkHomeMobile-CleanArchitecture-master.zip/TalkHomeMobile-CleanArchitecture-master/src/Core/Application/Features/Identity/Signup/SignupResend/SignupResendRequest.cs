﻿namespace Application.Features.Identity.Signup.SignupResend;
public class SignupResendRequest : IRequest<Result<object>>
{
    public string EmailAddress { get; set; } = default!;
    public string Msisdn { get; set; } = default!;
}