﻿using TrasnferHome.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TrasnferHome.Models.DAOs
{
    public class DBUser
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get
            {
                var name = "";
                if (!string.IsNullOrEmpty(FirstName))
                {
                    name = FirstName;
                }
                if (!string.IsNullOrEmpty(LastName))
                {
                    name += " " + LastName;
                }
                return name;
            }

        }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int CountryId { get; set; }
        public decimal Balance { get; set; }
        public string BalanceCurrency { get; set; }
        public string BalanceCurrencySymbol { get; set; }
        public bool IsEmailVerified { get; set; }
        public bool MailSubscription { get; set; }
        public SignUpType SignUpType { get; set; }
        public Roles Role { get; set; }
        public string PinNumber { get; set; }
        public bool IsNotificationsOn { get; set; }
        public bool IsActive { get; set; }

        //FCM Token
        public string Token { get; set; }
        public string UDID { get; set; }
        public DeviceType DeviceType { get; set; }
    }
}
