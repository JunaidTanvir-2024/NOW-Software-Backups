﻿using Infrastructure.BLL.Services.Voucherify.Definations;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Customers.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses;
using Microsoft.Extensions.Options;
using Models.Common;
using Models.Configurations;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.StackableDiscounts.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Products.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.Products.Responses;
using Infrastructure.BLL.Services.Voucherify.Models.Events;
using Infrastructure.BLL.Services.Voucherify.Models.Events.Responses;
using Models.Contracts.Response.Voucherify;
using Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Requests;
using Infrastructure.BLL.Services.Voucherify.Models.EarningRules.Responses;
using Serilog;
using Microsoft.AspNetCore.Http;
using System.Net;
using System;

namespace Infrastructure.BLL.Services.Voucherify
{
    internal class VoucherifyService : IVoucherifyService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger _logger;
        private readonly VoucherifyConfig _voucherifyConfig;

        public VoucherifyService(
            IHttpClientFactory httpClientFactory,
            IOptions<VoucherifyConfig> options,
            ILogger logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _voucherifyConfig = options.Value;
        }

        // Customers Endpoints
        public async Task<ApiResult<CustomerResponse>> GetCustomerBySourceId(GetVoucherifyCustomerRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.Customers}{request.SourceId}?LoyaltyCampaignId={request.LoyaltyCampaignId}";
            try
            {
                var response = await client.GetAsync(targetUrl);
                var result = await response.Content.ReadAsStringAsync();

                return ApiResponseSerializer<ApiResult<CustomerResponse>>(response, request, result, "GetCustomerBySourceId");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetCustomerBySourceId", request);
                return null;
            }
        }

        public async Task<ApiResult<ReferralCodeResponse>> GetReferralCode(GetReferralCodeRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.CustomerInvitationCode;
            
            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<ReferralCodeResponse>>(response, request, result, "GetReferralCode");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetReferralCode", request);
                return null;
            }
        }

        public async Task<ApiResult<CustomerResponse>> CreateVoucherifyCustomer(CreateVoucherifyCustomerRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Customers;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<CustomerResponse>>(response, request, result, "CreateVoucherifyCustomer");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "CreateCustomer", request);
                return null;
            }
        }

        // Promotions Endpoints
        public async Task<ApiResult<PromotionTierResponse>> GetCustomerSpecificPromotionTiers(GetCustomerSpecificPromotionTiersRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Promotions;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<PromotionTierResponse>>(response, request, result, "GetCustomerSpecificPromotionTiers");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetCustomerSpecificPromotionTiers", request);
                return null;
            }
        }


        // Stackable Discounts Endpoints
        public async Task<ApiResult<StackableDiscountValidationResponse>> ValidateStackableDiscounts(StackableDiscountValidationRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.ValidateStackableDiscounts;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<StackableDiscountValidationResponse>>(response, request, result, "GetCustomerSpecificPromotionTiers");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "ValidateStackableDiscounts", request);
                return null;
            }
        }


        public async Task<ApiResult<StackableDiscountRedemptionResponse>> RedeemStackableDiscounts(StackableDiscountRedemptionRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.RedeemStackableDiscounts;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<StackableDiscountRedemptionResponse>>(response, request, result, "RedeemStackableDiscounts");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "RedeemStackableDiscounts", request);
                return null;
            }
        }
        public async Task<ApiResult<StackableDiscountRollbackResponse>> RollbackStackableDiscounts(StackableDiscountRollbackRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.RollbackStackableDiscounts;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();

                return ApiResponseSerializer<ApiResult<StackableDiscountRollbackResponse>>(response, request, result, "RollbackStackableDiscounts");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "RollbackStackableDiscounts", request);
                return null;
            }
        }

        // Products Endpoints
        public async Task<ApiResult<ProductSkusResponse>> GetProductSKU(GetProductSkuRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.ProductSKUs + request.SkuNameOrId;
            try
            {
                var response = await client.GetAsync(targetUrl);
                var result = await response.Content.ReadAsStringAsync();
                return ApiResponseSerializer<ApiResult<ProductSkusResponse>>(response, request, result, "GetProductSKU");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetProductSKU", request);
                return null;
            }
        }
        public async Task<ApiResultSet<ProductSkusResponse>> GetProductSKUs(GetProductSkusRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + $"{VoucherifyConstants.Endpoints.ProductSKUs}?ProductNameOrId={request.ProductNameOrId}";
            try
            {
                var response = await client.GetAsync(targetUrl);
                var result = await response.Content.ReadAsStringAsync();
             
                return ApiResponseSerializer<ApiResultSet<ProductSkusResponse>>(response, request, result, "GetProductSKUs");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetProductSKUs", request);
                return null;
            }
        }

        // Voucherify Earning Rules
        public async Task<ApiResultSet<EarningRuleResponse>> GetCampaignEarningRules(GetEarningRulesRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.EarningRules}?CampaignNameOrId={request.CampaignId}&pageNumber={request.PageNumber}&pageSize={request.PageSize}";

            try
            {
                var response = await client.GetAsync(targetUrl);
                var result = await response.Content.ReadAsStringAsync();
                
                return ApiResponseSerializer<ApiResultSet<EarningRuleResponse>>(response, request, result, "GetCampaignEarningRules");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "GetCampaignEarningRules", request);
                return null;
            }
        }

        // Voucherify Events Endpoints
        public async Task<ApiResult<InvokedVoucherifyEventResponse>> InvokeVoucherifyEvent(InvokeVoucherifyEventRequest request, string uniqueReference)
        {
            var client = _httpClientFactory.CreateClient();

            AttachReferenceHeaders(uniqueReference, client);

            var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.VoucherifyEvents;

            var requestJson = JsonSerializer.Serialize(request);
            try
            {
                var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

                var result = await response.Content.ReadAsStringAsync();

                return ApiResponseSerializer<ApiResult<InvokedVoucherifyEventResponse>>(response, request, result, "InvokeVoucherifyEvent");
            }
            catch (Exception ex)
            {
                ApiExceptionLogger(ex, "InvokeVoucherifyEvent", request);
                return null;
            }
        }

        private T ApiResponseSerializer<T>(HttpResponseMessage response, object request, string result, string methodName)
        {
            if (response.StatusCode != HttpStatusCode.OK)
            {
                _logger.Debug($"{{Class: VoucherifyService, Method:{methodName}, Request: {JsonSerializer.Serialize(request)} StatusCode:{response.StatusCode}, Respponse:{result}}}");
            }
            return JsonSerializer.Deserialize<T>(result);
        }
        private void ApiExceptionLogger(Exception ex, string methodName, object request)
        {
            _logger.Error($"{{Class: VoucherifyService, Method:{methodName}, Request: {JsonSerializer.Serialize(request)}, Exception:{ex.StackTrace?.ToString()}}}");
        }
        private static void AttachReferenceHeaders(string uniqueReference, HttpClient client)
        {
            client.DefaultRequestHeaders.Add("UniqueReference", uniqueReference);
            client.DefaultRequestHeaders.Add("ProductCode", "THA");
            client.DefaultRequestHeaders.Add("ProductItemCode", "THA_APP");
        }

        #region Old Unused Commented Code

        // Earning Rules Endpoints
        //public async Task<ApiResult<EarningRuleResponse>> GetCampaignEarningRule(GetEarningRuleRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.EarningRules}/{request.EarningRuleId}/{request.CampaignId}";
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<EarningRuleResponse>>(result);
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.Error($"{{Class: VoucherifyService, Method:GetCampaignEarningRule, Exception:{ex.StackTrace?.ToString()}}}");

        //        throw;
        //    }
        //}

        // Get Loyalties
        //public async Task<ApiResultSet<CampaignResponse>> GetLoyalties(GetLoyaltiesRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.Loyalties}?limit={request.PageSize}&page={request.PageNumber}";
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        var vouchers = JsonDocument.Parse(result).RootElement.GetProperty("campaigns").ToString();
        //        return JsonSerializer.Deserialize<ApiResultSet<CampaignResponse>>(vouchers);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Get Specific Loyalty
        //public async Task<ApiResult<CampaignResponse>> GetLoyalty(GetLoyaltyByCampaignNameOrIdRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Loyalties + request.CampaignIdOrName;
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<CampaignResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Get Promotions Tiers
        //public async Task<ApiResultSet<PromotionTierResponse>> GetPromotionTiers(GetPromotionTiersRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.Promotions}?pageNumber={request.PageNumber}&pageSize={request.PageSize}";
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResultSet<PromotionTierResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Get Promotion Tier By Id 
        //public async Task<ApiResult<PromotionTierResponse>> GetPromotionTierById(string promotionTierId)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Promotions + promotionTierId;
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<PromotionTierResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Get list of vouchers
        //public async Task<ApiResultSet<VoucherResponse>> GetVouchers(GetVoucherifyVouchersRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.Vouchers}?pageNumber={request.PageNumber}&pageSize={request.PageSize}";
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResultSet<VoucherResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}
        // Get specific voucher
        //public async Task<ApiResult<VoucherResponse>> GetVoucher(GetVoucherifyVoucherByCodeRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + request.VoucherCode;

        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<VoucherResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Delete Voucher
        //public async Task<bool> DeleteVoucher(string voucherId)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Vouchers + voucherId;
        //    try
        //    {
        //        var response = await client.DeleteAsync(targetUrl);
        //        return response.IsSuccessStatusCode;
        //    }
        //    catch (System.Exception)
        //    {
        //        return false;
        //    }
        //}
        // Validate Voucher
        //public async Task<ApiResult<VoucherValidationResponse>> ValidateVoucher(ValidateVoucherRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.ValidateVoucher;

        //    var requestJson = JsonSerializer.Serialize(request);
        //    try
        //    {
        //        var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<VoucherValidationResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Redeem voucher
        //public async Task<ApiResult<VoucherRedemptionResponse>> RedeemVoucher(RedeemVoucherRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.RedeemVoucher;

        //    var requestJson = JsonSerializer.Serialize(request);

        //    try
        //    {
        //        var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<VoucherRedemptionResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // Get rewards against loyalty
        //public async Task GetLoyaltyRewards(GetLoyaltyRewardsByCampaignNameOrIdRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Loyalties + request.CampaignNameOrId;

        //    var response = await client.GetAsync(targetUrl);
        //    if (response.IsSuccessStatusCode)
        //    {
        //        var result = await response.Content.ReadAsStringAsync();
        //        var rewardAssignment = JsonDocument.Parse(result).RootElement.GetProperty("data").ToString();
        //        return JsonSerializer.Deserialize<ApiResult<AddLoyaltyPointsResponse>>(rewardAssignment);
        //    }
        //    return null;
        //}

        // Get specific product
        //public async Task<PromotionTierResponse> GetProduct(GetVoucherifyProductRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Products + request.ProductNameOrId;
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);
        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<PromotionTierResponse>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // update customers record
        //public async Task<ApiResult<CustomerResponse>> UpdateCustomer(UpdateVoucherifyCustomerRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Customers;

        //    var requestJson = JsonSerializer.Serialize(request);
        //    try
        //    {
        //        var response = await client.PutAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));

        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        var result = await response.Content.ReadAsStringAsync();
        //        return JsonSerializer.Deserialize<ApiResult<CustomerResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // delelte customer record
        //public async Task<bool> DeleteCustomer(DeleteVoucherifyCustomerRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.Customers + request.SourceId;
        //    try
        //    {
        //        var response = await client.DeleteAsync(targetUrl);
        //        return response.IsSuccessStatusCode;
        //    }
        //    catch (System.Exception)
        //    {
        //        return false;
        //    }
        //}

        // Get list of customers
        //public async Task<ApiResultSet<CustomerResponse>> GetCustomers(GetVoucherifyCustomersRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();
        //    var targetUrl = $"{_voucherifyConfig.ApiEndpoint}{VoucherifyConstants.Endpoints.Customers}?pageNumber={request.PageNumber}&pageSize={request.PageSize}";
        //    try
        //    {
        //        var response = await client.GetAsync(targetUrl);

        //        var jsonResponse = await response.Content.ReadAsStringAsync();

        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        return JsonSerializer.Deserialize<ApiResultSet<CustomerResponse>>(jsonResponse);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}

        // get customer loyalty card
        //public async Task<ApiResult<CustomerLoyaltyCardResponse>> GetCustomerLoyaltyCard(GetVoucherifyCustomerLoyaltyCardRequest request)
        //{
        //    var client = _httpClientFactory.CreateClient();

        //    var targetUrl = _voucherifyConfig.ApiEndpoint + VoucherifyConstants.Endpoints.CustomersLoyaltyCard;
        //    var requestJson = JsonSerializer.Serialize(request);
        //    try
        //    {
        //        var response = await client.PostAsync(targetUrl, new StringContent(requestJson, Encoding.UTF8, "application/json"));
        //        var result = await response.Content.ReadAsStringAsync();

        //        //if (response.IsSuccessStatusCode)
        //        //{
        //        return JsonSerializer.Deserialize<ApiResult<CustomerLoyaltyCardResponse>>(result);
        //        //}
        //    }
        //    catch (System.Exception)
        //    {
        //        return null;
        //    }
        //}
        #endregion
    }
}
