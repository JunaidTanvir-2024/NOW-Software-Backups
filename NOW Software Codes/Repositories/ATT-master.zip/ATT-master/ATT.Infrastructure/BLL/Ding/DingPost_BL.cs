﻿using ATT.Infrastructure.DAL;
using ATT.Models.Configurations;
using ATT.Models.Contracts;
using ATT.Models.Contracts.Ding.Request;
using ATT.Models.Contracts.Ding.Response;
using ATT.Models.Database;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PhoneNumbers;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.Common;
using ATT.Models.Contracts.Common;
using ServiceProvider = ATT.Models.Contracts.Common.ServiceProvider;
using ATT.Infrastructure.BLL.Sms;
using ATT.Infrastructure.Helper;

namespace ATT.Infrastructure.BLL.Ding
{
    public class DingPost_BL : IDingPost_BL
    {
        private ILogger _logger;
        private DingConfig _dingConf;
        private IDingAuth_BL _dingAuth_BL;
        private ICommon_BL _common_BL;
        private IAttDb_DL _appDB;
        private readonly SmtpConfig SmtpConfig;
        private readonly HttpConfig httpConfig;
        private ISmsSendingService _smsSendingService;
        public DingPost_BL(IAttDb_DL _db, ILogger appLoggers, IOptions<DingConfig> dingConf, ICommon_BL common_BL, IDingAuth_BL dingAuth_BL, IOptions<SmtpConfig> smpt, IOptions<HttpConfig> http, ISmsSendingService smsSendingService)
        {
            _appDB = _db;
            _logger = appLoggers;
            _dingConf = dingConf.Value;
            _dingAuth_BL = dingAuth_BL;
            SmtpConfig = smpt.Value;
            _common_BL = common_BL;
            httpConfig = http.Value;
            _smsSendingService = smsSendingService;
        }


        public async Task<JsonOperatorProductResponse> DingFreeSwitchGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, string productCode, string productItemCode)
        {

            ToMsisdn = ToMsisdn.Trim();
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 3;

            try
            {
                var getProvidersubUrl = $"GetProviders?accountNumber={ToMsisdn}";
                var getProductsubUrl = $"GetProducts?accountNumber={ToMsisdn}";
                var tokenRequestStartTime = DateTime.Now;
                var authResponse = await _dingAuth_BL.getAuthToken(account);
                var tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_dingConf.ApiEndPoint);
                HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var GetProviderStartTime = DateTime.Now;
                var httpProviderResponse = await dingHttpClient.GetAsync(getProvidersubUrl);
                var GetProviderEndTime = DateTime.Now;

                if (httpProviderResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    if (_dingConf.JsonResponseLogging)
                    {
                        _logger.Information($"Ding DingFreeSwitchGetPhoneOperator Request {getProvidersubUrl} Response {returnData}");
                    }
                    var dingOperatorResponse = JsonConvert.DeserializeObject<DingOperatorResponse>(returnData);
                    if (dingOperatorResponse.Items.Count == 0)
                    {
                        if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                ErrorMessage = "Ding provider not found against destination. Response" + returnData,
                                Status = "Failure",
                                FromMsisdn = fromMSISDN,
                                ToMsisdn = ToMsisdn,
                                ProductCode = productCode,
                                ProductItemCode = productItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Get
                            });
                        }

                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "Ding provider not found against destination. Response" + returnData);
                        result.errorCode = 12;
                        result.status = "Failure";
                        result.message = "Ding provider not found against destination";
                        return result;
                    }
                    //Filter and get only minutes providers not data
                    if (dingOperatorResponse.Items.Count > 1)
                    {
                        dingOperatorResponse.Items = dingOperatorResponse.Items.Where(r => !r.Name.ToLower().Contains(" data ")).ToList();
                    }
                    getProductsubUrl += $"&providerCodes={dingOperatorResponse.Items[0].ProviderCode}";

                    var productJson = "{}";
                    var requestJson = "";
                    var responseJson = "";
                    var serviceProviderId = result.servcieproviderid;

                    var GetPRoductStartTime = DateTime.Now;
                    var
                        httpProductResponse = await dingHttpClient.GetAsync(getProductsubUrl);
                    var GetPRoductEndTime = DateTime.Now;
                    var dingProductDetailedResponse = new DingOperatorDetailedResponse();
                    if (httpProductResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        requestJson = getProductsubUrl; responseJson = returnData;
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding DingFreeSwitchGetPhoneOperator Request {getProductsubUrl} Response {returnData}");
                        }
                        dingProductDetailedResponse = JsonConvert.DeserializeObject<DingOperatorDetailedResponse>(returnData);
                    }
                    else
                    {

                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                        result.status = "Failure";
                        result.errorCode = 2;
                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                        _logger.Debug($"  DingFreeSwitchGetPhoneOperator  Failed  Source:DING API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                        return result;
                    }

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = dingOperatorResponse.Items[0].ProviderCode;
                    operatorDetails.name = dingOperatorResponse.Items[0].Name;
                    operatorDetails.country = dingOperatorResponse.Items[0].RegionCodes[0];
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = dingOperatorResponse.Items[0].LogoUrl;

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Trh(operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, dingOperatorResponse.Items[0].CountryIso, dingOperatorResponse.Items[0].ProviderCode.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds, GetProviderApiTime: (GetProviderEndTime - GetProviderStartTime).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  DingFreeSwitchGetPhoneOperator  Failed  Source:Ding API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Ding API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {

                        CustomerChargeValueForReplacement custChargeValue = await _appDB.GetCustomerChargeValueForReplacement(ToMsisdn, productItemCode);

                        //range
                        if (dingProductDetailedResponse.Items.Count == 1)
                        {
                            //                 bool chargeValueFound = false;

                            //                 /// Min
                            //                 AttProduct product = new AttProduct();
                            //                 product.product = dingProductDetailedResponse.Items[0].Minimum.ReceiveValue.ToString();
                            //                 product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                            //                 product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;

                            //                 if (custChargeValue != null && dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString() == custChargeValue.OrignalChargeValue)
                            //                 {
                            //                     product.itemPriceClientccy = custChargeValue.NewChargeValue;
                            //                     product.totalPriceClientccy = custChargeValue.NewChargeValue;
                            //                     chargeValueFound = true;
                            //                 }
                            //                 else
                            //                 {
                            //                     product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                            //                     product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                            //                 }
                            //                 product.transactionfeeClientccy = 0.ToString();
                            //                 products.Add(product);

                            //                 await _appDB.insertaccessDetails(dbResult.InsertId,
                            //        account,
                            //        product.receiverccy,
                            //        product.product,
                            //        dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString(),
                            //        dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString(),
                            //        //endrate.CustomerChargeValue.ToString(),
                            //        //endrate.CustomerChargeValue.ToString(),
                            //        0,
                            //        dingProductDetailedResponse.Items[0].SkuCode,
                            //        dingProductDetailedResponse.Items[0].UatNumber
                            //        );

                            //                 //// max 
                            //                 product = new AttProduct();
                            //                 product.product = dingProductDetailedResponse.Items[0].Maximum.ReceiveValue.ToString();
                            //                 product.receiverccy = dingProductDetailedResponse.Items[0].Maximum.ReceiveCurrencyIso;
                            //                 product.clientccy = dingProductDetailedResponse.Items[0].Maximum.SendCurrencyIso;

                            //                 if (custChargeValue != null && dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString() == custChargeValue.OrignalChargeValue)
                            //                 {
                            //                     product.itemPriceClientccy = custChargeValue.NewChargeValue;
                            //                     product.totalPriceClientccy = custChargeValue.NewChargeValue;
                            //                     chargeValueFound = true;
                            //                 }
                            //                 else
                            //                 {
                            //                     product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                            //                     product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                            //                 }

                            //                 product.transactionfeeClientccy = 0.ToString();
                            //                 products.Add(product);

                            //                 await _appDB.insertaccessDetails(dbResult.InsertId,
                            //account,
                            //product.receiverccy,
                            //product.product,
                            //dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString(),
                            //dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString(),
                            ////endrate.CustomerChargeValue.ToString(),
                            ////endrate.CustomerChargeValue.ToString(),
                            //0,
                            //dingProductDetailedResponse.Items[0].SkuCode,
                            //dingProductDetailedResponse.Items[0].UatNumber
                            //);
                            //Charge value not matched with min and max then check either between min and max and calculate
                            if (custChargeValue != null /*&& !chargeValueFound*/
                                && Convert.ToDecimal(custChargeValue.OrignalChargeValue) >= dingProductDetailedResponse.Items[0].Minimum.SendValue
                                && Convert.ToDecimal(custChargeValue.OrignalChargeValue) <= dingProductDetailedResponse.Items[0].Maximum.SendValue
                                )
                            {


                                AttProduct product = new AttProduct();
                                product.product = ((int)Math.Floor((dingProductDetailedResponse.Items[0].Minimum.ReceiveValue / dingProductDetailedResponse.Items[0].Minimum.SendValue) * Convert.ToDecimal(custChargeValue.OrignalChargeValue))).ToString();
                                product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                                product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                                product.itemPriceClientccy = custChargeValue.NewChargeValue.ToString();
                                product.totalPriceClientccy = custChargeValue.NewChargeValue.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                products.Add(product);


                                await _appDB.insertaccessDetails(dbResult.InsertId,
               account,
               product.receiverccy,
               product.product,
               custChargeValue.OrignalChargeValue.ToString(),
               custChargeValue.OrignalChargeValue.ToString(),
               custChargeValue.NewChargeValue.ToString(),
               //endrate.CustomerChargeValue.ToString(),
               //endrate.CustomerChargeValue.ToString(),
               0,
               dingProductDetailedResponse.Items[0].SkuCode,
               dingProductDetailedResponse.Items[0].UatNumber
               );
                            }
                            else
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValue)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0])}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValue), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0]));
                            }


                        }
                        else
                        {
                            //foreach (var item in dingProductDetailedResponse.Items.Take(_dingConf.ProductCount))
                            //{
                            var dingProduct = dingProductDetailedResponse.Items.FirstOrDefault(r => r.Minimum.SendValue == decimal.Parse(custChargeValue.OrignalChargeValue));
                            if (dingProduct != null)
                            {
                                AttProduct product = new AttProduct();
                                product.product = ((int)Math.Floor((dingProduct.Minimum.ReceiveValue / dingProduct.Minimum.SendValue) * Convert.ToDecimal(custChargeValue.OrignalChargeValue))).ToString();
                                product.receiverccy = dingProduct.Minimum.ReceiveCurrencyIso;
                                product.clientccy = dingProduct.Minimum.SendCurrencyIso;

                                product.itemPriceClientccy = custChargeValue.NewChargeValue;
                                product.totalPriceClientccy = custChargeValue.NewChargeValue;

                                //if (custChargeValue != null && item.Minimum.SendValue.ToString() == custChargeValue.OrignalChargeValue)
                                //{
                                //    product.itemPriceClientccy = custChargeValue.NewChargeValue;
                                //    product.totalPriceClientccy = custChargeValue.NewChargeValue;
                                //}
                                //else
                                //{
                                //    product.itemPriceClientccy = item.Minimum.SendValue.ToString();
                                //    product.totalPriceClientccy = item.Minimum.SendValue.ToString();
                                //}

                                product.transactionfeeClientccy = 0.ToString();
                                products.Add(product);

                                await _appDB.insertaccessDetails(dbResult.InsertId,
               account,
               product.receiverccy,
               product.product,
               dingProduct.Minimum.SendValue.ToString(),
               dingProduct.Minimum.SendValue.ToString(),
               custChargeValue.NewChargeValue,
               //endrate.CustomerChargeValue.ToString(),
               //endrate.CustomerChargeValue.ToString(),
               0,
               dingProduct.SkuCode,
               dingProduct.UatNumber
               );
                                //}

                            }
                            else
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValue)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items)}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValue), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items));
                            }

                        }


                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  DingFreeSwitchGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                    result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  DingFreeSwitchGetPhoneOperator  Failed  Source:Ding API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = result.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Ding.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);

                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingFreeSwitchGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";

                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }

        }

        public async Task<JsonOperatorProductResponse> DingTHAGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, bool useDbRates, int? cdsp_config_id, string productCode, string productItemCode)
        {
            ToMsisdn = ToMsisdn.Trim();
            JsonOperatorProductResponse result = new JsonOperatorProductResponse();
            result.servcieproviderid = 3;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"  \"GET /DingTHAGetPhoneOperator\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {ToMsisdn}, destinationMSISDN: {fromMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }

            //var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN);// Get the discount if any exists in db agains destination

            try
            {
                var getProvidersubUrl = $"GetProviders?accountNumber={ToMsisdn}";
                var getProductsubUrl = $"GetProducts?accountNumber={ToMsisdn}";
                var tokenRequestStartTime = DateTime.Now;
                var authResponse = await _dingAuth_BL.getAuthToken(account);
                var tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_dingConf.ApiEndPoint);
                HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var GetProviderStartTime = DateTime.Now;
                var httpProviderResponse = await dingHttpClient.GetAsync(getProvidersubUrl);
                var GetProviderEndTime = DateTime.Now;

                if (httpProviderResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    if (_dingConf.JsonResponseLogging)
                    {
                        _logger.Information($"Ding DingTHAGetPhoneOperator Request {getProvidersubUrl} Response {returnData}");
                    }
                    var dingOperatorResponse = JsonConvert.DeserializeObject<DingOperatorResponse>(returnData);
                    if (dingOperatorResponse.Items.Count == 0)
                    {
                        if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                ErrorMessage = "Ding provider not found against destination. Response" + returnData,
                                Status = "Failure",
                                FromMsisdn = fromMSISDN,
                                ToMsisdn = ToMsisdn,
                                ProductCode = productCode,
                                ProductItemCode = productItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Get
                            });
                        }

                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "Ding provider not found against destination. Response" + returnData);
                        result.errorCode = 12;
                        result.status = "Failure";
                        result.message = "Ding provider not found against destination";
                        return result;
                    }
                    //Filter and get only minutes providers not data
                    if (dingOperatorResponse.Items.Count > 1)
                    {
                        var neglectedProducts = new string[] { " data", "prepaid plans", " bundles" };
                        dingOperatorResponse.Items = dingOperatorResponse.Items.
                            Where(r => !neglectedProducts.Any(x => r.Name.ToLower().Trim().Contains(
                                x, StringComparison.InvariantCultureIgnoreCase))).ToList();
                    }
                    getProductsubUrl += $"&providerCodes={dingOperatorResponse.Items[0].ProviderCode}";
                    var productJson = "{}";
                    var requestJson = "";
                    var responseJson = "";
                    var serviceProviderId = result.servcieproviderid;
                    var GetPRoductStartTime = DateTime.Now;
                    var httpProductResponse = await dingHttpClient.GetAsync(getProductsubUrl);
                    var GetPRoductEndTime = DateTime.Now;
                    var dingProductDetailedResponse = new DingOperatorDetailedResponse();
                    if (httpProductResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        requestJson = getProductsubUrl; responseJson = returnData;
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding DingTHAGetPhoneOperator Request {getProductsubUrl} Response {returnData}");
                        }
                        dingProductDetailedResponse = JsonConvert.DeserializeObject<DingOperatorDetailedResponse>(returnData);
                    }
                    else
                    {

                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                        result.status = "Failure";
                        result.errorCode = 2;
                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                        _logger.Debug($"  DingTHAGetPhoneOperator  Failed  Source:DING API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                        return result;
                    }

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = dingOperatorResponse.Items[0].ProviderCode;
                    operatorDetails.name = dingOperatorResponse.Items[0].Name;
                    operatorDetails.country = dingOperatorResponse.Items[0].RegionCodes[0];
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = dingOperatorResponse.Items[0].LogoUrl;

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.insertTransactionGUID_Tha(operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, dingOperatorResponse.Items[0].CountryIso, dingOperatorResponse.Items[0].ProviderCode.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds, GetProviderApiTime: (GetProviderEndTime - GetProviderStartTime).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  DingTHAGetPhoneOperator  Failed  Source:Ding API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Ding API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        int from_country_code = 0;
                        PhoneNumberUtil phoneUtil = PhoneNumberUtil.GetInstance();
                        try
                        {
                            if (!fromMSISDN.StartsWith("+"))
                                fromMSISDN = "+" + fromMSISDN;
                            PhoneNumber numberProto = phoneUtil.Parse(fromMSISDN, "");
                            from_country_code = numberProto.CountryCode;
                        }
                        catch (NumberParseException e)
                        {

                        }
                        THACustomerChargeValuesForReplacement custChargeValues = new THACustomerChargeValuesForReplacement();
                        if (useDbRates && cdsp_config_id.HasValue)
                            custChargeValues = await _appDB.GetTHACustomerChargeValuesForReplacement(cdsp_config_id.Value, operatorDetails.id, result.servcieproviderid, from_country_code);

                        //range
                        if (dingProductDetailedResponse.Items.Count == 1)
                        {
                            if (useDbRates)
                            {
                                foreach (var custChargeValue in custChargeValues.chargeValues.Where(r => r.buying_price >= dingProductDetailedResponse.Items[0].Minimum.SendValue && r.buying_price <= dingProductDetailedResponse.Items[0].Maximum.SendValue))
                                {

                                    var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination

                                    AttProduct product = new AttProduct();
                                    product.product = ((int)Math.Floor((dingProductDetailedResponse.Items[0].Minimum.ReceiveValue / dingProductDetailedResponse.Items[0].Minimum.SendValue) * custChargeValue.buying_price)).ToString();
                                    product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                                    product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();

                                    product.discountPercentage = discountPercentage;
                                    product.orignalAmount = product.totalPriceClientccy;
                                    product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                    product.totalPriceClientccy = product.itemPriceClientccy;

                                    products.Add(product);

                                    await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                   account,
                   product.receiverccy,
                   product.product,
                   custChargeValue.buying_price.ToString(),
                   custChargeValue.buying_price.ToString(),
                   product.totalPriceClientccy,
                   //endrate.CustomerChargeValue.ToString(),
                   //endrate.CustomerChargeValue.ToString(),
                   0,
                   dingProductDetailedResponse.Items[0].SkuCode,
                   dingProductDetailedResponse.Items[0].UatNumber,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                   );

                                }

                                //If no products found
                                if (!custChargeValues.chargeValues.Any(r => r.buying_price >= dingProductDetailedResponse.Items[0].Minimum.SendValue && r.buying_price <= dingProductDetailedResponse.Items[0].Maximum.SendValue))
                                {
                                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                    {
                                        await _common_BL.SendEmail(new EmailTransactionModel()
                                        {
                                            ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0])}",
                                            Status = "Failure",
                                            FromMsisdn = fromMSISDN,
                                            ToMsisdn = ToMsisdn,
                                            ProductCode = productCode,
                                            ProductItemCode = productItemCode,
                                            ServiceProviderName = ServiceProvider.Ding.ToString(),
                                            TransationType = TransationType.Get
                                        });
                                    }
                                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0]));
                                }

                            }
                            else if (!useDbRates)
                            {

                                var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, dingProductDetailedResponse.Items[0].Minimum.SendValue);// Get the discount if any exists in db agains destination

                                /// Min
                                AttProduct product = new AttProduct();
                                product.product = dingProductDetailedResponse.Items[0].Minimum.ReceiveValue.ToString();
                                product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                                product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                                product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                                product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                                product.transactionfeeClientccy = 0.ToString();


                                product.discountPercentage = discountPercentage;
                                product.orignalAmount = product.totalPriceClientccy;
                                product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                product.totalPriceClientccy = product.itemPriceClientccy;

                                products.Add(product);

                                await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                       account,
                       product.receiverccy,
                       product.product,
                       dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString(),
                       dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString(),
                       dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString(),
                       //endrate.CustomerChargeValue.ToString(),
                       //endrate.CustomerChargeValue.ToString(),
                       0,
                       dingProductDetailedResponse.Items[0].SkuCode,
                       dingProductDetailedResponse.Items[0].UatNumber,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                       );

                                var discountPercentage2 = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, dingProductDetailedResponse.Items[0].Maximum.SendValue);// Get the discount if any exists in db agains destination

                                /// MAX
                                product = new AttProduct();
                                product.product = dingProductDetailedResponse.Items[0].Maximum.ReceiveValue.ToString();
                                product.receiverccy = dingProductDetailedResponse.Items[0].Maximum.ReceiveCurrencyIso;
                                product.clientccy = dingProductDetailedResponse.Items[0].Maximum.SendCurrencyIso;
                                product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                                product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                                product.transactionfeeClientccy = 0.ToString();

                                product.discountPercentage = discountPercentage2;
                                product.orignalAmount = product.totalPriceClientccy;
                                product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                product.totalPriceClientccy = product.itemPriceClientccy;

                                products.Add(product);

                                await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                       account,
                       product.receiverccy,
                       product.product,
                       dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString(),
                       dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString(),
                       dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString(),
                       //endrate.CustomerChargeValue.ToString(),
                       //endrate.CustomerChargeValue.ToString(),
                       0,
                       dingProductDetailedResponse.Items[0].SkuCode,
                       dingProductDetailedResponse.Items[0].UatNumber,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                       );



                            }
                        }
                        else
                        {

                            if (useDbRates)
                            {
                                bool ProductMatched = false;
                                foreach (var custChargeValue in custChargeValues.chargeValues)
                                {
                                    var dingProduct = dingProductDetailedResponse.Items.FirstOrDefault(r => r.Minimum.SendValue == custChargeValue.buying_price);
                                    if (dingProduct != null)
                                    {

                                        var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, custChargeValue.selling_price);// Get the discount if any exists in db agains destination

                                        AttProduct product = new AttProduct();
                                        product.product = dingProduct.Minimum.ReceiveValue.ToString();
                                        product.receiverccy = dingProduct.Minimum.ReceiveCurrencyIso;
                                        product.clientccy = dingProduct.Minimum.SendCurrencyIso;
                                        product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                        product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                        product.transactionfeeClientccy = 0.ToString();

                                        product.discountPercentage = discountPercentage;
                                        product.orignalAmount = product.totalPriceClientccy;
                                        product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                        product.totalPriceClientccy = product.itemPriceClientccy;

                                        products.Add(product);

                                        await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                       account,
                       product.receiverccy,
                       product.product,
                       dingProduct.Minimum.SendValue.ToString(),
                       dingProduct.Minimum.SendValue.ToString(),
                        product.totalPriceClientccy,
                       //endrate.CustomerChargeValue.ToString(),
                       //endrate.CustomerChargeValue.ToString(),
                       0,
                       dingProduct.SkuCode,
                       dingProduct.UatNumber,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                       );
                                        ProductMatched = true;
                                    }

                                }
                                //If no products found
                                if (!ProductMatched)
                                {
                                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                    {
                                        await _common_BL.SendEmail(new EmailTransactionModel()
                                        {
                                            ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items)}",
                                            Status = "Failure",
                                            FromMsisdn = fromMSISDN,
                                            ToMsisdn = ToMsisdn,
                                            ProductCode = productCode,
                                            ProductItemCode = productItemCode,
                                            ServiceProviderName = ServiceProvider.Ding.ToString(),
                                            TransationType = TransationType.Get
                                        });
                                    }
                                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items));
                                }
                            }
                            else
                            {

                                foreach (var item in dingProductDetailedResponse.Items.Take(_dingConf.ProductCount))
                                {

                                    var discountPercentage = await _common_BL.GetDiscountSettings(productCode, productItemCode, ToMsisdn, fromMSISDN, item.Minimum.SendValue);// Get the discount if any exists in db agains destination

                                    AttProduct product = new AttProduct();
                                    product.product = item.Minimum.ReceiveValue.ToString();
                                    product.receiverccy = item.Minimum.ReceiveCurrencyIso;
                                    product.clientccy = item.Minimum.SendCurrencyIso;
                                    product.itemPriceClientccy = item.Minimum.SendValue.ToString();
                                    product.totalPriceClientccy = item.Minimum.SendValue.ToString();
                                    product.transactionfeeClientccy = 0.ToString();


                                    product.discountPercentage = discountPercentage;
                                    product.orignalAmount = product.totalPriceClientccy;
                                    product.itemPriceClientccy = Math.Round((Convert.ToDecimal(product.orignalAmount) - (Convert.ToDecimal(product.orignalAmount) * product.discountPercentage / 100)), 2).ToString();
                                    product.totalPriceClientccy = product.itemPriceClientccy;

                                    products.Add(product);

                                    await _appDB.insertaccessDetailsWithDiscount(dbResult.InsertId,
                   account,
                   product.receiverccy,
                   product.product,
                   item.Minimum.SendValue.ToString(),
                   item.Minimum.SendValue.ToString(),
                    item.Minimum.SendValue.ToString(),
                   //endrate.CustomerChargeValue.ToString(),
                   //endrate.CustomerChargeValue.ToString(),
                   0,
                   item.SkuCode,
                   item.UatNumber,
                   discountPercentage: product.discountPercentage,
                   orignalAmount: product.orignalAmount
                   );
                                }

                            }

                        }


                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  DingTHAGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                    result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  DingTHAGetPhoneOperator  Failed  Source:Ding API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Ding.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingTHAGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }

        }

        public async Task<JsonATTCRMOperatorProductResponse> DingATTCRMGetPhoneOperator(string account, string ToMsisdn)
        {
            ToMsisdn = ToMsisdn.Trim();
            JsonATTCRMOperatorProductResponse result = new JsonATTCRMOperatorProductResponse();

            try
            {
                var getProvidersubUrl = $"GetProviders?accountNumber={ToMsisdn}";
                var getProductsubUrl = $"GetProducts?accountNumber={ToMsisdn}";
                var authResponse = await _dingAuth_BL.getAuthToken(account);
                var baseAddress = new Uri(_dingConf.ApiEndPoint);
                HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var httpProviderResponse = await dingHttpClient.GetAsync(getProvidersubUrl);

                if (httpProviderResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    if (_dingConf.JsonResponseLogging)
                    {
                        _logger.Information($"Ding DingATTCRMGetPhoneOperator Request {getProvidersubUrl} Response {returnData}");
                    }
                    var dingOperatorResponse = JsonConvert.DeserializeObject<DingOperatorResponse>(returnData);
                    //Filter and get only minutes providers not data
                    if (dingOperatorResponse.Items.Count > 1)
                    {
                        dingOperatorResponse.Items = dingOperatorResponse.Items.Where(r => !r.Name.ToLower().Contains(" data ")).ToList();
                    }
                    getProductsubUrl += $"&providerCodes={dingOperatorResponse.Items[0].ProviderCode}";
                    var productJson = "{}";
                    var requestJson = "";
                    var responseJson = "";
                    var serviceProviderId = 3;
                    var httpProductResponse = await dingHttpClient.GetAsync(getProductsubUrl);
                    var dingProductDetailedResponse = new DingOperatorDetailedResponse();
                    if (httpProductResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        requestJson = getProductsubUrl; responseJson = returnData;
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding DingATTCRMGetPhoneOperator Request {getProductsubUrl} Response {returnData}");
                        }
                        dingProductDetailedResponse = JsonConvert.DeserializeObject<DingOperatorDetailedResponse>(returnData);
                    }
                    else
                    {

                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                        result.status = "Failure";
                        result.errorCode = 2;

                        _logger.Debug($"  DingATTCRMGetPhoneOperator  Failed  Source:DING API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                        return result;
                    }

                    ATTCRMPayLoad payload = new ATTCRMPayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttCRMOperator> operators = new List<AttCRMOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttCRMOperator operatorDetails = new AttCRMOperator();

                    //operatorDetails.id = dingOperatorResponse.Items[0].ProviderCode;
                    operatorDetails.name = dingOperatorResponse.Items[0].Name;
                    operatorDetails.country = dingOperatorResponse.Items[0].RegionCodes[0];

                    //range
                    if (dingProductDetailedResponse.Items.Count == 1)
                    {

                        result.isRange = true;
                        /// Min
                        AttProduct product = new AttProduct();
                        product.product = dingProductDetailedResponse.Items[0].Minimum.ReceiveValue.ToString();
                        product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                        product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                        product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                        product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Minimum.SendValue.ToString();
                        product.transactionfeeClientccy = 0.ToString();
                        products.Add(product);

                        /// MAX
                        product = new AttProduct();
                        product.product = dingProductDetailedResponse.Items[0].Maximum.ReceiveValue.ToString();
                        product.receiverccy = dingProductDetailedResponse.Items[0].Maximum.ReceiveCurrencyIso;
                        product.clientccy = dingProductDetailedResponse.Items[0].Maximum.SendCurrencyIso;
                        product.itemPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                        product.totalPriceClientccy = dingProductDetailedResponse.Items[0].Maximum.SendValue.ToString();
                        product.transactionfeeClientccy = 0.ToString();
                        products.Add(product);

                    }
                    else
                    {
                        result.isRange = false;
                        foreach (var item in dingProductDetailedResponse.Items.Take(_dingConf.ProductCount))
                        {
                            AttProduct product = new AttProduct();
                            product.product = item.Minimum.ReceiveValue.ToString();
                            product.receiverccy = item.Minimum.ReceiveCurrencyIso;
                            product.clientccy = item.Minimum.SendCurrencyIso;
                            product.itemPriceClientccy = item.Minimum.SendValue.ToString();
                            product.totalPriceClientccy = item.Minimum.SendValue.ToString();
                            product.transactionfeeClientccy = 0.ToString();
                            products.Add(product);

                        }
                    }

                    operatorDetails.products = products;
                    operators.Add(operatorDetails);
                    payload.operators = operators;
                    result.ATTCRMpayload = payload;
                    _logger.Information($"  DingATTCRMGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                    return result;
                }
                else
                {

                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                    result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  DingATTCRMGetPhoneOperator  Failed  Source:Ding API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingATTCRMGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }

        }
        public async Task<object> DingFreeSwitchTopUp(ExecuteData request)
        {
            try
            {
                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /DingFreeSwitchTopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }

                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /DingFreeSwitchTopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }


                try
                {

                    var subUrl = $"SendTransfer";
                    DingTopUpRequest topUpRequest = new DingTopUpRequest
                    {

                        sendValue = decimal.Parse(guidReferneceRecord.fromAmount),
                        distributorRef = nowtelTransactionReference,
                        accountNumber = _dingConf.SimulationMode ? guidReferneceRecord.UatNumber : guidReferneceRecord.tomsisdn,
                        sendCurrencyIso = guidReferneceRecord.fromCurrency.ToUpper(),
                        skuCode = guidReferneceRecord.skuCode,
                        ValidateOnly = false,
                        BillRef = nowtelTransactionReference

                    };
                    var json = JsonConvert.SerializeObject(topUpRequest);
                    var tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _dingAuth_BL.getAuthToken(guidReferneceRecord.account);
                    var tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_dingConf.ApiEndPoint);
                    HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.ding.topups-v1+json");
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                    string returnData = "";
                    var @TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await dingHttpClient.PostAsync(subUrl, httpContent);
                    var @TopUpApiEndTime = DateTime.Now;
                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding DingFreeSwitchTopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<DingTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v3(
                               DateTime.Now.ToString(),
                               guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                               guidReferneceRecord.selling_price,         // Customer Charge Value
                               response.transferRecord.price.SendValue - response.transferRecord.CommissionApplied,  // Actual Charge Value
                               response.transferRecord.price.ReceiveValue,
                               response.transferRecord.price.SendCurrencyIso,
                               response.transferRecord.price.ReceiveCurrencyIso,
                               guidReferneceRecord.destination_country,
                               "Success",
                               "",
                              guidReferneceRecord.operatorCode,
                               product,
                              guidReferneceRecord.operatorName,
                               null,
                               response.transferRecord.transferId.TransferRef,
                               fromMSISDN,
                               guidReferneceRecord.tomsisdn,
                               3,
                               messageToRecipient,
                               guidReferneceRecord.productCode,
                               guidReferneceRecord.ProductItemCode,
                               nowtelTransactionReference,
                               json,
                               returnData,
                               GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                               TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                               );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  DingFreeSwitchTopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  DingFreeSwitchTopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transferRecord.transferId.TransferRef}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price, // Customer Charge Value
                            currency = response.transferRecord.price.SendCurrencyIso,
                            reference = response.transferRecord.transferId.TransferRef
                        };

                        if (_dingConf.SendSmsToSender)
                        {
                            var smsToSend = _dingConf.smsTemplate
                                .Replace("#currency#", response.transferRecord.price.ReceiveCurrencyIso)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transferRecord.transferId.TransferRef);
                            _common_BL.SendTwilioSms(request.fromMSISDN, smsToSend);
                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh(
                           DateTime.Now.ToString(),
                            guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           "",
                           "",
                           "Failure",
                            "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                           guidReferneceRecord.operatorCode,
                           product,
                           "",
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           3,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                                                          json,
                                returnData,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Ding.ToString(),
                                    TransationType = TransationType.Execute
                                });
                            }

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  DingFreeSwitchTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  DingFreeSwitchTopUp  Failed  Source:Ding API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction_Trh(
                        DateTime.Now.ToString(),
                        guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                         guidReferneceRecord.operatorCode,
                        product,
                        "",
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        3,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        "",
                        ""
                        );

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }

                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  DingFreeSwitchTopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  DingFreeSwitchTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingFreeSwitchTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }
        public async Task<object> DingTHATopUp(ExecuteData request)
        {
            try
            {
                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                APIAccessGUID_Trh guidReferneceRecord = await _appDB.getTransactionGUIDRecord_Trh(nowtelTransactionReference, product);

                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /DingTHATopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /DingTHATopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                try
                {

                    var subUrl = $"SendTransfer";
                    DingTopUpRequest topUpRequest = new DingTopUpRequest
                    {

                        sendValue = decimal.Parse(guidReferneceRecord.fromAmount),
                        distributorRef = nowtelTransactionReference,
                        accountNumber = _dingConf.SimulationMode ? guidReferneceRecord.UatNumber : guidReferneceRecord.tomsisdn,
                        sendCurrencyIso = guidReferneceRecord.fromCurrency.ToUpper(),
                        skuCode = guidReferneceRecord.skuCode,
                        ValidateOnly = false,
                        BillRef = nowtelTransactionReference

                    };
                    var json = JsonConvert.SerializeObject(topUpRequest);
                    var tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _dingAuth_BL.getAuthToken(guidReferneceRecord.account);
                    var tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_dingConf.ApiEndPoint);
                    HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.ding.topups-v1+json");
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                    string returnData = "";

                    var @TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await dingHttpClient.PostAsync(subUrl, httpContent);
                    var @TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding DingTHATopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<DingTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh_v4(
                                DateTime.Now.ToString(),
                                guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                                guidReferneceRecord.selling_price,         // Customer Charge Value
                                response.transferRecord.price.SendValue - response.transferRecord.CommissionApplied,  // Actual Charge Value
                                response.transferRecord.price.ReceiveValue,
                                response.transferRecord.price.SendCurrencyIso,
                                response.transferRecord.price.ReceiveCurrencyIso,
                                guidReferneceRecord.destination_country,
                                "Success",
                                "",
                               guidReferneceRecord.operatorCode,
                                product,
                               guidReferneceRecord.operatorName,
                                null,
                                response.transferRecord.transferId.TransferRef,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                3,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                json,
                                returnData,
                                 guidReferneceRecord.discountPercentage.ToString(),
                                guidReferneceRecord.orignalAmount,
                                GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                                );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  DingTHATopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  DingTHATopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transferRecord.transferId.TransferRef}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price, // Customer Charge Value
                            currency = response.transferRecord.price.SendCurrencyIso,
                            reference = response.transferRecord.transferId.TransferRef
                        };

                        if (_dingConf.SendSmsToSender)
                        {
                            // Sms to Source Msisdn
                            var smsToSend = _dingConf.smsTemplate
                                .Replace("#currency#", response.transferRecord.price.ReceiveCurrencyIso)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transferRecord.transferId.TransferRef);
                            _common_BL.SendTwilioSms(request.fromMSISDN, smsToSend, guidReferneceRecord.productCode);


                            // Option Message Sms to Destination Msisdn
                            //var smsBody = request.messageToRecipient;
                            //_common_BL.SendTwilioSms(guidReferneceRecord.tomsisdn, smsBody, guidReferneceRecord.productCode, true);                           
                        }

                        try
                        {
                            var destination = HelperService.GetCountryISOCode(guidReferneceRecord.tomsisdn);
                            if (destination != null && (destination.Equals("GB") || destination.Equals("US")))
                            {
                                //this method will send the top up details to the recipeints
                                await _smsSendingService.SendTopupSmsDetailsToRecipients(
                                    new TopupSmsDetailsModel
                                    {
                                        FromMsisdn = guidReferneceRecord.frommsisdn,
                                        ToMsisdn = guidReferneceRecord.tomsisdn,
                                        TransactionId = response.transferRecord.transferId.TransferRef,
                                        ReceiptText = response.transferRecord.ReceiptText,
                                        PinCode = response.transferRecord.ReceiptParams.Pin,
                                        AmountTransfered = guidReferneceRecord.product,
                                    });
                            }                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"  DingTHATopUp-CustomSms  Database error occured while registering the Failed transaction=> Response: {JsonConvert.SerializeObject(response)}   Exception {ex.ToString()} ");
                        }

                        return result;

                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        try
                        {

                            await _appDB.insertAirTimeTransferTransaction_Trh(
                           DateTime.Now.ToString(),
                            guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           "",
                           "",
                           "Failure",
                            "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                           guidReferneceRecord.operatorCode,
                           product,
                           "",
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           3,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                                returnData,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                           );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Ding.ToString(),
                                    TransationType = TransationType.Execute

                                });
                            }

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  DingTHATopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  DingTHATopUp  Failed  Source:Ding API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.insertAirTimeTransferTransaction_Trh(
                        DateTime.Now.ToString(),
                        guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                         guidReferneceRecord.operatorCode,
                        product,
                        "",
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        3,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        "",
                        "");

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }

                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  DingTHATopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  DingTHATopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingTHATopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }

        public async Task<object> Com_ATT_DingTopUp(ExecuteData request, CRM_ATT_APIAccessGUID guidReferneceRecord)
        {
            try
            {
                string nowtelTransactionReference = request.nowtelTransactionReference;
                string product = request.product;
                string messageToRecipient = request.messageToRecipient;
                string fromMSISDN = request.fromMSISDN;

                if (guidReferneceRecord == null)
                {
                    _logger.Debug($"   /Com_ATT_DingTopUp  Failed   Source:General    Pasameters:     nowtelTransactionReference-{nowtelTransactionReference}     amount-{product}       Message:nowtelTransactionReference transaction reference could not be found in database");
                    var result = new { errorCode = 2, status = "Failure", message = "nowtelTransactionReference transaction reference could not be found in database" };
                    return result;
                }
                try
                {


                    var custValidate = await _appDB.ValidateNowtelCustomer(guidReferneceRecord.frommsisdn, guidReferneceRecord.tomsisdn, request.nowtelTransactionReference.Remove(0, 14), request.product, Convert.ToDecimal(guidReferneceRecord.fromAmount), guidReferneceRecord.productCode, guidReferneceRecord.ProductItemCode);

                    if (custValidate.isAllowed != 1)
                    {
                        var result = new { errorCode = 3, status = "Failure", message = "Your fund transfer failed!!," + custValidate.Message };
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"  \"GET /Com_ATT_DingTopUp\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {guidReferneceRecord.frommsisdn}, destinationMSISDN: {fromMSISDN}, currency:{guidReferneceRecord.account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                    var result = new { errorCode = 2, status = "Failure", message = "General API Access Error: " + ex.Message };
                    return result;
                }
                try
                {

                    var subUrl = $"SendTransfer";
                    DingTopUpRequest topUpRequest = new DingTopUpRequest
                    {

                        sendValue = decimal.Parse(guidReferneceRecord.fromAmount),
                        distributorRef = nowtelTransactionReference,
                        accountNumber = _dingConf.SimulationMode ? guidReferneceRecord.UatNumber : guidReferneceRecord.tomsisdn,
                        sendCurrencyIso = guidReferneceRecord.fromCurrency.ToUpper(),
                        skuCode = guidReferneceRecord.skuCode,
                        ValidateOnly = false,
                        BillRef = nowtelTransactionReference

                    };
                    var json = JsonConvert.SerializeObject(topUpRequest);
                    var tokenRequestStartTime = DateTime.Now;
                    var authResponse = await _dingAuth_BL.getAuthToken(guidReferneceRecord.account);
                    var tokenRequestEndTime = DateTime.Now;
                    var baseAddress = new Uri(_dingConf.ApiEndPoint);
                    HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/com.ding.topups-v1+json");
                    dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");

                    var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                    string returnData = "";

                    var @TopUpApiStartTime = DateTime.Now;
                    var httpResponse = await dingHttpClient.PostAsync(subUrl, httpContent);
                    var @TopUpApiEndTime = DateTime.Now;

                    if (httpResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding Com_ATT_DingTopUp Request {json} Response {returnData}");
                        }
                        var response = JsonConvert.DeserializeObject<DingTopUpResponse>(returnData);

                        //Successful transaction
                        try
                        {

                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                                guidReferneceRecord.ProductId,
                                DateTime.Now.ToString(),
                                guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                                guidReferneceRecord.selling_price,         // Customer Charge Value
                                response.transferRecord.price.SendValue - response.transferRecord.CommissionApplied,  // Actual Charge Value
                                response.transferRecord.price.ReceiveValue,
                                response.transferRecord.price.SendCurrencyIso,
                                response.transferRecord.price.ReceiveCurrencyIso,
                                guidReferneceRecord.destination_country,
                                "Success",
                                "",
                               guidReferneceRecord.operatorCode,
                                product,
                               guidReferneceRecord.operatorName,
                                null,
                                response.transferRecord.transferId.TransferRef,
                                fromMSISDN,
                                guidReferneceRecord.tomsisdn,
                                3,
                                messageToRecipient,
                                guidReferneceRecord.productCode,
                                guidReferneceRecord.ProductItemCode,
                                nowtelTransactionReference,
                                json,
                                returnData,
                                GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds,
                                crmamount: guidReferneceRecord.crmAmount
                                );

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  Com_ATT_DingTopUp  Database error occured while registering the successful transaction    Exception {ex.ToString()} ");
                        }

                        _logger.Information($"  Com_ATT_DingTopUp   Success   Pasameters:    tomsisdn-{guidReferneceRecord.tomsisdn}   amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-{response.transferRecord.transferId.TransferRef}   ");
                        var result = new
                        {
                            errorCode = 0,
                            status = "Success",
                            message = "Your funds have been sent",
                            amount = guidReferneceRecord.selling_price, // Customer Charge Value
                            currency = response.transferRecord.price.SendCurrencyIso,
                            reference = response.transferRecord.transferId.TransferRef
                        };

                        if (_dingConf.SendSmsToSender)
                        {
                            var smsToSend = _dingConf.smsTemplate
                                .Replace("#currency#", response.transferRecord.price.ReceiveCurrencyIso)
                                .Replace("#amount#", guidReferneceRecord.toAmount)
                                .Replace("#to#", guidReferneceRecord.tomsisdn)
                                .Replace("#TransRef#", response.transferRecord.transferId.TransferRef);
                            _common_BL.SendTwilioSms(request.fromMSISDN, smsToSend, guidReferneceRecord.productCode);


                            // Option Message Sms to Destination Msisdn
                            //var smsBody = request.messageToRecipient;
                            //await SendTwilioSms(guidReferneceRecord.tomsisdn, smsBody, guidReferneceRecord.productCode, true);
                        }
                        return result;
                    }
                    else
                    {
                        returnData = await httpResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        try
                        {

                            await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                                guidReferneceRecord.ProductId,
                           DateTime.Now.ToString(),
                            guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                           guidReferneceRecord.selling_price,         // Customer Charge Value
                           -1,
                           decimal.Parse(product),
                           guidReferneceRecord.account,
                           "",
                           "",
                           "Failure",
                           "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                           guidReferneceRecord.operatorCode,
                           product,
                           "",
                           null,
                           "",
                           fromMSISDN,
                           guidReferneceRecord.tomsisdn,
                           3,
                           messageToRecipient,
                           guidReferneceRecord.productCode,
                           guidReferneceRecord.ProductItemCode,
                           nowtelTransactionReference,
                           json,
                                returnData,
                                TopUpApiTime: (TopUpApiEndTime - TopUpApiStartTime).TotalMilliseconds
                           );

                            if (SmtpConfig.sendErrorExecuteTransactionEmail && !SmtpConfig.sendExecuteTransactionExceptionErrorsOnly)
                            {
                                await _common_BL.SendEmail(new EmailTransactionModel()
                                {
                                    accessGUID = nowtelTransactionReference,
                                    DestinationCountry = guidReferneceRecord.destination_country,
                                    ErrorMessage = "HttpStatusCode:" + httpResponse.StatusCode.ToString() + " Error:" + errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context,
                                    Status = "Failure",
                                    FromMsisdn = guidReferneceRecord.frommsisdn,
                                    ToMsisdn = guidReferneceRecord.tomsisdn,
                                    OperatorId = guidReferneceRecord.operatorCode,
                                    OperatorName = guidReferneceRecord.operatorName,
                                    ProductCode = guidReferneceRecord.productCode,
                                    ProductItemCode = guidReferneceRecord.ProductItemCode,
                                    ServiceProviderName = ServiceProvider.Ding.ToString(),
                                    TransationType = TransationType.Execute

                                });
                            }

                        }
                        catch (Exception ex)
                        {
                            _logger.Debug($"  Com_ATT_DingTopUp  Database error occured while registering the Failed transaction    Exception {ex.ToString()} ");
                        }


                        _logger.Debug($"  Com_ATT_DingTopUp  Failed  Source:Ding API  Pasameters:     tomsisdn-{guidReferneceRecord.tomsisdn}     amount-{product}    userCurrency-{guidReferneceRecord.account}   TransferToReference-N/A          Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                        var result = new
                        {
                            errorCode = 2,
                            status = "Failure",
                            message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context
                        };

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        await _appDB.CRM_ATT_insertAirTimeTransferTransaction(
                               guidReferneceRecord.ProductId,
                       DateTime.Now.ToString(),
                        guidReferneceRecord.account.ToLower() == "eur" ? _dingConf.EUR_client_id : _dingConf.GBP_client_id, // Username
                        guidReferneceRecord.selling_price,         // Customer Charge Value
                        -1,
                        decimal.Parse(product),
                        guidReferneceRecord.account,
                        "",
                        "",
                        "FailureException",
                        ex.Message,
                         guidReferneceRecord.operatorCode,
                        product,
                        "",
                        null,
                        "",
                        fromMSISDN,
                        guidReferneceRecord.tomsisdn,
                        3,
                        messageToRecipient,
                        guidReferneceRecord.productCode,
                        guidReferneceRecord.ProductItemCode,
                        nowtelTransactionReference,
                        "",
                        "");

                        if (SmtpConfig.sendErrorExecuteTransactionEmail)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                accessGUID = nowtelTransactionReference,
                                DestinationCountry = guidReferneceRecord.destination_country,
                                ErrorMessage = ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message,
                                Status = "FailureException",
                                FromMsisdn = guidReferneceRecord.frommsisdn,
                                ToMsisdn = guidReferneceRecord.tomsisdn,
                                OperatorId = guidReferneceRecord.operatorCode,
                                OperatorName = guidReferneceRecord.operatorName,
                                ProductCode = guidReferneceRecord.productCode,
                                ProductItemCode = guidReferneceRecord.ProductItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Execute

                            });
                        }

                    }
                    catch (Exception dbException)
                    {
                        _logger.Debug($"  Com_ATT_DingTopUp  Database error occured while registering the Failed transaction    Exception {dbException.Message} ");
                    }
                    _logger.Debug($"  Com_ATT_DingTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                    return errorResult;
                }
            }
            catch (Exception ex)
            {
                _logger.Debug($"  Com_ATT_DingTopUp  Failed  Source:General  Parameters-  currency:    Message:{ex.Message}");
                var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error. Check log for details. Exception: " + ex.Message };
                return errorResult;
            }

        }


        //private async Task SendTwilioSms(string to, string textMessage)
        //{
        //    bool isRestrictedCountry = false;
        //    Twilio.Types.PhoneNumber from = "888 8";

        //    foreach (var item in TwilioConfig.TwilioFromNumberCountries)
        //    {
        //        if (to.StartsWith(item))
        //        {
        //            isRestrictedCountry = true;
        //            from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
        //        }
        //    }

        //    if (!to.StartsWith("+"))
        //    {
        //        to = "+" + to;
        //    }

        //    string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";

        //    try
        //    {
        //        TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
        //        var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : "TransfHome", to: new Twilio.Types.PhoneNumber(to));
        //        return;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error($"DingPost - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
        //        return;
        //    }
        //}

        //private async Task SendTwilioSms(string to, string textMessage, string productCode = null)
        //{
        //    bool isRestrictedCountry = false;
        //    Twilio.Types.PhoneNumber from = "888 8";

        //    foreach (var item in TwilioConfig.TwilioFromNumberCountries)
        //    {
        //        if (to.StartsWith(item))
        //        {
        //            isRestrictedCountry = true;
        //            from = new Twilio.Types.PhoneNumber(TwilioConfig.TwilioNumber);
        //        }
        //    }

        //    if (!to.StartsWith("+"))
        //    {
        //        to = "+" + to;
        //    }

        //    string requestParameters = $"from : {from}, to: {to}, textMessage: {textMessage}";

        //    string fromText = "TransHome";

        //    if (!string.IsNullOrWhiteSpace(productCode))
        //    {
        //        fromText = productCode == "TRH" ? "TransHome" : "TalkHome";
        //        textMessage = productCode == "TRH" ? textMessage : textMessage.Replace("TransferHome", "Talk Home");
        //    }

        //    try
        //    {
        //        TwilioClient.Init(TwilioConfig.Sid, TwilioConfig.AuthToken);
        //        var message = await MessageResource.CreateAsync(body: textMessage, from: isRestrictedCountry ? from : fromText, to: new Twilio.Types.PhoneNumber(to));
        //        return;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error($"DingPost_BL - Method: SendTwilioSms, Parameters --> {requestParameters}, Exception: {ex.Message}");
        //        return;
        //    }
        //}

        public async Task<JsonPromoResponse> DingGetPromotions(string fromMSISDN)
        {

            JsonPromoResponse result = new JsonPromoResponse();
            result.servcieproviderid = 3;

            try
            {
                List<THADestinationDingProvider> destinationDingProviders = await _appDB.THAGetDingDestinationsOperators(fromMSISDN);

                var providersList = string.Empty;
                foreach (var provider in destinationDingProviders)
                {
                    providersList += $"providerCodes={provider.ding_operator_code}&";
                }

                if (providersList.Length > 0)
                {
                    providersList = "?" + providersList;
                    providersList = providersList.Substring(0, providersList.Length - 1);
                }


                var getPromitionssubUrl = $"GetPromotions{providersList}";
                var getPromitionsDescriptionsubUrl = $"GetPromotionDescriptions?languageCodes=en";
                var getCountriesSubUrl = "GetCountries";
                var getProvidersSubUrl = "GetProviders";

                var tokenRequestStartTime = DateTime.Now;
                var authResponse = await _dingAuth_BL.getAuthToken("eur");
                var tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_dingConf.ApiEndPoint);
                HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var httpPRomotionResponse = await dingHttpClient.GetAsync(getPromitionssubUrl);

                if (httpPRomotionResponse.StatusCode == HttpStatusCode.OK)
                {

                    returnData = await httpPRomotionResponse.Content.ReadAsStringAsync();
                    var dingPromotionsResponse = JsonConvert.DeserializeObject<DingPromoResponse>(returnData);
                    //dingPromotionsResponse.items = dingPromotionsResponse.items.Where(s => DateTime.UtcNow >= s.StartUtc && DateTime.UtcNow <= s.EndUtc).ToList();
                    var httpPromoDesctiptionResponse = await dingHttpClient.GetAsync(getPromitionsDescriptionsubUrl);
                    if (httpPromoDesctiptionResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpPromoDesctiptionResponse.Content.ReadAsStringAsync();
                        var dingPromotionsDescriptionResponse = JsonConvert.DeserializeObject<DingPromoDescriptionResponse>(returnData);

                        var httpCountriesResponse = await dingHttpClient.GetAsync(getCountriesSubUrl);
                        var dingCountriesResponse = new DingCountries();
                        if (httpCountriesResponse.StatusCode == HttpStatusCode.OK)
                        {
                            returnData = await httpCountriesResponse.Content.ReadAsStringAsync();
                            dingCountriesResponse = JsonConvert.DeserializeObject<DingCountries>(returnData);
                        }
                        else
                        {

                            returnData = await httpCountriesResponse.Content.ReadAsStringAsync();
                            var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                            result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                            result.status = "Failure";
                            result.errorCode = 2;

                            _logger.Debug($"  DingGetPromotions  Failed  Source:API  Pasameters:  fromMSISDN={fromMSISDN}    Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                            return result;
                        }


                        var httpProvidersResponse = await dingHttpClient.GetAsync(getProvidersSubUrl);
                        var dingProvidersResponse = new DingProviders();
                        if (httpProvidersResponse.StatusCode == HttpStatusCode.OK)
                        {
                            returnData = await httpProvidersResponse.Content.ReadAsStringAsync();
                            dingProvidersResponse = JsonConvert.DeserializeObject<DingProviders>(returnData);
                        }
                        else
                        {

                            returnData = await httpProvidersResponse.Content.ReadAsStringAsync();
                            var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                            result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                            result.status = "Failure";
                            result.errorCode = 2;

                            _logger.Debug($"  DingGetPromotions  Failed  Source:API  Pasameters: fromMSISDN={fromMSISDN}    Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                            return result;
                        }



                        PayLoad payload = new PayLoad();
                        result.message = "Promotions found";
                        result.status = "Success";
                        result.errorCode = 0;


                        var promoDetails = (from p in dingPromotionsResponse.items
                                            join d in dingPromotionsDescriptionResponse.items on p.LocalizationKey equals d.LocalizationKey into temp
                                            from t in temp.DefaultIfEmpty()
                                            select new PromoDetails()
                                            {
                                                title = t.Headline,
                                                description = t.TermsAndConditionsMarkDown,
                                                dateFrom = p.StartUtc.ToString("ddd, dd MMM yyy HH':'mm':'ss zzz"),
                                                dateTo = p.EndUtc.ToString("ddd, dd MMM yyy HH':'mm':'ss zzz"),
                                                operatorName = dingProvidersResponse.items.FirstOrDefault(s => s.ProviderCode.ToLower() == p.ProviderCode.ToLower())?.Name,
                                                countryName = dingCountriesResponse.items.FirstOrDefault(s => s.CountryIso.ToLower() == dingProvidersResponse.items.FirstOrDefault(ss => ss.ProviderCode.ToLower() == p.ProviderCode.ToLower())?.CountryIso.ToLower())?.CountryName,
                                                promotionstatus = (DateTime.UtcNow >= p.StartUtc && DateTime.UtcNow <= p.EndUtc) ? "Active" :
                                                (p.StartUtc > DateTime.UtcNow && DateTime.UtcNow < p.EndUtc) ? "UpComming" : "Expired",
                                                title2 = t.PromotionType,
                                                denomination = "",
                                                denominationLocal = "",
                                                operatorId = "-1",
                                                subOperatorId = "-1",
                                                pubDate = "",
                                                countryId = ""
                                                //ProviderCode = p.ProviderCode,
                                                //CurrencyIso = p.CurrencyIso,
                                                //LocalizationKey = p.LocalizationKey,
                                                //MinimumSendAmount = p.MinimumSendAmount,
                                                //ValidityPeriodIso = p.ValidityPeriodIso,
                                                //Dates = t.Dates,
                                                //LanguageCode = t.LanguageCode,
                                                //BonusValidity = t.BonusValidity
                                            }).Where(s => s.promotionstatus != "Expired").ToList();

                        result.payload = new PromonPayload()
                        {
                            item = promoDetails,
                            dingCountries = destinationDingProviders.Select(s => s.country_name).Distinct().ToList()
                        };

                        return result;
                    }
                    else
                    {

                        returnData = await httpPromoDesctiptionResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                        result.status = "Failure";
                        result.errorCode = 2;

                        _logger.Debug($"  DingGetPromotions  Failed  Source:Ding API  Pasameters:      fromMSISDN={fromMSISDN}Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                        return result;
                    }
                }
                else
                {

                    returnData = await httpPRomotionResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                    result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                    result.status = "Failure";
                    result.errorCode = 2;

                    _logger.Debug($"  DingGetPromotions  Failed  Source:API  Pasameters:      fromMSISDN={fromMSISDN}   Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  DingGetPromotions  Failed  Source:General  Parameters- fromMSISDN={fromMSISDN}   Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                return result;
            }

        }



        public async Task<JsonOperatorProductResponse> Com_ATT_DingGetPhoneOperator(string fromMSISDN, string account, string ToMsisdn, int? cdsp_config_id, string productCode, string productItemCode, string ProductId, int selectedCarrierNumber)
        {

            JsonOperatorProductResponse result = new JsonOperatorProductResponse();


            result.servcieproviderid = 3;

            // Validating fraud customers , at_check_fraud

            try
            {

                bool isPermitted = await _appDB.CheckFraudUser("", ToMsisdn, fromMSISDN);
                if (isPermitted == false)
                {
                    result.errorCode = 3;
                    result.status = "Failure";
                    result.message = "Fraud detected. Access Blocked.";
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Error($"  \"GET /Com_ATT_DingGetPhoneOperator\"  Failed  Source:CheckFraudUser,  Parameters- sourceMSISDN: {ToMsisdn}, destinationMSISDN: {fromMSISDN}, currency:{account}    Message:{ex.ToString()}, StackTrace: {ex.StackTrace}");

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error: " + ex.Message;
                return result;

            }

            try
            {
                var getProvidersubUrl = $"GetProviders?accountNumber={ToMsisdn}";
                var getProductsubUrl = $"GetProducts?accountNumber={ToMsisdn}";
                var tokenRequestStartTime = DateTime.Now;
                var authResponse = await _dingAuth_BL.getAuthToken(account);
                var tokenRequestEndTime = DateTime.Now;
                var baseAddress = new Uri(_dingConf.ApiEndPoint);
                HttpClient dingHttpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(httpConfig.TimeOut), BaseAddress = baseAddress };
                dingHttpClient.DefaultRequestHeaders.TryAddWithoutValidation("authorization", $"{authResponse.token_type} {authResponse.access_token}");
                string returnData = "";
                var GetProviderStartTime = DateTime.Now;
                var httpProviderResponse = await dingHttpClient.GetAsync(getProvidersubUrl);
                var GetProviderEndTime = DateTime.Now;

                if (httpProviderResponse.StatusCode == HttpStatusCode.OK)
                {
                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    if (_dingConf.JsonResponseLogging)
                    {
                        _logger.Information($"Ding Com_ATT_DingGetPhoneOperator Request {getProvidersubUrl} Response {returnData}");
                    }
                    var dingOperatorResponse = JsonConvert.DeserializeObject<DingOperatorResponse>(returnData);

                    if (dingOperatorResponse.Items.Count == 0)
                    {
                        if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                        {
                            await _common_BL.SendEmail(new EmailTransactionModel()
                            {
                                ErrorMessage = "Ding provider not found against destination. Response" + returnData,
                                Status = "Failure",
                                FromMsisdn = fromMSISDN,
                                ToMsisdn = ToMsisdn,
                                ProductCode = productCode,
                                ProductItemCode = productItemCode,
                                ServiceProviderName = ServiceProvider.Ding.ToString(),
                                TransationType = TransationType.Get
                            });
                        }
                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "Ding provider not found against destination. Response" + returnData);
                        result.errorCode = 12;
                        result.status = "Failure";
                        result.message = "Ding provider not found against destination";
                        return result;
                    }
                    //Filter and get only minutes providers not data
                    if (dingOperatorResponse.Items.Count > 1)
                    {
                        dingOperatorResponse.Items = dingOperatorResponse.Items.Where(r => !r.Name.ToLower().Contains(" data ")).ToList();
                    }
                    getProductsubUrl += $"&providerCodes={dingOperatorResponse.Items[0].ProviderCode}";
                    var productJson = "{}";
                    var requestJson = "";
                    var responseJson = "";
                    var serviceProviderId = result.servcieproviderid;
                    var GetPRoductStartTime = DateTime.Now;
                    var httpProductResponse = await dingHttpClient.GetAsync(getProductsubUrl);
                    var GetPRoductEndTime = DateTime.Now;
                    var dingProductDetailedResponse = new DingOperatorDetailedResponse();
                    if (httpProductResponse.StatusCode == HttpStatusCode.OK)
                    {
                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        requestJson = getProductsubUrl; responseJson = returnData;
                        if (_dingConf.JsonResponseLogging)
                        {
                            _logger.Information($"Ding Com_ATT_DingGetPhoneOperator Request {getProductsubUrl} Response {returnData}");
                        }
                        dingProductDetailedResponse = JsonConvert.DeserializeObject<DingOperatorDetailedResponse>(returnData);
                    }
                    else
                    {

                        returnData = await httpProductResponse.Content.ReadAsStringAsync();
                        var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                        result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                        result.status = "Failure";
                        result.errorCode = 2;

                        await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                        _logger.Debug($"  Com_ATT_DingGetPhoneOperator  Failed  Source:DING API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");

                        return result;
                    }

                    PayLoad payload = new PayLoad();
                    result.message = "Operators found";
                    result.status = "Success";
                    result.errorCode = 0;
                    List<AttOperator> operators = new List<AttOperator>();
                    List<AttProduct> products = new List<AttProduct>();
                    AttOperator operatorDetails = new AttOperator();

                    operatorDetails.id = dingOperatorResponse.Items[0].ProviderCode;
                    operatorDetails.name = dingOperatorResponse.Items[0].Name;
                    operatorDetails.country = dingOperatorResponse.Items[0].RegionCodes[0];
                    operatorDetails.nowtelTransactionReference = Guid.NewGuid().ToString();
                    operatorDetails.ProductItemCode = productItemCode;
                    operatorDetails.iconUri = dingOperatorResponse.Items[0].LogoUrl;

                    DBResponse dbResult = new DBResponse();
                    dbResult = await _appDB.Com_ATT_insertTransactionGUID(ProductId, operatorDetails.nowtelTransactionReference, account.ToUpper(), ToMsisdn, productJson, requestJson, responseJson, serviceProviderId, fromMSISDN, productItemCode, dingOperatorResponse.Items[0].CountryIso, dingOperatorResponse.Items[0].ProviderCode.ToString(), productCode, operatorDetails.name, operatorDetails.iconUri, operatorDetails.country, GetTokenApiTime: (tokenRequestEndTime - tokenRequestStartTime).TotalMilliseconds, GetProviderApiTime: (GetProviderEndTime - GetProviderStartTime).TotalMilliseconds, GetProductApiTime: (GetPRoductEndTime - GetPRoductStartTime).TotalMilliseconds);
                    if (dbResult.DBStatus == 0)
                    {
                        _logger.Debug($"  Com_ATT_DingGetPhoneOperator  Failed  Source:Ding API  Database error occured while while inserting GUID and ProductJson record.    Exception {dbResult.DBErrorMessage} ");

                        result.errorCode = 2;
                        result.status = "Failure";
                        result.message = " Source:Ding API  Database error occured while while inserting GUID and ProductJson record . Exception:" + dbResult.DBErrorMessage;
                        return result;
                    }
                    else
                    {
                        COMM_ATT_CustomerChargeValuesForReplacement custChargeValues = new COMM_ATT_CustomerChargeValuesForReplacement();
                        if (cdsp_config_id.HasValue)
                            custChargeValues = await _appDB.Com_ATT_GetCustomerChargeValuesForReplacement(cdsp_config_id.Value, selectedCarrierNumber);

                        //range
                        if (dingProductDetailedResponse.Items.Count == 1)
                        {
                            foreach (var custChargeValue in custChargeValues.chargeValues.Where(r => r.buying_price >= dingProductDetailedResponse.Items[0].Minimum.SendValue && r.buying_price <= dingProductDetailedResponse.Items[0].Maximum.SendValue))
                            {

                                AttProduct product = new AttProduct();
                                product.product = custChargeValue.received_amount.ToString(); //((int)Math.Floor((dingProductDetailedResponse.Items[0].Minimum.ReceiveValue / dingProductDetailedResponse.Items[0].Minimum.SendValue) * custChargeValue.buying_price)).ToString();
                                product.receiverccy = dingProductDetailedResponse.Items[0].Minimum.ReceiveCurrencyIso;
                                product.clientccy = dingProductDetailedResponse.Items[0].Minimum.SendCurrencyIso;
                                product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                product.transactionfeeClientccy = 0.ToString();
                                products.Add(product);

                                await _appDB.insertaccessDetails(dbResult.InsertId,
               account,
               product.receiverccy,
               product.product,
               custChargeValue.buying_price.ToString(),
               custChargeValue.buying_price.ToString(),
               custChargeValue.selling_price.ToString(),
               //endrate.CustomerChargeValue.ToString(),
               //endrate.CustomerChargeValue.ToString(),
               0,
               dingProductDetailedResponse.Items[0].SkuCode,
               dingProductDetailedResponse.Items[0].UatNumber
               );

                            }

                            //If no products found
                            if (!custChargeValues.chargeValues.Any(r => r.buying_price >= dingProductDetailedResponse.Items[0].Minimum.SendValue && r.buying_price <= dingProductDetailedResponse.Items[0].Maximum.SendValue))
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0])}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items[0]));
                            }
                        }
                        else
                        {
                            bool ProductMatched = false;
                            foreach (var custChargeValue in custChargeValues.chargeValues)
                            {
                                var dingProduct = dingProductDetailedResponse.Items.FirstOrDefault(r => r.Minimum.SendValue == custChargeValue.buying_price);
                                if (dingProduct != null)
                                {
                                    AttProduct product = new AttProduct();
                                    product.product = dingProduct.Minimum.ReceiveValue.ToString();
                                    product.receiverccy = dingProduct.Minimum.ReceiveCurrencyIso;
                                    product.clientccy = dingProduct.Minimum.SendCurrencyIso;
                                    product.itemPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.totalPriceClientccy = custChargeValue.selling_price.ToString();
                                    product.transactionfeeClientccy = 0.ToString();
                                    products.Add(product);

                                    await _appDB.insertaccessDetails(dbResult.InsertId,
                   account,
                   product.receiverccy,
                   product.product,
                   dingProduct.Minimum.SendValue.ToString(),
                   dingProduct.Minimum.SendValue.ToString(),
                    custChargeValue.selling_price.ToString(),
                   //endrate.CustomerChargeValue.ToString(),
                   //endrate.CustomerChargeValue.ToString(),
                   0,
                   dingProduct.SkuCode,
                   dingProduct.UatNumber
                   );
                                    ProductMatched = true;
                                }
                            }

                            //If no products found
                            if (!ProductMatched)
                            {
                                if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                                {
                                    await _common_BL.SendEmail(new EmailTransactionModel()
                                    {
                                        ErrorMessage = $"ProductNotMatched: \n\r ConfiguredRates: {JsonConvert.SerializeObject(custChargeValues)} \n\r ProviderResponse: {JsonConvert.SerializeObject(dingProductDetailedResponse.Items)}",
                                        Status = "Failure",
                                        FromMsisdn = fromMSISDN,
                                        ToMsisdn = ToMsisdn,
                                        ProductCode = productCode,
                                        ProductItemCode = productItemCode,
                                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                                        TransationType = TransationType.Get
                                    });
                                }
                                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, "ProductNotMatched", DbConfiguredValues: JsonConvert.SerializeObject(custChargeValues), OperatorResponse: JsonConvert.SerializeObject(dingProductDetailedResponse.Items));
                            }

                        }
                        operatorDetails.accessid = dbResult.InsertId;
                        operatorDetails.products = products;
                        operators.Add(operatorDetails);
                        payload.operators = operators;
                        result.payload = payload;
                        _logger.Information($"  Com_ATT_DingGetPhoneOperator  Success      Parameters-msisdn:{ToMsisdn} currency:{account}");

                        return result;
                    }
                }
                else
                {

                    returnData = await httpProviderResponse.Content.ReadAsStringAsync();
                    var errorResponse = JsonConvert.DeserializeObject<DingErrorResponse>(returnData);

                    result.message = errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context;
                    result.status = "Failure";
                    result.errorCode = 2;
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                    _logger.Debug($"  Com_ATT_DingGetPhoneOperator  Failed  Source:Ding API  Pasameters:      msisdn={ToMsisdn}      currency-{account}       Reason={errorResponse.ErrorCodes[0].Code + " " + errorResponse.ErrorCodes[0].Context}");
                    if (SmtpConfig.sendErrorGetProductsEmail && !SmtpConfig.sendGetProductsExceptionErrorsOnly)
                    {
                        await _common_BL.SendEmail(new EmailTransactionModel()
                        {
                            ErrorMessage = result.message,
                            Status = "Failure",
                            FromMsisdn = fromMSISDN,
                            ToMsisdn = ToMsisdn,
                            ProductCode = productCode,
                            ProductItemCode = productItemCode,
                            ServiceProviderName = ServiceProvider.Ding.ToString(),
                            TransationType = TransationType.Get
                        });
                    }
                    await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, result.message);
                    return result;
                }

            }
            catch (Exception ex)
            {
                _logger.Debug($"  Com_ATT_DingGetPhoneOperator  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                //var errorResult = new { errorCode = 1, status = "Failure", message = "General API Access Error" };
                //return Json(errorResult);

                result.errorCode = 2;
                result.status = "Failure";
                result.message = "General API Access Error";
                if (SmtpConfig.sendErrorGetProductsEmail)
                {
                    await _common_BL.SendEmail(new EmailTransactionModel()
                    {
                        ErrorMessage = ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""),
                        Status = "Failure",
                        FromMsisdn = fromMSISDN,
                        ToMsisdn = ToMsisdn,
                        ProductCode = productCode,
                        ProductItemCode = productItemCode,
                        ServiceProviderName = ServiceProvider.Ding.ToString(),
                        TransationType = TransationType.Get
                    });
                }
                await _appDB.insertGetProductsAccessErrors(account, ToMsisdn, result.servcieproviderid, fromMSISDN, productCode, productItemCode, ex.Message + (ex.InnerException != null ? " Details " + ex.InnerException.Message : ""));
                return result;
            }

        }

    }
}
