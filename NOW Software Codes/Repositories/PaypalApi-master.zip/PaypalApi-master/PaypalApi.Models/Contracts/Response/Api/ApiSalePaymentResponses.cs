﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Response.Api
{
    

    public class ApiCreateSalePaymentResponse
    {

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("create_time")]
        public DateTime CreateTime { get; set; }        

        [JsonProperty("intent")]
        public string Intent { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("payer")]
        public Payers Payer { get; set; }

        [JsonProperty("transactions")]
        public Transactions[] Transaction { get; set; }

        [JsonProperty("links")]
        public Links[] RedirectLinks { get; set; }

    }

    public class ApiExecuteSalePaymentResponse
    {

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("create_time")]
        public DateTime CreateTime { get; set; }

        [JsonProperty("intent")]
        public string Intent { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("cart")]
        public string Cart { get; set; }

        [JsonProperty("payer")]
        public ExecutePayers Payer { get; set; }

        [JsonProperty("transactions")]
        public ExecuteTransactions[] Transaction { get; set; }

        [JsonProperty("links")]
        public Links[] RedirectLinks { get; set; }

    }


    public class ExecuteTransactions
    {
        [JsonProperty("amount")]
        public Amounts Amount { get; set; }

        [JsonProperty("payee")]
        public Payees Payee { get; set; }

        [JsonProperty("item_list")]
        public ItemLists ItemList { get; set; }

        [JsonProperty("related_resources")]
        public RelatedResource[] RelatedResources { get; set; }

    }

    public class Sales
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("create_time")]
        public DateTime CreateTime { get; set; }

        [JsonProperty("amount")]
        public Amounts Amount { get; set; }

        [JsonProperty("payment_mode")]
        public string PaymentMode { get; set; }

        [JsonProperty("protection_eligibility")]
        public string ProtectionEligibility { get; set; }

        [JsonProperty("protection_eligibility_type")]
        public string ProtectionEligibilityType { get; set; }

        [JsonProperty("transaction_fee")]
        public TransactionFees TransactionFee { get; set; }

        [JsonProperty("parent_payment")]
        public string ParentPayment { get; set; }

        [JsonProperty("links")]
        public Links[] RedirectLinks { get; set; }

    }

    public class TransactionFees
    {
        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }

    }

    public class RelatedResource
    {
        [JsonProperty("sale")]
        public Sales Sale { get; set; }

    }

    public class ItemLists
    {
        [JsonProperty("shipping_address")]
        public ShippingAddress ShippingAddress { get; set; }
       
    }


    public class Payees
    {        
        [JsonProperty("merchant_id")]
        public string MerchantId { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
    }

    public class ExecutePayers
    {
        [JsonProperty("payment_method")]
        public string PaymentMethod { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }


        [JsonProperty("payer_info")]
        public PayersInfo PayerInfo { get; set; }

    }

    public class PayersInfo
    {
        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        [JsonProperty("last_name")]
        public string LastName { get; set; }

        [JsonProperty("payer_id")]
        public string PayerId { get; set; }

        [JsonProperty("country_code")]
        public string CountryCode { get; set; }

        [JsonProperty("shipping_address")]
        public ShippingAddress ShippingAddress { get; set; }        

    }


    public class ShippingAddress
    {
        [JsonProperty("recipient_name")]
        public string RecipientName { get; set; }

        [JsonProperty("line1")]
        public string Line1 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("postal_code")]
        public string PostalCode { get; set; }

        [JsonProperty("country_code")]
        public string CountryCode { get; set; }

    }

    public class Links
    {
        [JsonProperty("href")]
        public string Href { get; set; }

        [JsonProperty("rel")]
        public string Rel { get; set; }

        [JsonProperty("method")]
        public string Method { get; set; }
        
    }

    public class Transactions
    {
        [JsonProperty("amount")]
        public Amounts Amount { get; set; }

        [JsonProperty("invoice_number")]
        public string InvoiceNumber { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

    }

    public class Amounts
    {
        [JsonProperty("total")]
        public string Total { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }
    }

    public class Payers
    {
        [JsonProperty("payment_method")]
        public string PaymentMethod { get; set; }

    }

}
