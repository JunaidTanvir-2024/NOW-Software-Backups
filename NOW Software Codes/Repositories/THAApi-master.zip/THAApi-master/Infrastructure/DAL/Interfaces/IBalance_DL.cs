﻿using Models.Contracts.Request;
using System;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DAL.Interfaces
{
    public interface IBalance_DL
    {
        Task<UserAccountBalance> GetUserAccountBalance(string msisdn);

        //Task<UserAccountBalance> GetUserAccountBalanceByAccount(string account);
    }
}
