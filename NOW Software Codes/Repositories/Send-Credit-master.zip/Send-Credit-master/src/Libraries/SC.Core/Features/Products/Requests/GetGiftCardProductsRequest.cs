﻿using SC.Core.Common.Model;

namespace SC.Core.Features.Products;

public sealed class GetGiftCardProductsRequest : IRequest<IResultWrapper>
{
    public int Page { get; set; }
    public int RecordsPerPage { get; set; }
    public ProductRequestType RequestType { get; set; }
    public Filter? Filters { get; set; }
}

public sealed class GetGiftCardProductsRequestValidator : AbstractValidator<GetGiftCardProductsRequest>
{
    public GetGiftCardProductsRequestValidator()
    {
    }
}