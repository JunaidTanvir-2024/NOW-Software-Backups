﻿using Application.Common.Caching;
using Application.Common.Interfaces.Infrastructure.Identity;

namespace Application.Features.Account.Product.UpdateConfirm;
public class UpdateProductConfirmRequestHandler : IRequestHandler<UpdateProductConfirmRequest, Result<object>>
{
    #region Fields

    private readonly IStringLocalizer<UpdateProductConfirmRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly ICacheService _cacheService;
    private readonly ICacheKeyService _cacheKeyService;

    #endregion

    #region Ctor

    public UpdateProductConfirmRequestHandler(
        IStringLocalizer<UpdateProductConfirmRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        ICommonService commonService,
        IOtpService otpService,
        ICacheService cacheService,
        ICacheKeyService cacheKeyService)
    {
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _commonService = commonService;
        _otpService = otpService;
        _cacheService = cacheService;
        _cacheKeyService = cacheKeyService;
    }

    #endregion

    #region Method

    public async Task<Result<object>> Handle(UpdateProductConfirmRequest request, CancellationToken cancellationToken)
    {
        request.Msisdn = _commonService.FormatMsisdn(request.Msisdn);

        //Check number is valid THM number
        var msisdn = await _unitOfWork.UserRepo.GetMsisdnDetail(request.Msisdn);
        if (msisdn == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.InvalidMsisdn], CustomStatusCode.InvalidMsisdn);
        }

        //Check number msisdn is not already attached
        if (await _unitOfWork.UserRepo.IsProductAlreadyAttached(request.Msisdn))
        {
            return Result<object>.Failure(
                _localizer[CustomStatusKey.MsisdnAlreadyRegistered], CustomStatusCode.MsisdnAlreadyRegistered);
        }

        //Check if product id exists user products
        var userProducts = await _unitOfWork.UserRepo.GetUserProducts(_currentUser.GetUserId());
        if (!userProducts.Any(x => x.Id.Equals(request.ProductId)))
        {
            return Result<object>.Failure(
                _localizer[CustomStatusKey.InvalidProductReference], CustomStatusCode.InvalidProductReference);
        }

        //Validate msisdn Otp
        var msisdnOtpResponse = await _otpService.VerifyOtp(request.Otp, request.Msisdn, OtpType.UpdateProduct, false);
        if (msisdnOtpResponse.Code == CustomStatusCode.InvalidOtp)
        {
            return Result<object>.Failure(_localizer[CustomStatusKey.InvalidOtp], CustomStatusCode.InvalidOtp);
        }

        //Update user product
        await _unitOfWork.UserRepo.AddProduct(
            new UserProduct()
            {
                Id = request.ProductId,
                AccountId = msisdn.AccountId!,
                Status = (int) SimStatus.Completed,
                Msisdn = request.Msisdn,
                UserId = _currentUser.GetUserId()
            });

        //Remove cache for prducts
        await _cacheService.RemoveAsync(_cacheKeyService.GetCacheKey(CacheKeys.UserProduct, _currentUser.GetUserId().ToString()), cancellationToken);

        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}
