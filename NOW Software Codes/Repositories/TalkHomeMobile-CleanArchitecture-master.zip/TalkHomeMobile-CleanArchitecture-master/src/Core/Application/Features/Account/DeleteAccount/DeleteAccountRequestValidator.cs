﻿using Application.Features.Account.Product.AddConfirm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Account.DeleteAccount;

public class DeleteAccountRequestValidator : AbstractValidator<DeleteAccountRequest>
{
    public DeleteAccountRequestValidator()
    {
        RuleFor(p => p.Email).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull();
        RuleFor(p => p.Password).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull();
    }
}
