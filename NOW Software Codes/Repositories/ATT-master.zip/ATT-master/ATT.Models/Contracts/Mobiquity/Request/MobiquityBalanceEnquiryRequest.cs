﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Mobiquity.Request
{
    public class MobiquityBalanceEnquiryRequest
    {
        public BalanceEnquiryCommand COMMAND { get; set; }

    }

    public class BalanceEnquiryCommand
    {
        public string TYPE { get; set; }
        public string MSISDN { get; set; }
        public string PROVIDER { get; set; }
        public string PAYID { get; set; }
        public string MPIN { get; set; }
        public string PIN { get; set; }
        public string BLOCKSMS { get; set; }
        public string LANGUAGE1 { get; set; }
        public string CELLID { get; set; }
        public string FTXNID { get; set; }
    }
}
