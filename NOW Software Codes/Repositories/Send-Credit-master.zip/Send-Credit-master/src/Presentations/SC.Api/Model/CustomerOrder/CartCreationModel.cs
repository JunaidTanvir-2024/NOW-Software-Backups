﻿using System.ComponentModel;

namespace SC.Api.Model.CustomerOrder;
public class CartCreationModel
{
    public long CustomerCartID { get; set; } = default!;
    public long ProductID { get; set; } = default!;
    public string Currency { get; set; } = default!;

    [DefaultValue(false)]
    public bool IsGuestUser { get; set; } = default!;
    public string? UserID { get; set; } = default;
    public decimal ProductPrice { set; get; }

}

