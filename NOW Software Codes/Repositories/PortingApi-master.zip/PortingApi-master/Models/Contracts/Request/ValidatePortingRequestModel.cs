﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class ValidatePortingRequestModel
    {
        [Required(ErrorMessage = "Email Required")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Port type Required")]
        public PortTypes PortType { get; set; }
        [Required]
        public Products Product { get; set; }
        public string Msisdn { get; set; }
    }
}
