﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
	public class History_BL : IHistory_BL
	{
		private readonly IHistory_DL History_DL;
		private readonly IBundle_DL Bundle_DL;

		//Types
		private const string Topup = "Topup";
		private const string BundlePurchase = "BundlePurchase";
		private const string AirTimeTransfer = "AirTimeTransfer";
		private const string InAppTransfer = "InAppTransfer";

		//Methods
		//private const string Card = "Card";
		//private const string PayPal = "PayPal";
		//private const string InAppTransferDebit = "InAppTransferDebit";
		//private const string InAppTransferCredit = "InAppTransferCredit";
		//private const string Voucher = "Voucher";
		//private const string AccountBalance = "AccountBalance";

		public History_BL(IHistory_DL history_DL, IBundle_DL bundle_DL)
		{
			History_DL = history_DL;
			Bundle_DL = bundle_DL;
		}
		public async Task<GenericApiResponse<object>> GetEntirePaymentHistory(string msisdn, string account)
		{
			var payload = new List<object>();

			var paymentHistories = await History_DL.GetEntirePaymentHistory(account, msisdn);
			var bundleDetails = await Bundle_DL.GetBundleDetailsByIds(paymentHistories.Where(e => e.Type == BundlePurchase && e.BundleId != null).Select(e => e.BundleId).Distinct().ToList());
			foreach (var x in paymentHistories)
			{
				if (x.Type == Topup)
				{
					payload.Add(
						new PaymentVoucherHistory()
						{
							Amount = x.Db == "account" ? x.Amount / 100 : x.Amount,
							Successfull = x.Db == "account" ? true : x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Type = x.Type,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A"
						});
				}
				else if (x.Type == InAppTransfer)
				{
					payload.Add(
						new PaymentInAppTransferHistory()
						{
							Amount = x.Amount / 100,
							Successfull = true,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn
						});
				}
				else if (x.Type == AirTimeTransfer)
				{
					payload.Add(
						new PaymentInAppTransferHistory()
						{
							Amount = x.Amount,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn
						});
				}
				else if (x.Type == BundlePurchase)
				{
					var details = bundleDetails.FirstOrDefault(e => e.Id == Guid.Parse(x.BundleId));
					payload.Add(
						new PaymentBundleHistory()
						{
							Amount = x.Amount,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							BundleName = details != null ? details.DisplayName : "N/A",
							BundleId = x.BundleId,
							BundleDestination = details.Destination,
							BundleCategory = (int)(details?.Category ?? BundleCategory.Platinium),
							BundleCategoryName = (details?.Category ?? BundleCategory.Platinium).ToString(),
							BundleType = (int)(details?.Type ?? BundleType.PAYG),
							BundleTypeName = (details?.Type ?? BundleType.PAYG).ToString()
						});
				}
			};

			return GenericApiResponse<object>.Success(new { paymentHistory = payload },
					payload.Count > 0 ? "History found successfully" : "History not found");
		}
		public async Task<GenericApiResponse<object>> GetEntirePaymentHistoryV2(string msisdn, string account)
		{
			var payload = new List<object>();

			var paymentHistories = await History_DL.GetEntirePaymentHistoryV2(account, msisdn);
			var bundleDetails = await Bundle_DL.GetBundleDetailsByIds(paymentHistories.Where(e => e.Type == BundlePurchase && e.BundleId != null).Select(e => e.BundleId).Distinct().ToList());
			foreach (var x in paymentHistories)
			{
				if (x.Type == Topup)
				{
					payload.Add(
						new PaymentVoucherHistory()
						{
							Amount = x.Db == "account" ? x.Amount / 100 : x.Amount,
							Discount = x.Discount,
							TotalAmount = x.TotalAmount,
							DiscountCode = x.DiscountCode,
							DiscountCodeType = x.DiscountCodeType,
							Successfull = x.Db == "account" ? true : x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Type = x.Type,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							RewardPoints = 0
						});
				}
				else if (x.Type == InAppTransfer)
				{
					payload.Add(
						new PaymentInAppTransferHistory()
						{
							Amount = x.Amount / 100,
							Successfull = true,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn,
							RewardPoints = 0

						});
				}
				else if (x.Type == AirTimeTransfer)
				{
					payload.Add(
						new PaymentInAppTransferHistoryV2()
						{
							Amount = x.Amount,
							Discount = x.Discount,
							TotalAmount = x.TotalAmount,
							ServiceFee = x.ServiceFee,
							ServiceFeeDiscount = x.ServiceFeeDiscount,
							TotalServiceFee = x.TotalServiceFee,
							DiscountCode = x.DiscountCode,
							DiscountCodeType = x.DiscountCodeType,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							Msisdn = x.Msisdn,
							RewardPoints = 0

						});
				}
				else if (x.Type == BundlePurchase)
				{
					var details = bundleDetails.FirstOrDefault(e => e.Id == Guid.Parse(x.BundleId));
					payload.Add(
						new PaymentBundleHistory()
						{
							Amount = x.Amount,
							Discount = x.Discount,
							TotalAmount = x.TotalAmount,
							DiscountCode = x.DiscountCode,
							DiscountCodeType = x.DiscountCodeType,
							Successfull = x.IsSuccess,
							TransDate = x.PaymentDate,
							Method = x.Method,
							Reference = !string.IsNullOrEmpty(x.Reference) ? x.Reference : "N/A",
							Type = x.Type,
							BundleName = details != null ? details.DisplayName : "N/A",
							BundleId = x.BundleId,
							BundleDestination = details.Destination,
							BundleCategory = (int)(details?.Category ?? BundleCategory.Platinium),
							BundleCategoryName = (details?.Category ?? BundleCategory.Platinium).ToString(),
							BundleType = (int)(details?.Type ?? BundleType.PAYG),
							BundleTypeName = (details?.Type ?? BundleType.PAYG).ToString(),
							RewardPoints = 0

						});
				}
			};

			return GenericApiResponse<object>.Success(new { paymentHistory = payload },
					payload.Count > 0 ? "History found successfully" : "History not found");
		}
		public async Task<IEnumerable<UserAccountPaymentHistory>> GetPaymentHistory(string msisdn)
		{
			try
			{
				return await History_DL.GetPaymentHistoryAsync(msisdn);
			}
			catch (Exception)
			{
				return null;
			}
		}

	}
}
