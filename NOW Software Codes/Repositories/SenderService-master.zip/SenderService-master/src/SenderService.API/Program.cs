using Microsoft.AspNetCore.Server.Kestrel.Core;
using SenderService.Core;
using SenderService.Core.Persistence;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
//// Serilog Configurations
builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(hostingContext.Configuration));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddCoreLayerServices(builder.Configuration);
builder.Services.AddSwaggerGen();

builder.Services.Configure<KestrelServerOptions>(options =>
{
    options.Limits.MaxRequestBodySize = 9999999999999; // or the maximum size you want to allow
});
var app = builder.Build();

//DatabaseInitialization.InitializeDatabase(app.Services);

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
