﻿using Models.Contracts.Request;
using Models.Contracts.Request.AndroidInAppPayment;
using Models.Contracts.Request.User_Account;
using Models.Contracts.Response;
using Models.Contracts.Response.AndroidInAppPayment;
using Models.Database;
using Models.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IUserAccount_BL
    {
        Task<GenericApiResponse<VerifyEmailReponse>> SendEmailVerificationLink(VerifyEmailRequest model, string msisdn);
        Task<GenericApiResponse<UserNotifications>> GetUserNotifications(string msisdn);
        Task<GenericApiResponse<UserNotifications>> UpdateUserNotifications(UserNotifications request, string msisdn);
        Task<GenericApiResponse<UpdateUserProfileResponse>> UpdateUserProfile(UpdateUserProfileRequest request, string msisdn);
        Task<GenericApiResponse<Profile>> GetUserProfile(string msisdn);
        Task<GenericApiResponse<SmsResult>> SendPinReminder(string msisdn, AppInfo appInfo);
        Task<FeedbackResponse> FeedbackIsActive(string msisdn);
        Task<GenericApiResponse<RSS>> GetPromotions(string msisdn);
        Task<UserAccountInformation> GetUserAccountInfoCatche(string sipUserName);
        Task<UserAccount> GetATTUserAccountWithoutCaching(string msisdn);
        //
        Task<GenericApiResponse<ReferralCode>> CreateReferralCode(string msisdn, string name);
        Task<GenericApiResponse<string>> UpdateReferralCode(string msisdn, ReferralCode referralCode);
        Task<GenericApiResponse<bool>> SetPromotions(string msisdn, Promotion promotion);
        Task<GenericApiResponse<bool>> SetEmail(string msisdn, Email email);
        Task<GenericApiResponse<string>> ExecuteWebCallthrough(string msisdn, string destination, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<GenericApiResponse<useremailRegistration>> getEmail(string msisdn);
        Task<GenericApiResponse<GetAutoTopupDetailsResponse>> GetAutoTopupDetails(string msisdn);

		Task<GenericApiResponse<bool>> SetFCMToken(FCMToKenReq fcmToken, string msisdn);
        Task<UserAccountBalance> GetUserAccountBalance(string msisdn);
        Task<GenericApiResponse<Referrals>> GetReferrals(string msisdn);
        //
        Task<bool> AuthenticateAsync(string msisdn, string pin);
        Task<GenericApiResponse<UserAccount>> Login(string msisdn, AppInfo info, string remoteIp, bool IsIOS = false, bool IsAndroid = false, string IOSAllowedVersion = null, string AndroidAllowedVersion = null);
        Task<GenericApiResponse<MsisdnInfomation>> Create(string msisdn, AppInfo appInfo, bool isTrusted, string remoteIp, string productCode, string productItemCode, string AuthTx = null, bool isLegacySignup = true);
        Task<GenericApiResponse<UserAccount>> Login(string msisdn, AppInfo appInfo);
        Task<GenericApiResponse<CallQualityResponse>> SaveCallQuality(CallQualityRequest request, string msisdn);
        Task<GenericApiResponse<ClientCallResponse>> SaveClientCallLogs(SaveClientCallRequest request, string msisdn);
        Task<GenericApiResponse<AndroidInAppPaymentResponse>> getAndriodPaymentOptions(string currency);
        Task<GenericApiResponse<AndroidPaymentVerificationResponse>> AndrionPaymentVerification(AndroidPaymentVerificationRequest request, string msisdn);
        Task<UserAccount> GetUserAccountWithoutCaching(string msisdn);
        Task<GenericApiResponse<DeleteAccountResponseModel>> DeleteAccountAsync(string account, string msisdn);
        Task<GenericApiResponse<MsisdnInfomation>> Create(UserInf signup, string remoteIp);
        Task<GenericApiResponse<UpdateUserProfileResponse>> UpdateUserProfileV2(UpdateUserProfileRequestV2 request, string msisdn);     
        Task<GenericApiResponse<bool>> CreateDeleteAccountRequest(DeleteAccountLogRequestModel model);
        Task<GenericApiResponse<List<DeleteAccountReason>>> GetDeleteAccountReasons(string languageName);      
        Task<GenericApiResponse<bool>> UpdateDeletedAccountStatus(DeleteAccountLogRequestModel model);
        Task DeleteAccountsRequestsAsync();
    }
}
