﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.ThresholdAmount;

public class ThresholdAmountRequestHandler : IRequestHandler<ThresholdAmountRequest, Result<List<float>>>
{
    private readonly IStringLocalizer<ThresholdAmountRequestHandler> _localizer;
    private readonly TopupSettings _topupSettings;

    public ThresholdAmountRequestHandler(
        IStringLocalizer<ThresholdAmountRequestHandler> localizer,
        IOptions<TopupSettings> topupSettings)
    {
        _localizer = localizer;
        _topupSettings = topupSettings.Value;
    }

    public Task<Result<List<float>>> Handle(ThresholdAmountRequest request, CancellationToken cancellationToken)
    {
        return Task.FromResult(Result<List<float>>.Success(_topupSettings.AutoTopupThresholdAmounts, _localizer[CustomStatusKey.Success]));
    }
}