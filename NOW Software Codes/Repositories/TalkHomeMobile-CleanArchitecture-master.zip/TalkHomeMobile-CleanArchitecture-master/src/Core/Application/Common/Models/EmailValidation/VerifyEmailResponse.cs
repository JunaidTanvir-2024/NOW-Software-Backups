﻿namespace Application.Common.Models.EmailValidation;
public class VerifyEmailResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }
    [JsonPropertyName("status")]
    public bool Status { get; set; } = true;
    [JsonPropertyName("statusCode")]
    public int StatusCode { get; set; }
    [JsonPropertyName("errors")]
    public Dictionary<string, string>? Errors { get; set; } = new Dictionary<string, string>();
    [JsonPropertyName("payload")]
    public VerifyEmailResponsePayload Payload { get; set; } = new VerifyEmailResponsePayload();
}
public class VerifyEmailResponsePayload
{
    public bool IsEmailValid { get; set; }
}