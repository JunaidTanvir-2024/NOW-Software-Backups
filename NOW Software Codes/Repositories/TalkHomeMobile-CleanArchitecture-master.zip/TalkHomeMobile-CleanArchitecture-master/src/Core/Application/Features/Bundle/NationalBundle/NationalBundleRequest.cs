using Application.Features.Bundle.Model;

namespace Application.Features.Bundle.NationalBundle;

public sealed class NationalBundleRequest : IRequest<Result<List<BundleInfo>>>
{
    public string Msisdn { get; set; } = default!;
}
