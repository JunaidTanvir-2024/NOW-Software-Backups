﻿using Application.Features.Address;

namespace Application.Common.Interfaces;
public interface IAddressService : ISerivcesType.ITransientService
{
    Task<AddressResponseModel> GetAddresses(string postcode);
}
