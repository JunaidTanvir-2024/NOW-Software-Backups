﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class PortOutBySmsRequestModel
    {
        [Required]
        public string to { get; set; }
        [Required]
        public Int64 sender { get; set; }
        [Required]
        public string text { get; set; }
    }
}
