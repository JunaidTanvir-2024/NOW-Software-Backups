using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.BLL.Implementation;
using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Implementation;
using Infrastructure.DAL.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Models.Configurations;
using Serilog;

namespace AirShipApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddSingleton((ILogger)new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "AirshipApi-log-{Date}.txt"))
            .CreateLogger());
            services.Configure<ConnectionStrings>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.Configure<AirshipConfig>(Configuration.GetSection("Airship"));
            services.AddTransient<INamedUser_BL, NamedUser_BL>();
            services.AddTransient<INamedUser_DL, NamedUser_DL>(); 
            services.AddTransient<IChannel_BL, Channel_BL>();
            services.AddTransient<IChannel_DL, Channel_DL>();
            services.AddTransient<IEmail_BL, Email_BL>();
            services.AddTransient<IEmail_DL, Email_DL>();
            services.AddTransient<IPush_BL, Push_BL>();
            services.AddTransient<IPush_DL, Push_DL>();
            services.AddTransient<IStaticList_BL, StaticList_BL>();
            services.AddTransient<IStaticList_DL, StaticList_DL>(); 
            services.AddTransient<ICustomEvents_BL, CustomEvents_BL>();
            services.AddTransient<ICustomEvents_DL, CustomEvents_DL>();
            services.AddSingleton<IApiCall, ApiCall>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Airship API",
                    Description = "Airship API",
                    TermsOfService = new Uri("https://Airship.co.uk/"),
                    Contact = new OpenApiContact() { Name = "Airship", Email = "hello@Airship.com", Url = new Uri("https://Airship.co.uk/") }
                });

                //c.AddSecurityDefinition("oauth2", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                //{
                //    Description = "Standard Authorization header using the Basic scheme. Example: \"Basic {value}\"",
                //    In = ParameterLocation.Header,
                //    Name = "Authorization",
                //    Type = SecuritySchemeType.ApiKey
                //});

                //c.AddSecurityDefinition("NowtelAuth", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                //{
                //    Description = "Standard NowtelAuth header using the Basic scheme. Example: \"NowtelAuth {value}\"",
                //    In = ParameterLocation.Header,
                //    Name = "NowtelAuth",
                //    Type = SecuritySchemeType.ApiKey
                //});

                //c.OperationFilter<SecurityRequirementsOperationFilter>();
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Airship API V1");
            });
        }
    }
}
