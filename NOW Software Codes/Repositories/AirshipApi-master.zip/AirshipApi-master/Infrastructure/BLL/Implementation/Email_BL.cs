﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.DAL.Interfaces;
using Models.Configurations;
using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Pay360.Response;
using Models.Contracts.Request;
using Models.Enums;
using Newtonsoft.Json;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Implementation
{
    public class Email_BL : IEmail_BL
    {

        private IApiCall ApiCall;
        private readonly ILogger Logger;
        private IEmail_DL EmailDb;

        public Email_BL(ILogger logger, IApiCall apiCall, IEmail_DL emailDb)
        {
            Logger = logger;
            ApiCall = apiCall;
            EmailDb = emailDb;
        }

        public async Task<GenericApiResponse<ApiGetChannelByEmailResponse>> GetChannelByEmail(GetChannelByEmailRequest request)
        {

            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.ProductCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/channels/email/" + request.email_channel_id;
                IRestResponse httpResponse = await ApiCall.Get(url, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Channel_BL, Method: GetChannelByEmail, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiGetChannelByEmailResponse apiResponseModel = JsonConvert.DeserializeObject<ApiGetChannelByEmailResponse>(responseJson);
                        if (apiResponseModel.ok == true)
                        {
                            return GenericApiResponse<ApiGetChannelByEmailResponse>.Success(apiResponseModel, "Success");
                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure("Unsuccessfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        ApiStatusCodes code = (httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound ? ApiStatusCodes.InvalidChannel : ApiStatusCodes.UnSuccessful);
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure(errorMessage, code);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Channel_BL, Method: GetChannelByEmail, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<ApiGetChannelByEmailResponse>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }

        public async Task<GenericApiResponse<string>> AddEmailChannel(AddEmailChannelRequest request)
        {
            try
            {
                GenericResult<Credentials> credResult = ApiCall.GetCredentials(request.productCode);
                if (credResult.Status == Status.Failure)
                {
                    ApiStatusCodes code = (credResult.ErrorCode == 1 ? ApiStatusCodes.CredentialsNotFound : ApiStatusCodes.CodeException);
                    return GenericApiResponse<string>.Failure(credResult.ErrorMessage, code);
                }
                Credentials credentials = credResult.Data;
                string authHeader = (credentials.AuthType == AuthType.Basic ? Utility.CreateBasicHeader(credentials.AppKey, credentials.MasterSecret) : credentials.BearerToken);

                string url = credentials.ApiEndPoint + "/api/channels/email";
                Dictionary<string, List<string>> tags = new Dictionary<string, List<string>>();
                ApiAddEmailChannelRequest apiRequest = new ApiAddEmailChannelRequest()
                {
                    channel = new ApiEmailChannelRequest()
                    {
                        type = DeviceType.email.ToString(),
                        commercial_opted_in = request.commercialOptedIn.HasValue ? request.commercialOptedIn.Value.ToString("yyyy-MM-ddTHH:mm:ssZ") : null,
                        commercial_opted_out = request.commercialOptedOut.HasValue ? request.commercialOptedOut.Value.ToString("yyyy-MM-ddTHH:mm:ssZ") : null,
                        transactional_opted_in = request.transactionalOptedIn.HasValue ? request.transactionalOptedIn.Value.ToString("yyyy-MM-ddTHH:mm:ssZ") : null,
                        transactional_opted_out = request.transactionalOptedOut.HasValue ? request.transactionalOptedOut.Value.ToString("yyyy-MM-ddTHH:mm:ssZ") : null,
                        Address = request.Address,
                        TimeZone = request.TimeZone,
                        LocaleCountry = request.LocaleCountry,
                        LocaleLanguage = request.LocaleLanguage
                    }
                };
                string jsonRequest = JsonConvert.SerializeObject(apiRequest);
                IRestResponse httpResponse = await ApiCall.Post(url, jsonRequest, credentials.AuthType, authHeader);
                if (httpResponse == null)
                {
                    Logger.Error($"Class: Email_BL, Method: AddEmailChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: Null response received.");
                    return GenericApiResponse<string>.Failure("Null response received.", ApiStatusCodes.NullContent);
                }
                else
                {
                    if ((int)httpResponse.StatusCode >= 200 && (int)httpResponse.StatusCode <= 299)
                    {
                        string responseJson = httpResponse.Content;
                        ApiAddEmailChannelResponse apiResponseModel = JsonConvert.DeserializeObject<ApiAddEmailChannelResponse>(responseJson);
                        if (apiResponseModel.ok == true)
                        {

                            var dbResult = await EmailDb.AddEmailChannel(request, apiResponseModel.channel_id);
                            if (dbResult.Status == Status.Success)
                            {
                                return GenericApiResponse<string>.Success(null, "Success");
                            }
                            else
                            {
                                return GenericApiResponse<string>.Failure(dbResult.ErrorMessage, ApiStatusCodes.UnSuccessful);
                            }

                        }
                        else
                        {
                            string response = httpResponse.Content;
                            return GenericApiResponse<string>.Failure("Unsuccesfull", ApiStatusCodes.UnSuccessful);
                        }

                    }
                    else if ((int)httpResponse.StatusCode >= 400 && (int)httpResponse.StatusCode <= 499)
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                    else
                    {
                        string responseJson = httpResponse.Content;
                        string errorMessage = Utility.GetJsonObjectValueByKey("error", responseJson);
                        return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.UnSuccessful);
                    }
                }

            }
            catch (Exception ex)
            {
                string errorMessage = (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message);
                Logger.Error($"Class:  Email_BL, Method: AddEmailChannel, Parameters: {JsonConvert.SerializeObject(request)}, ErrorMessage: " + errorMessage + ", StackTrace: " + ex.StackTrace);
                return GenericApiResponse<string>.Failure(errorMessage, ApiStatusCodes.CodeException);
            }

        }
    }
}
