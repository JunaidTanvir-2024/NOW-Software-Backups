﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class SMSConfig
    {
        public int LoginSMSLimit { get; set; }
        public int ResendSmsLimit { get; set; }
    }
}
