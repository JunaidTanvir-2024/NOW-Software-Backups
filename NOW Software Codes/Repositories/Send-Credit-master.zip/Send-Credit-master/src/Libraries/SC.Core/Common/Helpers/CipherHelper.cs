﻿

namespace SC.Core.Common.Helpers;

public static class CipherHelper
{
    public static string Encrypt(string inputText)
    {
        byte[] originalBytes = Encoding.UTF8.GetBytes(inputText);
        byte[] encryptedBytes = null;
        byte[] SaltBytes = GetKeyBytes(AppConstants.SecurityHeaders.SALTKey);

        SaltBytes = SHA256.Create().ComputeHash(SaltBytes);
        int saltSize = GetSaltSize(SaltBytes);

        byte[] saltBytes = GetRandomBytes(saltSize);


        byte[] bytesToBeEncrypted = new byte[saltBytes.Length + originalBytes.Length];
        for (int i = 0; i < saltBytes.Length; i++)
        {
            bytesToBeEncrypted[i] = saltBytes[i];
        }
        for (int i = 0; i < originalBytes.Length; i++)
        {
            bytesToBeEncrypted[i + saltBytes.Length] = originalBytes[i];
        }

        encryptedBytes = AES_Encrypt(bytesToBeEncrypted, SaltBytes);

        return Convert.ToBase64String(encryptedBytes);
    }
    public static string Decrypt(string inputDecryptedText)
    {
        byte[] bytesToBeDecrypted = Convert.FromBase64String(inputDecryptedText);
        byte[] SALTBytes = GetKeyBytes(AppConstants.SecurityHeaders.SALTKey);


        SALTBytes = SHA256.Create().ComputeHash(SALTBytes);

        byte[] decryptedBytes = AES_Decrypt(bytesToBeDecrypted, SALTBytes);


        int saltSize = GetSaltSize(SALTBytes);


        byte[] originalBytes = new byte[decryptedBytes.Length - saltSize];
        for (int i = saltSize; i < decryptedBytes.Length; i++)
        {
            originalBytes[i - saltSize] = decryptedBytes[i];
        }

        return Encoding.UTF8.GetString(originalBytes);
    }
    private static byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] SALTBytes)
    {
        byte[] encryptedBytes = null;
        byte[] saltBytes = SALTBytes;

        using (MemoryStream ms = new MemoryStream())
        {
            using (var AES = Aes.Create("AesManaged")!)
            {
                AES.KeySize = 256;
                AES.BlockSize = 128;

                var key = new Rfc2898DeriveBytes(SALTBytes, saltBytes, 1000);
                AES.Key = key.GetBytes(AES.KeySize / 8);
                AES.IV = key.GetBytes(AES.BlockSize / 8);

                AES.Mode = CipherMode.CBC;

                using (CryptoStream cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                    cs.Close();
                }
                encryptedBytes = ms.ToArray();
            }
        }

        return encryptedBytes;
    }
    private static byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] SALTBytes)
    {
        byte[] decryptedBytes = null;
        byte[] saltBytes = SALTBytes;


        using (MemoryStream ms = new MemoryStream())
        {
            using (var AES = Aes.Create("AesManaged")!)
            {
                AES.KeySize = 256;
                AES.BlockSize = 128;

                var key = new Rfc2898DeriveBytes(SALTBytes, saltBytes, 1000);
                AES.Key = key.GetBytes(AES.KeySize / 8);
                AES.IV = key.GetBytes(AES.BlockSize / 8);

                AES.Mode = CipherMode.CBC;

                using (CryptoStream cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                    cs.Close();
                }
                decryptedBytes = ms.ToArray();
            }
        }

        return decryptedBytes;
    }

    private static int GetSaltSize(byte[] SALTBytes)
    {
        var key = new Rfc2898DeriveBytes(SALTBytes, SALTBytes, 1000);
        byte[] ba = key.GetBytes(2);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ba.Length; i++)
        {
            sb.Append(Convert.ToInt32(ba[i]).ToString());
        }
        int saltSize = 0;
        string s = sb.ToString();
        foreach (char c in s)
        {
            int intc = Convert.ToInt32(c.ToString());
            saltSize = saltSize + intc;
        }

        return saltSize;
    }
    private static byte[] GetKeyBytes(string inputText)
    {

        byte[] ba = null;

        if (inputText.Length == 0)
            ba = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        else
        {

            var securePassword = new SecureString();

            foreach (char c in inputText)
                securePassword.AppendChar(c);

            securePassword.MakeReadOnly();
            IntPtr unmanagedBytes = Marshal.SecureStringToGlobalAllocAnsi(securePassword);
            try
            {

                unsafe
                {
                    byte* byteArray = (byte*)unmanagedBytes.ToPointer();


                    byte* pEnd = byteArray;
                    while (*pEnd++ != 0) { }
                    int length = (int)((pEnd - byteArray) - 1);

                    ba = new byte[length];

                    for (int i = 0; i < length; ++i)
                    {
                        byte dataAtIndex = *(byteArray + i);
                        ba[i] = dataAtIndex;
                    }
                }
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocAnsi(unmanagedBytes);
            }
        }

        return System.Security.Cryptography.SHA256.Create().ComputeHash(ba);
    }
    private static byte[] GetRandomBytes(int length)
    {
        byte[] ba = new byte[length];
        RNGCryptoServiceProvider.Create().GetBytes(ba);
        return ba;
    }
}

