using System.Transactions;

using FH.Core.Definitions;
using FH.Core.Interfaces.Services;

using FluentValidation;
using MessageBrokerModel;
using Mediator;

using RW;

using static FH.Core.Definitions.AppEnums;
using static MessageBrokerModel.TransactionMessageDto;

namespace FH.UseCases.Cart;
public sealed class BulkPurchase
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public required List<PurchaseItem> PurchaseItems { get; set; }
        public required string TransactionReference { get; set; }
        public sealed record PurchaseItem
        {
            public required string ProductVendorCode { get; set; }
            public required string CartReference { get; set; }
            public required long ProductId { get; set; }
            public required string RecipientMsisdn { get; set; }
            public required string SenderMsisdn { get; set; }
            public required string SenderName { get; set; }
            public required ushort Quantity { get; set; }
            public ProductPurchaseType ProductType { get; set; }
        }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.TransactionReference).NotEmpty().NotNull();
            RuleFor(x => x.PurchaseItems).NotNull();
            RuleForEach(x => x.PurchaseItems)
                .ChildRules(item =>
                {
                    item.RuleFor(y => y.ProductId).GreaterThan(0);
                    item.RuleFor(y => y.ProductVendorCode).NotEmpty().NotNull();
                    item.RuleFor(y => y.SenderMsisdn).NotEmpty().NotNull();
                    item.RuleFor(y => y.RecipientMsisdn).NotEmpty().NotNull();
                    item.RuleFor(y => y.ProductType).NotNull().NotEmpty();
                });
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required string TransactionReference { get; set; }
        public List<PurchasedItem> PurchasedItems { get; set; } = [];
        public sealed record PurchasedItem
        {
            public required string ProductVendorCode { get; set; }
            public required string CartReference { get; set; }
            public required long ProductId { get; set; }
            public required string Status { get; set; }
        }
    }
    #endregion

    #region Handler
    public sealed class Handler(IMediator mediator, IMessagePublisher messagePublisher) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IMediator _mediator = mediator;
        private readonly IMessagePublisher _messagePublisher = messagePublisher;

        public async ValueTask<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = new Response()
            {
                TransactionReference = request.TransactionReference,
            };

            var purchasedItems = new List<Response.PurchasedItem>();

            foreach (var item in request.PurchaseItems)
            {
                if (item.ProductType == ProductPurchaseType.Bundle)
                {
                    var bundlePurchasedItems = await PurchaseBundle(item, request.TransactionReference, item.Quantity, cancellationToken);

                    purchasedItems.AddRange(bundlePurchasedItems.PurchasedItems.Select(result => new Response.PurchasedItem
                    {
                        ProductId = result.ProductId,
                        ProductVendorCode = result.ProductVendorCode,
                        CartReference = item.CartReference,
                        Status = result.Status,
                    }));
                }
                if (item.ProductType == ProductPurchaseType.Topup)
                {
                    var topupPurchasedItems = await PurchaseTopup(item, request.TransactionReference, item.Quantity, cancellationToken);

                    purchasedItems.AddRange(topupPurchasedItems.PurchasedItems.Select(result => new Response.PurchasedItem
                    {
                        ProductId = result.ProductId,
                        ProductVendorCode = result.ProductVendorCode,
                        CartReference = item.CartReference,
                        Status = result.Status,
                    }));
                }
                if (item.ProductType == ProductPurchaseType.InternetData)
                {
                    var internetDataPurchasedItems = await PurchaseInternetData(item, request.TransactionReference, item.Quantity, cancellationToken);

                    purchasedItems.AddRange(internetDataPurchasedItems.PurchasedItems.Select(result => new Response.PurchasedItem
                    {
                        ProductId = result.ProductId,
                        ProductVendorCode = result.ProductVendorCode,
                        CartReference = item.CartReference,
                        Status = result.Status,
                    }));
                }
                if (item.ProductType == ProductPurchaseType.GiftCard)
                {
                    var giftCardPurchasedItems = await PurchaseGiftCard(item, request.TransactionReference, item.Quantity, cancellationToken);

                    purchasedItems.AddRange(giftCardPurchasedItems.PurchasedItems.Select(result => new Response.PurchasedItem
                    {
                        ProductId = result.ProductId,
                        ProductVendorCode = result.ProductVendorCode,
                        CartReference = item.CartReference,
                        Status = result.Status,
                    }));
                }
            }
            if (purchasedItems.Count > 0)
            {
                // test Message in messageBroker
                await _messagePublisher.PublishMessage(new TransactionMessageDto()
                {
                    Publisher = "FusionHub",
                    TransactionReference = response.TransactionReference,
                    TransactionItems = new TransactionItem()
                    {
                        CartReference = purchasedItems.First().CartReference,
                        ProductId = purchasedItems.First().ProductId,
                        ProductVendorCode = purchasedItems.First().ProductVendorCode,
                        Status = purchasedItems.First().Status
                    },
                });

                response.PurchasedItems.AddRange(purchasedItems);
                return ResultWrapper.Success(response);
            }

            return ResultWrapper.Failure(AppConstants.StatusKey.BadRequest, AppConstants.StatusCode.BadRequest);
        }

        private async Task<BuyInternetData.Response> PurchaseInternetData(Query.PurchaseItem item, string uniqueReference, ushort quantity, CancellationToken cancellationToken)
        {

            return (await _mediator.Send(new BuyInternetData.Query()
            {
                ProductId = item.ProductId,
                CartReference = item.CartReference,
                ProductVendorCode = item.ProductVendorCode,
                RecipientMsisdn = item.SenderMsisdn,
                SenderMsisdn = item.SenderMsisdn,
                SenderName = item.SenderName,
                TransactionReference = uniqueReference,
                Quantity = quantity,
            }, cancellationToken)).TypedPayload<BuyInternetData.Response>() ?? default!;
        }

        private async Task<BuyTopup.Response> PurchaseTopup(Query.PurchaseItem item, string uniqueReference, ushort quantity, CancellationToken cancellationToken)
        {
            return (await _mediator.Send(new BuyTopup.Query()
            {
                ProductId = item.ProductId,
                CartReference = item.CartReference,
                ProductVendorCode = item.ProductVendorCode,
                RecipientMsisdn = item.SenderMsisdn,
                SenderMsisdn = item.SenderMsisdn,
                SenderName = item.SenderName,
                TransactionReference = uniqueReference,
                Quantity = quantity,
            }, cancellationToken)).TypedPayload<BuyTopup.Response>() ?? default!;
        }

        private async Task<BuyBundle.Response> PurchaseBundle(Query.PurchaseItem item, string uniqueReference, ushort quantity, CancellationToken cancellationToken)
        {
            return (await _mediator.Send(new BuyBundle.Query()
            {
                ProductId = item.ProductId,
                CartReference = item.CartReference,
                ProductVendorCode = item.ProductVendorCode,
                RecipientMsisdn = item.SenderMsisdn,
                SenderMsisdn = item.SenderMsisdn,
                SenderName = item.SenderName,
                TransactionReference = uniqueReference,
                Quantity = quantity,
            }, cancellationToken)).TypedPayload<BuyBundle.Response>() ?? default!;
        }
        private async Task<BuyGiftCard.Response> PurchaseGiftCard(Query.PurchaseItem item, string uniqueReference, ushort quantity, CancellationToken cancellationToken)
        {
            return (await _mediator.Send(new BuyGiftCard.Query()
            {
                ProductId = item.ProductId,
                ProductVendorCode = item.ProductVendorCode,
                CartReference = item.CartReference,
                SenderName = item.SenderName,
                RecipientMsisdn = item.SenderMsisdn,
                SenderMsisdn = item.SenderMsisdn,
                TransactionReference = uniqueReference,
                Quantity = quantity,
            }, cancellationToken)).TypedPayload<BuyGiftCard.Response>() ?? default!;
        }
    }
    #endregion
}
