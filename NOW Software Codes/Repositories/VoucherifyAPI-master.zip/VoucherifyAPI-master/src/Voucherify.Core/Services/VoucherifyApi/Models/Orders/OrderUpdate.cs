using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Orders;

public class OrderUpdate
{
    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("amount")]
    public long? Amount { get; set; }

    [JsonPropertyName("items")]
    public List<OrderItem>? Items { get; private set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    public OrderUpdate WithAmount(long? amount)
    {
        Amount = amount;
        return this;
    }

    public OrderUpdate WithItems(List<OrderItem> items)
    {
        Items = items;
        return this;
    }
}
