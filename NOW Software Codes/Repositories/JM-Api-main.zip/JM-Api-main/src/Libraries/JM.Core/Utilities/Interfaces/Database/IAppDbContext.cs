using JM.Core.Entities;
using JM.Core.Utilities.DependencyResolver;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace JM.Core.Utilities.Interfaces.Database;

public interface IAppDbContext : ResolveAs.IScoped
{
    public DbSet<Country> Country { get; }
    public DbSet<UserDetail> UserDetail { get; }
    public DbSet<Vendor> Vendor { get; }
    public DbSet<AppLog> AppLog { get; }
    public DbSet<VendorLog> VendorLog { get; }
    public DbSet<Otp> Otp { get; }
    public DbSet<Trip> Trip { get; }
    public DbSet<Place> Place { get; }
    public DbSet<ExpenseCategory> ExpenseCategory { get; }
    public DbSet<Traveler> Traveler { get; }
    public DbSet<Media> Media { get; }
    public DbSet<Expense> Expense { get; }
    public DbSet<ChatRoom> ChatRoom { get; }
    public DbSet<Subscription> Subscription { get; }
    public DbSet<TripPlace> TripPlace { get; }
    public DbSet<Friendship> Friendship { get; }
    public DbSet<Currency> Currency { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    int SaveChanges();
    Task<IDbContextTransaction> BeginTransactionAsync();
    IDbContextTransaction BeginTransaction();
}
