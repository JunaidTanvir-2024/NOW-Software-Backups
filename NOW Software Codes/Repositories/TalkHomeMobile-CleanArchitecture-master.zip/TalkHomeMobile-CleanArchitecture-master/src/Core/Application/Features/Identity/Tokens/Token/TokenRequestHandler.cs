﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;
using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Identity.Tokens.Token;

public class TokenRequestHandler : IRequestHandler<TokenRequest, Result<TokenResponse>>
{
    #region Fields

    private readonly ITokenService _tokenService;
    private readonly IStringLocalizer<RefreshTokenRequestHandler> _localizer;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICommonService _commonService;
    private readonly IOtpService _otpService;
    private readonly IMapper _mapper;
    private readonly ISmsService _smsService;
    private readonly IMailService _mailService;
    private readonly LoginSettings _loginSettings;

    #endregion

    #region Ctor

    public TokenRequestHandler(
        ITokenService tokenService,
        IStringLocalizer<RefreshTokenRequestHandler> localizer,
        IUnitOfWork unitOfWork,
        ICommonService commonService,
        IOptions<LoginSettings> loginSettings,
        IOtpService otpService,
        IMapper mapper,
        ISmsService smsService,
        IMailService mailService)
    {
        _tokenService = tokenService;
        _localizer = localizer;
        _unitOfWork = unitOfWork;
        _commonService = commonService;
        _otpService = otpService;
        _mapper = mapper;
        _smsService = smsService;
        _mailService = mailService;
        _loginSettings = loginSettings.Value;
    }

    #endregion

    #region Methods

    public async Task<Result<TokenResponse>> Handle(TokenRequest request, CancellationToken cancellationToken)
    {
        //Check if request is from App
        (bool IsAppRequest, DeviceType? deviceType, MediumType MediumType) = _commonService.IsAppRequest();
        User? user;

        request.UserInfo.EmailOrPhone = request.UserInfo.EmailOrPhone.Trim().Normalize();

        LoginType loginType;

        if (_commonService.IsValidEmailAddress(request.UserInfo.EmailOrPhone))
        {
            loginType = LoginType.Email;
            user = await _unitOfWork.UserRepo.GetUserByEmail(request.UserInfo.EmailOrPhone);
        }
        else
        {
            request.UserInfo.EmailOrPhone = _commonService.FormatMsisdn(request.UserInfo.EmailOrPhone);

            loginType = LoginType.PhoneNumber;
            user = await _unitOfWork.UserRepo.GetUserByMsisdn(request.UserInfo.EmailOrPhone);
        }

        //User not registered
        if (user == null)
        {
            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials], CustomStatusCode.InvalidCredentials);
        }

        //Validate user for any type of de-activation

        //Validate Password
        bool isAuthenticated = SecurityHelper.CheckPassword(request.UserInfo.Password, user);
        if (!isAuthenticated)
        {
            if (_loginSettings.InvalidLogin.IsActive)
            {
                await _unitOfWork.UserRepo.SaveInvalidLoginAttempt(user.Id, request.IpAddress);
            }

            return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.InvalidCredentials],
                CustomStatusCode.InvalidCredentials);
        }

        //Save device logs and mark current device as active for user
        if (IsAppRequest)
        {
            //Check if user device used for first time
            if (await _unitOfWork.DeviceRepo.IsNewDevice(request.AppInfo.DevicePersistentID, user.Id))
            {
                //Save device logs as login action
                var userDeviceLog = _mapper.Map<UserDeviceLog>((request, user));
                await _unitOfWork.DeviceRepo.SaveDeviceLog(userDeviceLog);

                //string? currentMsisdn = String.Empty;
                //if (loginType == LoginType.PhoneNumber)
                //{
                //    currentMsisdn = request.UserInfo.EmailOrPhone;
                //}
                //else
                //{
                //    //Get user current default msisdn for sending message
                //    var userProds = await _unitOfWork.UserRepo.GetUserProducts(user.Id);
                //    if (userProds.Any())
                //    {
                //        currentMsisdn = userProds.Any(x => x.IsDefault)
                //            ? userProds.First(x => x.IsDefault).Msisdn :
                //            userProds.First().Msisdn;
                //    }
                //}

                //if (!string.IsNullOrEmpty(currentMsisdn))
                //{

                //Save user device as un-confirmed and in-active
                await _unitOfWork.DeviceRepo.SaveUserDeviceAsInActive(
                    request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, user.Id);

                //Send otp message
                var (Otp, otpModel) = await _otpService.CreateOtp(request.UserInfo.EmailOrPhone + "-" + request.AppInfo.DevicePersistentID, OtpType.Device, null);
                if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
                {
                    if (loginType == LoginType.Email)
                    {
                        await _mailService.SendSignupEmailOtpAsync(request.UserInfo.EmailOrPhone, Otp, null);
                    }
                    else
                    {
                        await _smsService.SendOtpMessage(request.UserInfo.EmailOrPhone, Otp.ToString()!);
                    }
                }
                return Result<TokenResponse>.Failure(_localizer[CustomStatusKey.DeviceNotVerified], CustomStatusCode.DeviceNotVerified);
                //}
                //else
                //{
                //    //It means this is user first device and no msisdn is attached
                //    //Mark current device as active and confirmed for this user
                //    await _unitOfWork.DeviceRepo.SaveDeviceAsActiveAndConfirmed(
                //        request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, user.Id);
                //}
            }
            else
            {
                //Save device logs as login action
                var userDeviceLog = _mapper.Map<UserDeviceLog>((request, user));
                await _unitOfWork.DeviceRepo.SaveDeviceLog(userDeviceLog);


                //Mark current device as active for user
                await _unitOfWork.DeviceRepo.MarkDeviceAsActive(
                    request.AppInfo.DevicePersistentID, (DeviceType) deviceType!, user.Id);
            }
        }

        //Get user auth token
        var tokenInfo = await _tokenService.GetTokenAsync(user, request.IpAddress!, cancellationToken);

        return Result<TokenResponse>.Success(tokenInfo, _localizer[CustomStatusKey.Success]);
    }

    #endregion
}