﻿using FluentValidation;

namespace Voucherify.Api.Features.Campaigns.Requests;

public class DeleteCampaignRequest
{
    public string CampaignNameOrId { get; set; } = null!;
}
internal class DeleteCampaignRequestValidator : AbstractValidator<DeleteCampaignRequest>
{
    public DeleteCampaignRequestValidator()
    {
        RuleFor(p => p.CampaignNameOrId).NotNull().NotEmpty();
    }
}