﻿using Models.Contracts.PaypalApiContracts;
using Models.Contracts.Request;
using Models.Contracts.Response;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface IPayment_BL
	{
		Task<GenericApiResponse<CardPaymentResponseModel>> NewCustomerPaymentAsync(
							NewCustomerPaymentRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<CardPaymentResponseModel>> NewCustomerPaymentV2Async(
							NewCustomerPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<CardPaymentResponseModel>> Resume3DTransactionAsync(
							Resume3DPaymentRequest request, Resume3DPaymentDataRequest data);
		Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoTopupWithCardResume3DTransactionAsync(
							Resume3DPaymentRequest request, Resume3DPaymentDataRequest data);
		Task<GenericApiResponse<CardPaymentResponseModel>> Resume3DTransactionV2Async(
							Resume3DPaymentRequest request, Resume3DPaymentDataRequestV2 data);
		Task<GenericApiResponse<CardPaymentResponseModel>> ExistingCardPaymentAsync(ExistingCardPaymentRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<CardPaymentResponseModel>> ExistingCardPaymentV2Async(ExistingCardPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<CardPaymentResponseModel>> ActivateBundleDefaultCardPaymentAsync(ActivateBundleRequestModel model, string msisdn, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPaymentAsync(PaypalPaymentRequestModel model, string msisdn, string currency, string ipAddress, string advertiserID);
		Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalByPay360PaymentCallBackAsync(
																					  PaypalByPay360PaymentCallBackRequestModel model);
		Task<GenericApiResponse<PaypalPaymentResponseModel>> PaypalPaymentV2Async(PaypalPaymentRequestModelV2 model, string msisdn, string currency, string ipAddress, string advertiserID);
		Task<GenericApiResponse<PaypalByPay360PaymentCallBackResponseModel>> PaypalPaymentCallBackV2Async(
																					  PaypalPaymentCallbackData model);
		Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPalAsync(TransferByPayPalRequestModel model, string currency, string ipAddress, string msisdn, string advertiserID);
		Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPalV2Async(TransferByPayPalRequestModelV2 model, string currency, string ipAddress, string msisdn, string advertiserID);
		Task<GenericApiResponse<InternationalTopupInfo>> TransferByPayPalCallbackAsync(TransferByPaypalCallBackRequestModel model);
		Task<GenericApiResponse<InternationalTopupInfo>> TransferByPayPalCallbackV2Async(PaypalPaymentCallbackData model);
		Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCardAsync(TransferByNewCustomerRequestModel model, string currency, string ipAddress, string msisdn, string email, string advertiserID);
		Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCardAsync(TransferByExistingCustomerRequestModel model, string currency, string ipAddress, string msisdn, string email, string advertiserID);
		Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCardV2Async(TransferByNewCustomerRequestModelV2 model, string currency, string ipAddress, string msisdn, string email, string advertiserID);
		Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCardV2Async(TransferByExistingCustomerRequestModelV2 model, string currency, string ipAddress, string msisdn, string email, string advertiserID);

		Task<GenericApiResponse<InternationalTopupInfo>> TransferByCardResume3DTransactionCallbackAsync(TransferByPay360Resume3DData data, Resume3DPaymentRequest request);
		Task<GenericApiResponse<InternationalTopupInfo>> TransferByCardResume3DTransactionCallbackV2Async(TransferByPay360Resume3DDataV2 data, Resume3DPaymentRequest request, string userAccountId);
        Task<GenericApiResponse<PaymentMethodsPayload>> GetCustomerCards(
                            Pay360CustomerRequestModel request);
        Task<GenericApiResponse<Pay360PaymentAmountResponse>> GetPaymentAmounts(string currency, string msisdn, string email);
        Task<GenericApiResponse<Pay360PaymentAmountResponseV2>> GetPaymentAmountsV2(string currency, string msisdn, string email, string accountTopupDescription);
        Task<GenericApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(GetAddressByPostCodeRequestModel model);
        Task<GenericApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency, string email);
        Task<GenericApiResponse<bool>> SetAutoTopUpV2(SetAutoTopUpRequestModel model, string msisdn, string currency, string email);
        Task<GenericApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn, string email);
        Task<GenericApiResponse<bool>> SetDefaultCard(string msisdn, SetDefaultCardUserRequest request);
        Task<GenericApiResponse<bool>> RemoveCard(string msisdn, string account, RemoveCardUserRequest request);
		Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoTopupWithCard(SetAutoTopupWithCardRequestModel model, string msisdn, string accountId, string currency, string ipAddress, string email, string advertiserID);
		Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoBundleRenewalWithCard(SetAutoRenewalCardRequestModel model, string msisdn, string accountId, string currency, string ipAddress, string email, string advertiserID);
        Task<GenericApiResponse<CardPaymentResponseModel>> SetAutoBundleRenewalCardResume3DTransactionAsync(
                            Resume3DPaymentRequest request, Resume3DPaymentDataRequest data);

    }
}
