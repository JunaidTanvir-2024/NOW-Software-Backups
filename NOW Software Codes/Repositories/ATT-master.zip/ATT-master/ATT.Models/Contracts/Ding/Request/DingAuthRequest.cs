﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Request
{
    public class DingAuthRequest
    {
        public string AuthApiEndPoint { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
        public string grant_type { get; set; }
    }
}
