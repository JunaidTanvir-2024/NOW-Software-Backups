﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    
    public class InAppPurchaseOptions
    {
        public IList<InAppPurchase> inAppPurchase { get; set; }

        public string Ivr { get; set; }

        public bool Voucher { get; set; }

        public IList<PaymentButtons> Buttons { get; set; }

    }

    public class IOSversion
    {
        public string Version { get; set; }
    }

    public class InAppPurchase
    {
        private string id;

        public string Id
        {
            get
            {
                return $"{this.Currency}_{this.Credit}";
            }
        }

        public string Currency { get; set; }

        public string Credit { get; set; }
    }

    public class ValidateResponse2
    {

        public int errorCode { get; set; }
        public bool isValid { get; set; }
        public string errorMessage { get; set; }

    }


    public class ValidateResponse
    {
        public int errorCode { get; set; }
        public bool isValid { get; set; }
        public string errorMessage { get; set; }
    }
}
