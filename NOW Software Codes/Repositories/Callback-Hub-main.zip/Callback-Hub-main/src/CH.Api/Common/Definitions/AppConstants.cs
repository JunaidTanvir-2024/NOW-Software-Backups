namespace CH.Api.Common.Definitions;

public class AppConstants
{
    public static class ContentTypes
    {
        public const string ApplicationJson = "application/json";
    }
    public static class DatabaseConnections
    {
        public const string CallbackHub = "CallbackHub";
    }
    public static class SecurityHeaders
    {
        public const string XFrameOptions = "X-FrameOptions";
        public const string XContentTypeOptions = "X-Content-Type-Options";
        public const string ReferrerPolicy = "Referrer-Policy";
        public const string PermissionsPolicy = "Permissions-Policy";
        public const string SameSite = "SameSite";
        public const string XXSSProtection = "X-XSS-Protection";
        public const string ContentPolicy = "ContentPolicy";
    }
    public static class StatusCodes
    {
        public const int InternalServerError = Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError;
    }
}
