﻿using Application.Common.Enums;
using Application.Common.Models.ResponseWrappers;
using Application.Common.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using NowMobile.Api.Filters;

namespace NowMobile.Api.Filters;

public class BasicAuthFilter : Attribute, IAsyncResourceFilter
{
    #region Fields

    private readonly IStringLocalizer<ValidateModelStateAttribute> _localizer;
    private readonly BasicAuthSetting _basicAuth;

    #endregion

    #region Ctors
    public BasicAuthFilter(IStringLocalizer<ValidateModelStateAttribute> localizer, IOptions<BasicAuthSetting> basicAuth)
    {
        _localizer = localizer;
        _basicAuth = basicAuth.Value;
    }

    #endregion

    #region Method

    public async Task OnResourceExecutionAsync(ResourceExecutingContext context, ResourceExecutionDelegate next)
    {
        try
        {
            var attribute = context.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousAttribute>();
            if (attribute != null)
            {
                await next();
            }
            else
            {
                string authHeader = context.HttpContext.Request.Headers["NowtelAuth"];
                if (authHeader == null)
                {
                    context.Result = new JsonResult(Result<object>.Failure(
                     _localizer.GetString(CustomStatusKey.Unauthorized),
                     CustomStatusCode.Unauthorized))
                    { StatusCode = 401 };
                }

                //var authHeaderValue = AuthenticationHeaderValue.Parse(authHeader);
                var credentials = Encoding.UTF8
                                    .GetString(Convert.FromBase64String(authHeader!))
                                    .Split(':', 2);
                if (credentials.Length == 2)
                {
                    string username = _basicAuth.UserName!;
                    string password = _basicAuth.Password!;

                    if (credentials[0].Equals(username) && credentials[1].Equals(password))
                    {
                        await next();
                    }
                    else
                    {
                        context.Result = new JsonResult(Result<object>.Failure(
         _localizer.GetString(CustomStatusKey.Unauthorized),
         CustomStatusCode.Unauthorized))
                        { StatusCode = 401 };
                    }
                }
            }
        }
        catch
        {
            context.Result = new JsonResult(Result<object>.Failure(
          _localizer.GetString(CustomStatusKey.Unauthorized),
          CustomStatusCode.Unauthorized))
            { StatusCode = 401 };
        }


    }
}

#endregion

public static class BasicAuthFilterExtensions
{
    public static void AddBasicAuthFilter(this FilterCollection filter) => filter.Add<BasicAuthFilter>();
}

