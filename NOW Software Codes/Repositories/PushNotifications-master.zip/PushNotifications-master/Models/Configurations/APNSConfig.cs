﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class APNSConfig
    {
        public string P8privateKey { get; set; }
        public string P8privateKeyId { get; set; }
        public string TeamId { get; set; }
        public string AppBundleIdentifier { get; set; }
    }
}
