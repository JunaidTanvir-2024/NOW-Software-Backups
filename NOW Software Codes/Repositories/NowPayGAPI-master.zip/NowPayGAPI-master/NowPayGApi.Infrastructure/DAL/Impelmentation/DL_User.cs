﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.DbConnections;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.DAL.Impelmentation
{
    public class DL_User : IDL_User
    {
        private readonly IDbConnectionSettings Db;

        public DL_User(IOptions<ConnectionString> connectionString)
        {
            Db = new DbConnectionSettings(new SqlConnection(connectionString.Value.NowPaygDbConnection));
        }

        public async Task<DBUser> Login(DBUser model)
        {
            DBUser result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@Password", model.Password);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("NowPayG_Api_Login", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> Register(DBUser model)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@Password", model.Password);
                parameters.Add("@CountryId", model.CountryId);
                parameters.Add("@Firstname", model.FirstName);
                parameters.Add("@Lastname", model.LastName);
                parameters.Add("@Role", model.Role);
                parameters.Add("@MailSubscription", model.MailSubscription);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("NowPayG_Api_RegisterUser", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> RegisterSocialMediaUser(DBUser model)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", model.Email);
                parameters.Add("@Firstname", model.FirstName);
                parameters.Add("@Lastname", model.LastName);
                parameters.Add("@SocialSignUpTypeId", model.SocialSignUpTypeId);
                parameters.Add("@Role", model.Role);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("NowPayG_Api_RegisterSocialMediaUser", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> InsertUserToken(DBUserTokens model)
        {
            int result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", model.Token);
                parameters.Add("@TokenTypeId", model.TokenTypeId);
                parameters.Add("@UserId", model.UserId);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<int>("NowPayG_Api_InsertToken", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<DBResult<int>> VerifyEmailByToken(string token, int expiryHours, int tokenTypeId)
        {
            DBResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);
                parameters.Add("@ExpiryHours", expiryHours);
                parameters.Add("@TokenTypeId", tokenTypeId);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBResult<int>>("NowPayG_Api_VerifyEmailByToken", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<DBResult<int>> UpdateUserPassword(string token, int expiryHours, string password)
        {
            DBResult<int> result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Token", token);
                parameters.Add("@ExpiryHours", expiryHours);
                parameters.Add("@Password", password);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBResult<int>>("NowPayG_Api_UpdateUserPassword", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> IsUserExistByEmail(string email)
        {
            DBUser result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("NowPayG_Api_IsUserExistByEmail", parameters, commandType: CommandType.StoredProcedure);
                if (result != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<DBUser> GetUserByEmail(string email)
        {
            DBUser result;
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Email", email);

                result = await Db.SqlConnection.QueryFirstOrDefaultAsync<DBUser>("NowPayG_Api_GetUserByEmail", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveUserAddress(DBUserAddress model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserID", model.UserId);
                parameters.Add("@AddressLine1", model.AddressLine1);
                parameters.Add("@AddressLine2", model.AddressLine2);
                parameters.Add("@IsDefaultAddress", model.IsDefaultAddress);
                parameters.Add("@City", model.City);
                parameters.Add("@PostCode", model.PostCode);
                parameters.Add("@Country", model.CountryId);
                parameters.Add("@County", model.County);
                parameters.Add("@AddressType", (int)model.AddressType);

                var result = await Db.SqlConnection.QuerySingleOrDefaultAsync<int>("NowPayG_Api_SaveUserAddress", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveUserSIMOrder(DBUserSIMOrder model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserID", model.UserId);
                parameters.Add("@UserAddressID", model.UserAddessId);
                parameters.Add("@ProductID", (int)model.Product);
                parameters.Add("@IsReplacement", model.IsReplacement);

                var result = await Db.SqlConnection.QuerySingleOrDefaultAsync<int>("NowPayG_Api_SaveUserSimOrder", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveUserProduct(Models.DAOs.DBUserProduct model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@MobileNumber", model.ProductRef);
                parameters.Add("@UserId", model.UserId);
                parameters.Add("@ProductId", (int)model.ProductId);
                parameters.Add("@AccountId", model.AccountId);

                parameters.Add("@IsAlreadyExists", DbType.Int32, direction: ParameterDirection.Output);

                await Db.SqlConnection.QuerySingleOrDefaultAsync<int>("NowPayG_Api_SaveUserProducts", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@IsAlreadyExists");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<IEnumerable<DBUserProduct>> GetAllProductsByUserID(Models.DAOs.DBUserProduct model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", model.UserId);

                var result = await Db.SqlConnection.QueryAsync<DBUserProduct>("NowPayG_Api_GetAllProductsByUserID", parameters, commandType: CommandType.StoredProcedure);
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> UpdateMailSubscription(DBUser model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@UserId", model.Id);
                parameters.Add("@StatusID", model.MailSubscription);

                var result = await Db.SqlConnection.ExecuteAsync("NowPayG_Api_UpdateMailSubscription", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> ChangeAccountPassword(ChangePasswordRequestModel model)
        {
            try
            {
                var parameters = new DynamicParameters();

                parameters.Add("@NewPassword", model.NewPassword);
                parameters.Add("@OldPassword", model.OldPassword);
                parameters.Add("@UserId", model.UserID);

                var result = await Db.SqlConnection.QuerySingleOrDefaultAsync<int>("NowPayG_Api_ChangeAccountPassword", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> VerifyUserEmail(string email)
        {
            try
            {
                var parameters = new DynamicParameters();
                
                parameters.Add("@Email", email);

                var result = await Db.SqlConnection.QuerySingleOrDefaultAsync<int>("NowPayG_Api_VerifyUserEmail", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
