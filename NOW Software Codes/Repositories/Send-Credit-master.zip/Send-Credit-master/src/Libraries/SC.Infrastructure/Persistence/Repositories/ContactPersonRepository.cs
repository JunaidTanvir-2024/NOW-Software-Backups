﻿using Microsoft.Extensions.Configuration;

using SC.Core.Common.DTOs.CustomerOrder;
using SC.Core.Models.Dtos;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Infrastructure.Persistence.Repositories
{
    public class ContactPersonRepository : IContactPersonRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public ContactPersonRepository(IConfiguration configuration, ILogger logger)
        {
            this._configuration = configuration;
            this._logger = logger;
        }

        public async Task<List<ContactPersonDto>> GetContactPersons(GetContactPersonDto.Request request)
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var table = new DataTable();
                    table.Columns.Add("first_name", typeof(string));
                    table.Columns.Add("last_name", typeof(string));
                    table.Columns.Add("email", typeof(string));
                    table.Columns.Add("mobile_no", typeof(string));
                    table.Rows.Add(request?.Contactfilters?.FirstName, request?.Contactfilters?.LastName, request?.Contactfilters?.Email, request?.Contactfilters?.MobileNo);

                    var contactParameters = new DynamicParameters();

                    contactParameters.Add("@contact_person_Filter", value: table.AsTableValuedParameter(AppConstants.TablesTypes.ContactPersonFilterType));
                    contactParameters.Add("userId", request?.UserId);

                    var contactpersons = (await connection.QueryAsync<ContactPersonDto>(AppConstants.StoreProcedures.GetContactPersons, contactParameters, commandType: CommandType.StoredProcedure)).ToList();
                    return contactpersons;
                }
                catch (Exception ex)
                {
                    _logger.Error(nameof(GetContactPersons) + ":  \n" +
                                    "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                    "StackTrace: " + ex.StackTrace);
                    return default;
                }
            }
        }

        public async Task<int> AddContactPerson(ContactPersonDto contactPersonDto)
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("user_id", contactPersonDto.UserId);
                    parameters.Add("first_name", contactPersonDto.FirstName);
                    parameters.Add("last_name", contactPersonDto.LastName);
                    parameters.Add("email", contactPersonDto.Email);
                    parameters.Add("mobile_no", contactPersonDto.MobileNo);
                    parameters.Add("created_at", DateTime.UtcNow);
                    parameters.Add("updated_at", DateTime.UtcNow);
                    parameters.Add("created_by", contactPersonDto.UserId);
                    parameters.Add("updated_by", contactPersonDto.UserId);

                    var result = await connection.ExecuteAsync(AppConstants.StoreProcedures.InsertContactPerson, parameters, commandType: CommandType.StoredProcedure);
                    return result;
                }
                catch (Exception ex)
                {
                    _logger.Error(nameof(AddContactPerson) + ":  \n" +
                                                      "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                                      "StackTrace: " + ex.StackTrace);
                    return -1;
                }
            }
        }

        public async Task<int> UpdateContactPerson(ContactPersonDto contactPersonDto)
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("id", contactPersonDto.Id);
                    parameters.Add("first_name", contactPersonDto.FirstName);
                    parameters.Add("last_name", contactPersonDto.LastName);
                    parameters.Add("email", contactPersonDto.Email);
                    parameters.Add("mobile_no", contactPersonDto.MobileNo);
                    parameters.Add("updated_at", DateTime.UtcNow);
                    parameters.Add("updated_by", contactPersonDto.UpdatedBy);

                    var result = await connection.ExecuteAsync(AppConstants.StoreProcedures.UpdateContactPerson, parameters, commandType: CommandType.StoredProcedure);

                    return result > 0 ? result : -1;
                }
                catch (Exception ex)
                {
                    _logger.Error(nameof(UpdateContactPerson) + ":  \n" +
                                                      "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                                      "StackTrace: " + ex.StackTrace);
                    return -1;
                }
            }
        }

        public async Task<int> DeleteContactPerson(int id)
        {
            using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.SendCredit)))
            {
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("id", id);

                    var result = await connection.ExecuteAsync(AppConstants.StoreProcedures.DeleteContactPerson, parameters, commandType: CommandType.StoredProcedure);

                    return result > 0 ? result : -1;
                }
                catch (Exception ex)
                {
                    _logger.Error(nameof(DeleteContactPerson) + ":  \n" +
                                                      "ErrorMessage: " + (ex.InnerException == null ? ex.Message : ex.Message + ". " + ex.InnerException.Message) + "," +
                                                      "StackTrace: " + ex.StackTrace);
                    return -1;
                }
            }
        }
    }
}