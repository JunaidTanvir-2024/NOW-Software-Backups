﻿using THCC.Application.Models.Dtos;
using THCC.Application.Settings;

namespace THCC.Application.Features.Payment.Card.AutoTopup.NewCard
{
    public class AutoTopupNewCardPaymentRequest : IRequest<object>
    {
        public PaymentNewCardDto PaymentCardInfo { get; set; } = default!;
        public PaymentAddressDto PaymentAddressInfo { get; set; } = default!;
        public decimal Amount { get; set; }
    }

    public class AutoTopupNewCardPaymentRequestValidator : AbstractValidator<AutoTopupNewCardPaymentRequest>
    {
        public AutoTopupNewCardPaymentRequestValidator(
            IOptions<TopupSettings> topupSettings)
        {
            RuleFor(p => p.Amount).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .NotNull()
                .Must(x => topupSettings.Value.Amounts.Any(a => a.Amount == x))
                .WithMessage("Please only use: " + string.Join(",", values: topupSettings.Value.Amounts.Select(a => a.Amount)));

            RuleFor(p => p.PaymentCardInfo.CardNumber)
                .NotEmpty()
                .NotNull()
                .MaximumLength(19)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentCardInfo.ExpiryMonth)
                .NotEmpty()
                .NotNull()
                .MinimumLength(2)
                .MaximumLength(2)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentCardInfo.ExpiryYear)
                .NotEmpty()
                .NotNull()
                .MinimumLength(2)
                .MaximumLength(2)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentCardInfo.NameOnCard)
                .NotEmpty()
                .NotNull()
                .MaximumLength(200)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentCardInfo.SecurityCode)
                .NotEmpty()
                .NotNull()
                .MinimumLength(3)
                .MaximumLength(4)
                .When(x => x.PaymentCardInfo != null);

            RuleFor(p => p.PaymentAddressInfo.AddressL1)
                .NotNull()
                .NotEmpty()
                .MaximumLength(1000)
                .When(x => x.PaymentAddressInfo != null);

            RuleFor(p => p.PaymentAddressInfo.City)
                .NotNull()
                .NotEmpty()
                .MaximumLength(100)
                .When(x => x.PaymentAddressInfo != null);

            RuleFor(p => p.PaymentAddressInfo.PostCode)
                .NotNull()
                .NotEmpty()
                .MaximumLength(9).WithMessage("Your post code length must not exceed 9.")
                .When(x => x.PaymentAddressInfo != null);

            RuleFor(p => p.PaymentAddressInfo.CountryCode)
                .NotNull()
                .NotEmpty()
                .MaximumLength(5)
                .When(x => x.PaymentAddressInfo != null);
        }
    }
}

