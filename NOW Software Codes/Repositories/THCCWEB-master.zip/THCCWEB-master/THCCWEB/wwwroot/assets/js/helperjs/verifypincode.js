﻿$(document).ready(function () {
  
    $("#verifyPinCode").click(function (event) {
        if (!$("#fastTopUp").valid()) return
        var model = {};
        model.pin = $("#pinCode").val();
        $.ajax({
            beforeSend: function () {
                loader.btnloadershow(event);
            },
            type: "POST",
            url: "/Account/VerifyPinNumber",
            data: model,
            async: true,
            success: function (json) {
                if (json.errorCode == 0) {
                    $("#fastTopUp").submit();
                    return;
                } else {
                    $('#errorMessage').show();
                    return;
                }
            },
            error: function (error) {
                return;
            }
            , complete: function () {
                loader.btnloaderhide(event);
            }
        });
    });
});
