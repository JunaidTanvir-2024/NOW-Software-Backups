﻿using Infrastructure.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Models.Contracts.Request;
using Models.Contracts.Response;
using THAApi.Utilities;
using Infrastructure.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    [Route("topup")]
    public class TopupController : Controller
    {
        private readonly ITopup_BL TopupBL;

        public TopupController(ITopup_BL topup_BL)
        {
            TopupBL = topup_BL;
        }

        [HttpGet]
        [Route("GetLastTopUp")]
        public async Task<IActionResult> GetLastTopUp()
        {
            return Ok(await TopupBL.GetLastTopUp(User.Account(), User.Msisdn(), User.Email()));
        }

        [HttpGet]
        [Route("GetTopUpPaymentHistory")]
        public async Task<IActionResult> GetTopUpPaymentHistory()
        {
            return Ok(await TopupBL.GetTopUpPaymentHistory(User.Account()));
        }

        [HttpPost]
        [Route("ios/verifyreceipt")]
        public async Task<IActionResult> VerifyInAppPurchaseReceipt([FromBody] VerifyReceiptRequest request)
        {
            request.Msisdn = User.Msisdn();
            //request.Pin = ((BasicAuthenticationIdentity)this.User.Identity).Pin;
            return Ok(await TopupBL.VerifyInAppPurchaseReceipt(request));
        }

        [HttpPost]
        [Route("validate/{typePayment}")]
        public async Task<IActionResult> Validate(string typePayment)
        {
            return Ok(await TopupBL.ValidateCustomer(User.Msisdn(), typePayment));
        }

        [HttpPost]
        [Route("voucher")]
        public async Task<IActionResult> Voucher([FromBody] VoucherTopupRequest request)
        {
            request.advertiserID = HttpContext.GetAdvertiserID();
            var result = await TopupBL.VoucherTopup(request);

            var response = (VoucherTopupResponse)result.Payload;

            if (!String.IsNullOrEmpty(response?.CreditApplied) && (response.BalanceBefore != response.BalanceAfter))
            {
                return Ok(new
                {
                    result = "success",
                    balancebefore = response.BalanceBefore,
                    balanceafter = response.BalanceAfter,
                    creditapplied = response.CreditApplied,
                    currency = response.Currency
                });
            }

            return Ok(new
            {
                result = "failed",
                balancebefore = response.BalanceBefore,
                balanceafter = response.BalanceAfter,
                creditapplied = response.CreditApplied,
                currency = response.Currency
            });
        }

        [HttpGet]
        [Route("android/options")]
        public async Task<IActionResult> GetAndroidOptions()
        {
            return Ok(await TopupBL.GetAndroidPurchaseOptions(User.Msisdn()));
        }

        [Route("ios/options/1")]
        [HttpPost]
        public async Task<IActionResult> GetIosOptions1(IOSversion IosVersion)
        {
            string version = "";
            if (IosVersion != null)
                version = IosVersion.Version;

            return Ok(await TopupBL.GetInAppIosPurchaseOptions1(User.Msisdn(), version));
        }
    }
}































































































