﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Serilog;
using System.IO;
using SmsOutReachCallBackUrlApi.Models.Configurations;
using System.Data;
using SmsOutReachCallBackUrlApi.Models.Connections;
using SmsOutReachCallBackUrlApi.Infrastructure.Xeebi;
using SmsOutReachCallBackUrlApi.Models.Middleware;
using SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts;
using SmsOutReachCallBackUrlApi.Infrastructure.Sap;

namespace SmsOutReachCallBackUrlApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton((ILogger)new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.RollingFile(Path.Combine(Configuration.GetSection("Serilog")["FilePath"], "SmsOutReachCallBackUrlApi-log-{Date}.txt"))
            .CreateLogger());

            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionStrings"));
            services.Configure<SerilogConfig>(Configuration.GetSection("Serilog"));
            services.AddTransient(typeof(IDbConnection), typeof(DbConnectionSettings));
            services.AddTransient(typeof(IXeebiDb), typeof(XeebiDb));
            services.AddTransient(typeof(IXeebiPost), typeof(XeebiPost));
            services.AddTransient(typeof(IPoppayoutsDb), typeof(PoppayoutsDb));
            services.AddTransient(typeof(IPoppayoutsPost), typeof(PoppayoutsPost));
            services.AddTransient(typeof(ISapDb), typeof(SapDb));
            services.AddTransient(typeof(ISapPost), typeof(SapPost));
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            // Logging middleware for capturing response time and other Request & Response details
            app.UseMiddleware<DogStatsDMiddleware>();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();
            
            
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    "PoppayoutsSmsCallBackUrl",
                    "PoppayoutsSmsCallBackUrl",
                    defaults: new { controller = "Poppayouts", action = "SmsCallBackUrl" }
                    );
                routes.MapRoute(
                    "XeebiSmsCallBackUrl",
                    "smsreport",
                    defaults: new { controller= "Xeebi", action= "SmsCallBackUrl" }
                    );
                routes.MapRoute(
                    "SapSmsCallBackUrl",
                    "SapSmsCallBackUrl",
                    defaults: new { controller = "Sap", action = "SmsCallBackUrl" }
                    );
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
