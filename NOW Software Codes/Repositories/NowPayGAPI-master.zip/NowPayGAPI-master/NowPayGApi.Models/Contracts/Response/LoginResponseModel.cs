﻿using Newtonsoft.Json;
using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class LoginResponseModel
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public int CountryId { get; set; }
        public string Email { get; set; }
        //[JsonIgnore]
        public Roles Role { get; set; }
        public IEnumerable<UserProductsResponseModel> ProductList { get; set; }
    }
}
