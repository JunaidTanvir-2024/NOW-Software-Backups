namespace FH.Core.Extensions.DTOs;
/// <summary>
/// It will be used to handle exceptional cases occured in dual behaviors properties while deserializing amounts
/// </summary>
public sealed class RangeObject
{
    public decimal Value { get; set; }
    public decimal Min { get; set; }
    public decimal Max { get; set; }
}
