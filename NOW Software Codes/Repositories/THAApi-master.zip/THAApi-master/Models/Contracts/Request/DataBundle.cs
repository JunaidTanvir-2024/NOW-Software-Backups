﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
   
    public class DataBundle
    {
        public string recipientNumber { get; set; }
    }

    public class DataBundleDetail
    {
        public string id { get; set; }
        public string name { get; set; }
        public int country_id { get; set; }
        public string country { get; set; }
        public string nowtelTransactionReference { get; set; }
        public string iconUri { get; set; }
        public string ProductApiType { get; set; }
        public List<DataBundleProductList> products { get; set; }

    }

    public class DataBundlesProducts
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public int servcieproviderid { get; set; }
        public DataBundlesOperatorProducts payload { get; set; }
    }

    public class DataBundlesOperatorProducts
    {
        public List<DataBundleDetail> operators { get; set; }
    }

    public class DataBundleProductList
    {
        public int ProductId { get; set; }
        public string Product { get; set; }
        public string ProductDesc { get; set; }
        public string ProductInternal { get; set; }
        public string ProductInternalDesc { get; set; }
        public string AccountCurrency { get; set; }
        public string ProductCurrency { get; set; }
        public double WholeSalePrice { get; set; }
        public double CalculatedRetailPrice { get; set; }
        public double TransactionFee { get; set; }
        public double CustomerChargePrice { get; set; }
        public string BundleVolume { get; set; }
        public string ExpiryDays { get; set; }
        public string Extra { get; set; }
        public string LocalMinutes { get; set; }
        public string InternationalMinutes { get; set; }
        public string LocalSms { get; set; }
        public string InternationalSms { get; set; }
        public string FacebookData { get; set; }
        public string TwitterData { get; set; }
        public string InstragramData { get; set; }
        public string ProductDisplay { get; set; }
    }


    public class DataBundleExecute
    {
        [Required]
        public string sender_number { get; set; }
        [Required]
        public int operator_id { get; set; }
        [Required]
        public string productType { get; set; }
        [Required]
        public string productValue { get; set; }
        [Required]
        public string nowtelTransactionReference { get; set; }
        public string sender_sms_notification { get; set; }
        public string sender_sms_text { get; set; }
        public string recipient_sms_notification { get; set; }
        public string recipient_sms_text { get; set; }
        public DataBundleSender sender { get; set; }
        public DataBundleRecipient recipient { get; set; }

    }

    public class DataBundleExecuteReq
    {
        [Required]
        public int operator_id { get; set; }
        [Required]
        public string productType { get; set; }
        [Required]
        public string productValue { get; set; }
        [Required]
        public string nowtelTransactionReference { get; set; }
        public string messageToRecipient { get; set; }

    }




    public class DataBundleExecuetReponse
    {
        public string reference { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }

    }

    public class DataBundleData
    {
        public DataBundleExecuetReponse data { get; set; }
    }

    public class DataBundleExecuetSrvReponse
    {
        public int errorCode { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public string reference { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
    }

    public class DataBundleExecuteSrvReponse
    {
        public int errorCode { get; set; }
        public string status { get; set; }
        public string message { get; set; }
        public DataBundleData payLoad { get; set; }
    }


    public class DataBundlePayLoad
    {
        public string reference { get; set; }
        public string amount { get; set; }
        public string currency { get; set; }
    }


    public class DataBundleSender
    {
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string first_name { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
    }

    public class DataBundleRecipient
    {
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string first_name { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
    }

    public class Error
    {
        public int code { get; set; }
        public string message { get; set; }
    }

    public class DataBundleSummary
    {
        public string NowtelTransactionReference { get; set; }
        public double WholeSalePrice { get; set; }
        public double CalculatedRetailPrice { get; set; }
        public double TransactionFee { get; set; }
        public double CustomerChargePrice { get; set; }
    }


    public class DataBundleRecord
    {
        public string NowtelTransactionReference { get; set; }
        public string Clientccy { get; set; }
        public string Receiverccy { get; set; }
        public string Product { get; set; }
        public string ProductDesc { get; set; }
        public double WholeSalePrice { get; set; }
        public double CalculatedRetailPrice { get; set; }
        public double TransactionFee { get; set; }
        public double CustomerChargePrice { get; set; }
        public string ToMsisdn { get; set; }
    }

    public class DataBundleBalance
    {
        public decimal new_balance { get; set; }
        public int audit_id { get; set; }
    }
}
