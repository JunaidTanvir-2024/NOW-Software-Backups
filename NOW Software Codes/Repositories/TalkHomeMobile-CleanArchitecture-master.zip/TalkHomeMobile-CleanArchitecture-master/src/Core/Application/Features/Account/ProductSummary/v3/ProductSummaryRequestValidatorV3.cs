﻿namespace Application.Features.Account.ProductSummary.v3;
public class ProductSummaryRequestValidatorV3 : AbstractValidator<ProductSummaryRequestV3>
{
    public ProductSummaryRequestValidatorV3(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");
    }
}