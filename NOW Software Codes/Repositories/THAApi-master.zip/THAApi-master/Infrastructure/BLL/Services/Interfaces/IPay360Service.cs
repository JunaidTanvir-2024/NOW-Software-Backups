﻿using Models.Contracts.Request;
using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface IPay360Service
    {
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType);
        Task<GenericPay360ApiResponse<GetAddressByPostCodeResponseModel>> GetAddressByPostCode(GetAddressByPostCodeRequestModel model);
        Task<GenericPay360ApiResponse<bool>> SetAutoTopUp(SetAutoTopUpRequestModel model, string msisdn, string currency, string email);
        Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(string msisdn, string email);
        Task<GenericPay360ApiResponse<PaymentMethodsPayload>> GetPaymentMethods(string msisdn);
        Task<GenericPay360ApiResponse<bool>> SetDefaultCard(string msisdn, SetDefaultCardUserRequest defaultCardReq);
        Task<GenericPay360ApiResponse<RemoveAllPaymentMethodsResponse>> RemoveAllCardsAsync(string msisdn);
        Task<GenericPay360ApiResponse<bool>> RemoveCard(string msisdn, RemoveCardUserRequest removeCardReq);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DV1Transaction(Pay360Resume3DRequest request);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DV2Transaction(Pay360Resume3DRequest request);
        Task<GenericPay360ApiResponse<RefundFullPaymentResponseModel>> RefundFullPayment(RefundFullPaymentRequestModel request);
        Task<GenericPay360ApiResponse<CaptureTransactionResponseModel>> CaptureTransaction(CaptureTransactionRequestModel model);
        Task CancelTransaction(CancelTransactionRequestModel model);
    }
}
