﻿namespace Application.Features.Account.Product.AddResend;
public class AddProductResendRequestValidator : AbstractValidator<AddProductResendRequest>
{
    public AddProductResendRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.Alias).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull();
    }
}
