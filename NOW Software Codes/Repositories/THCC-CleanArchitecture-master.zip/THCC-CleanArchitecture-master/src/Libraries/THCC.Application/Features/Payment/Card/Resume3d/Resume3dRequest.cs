﻿namespace THCC.Application.Features.Payment.Card.Resume3d;

public class Resume3dRequest : IRequest<object>
{
    public string TransactionId { get; set; } = default!;
    public long OrderId { get; set; }
}

public class Resume3dRequestValidator : AbstractValidator<Resume3dRequest>
{
    public Resume3dRequestValidator()
    {
        RuleFor(p => p.TransactionId)
            .NotNull()
            .NotEmpty();
    }
}