﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class GetUserInfoRequestModel
    {
        public int UserId { get; set; }
    }
}
