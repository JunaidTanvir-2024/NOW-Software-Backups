﻿using Application.Common.Extensions.DependencyResolver;
using Application.Features.Sim;
using Domain.Aggregate;

namespace Application.Common.Interfaces.Repositories;

public interface ISimRepository : IServicesType.IScopedService
{
    Task<int> ValidateSimOrder(string email, string addressL1, string postCode, string IpAddress);
    Task<int> FreeSimOrder(FreeSimOrder model, MediumType MediumType);
    Task<long> CreditSimOrder(CreditSimOrder model, MediumType MediumType);
    Task UpdateCreditSimOrderItem(long itemId, long creditSimOrderId, float amount, string bundleUUId);
    Task RemoveCreditSimOrderItem(long itemId);
    Task<IEnumerable<CreditSimOrderDetail>> GetCreditSimOrderDetails(long creditSimOrderId);
    Task UpdatePortInNumbersInCreditSimOrder(string newNumber, string oldNumber);
    Task<int> AddReplacementSimOrder(SimAddressInfo model, string msisdn, long userId);
    Task<int> PortInSimOrder(FreeSimOrder model);
    Task<DbResult<string>> UpdateCreditSimPayment(
            long userId,
            long orderId,
            PaymentMethod paymentMethod,
            string transactionId,
            bool isPaymentSuccess,
            string errorMessage,
            string errorCode,
            bool dontGenerateMsisdn=false);
    Task<bool> IsCreditSimAvailableInPool();
    Task<bool> ValidatePostCodeRequest(string? email, string postCode, string ipAddress, string token);
}
