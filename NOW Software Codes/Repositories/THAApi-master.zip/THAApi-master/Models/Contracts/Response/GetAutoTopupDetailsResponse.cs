﻿using Models.Enums;

namespace Models.Contracts.Response
{
	public class GetAutoTopupDetailsResponse
	{
        public UserAutoTopupDetails UserAutoTopup { get; set; }
        public AutoTopupOptionDetails AutoTopupOptions { get; set; }
        public class UserAutoTopupDetails
		{
			public bool Status { get; set; }
			public float Threshold { get; set; }
			public float TopupAmount { get; set; }
			public PaymentMethods PaymentMethod { get; set; }
			public string CardMaskedPAN { get; set; }
			public bool LastAutoTopupFailed { get; set; }
			public float MaximumSpendLimit { get; set; }
		}
		public class AutoTopupOptionDetails
		{
			public string[] TopupAmounts { get; set; }
			public string[] ThresholdAmounts { get; set; }
        }
	}
}
