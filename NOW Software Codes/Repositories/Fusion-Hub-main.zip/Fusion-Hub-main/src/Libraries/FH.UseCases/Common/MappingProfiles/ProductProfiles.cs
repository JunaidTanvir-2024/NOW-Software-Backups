using FH.Core.DTOs.Database;
using FH.UseCases.Products;

using Mapster;

namespace FH.UseCases.Common.MappingProfiles;

public class ProductResponseProfile : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        // Handler Query & Response should be as destination and DTOs Request & Responses should be on the right

        config.NewConfig<GetProducts.Response, ProductDto.Response>()
        .TwoWays()
        .Map(des => des.ProductId, src => src.Product.ProductId)
        .Map(des => des.ProductName, src => src.Product.ProductName)
        .Map(des => des.ProductAliasName, src => src.Product.ProductAliasName)
        .Map(des => des.Description, src => src.Product.Description)
        .Map(des => des.Logo, src => src.Product.Logo)
        .Map(des => des.ValidityUnit, src => src.Product.ValidityUnit)
        .Map(des => des.ValidityValue, src => src.Product.ValidityValue)
        .Map(des => des.VendorProductCode, src => src.Product.VendorProductCode)
        .Map(des => des.VendorOperatorCode, src => src.Product.VendorOperatorCode)
        .Map(des => des.ProductType, src => src.Product.ProductType)

        .Map(des => des.OperatorName, src => src.Product.ProductOperator.OperatorName)
        .Map(des => des.OperatorDescription, src => src.Product.ProductOperator.OperatorDescription)

        .Map(des => des.CountryName, src => src.Product.ProductCountry.CountryName)
        .Map(des => des.CountryIsoCode2, src => src.Product.ProductCountry.CountryIsoCode2)
        .Map(des => des.CountryIsoCode3, src => src.Product.ProductCountry.CountryIsoCode3)
        .Map(des => des.Continent, src => src.Product.ProductCountry.Continent)
        .Map(des => des.CallingCode, src => src.Product.ProductCountry.CallingCode)

        .Map(des => des.CurrencyName, src => src.Product.ProductCurrency.CurrencyName)
        .Map(des => des.CurrencyCode, src => src.Product.ProductCurrency.CurrencyCode)
        .Map(des => des.CurrencyIsDefault, src => src.Product.ProductCurrency.CurrencyIsDefault)

        .Map(des => des.CategoryName, src => src.Product.ProductCategory.CategoryName)
        .Map(des => des.CategoryDescription, src => src.Product.ProductCategory.CategoryDescription)

        .Map(des => des.SubCategoryName, src => src.Product.ProductSubCategory.SubCategoryName)
        .Map(des => des.SubCategoryDescription, src => src.Product.ProductSubCategory.SubCategoryDescription)

        .Map(des => des.VendorName, src => src.Product.ProductVendor.VendorName)
        .Map(des => des.VendorDescription, src => src.Product.ProductVendor.VendorDescription)

        .Map(des => des.SellingPrice, src => src.Product.ProductPrice.SellingPrice)
        .Map(des => des.Tax, src => src.Product.ProductPrice.Tax)
        .Map(des => des.Fee, src => src.Product.ProductPrice.Fee)
        .Map(des => des.MaxPrice, src => src.Product.ProductPrice.MaxPrice)
        .Map(des => des.MinPrice, src => src.Product.ProductPrice.MinPrice)

        .Map(des => des.ProductBenefitsJson, src => src.Product.ProductBenefitsJson);
    }
}
