﻿using THCC.Application.Settings;

namespace THCC.Application.Features.TrustPilot
{
    public class RatingRequestHandler : IRequestHandler<RatingRequest, TrustPilotSettings>
    {
        private readonly TrustPilotSettings _trustPilotSetting;

        public RatingRequestHandler(
                    IOptions<TrustPilotSettings> trustPilotSetting)
        {
            _trustPilotSetting = trustPilotSetting.Value;
        }

        Task<TrustPilotSettings> IRequestHandler<RatingRequest, TrustPilotSettings>.Handle(
                                RatingRequest request, CancellationToken cancellationToken)
        {
            return Task.FromResult(_trustPilotSetting);
        }
    }
}
