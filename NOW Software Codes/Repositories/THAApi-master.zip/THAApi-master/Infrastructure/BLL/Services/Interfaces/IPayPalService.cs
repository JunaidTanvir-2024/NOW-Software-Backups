﻿using Microsoft.Extensions.DependencyInjection;
using Models.Contracts.PaypalApiContracts;
using Models.Contracts.Response;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
	public interface IPayPalService
	{
		Task<PaypalPaymentResponse> PayPalCreateSalePayment(PaypalPaymentRequest request, PaypalPaymentCallbackData callBackData);
		Task<PaypalPaymentResponse> PayPalCreateSalePaymentWithSubscription(PaypalPaymentRequest request, bool subscriptionWithInitialSale = false);
		Task<PaypalPaymentResponse> DirectPayPalExecuteSalePayment(string customerUniqueRef, string payerId, string paymentId);
		Task<PaypalPaymentResponse> PayPalCancelSubscription(PaypalSuspendSubscriptionRequest request);
		Task<PayPalUpdateSubscriptionResponse> UpdatePayPalSubscriptionProductRef(string subscriptionId, string productRef);
	}
}
