﻿namespace ATT.Models.Constants.Enums
{
    public enum SmsStatusEnum
    {
        Pending=1,
        Error,
        Delivered
    }
}
