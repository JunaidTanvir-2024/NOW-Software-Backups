using Asp.Versioning;

namespace JM.Api.Controllers.Common;

[ApiVersion(1.0)]
public abstract class V1ApiController : BaseApiController { }

[ApiVersion(2.0)]
public abstract class V2ApiController : BaseApiController { }
