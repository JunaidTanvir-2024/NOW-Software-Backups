﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Utility
{
    public enum Roles
    {
        Guest = 1,
        User = 2,
        Admin = 3,
        Owner = 4
    }
    public enum UserTokenTypes
    {
        SignUpVerificationToken = 1,
        ForgotPasswordVerificationToken = 2
    }
    public enum LoginTypes
    {
        Google = 1,
        Facebook = 2,
        Instagram = 3,
        Twitter = 4,
        Normal = 5
    }
    public enum AddressTypes
    {
        Billing = 1,
        simOrder = 2
    }
    public enum ProductType
    {
        NowPayG = 1
    }
}
