﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Utilities
{
    public class Utility
    {
        public static string CreateBasicHeader(string Username, string Password)
        {
            return Convert.ToBase64String(
                                System.Text.ASCIIEncoding.ASCII.GetBytes(
                                    string.Format("{0}:{1}", Username, Password)));
        }
        public static string ConvertMicrosoftJsonDate(string microsoftJsonDate)
        {
            // Orignal Date Format = "/Date(1563580800000+0100)/"

            try
            {
                if (!string.IsNullOrWhiteSpace(microsoftJsonDate))
                {
                    if (microsoftJsonDate.Contains("/Date("))
                    {
                        DateTime initialDate = new DateTime(1970, 1, 1);
                        microsoftJsonDate = microsoftJsonDate.Replace("/Date(", "").Split(new char[] { '+' })[0];
                        double dateMilliseconds = Convert.ToDouble(microsoftJsonDate);
                        string returndate = initialDate.AddMilliseconds(dateMilliseconds).ToString();
                        return returndate;
                    }
                    else
                    {
                        return microsoftJsonDate;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        public static string GetJsonObjectValueByKey(string key, string jsonData)
        {
            string result = "An error occured.";
            try
            {
                // reasonMessage
                key = "\"" + key + "\"";
                int startIndex = jsonData.IndexOf(key);
                if (startIndex != -1)
                {
                    startIndex = startIndex + key.Length;
                    startIndex = jsonData.IndexOf("\"", startIndex);
                    if (startIndex != -1)
                    {
                        int endIndex = jsonData.IndexOf("\"", startIndex + 1);
                        if (endIndex != -1)
                        {
                            result = jsonData.Substring(startIndex + 1, endIndex - startIndex - 1);
                        }
                    }
                }
                else // key does not exists in jsonData
                {

                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }
    }

    public static class ExtensionMethods
    {
        public static T ToEnum<T>(this string value)
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }
    }
}
