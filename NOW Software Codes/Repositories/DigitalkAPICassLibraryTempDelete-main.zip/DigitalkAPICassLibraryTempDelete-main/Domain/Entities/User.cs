﻿namespace Domain.Entities;

public class User
{
    public long Id { get; set; }
    public string Email { get; set; } = default!;
    public byte[] Password { get; set; } = default!;
    public byte[] PasswordPrefix { get; set; } = default!;
    public byte[] PasswordSuffix { get; set; } = default!;
    public byte[] Key { get; set; } = default!;
    public byte[] IV { get; set; } = default!;
    public string Title { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public DateTime? DateOfBirth { get; set; }
    public string ContactNo { get; set; } = default!;
    public string MobileNo { get; set; } = default!;
    public bool IsSubscribedToNewsletter { get; set; }
    public int? SubscriberId { get; set; }
    public int? ClientID { get; set; }
    public int? ReturnCode { get; set; }
    public bool IsUpdated { get; set; }
    public bool IsConfirmedUser { get; set; }
    public string ConfirmationToken { get; set; } = default!;
    public bool IsActive { get; set; }
    public string Image { get; set; } = default!;
    public string? RefreshToken { get; set; }
    public DateTime? RefreshTokenExpiryTime { get; set; }
}
