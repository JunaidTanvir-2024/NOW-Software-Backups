﻿using FluentValidation;

namespace Voucherify.Api.Features.Campaigns.Requests;

internal class UpdateCampaignRequest
{
}

internal class UpdateCampaignRequestValidator : AbstractValidator<UpdateCampaignRequest>
{
    public UpdateCampaignRequestValidator()
    {

    }
}