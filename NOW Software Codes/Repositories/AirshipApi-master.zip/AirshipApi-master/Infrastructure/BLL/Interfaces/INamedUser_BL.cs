﻿using Models.Contracts;
using Models.Contracts.Airship.Request;
using Models.Contracts.Airship.Response;
using Models.Contracts.Pay360.Response;
using Models.Contracts.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Interfaces
{
    public interface INamedUser_BL
    {
        Task<GenericApiResponse<string>> NUserChannelAssociation(NUserChannelAssocRequest request);
        Task<GenericApiResponse<string>> WebNUserChannelAssociation(WebNUserChannelAssociationRequest request);
        Task<GenericApiResponse<string>> AddNUserTags(AddNUserTagsRequest request);
        Task<GenericApiResponse<ApiGetUserByIdResponse>> GetNamedUserById(GetUserByIdRequest request);
        Task<GenericApiResponse<ApiGetNamedUsersResponse>> GetNamedUsers(GetAllNamedUsersRequest request);
        Task<GenericApiResponse<string>> EmailAssociationWithNamedUser(EmailAssociationWithNamedUserRequest request);
        Task<GenericApiResponse<string>> DisassociateEmailChannelFromNamedUser(DisassociateEmailChannelFromNamedUserRequest request);
        Task<GenericApiResponse<string>> NuserChannelDisassociation(NuserChannelDisassociationRequest request);
    }
}
