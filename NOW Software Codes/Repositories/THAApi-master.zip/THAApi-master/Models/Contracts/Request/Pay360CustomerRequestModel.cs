﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class Pay360CustomerRequestModel
    {
        public string customerUniqueRef { get; set; }
        public string productCode { get; set; }
    }
}
