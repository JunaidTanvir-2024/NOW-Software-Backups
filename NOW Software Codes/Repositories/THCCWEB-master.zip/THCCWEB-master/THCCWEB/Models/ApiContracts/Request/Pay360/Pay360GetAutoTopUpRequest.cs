﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Pay360
{
    public class Pay360GetAutoTopUpRequest
    {
        public string Msisdn { get; set; }
        public string Email { get; set; }
        public string ProductCode { get; set; }
    }
}
