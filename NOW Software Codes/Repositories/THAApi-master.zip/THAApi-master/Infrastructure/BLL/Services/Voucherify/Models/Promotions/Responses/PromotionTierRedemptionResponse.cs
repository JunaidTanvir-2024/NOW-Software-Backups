using Models.Common;
using System;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses
{
    public class PromotionTierRedemptionResponse
    {

        [JsonPropertyName("")]
        public string Id { get; set; }

        [JsonPropertyName("")]
        public bool RedemptionStatus { get; set; }

        [JsonPropertyName("")]
        public DateTime? RedemptionDate { get; set; }

        [JsonPropertyName("")]
        public Metadata CustomerMetadata { get; set; }

        [JsonPropertyName("")]
        public string SourceId { get; set; }

        [JsonPropertyName("")]
        public string CustomerId { get; set; }
        //public Voucher? Voucher { get; set; }
    }
}
