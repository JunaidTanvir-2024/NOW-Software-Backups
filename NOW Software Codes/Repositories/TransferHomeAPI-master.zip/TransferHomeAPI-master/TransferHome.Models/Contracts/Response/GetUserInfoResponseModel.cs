﻿using System;
using System.Collections.Generic;
using System.Text;
using TrasnferHome.Models.Utility;

namespace TransferHome.Models.Contracts.Response
{
    public class GetUserInfoResponseModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string PinNumber { get; set; }
        public string Password { get; set; }
        public int CountryId { get; set; }
        public decimal Balance { get; set; }
        public string BalanceCurrency { get; set; }
        public string BalanceCurrencySymbol { get; set; }
        public bool IsEmailVerified { get; set; }
        public bool MailSubscription { get; set; }
        public string SignUpType { get; set; }
        public string Role { get; set; }
        public bool IsNotificationsOn { get; set; }
    }
}
