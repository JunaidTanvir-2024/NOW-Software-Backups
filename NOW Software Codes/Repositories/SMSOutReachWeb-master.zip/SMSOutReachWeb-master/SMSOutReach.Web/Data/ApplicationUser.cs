﻿using Microsoft.AspNetCore.Identity;

namespace SMSOutReach.Web.Data
{
    public class ApplicationUser:IdentityUser
    {
        public string Name { get; set; }
    }
}
