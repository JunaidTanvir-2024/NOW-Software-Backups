﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Response
{
    public class GetTopupAmountsResponseModel
    {
        public IEnumerable<TopupAmount> TopUpAmounts { get; set; }
    }
    public class TopupAmount
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public bool IsActive { get; set; }
    }
}
