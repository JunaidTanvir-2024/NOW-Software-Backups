﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Response;

namespace TalkhomeAPI.Services.Interfaces
{
    public interface ITransferService
    {
        Task<GenericApiResponse<GetProductsResponseModel>> GetProducts(string toMsisdn, string fromMsisdn, string currency);
        Task<GenericApiResponse<TransferByAccountBalanceResponseModel>> TransferByAccountBalance(
            TransferByAccountBalanceRequestModel model, string msisdn, string currency);
        Task<GenericApiResponse<GetSpecialPromotionBalanceToDeductResponseModel>> GetSpecialPromotionBalanceToDeduct(
            string msisdn, decimal amount,
            string nowtelRef=null,
			string product = null);
        Task<GenericApiResponse<TransferByPayPalResponseModel>> TransferByPayPal(
                TransferByPayPalRequestModel model, string msisdn, string currency, string account);
        Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV1(
            TransferByPayPalCallBackV1RequestModel model, string msisdn, string currency);
        Task<GenericApiResponse<TransferByPayPalCallBackResponseModel>> TransferByPayPalCallBackV2(
            TransferByPayPalCallBackV2RequestModel model, string msisdn, string currency);
        Task<GenericApiResponse<TransferByCardResponseModel>> TransferByExistingCard(
            TransferByExistingCardRequestModel model, string msisdn, string currency, string account);
        Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCustomer(
            TransferByNewCustomerRequestModel model, string msisdn, string currency, string account);
        Task<GenericApiResponse<TransferByCardResponseModel>> TransferByNewCard(
            TransferByNewCardRequestModel model, string msisdn, string currency, string account);
        Task<GenericApiResponse<TransferByCardResponseModel>> TransferByCard3dSecureCallBack(
            TransferByCardCallBackRequestModel model);
    }
}
