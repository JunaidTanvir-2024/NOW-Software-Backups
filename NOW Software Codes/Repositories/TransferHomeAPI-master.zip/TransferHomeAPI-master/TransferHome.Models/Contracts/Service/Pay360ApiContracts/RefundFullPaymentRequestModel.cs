﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Service.Pay360ApiContracts
{
    public class RefundFullPaymentRequestModel
    {
        public string transactionId { get; set; }
    }
}
