﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SmsOutReachCallBackUrlApi.Contracts.Poppayouts.Request;
using SmsOutReachCallBackUrlApi.Models;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Poppayouts
{
    public interface IPoppayoutsDb
    {
        Task<DbResult> InsertUpdateSmsCallBackUrlData(PoppayoutsSmsCallBackUrlRequest deliveryReport);
    }
}
