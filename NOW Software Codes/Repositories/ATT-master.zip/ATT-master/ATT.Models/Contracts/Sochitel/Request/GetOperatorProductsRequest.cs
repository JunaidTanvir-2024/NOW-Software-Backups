﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.Sochitel.Request
{
    public class GetOperatorProductsRequest : BaseRequest
    {
        public string command = "getOperatorProducts";

        public string @operator { get; set; }
    }
}
