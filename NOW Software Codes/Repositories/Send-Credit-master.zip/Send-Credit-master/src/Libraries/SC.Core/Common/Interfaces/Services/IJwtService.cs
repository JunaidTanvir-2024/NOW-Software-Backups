﻿namespace SC.Core.Common.Interfaces.Services;
public interface IJwtService
{
    Task<TokensDto> GetTokensAsync(ClaimDto? claimsDto);
    ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    ECDsa GetSecurityKeyViaFile(string filePath);
}

