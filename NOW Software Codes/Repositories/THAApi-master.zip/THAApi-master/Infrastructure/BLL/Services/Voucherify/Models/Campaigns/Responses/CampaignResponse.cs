using Infrastructure.BLL.Services.Voucherify.Models.Promotions.Responses;
using Models.Common;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Infrastructure.BLL.Services.Voucherify.Models.Campaigns.Responses
{
    public class CampaignResponse
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("active")]
        public bool Active { get; set; }
        [JsonPropertyName("description")]
        public string Description { get; set; }
        [JsonPropertyName("campaignType")]
        public string CampaignType { get; set; }
        [JsonPropertyName("startDate")]
        public DateTime StartDate { get; set; }
        [JsonPropertyName("expirationDate")]
        public DateTime ExpirationDate { get; set; }
        [JsonPropertyName("metadata")]
        public Metadata Metadata { get; set; }
        [JsonPropertyName("promotionTiers")]
        public List<PromotionTierResponse> PromotionTiers { get; set; }
    }
}