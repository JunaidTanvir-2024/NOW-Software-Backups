﻿using System.ComponentModel;

namespace SC.Api.Model;
public class SignInModel
{
    public string Email { get; set; }
    public string Password { get; set; }
    [DefaultValue(false)]
    public bool IsGuestUser { get; set; } = false;
    public string? UserID { get; set; } = default;
}

