namespace Voucherify.Core.Services.VoucherifyApi;

public class VoucherifySetting
{
    public const string SectionName = nameof(VoucherifySetting);
    public static VoucherifySetting Instance { get; } = new VoucherifySetting();
    public string ApiEndpoint { get; set; } = null!;
    public string AppId { get; set; } = null!;
    public string AppToken { get; set; } = null!;
}