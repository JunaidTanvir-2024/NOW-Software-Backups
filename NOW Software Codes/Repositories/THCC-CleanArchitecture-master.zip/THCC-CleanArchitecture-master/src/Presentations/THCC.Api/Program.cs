using System.Threading.RateLimiting;

using FluentValidation.AspNetCore;

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;

using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

using Serilog;

using THCC.Api;
using THCC.Api.Filters;
using THCC.Api.Middlewares;
using THCC.Application;
using THCC.Application.Models.ResponseWrappers;
using THCC.Application.Settings;
using THCC.Infrastructure.Persistence.EntityFrameworkConfigurations;

using static THCC.Domain.Constants.ThccConstants;

const string myAllowSpecificOrigins = "_myAllowSpecificOrigins";

var builder = WebApplication.CreateBuilder(args);
{
    builder.Host.UseSerilog((hostingContext, config) => config.ReadFrom.Configuration(
                                                hostingContext.Configuration).WriteTo.Sentry());
    builder.WebHost.UseSentry();
    builder.Host.AddJsonFilesConfigurations();
    builder.Services.AddControllers();

    var rateLimitingSettings = builder.Configuration.GetSection("RateLimitingSettings").Get<RateLimitingSettings>();
    builder.Services.AddRateLimiter(options =>
    {
        options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
              RateLimitPartition.GetFixedWindowLimiter(
                  partitionKey: httpContext.User.Identity?.Name ?? httpContext.GetClientIpAddress()!,
                  factory: partition => httpContext.User.Identity!.IsAuthenticated
                  ? new FixedWindowRateLimiterOptions
                  {
                      AutoReplenishment = true,
                      PermitLimit = (int)rateLimitingSettings!.AuthPermitLimit!,
                      QueueLimit = (int)rateLimitingSettings!.AuthQueueLimit!,
                      QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                      Window = TimeSpan.FromSeconds((int)rateLimitingSettings!.AuthWindow!)
                  } : new FixedWindowRateLimiterOptions
                  {
                      AutoReplenishment = true,
                      PermitLimit = (int)rateLimitingSettings!.PermitLimit!,
                      QueueLimit = (int)rateLimitingSettings!.QueueLimit!,
                      QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                      Window = TimeSpan.FromSeconds((int)rateLimitingSettings!.Window!)
                  }));
        options.OnRejected = async (context, token) =>
        {
            context.HttpContext.Response.StatusCode = 429;
            await context.HttpContext.Response.WriteAsync(
                JsonConvert.SerializeObject(new ErrorResult()
                {
                    Errors = new List<ErrorDto>()
                    {
                                new ErrorDto() {
                                    Code = CustomStatusCode.TooManyRequests,
                                    Message = "Too many requests. Please try again later."
                                }
                    }
                }, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }), cancellationToken: token);
        };
    });

    builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(options =>
    {
        options.AddSecurityDefinition(JwtBearerDefaults.AuthenticationScheme, new OpenApiSecurityScheme
        {
            Name = "Authorization",
            Description = "Input your Jwt Bearer token to access this API",
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.Http,
            Scheme = JwtBearerDefaults.AuthenticationScheme,
            BearerFormat = "JWT",
        });
        options.OperationFilter<SwaggerGlobalAuthFilter>();
    });

    builder.Services.AddApiDependencies(builder.Configuration);
    builder.Services.AddRouting(options => options.LowercaseUrls = true);
    builder.Services.AddFluentValidationAutoValidation().AddFluentValidationClientsideAdapters();
    builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);

    string[] allowedOrigins = builder.Configuration.GetSection("AllowedOrigins").Get<string[]>()!;
    builder.Services.AddCors(options => options.AddPolicy(myAllowSpecificOrigins, policy => policy
                                    .WithOrigins(allowedOrigins)
                                    .AllowAnyHeader()
                                    .AllowAnyMethod()));

    builder.Services.AddHealthChecks();
    builder.Services.AddHsts(options =>
    {
        options.Preload = true;
        options.IncludeSubDomains = true;
        options.MaxAge = TimeSpan.FromDays(365);
    });
}

var app = builder.Build();
{

    app.UseSecurityHeadersMiddleware();
    app.UseExceptionMiddleware();
    if (app.Environment.IsDevelopment() || app.Environment.IsStaging())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
    if (app.Environment.IsProduction())
    {
        app.UseHsts();
    }

    //app.UseRateLimiter();
    app.UseNotFoundMiddleware();
    app.UseStaticFiles();
    app.UseRouting();
    app.UseCors(myAllowSpecificOrigins);
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseRequestLogging();
    app.MapControllers();
    app.MapHealthChecks("/health");
    await app.InitializeDataBase();
    app.UseSentryTracing();
    app.Run();
}