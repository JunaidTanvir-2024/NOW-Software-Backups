using System.Net.Mail;
using System.Net;
using MM.Core.Common.Interfaces.Database;

namespace MM.Infrastructure.Services.Email;
public class EmailService : IEmailService
{
    private readonly MailSettings _settings;
    private readonly ILogger _logger;
    private readonly ISmsLogRepository _messageLogRepository;


    public EmailService(ILogger logger, ISmsLogRepository messageLogRepository, IOptions<MailSettings> settings)
    {
        _settings = settings.Value;
        _logger = logger;
        _messageLogRepository = messageLogRepository;
    }
    public async Task SendEmailAsync(SendEmailRequestDTO sendEmailRequestDTO)
    {
        var IsActive = false;
       
        if (sendEmailRequestDTO != null)
        {
            (string from, string displayName) = MailFrom(sendEmailRequestDTO?.ProductCode);
            try
            {

                var messageLog = new MessageLog
                {
                    Receiver = sendEmailRequestDTO.To,
                    Sender = from,
                    Message = sendEmailRequestDTO.EmailBody,
                    MessageStatus = _settings.IsActive,
                    CurrentTime = DateTime.UtcNow,
                    Guid = Guid.NewGuid(),
                    CreatedBy = "MM Email Service",
                    TransactionId = Guid.NewGuid().ToString(),
                    MessageSid = Guid.NewGuid().ToString(),

                };
                try
                {
                    if (string.IsNullOrEmpty(sendEmailRequestDTO.EmailBody))
                    {
                        //return  ;
                    }

                    System.Net.Mail.SmtpClient client;
                    client = new System.Net.Mail.SmtpClient(_settings.Host, _settings.Port);
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.EnableSsl = false;
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(_settings.UserName, _settings.Password);

                    var mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress(from!, displayName);
                    mailMessage.Sender = new MailAddress(from!, displayName);
                    mailMessage.To.Add(sendEmailRequestDTO.To);
                    mailMessage.Body = sendEmailRequestDTO.EmailBody;
                    mailMessage.Subject = sendEmailRequestDTO.Subject;
                    mailMessage.IsBodyHtml = true;

                    await client.SendMailAsync(mailMessage);

                }
                catch (Exception ex)
                {
                    messageLog.MessageError = ex.ToString();
                }
                await _messageLogRepository.InsertSmsLog(messageLog);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

    }

    private void HandleSendEmailException(SendEmailRequestDTO emailRequest, Exception ex)
    {
        string requestParameters = $"to: {emailRequest.To}, textMessage: {emailRequest.EmailBody},productCode: {emailRequest.ProductCode}";
        _logger.Error($"  Method: SendEmailAsync, Parameters --> {requestParameters}, Exception: {ex.Message}");
    }
    private (string from, string displayName) MailFrom(string product)
    {
        if (string.IsNullOrEmpty(product))
        {

            return ("", "");
        }
        else if (string.Equals(product, "SC"))
        {
            return (_settings.MailFrom.SC.Split("|")[0], _settings.MailFrom.SC.Split("|")[1]);
        }
        else if (string.Equals(product, "THM"))
        {
            return (_settings.MailFrom.THM.Split("|")[0], _settings.MailFrom.THM.Split("|")[1]);
        }
        else if (string.Equals(product, "THA"))
        {
            return (_settings.MailFrom.THA.Split("|")[0], _settings.MailFrom.THA.Split("|")[1]);
        }
        return ("", "");

    }
}
