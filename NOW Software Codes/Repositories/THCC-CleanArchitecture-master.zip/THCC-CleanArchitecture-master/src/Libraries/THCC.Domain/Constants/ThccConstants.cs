namespace THCC.Domain.Constants;

public static class ThccConstants
{
    public static class StoredProcedures
    {
        #region Legacy-DB

        public const string GetUserByEmail_Legacy = "th_select_user_v3";
        public const string GetUserByProducts_Legacy = "th_select_user_product_v3";

        #endregion

        #region New-THCC-DB

        public const string GetConfirmationToken = "GetToken";
        public const string SaveToken = "SaveToken";
        public const string AddUserProduct = "AddUserProduct";
        public const string GetRates = "GetRates";
        public const string SaveOrderDetails = "SaveOrderHistoryV6";
        public const string OrderDetails = "GetOrderDetailsV4";
        public const string UpdateOrderHistoryStatus = "UpdateOrderStatusV2";
        public const string UpdateFulfillmentItems = "UpdateFulfillmentItemsV2";
        public const string GetUserProduct = "GetUserProduct";
        public const string GetTransactionHistory = "GetOrderHistory_V5";
        public const string IsUserPinNumber = "IsUserPinNumber";
        public const string CreateUpdateRating = "AddRating";
        public const string GetCallingCardsHistory = "GetCallingCards";
        public const string IsCardNumberRegistered = "IsCardNumberRegistered";
        public const string GetUserByProduct = "GetUserByProduct";
        public const string SaveOrderHistory = "SaveOrderHistory";

        #endregion

        #region BackHome-DB

        public const string GetPinInfo = "thcc_get_pin_account";
        public const string GetCardNumberInfo = "thcc_get_account";
        public const string GetCardPurchaseDate = "Get_THRCC_PurchaseDate";
        public const string DisableAutoTopup = "OffAutotopup";
        public const string UpdateAutoTopupStatus = "UpdateAutoTopup";
        public const string GetAutoTopup = "thcc_GetAutoTopup";
        public const string GetPoints = "th_get_web_points_by_account_revised_v2";
        public const string Pay360ThrccCardFullfilment = "thcc_pay360_accountupdatebalance_v2";
        public const string PaypalThrccCardFullfilment = "thcc_paypal_accountupdatebalance_v2";
        public const string GetAccountDetails = "th_get_callingcard_account_summary";
        public const string RedeemPoints = "thcc_web_redeem_accountupdatebalance_v1";
        public const string GetLastTopupInfo = "th_getLastTopup";
        public const string GetRechargableCardCallHistory = "thcc_get_call_history_by_pin";
        public const string GetTHRCCAutoTopupTransactions = "Pay360_Daemon_GetTHRCCAutoTopupTransactions_v2";
        public const string GetTHRCCAutoTopupTransactionsSimulation = "Pay360_Daemon_GetTHRCCAutoTopupTransactions_simu";
        public const string UpdateAutoTopupTransaction = "Pay360_Daemon_UpdateAutoTopupTransaction";
        public const string ThrccCustomerFullfilment = "thcc_pay360_accountupdatebalance_auto";

        public const string GetTHRCCConsumptionHistory = "trc_airship_get_cdr_upload_v1";
        public const string UpdateTHRCCConsumptionItem = "trc_airship_cdr_update";

        #endregion

        #region TalkHome-DB

        public const string GetClassicPinDetails = "thcc_get_pin_details";
        public const string GetClassicCardCallHistory = "thcc_get_call_history_by_pin";

        #endregion

        #region TalkHomeRechargeableCard-DB

        public const string Pay360ThccCardFullfilment = "thcc_getNextPIN_pay360_Pending_v4";
        public const string PaypalThccCardFullfilment = "thcc_getNextPIN_paypal_Pending_v4";
        public const string THRCCPin = "THRCC_get_pin_webAPI_v1";//get_pin_webAPI_v1

        #endregion

        #region CentralizedPayment-DB

        public const string GetCustomerByMerchantReference = "Pay360_Daemon_GetCustomerByMerchantRef";
        public const string AddAutoTopupTransaction = "Pay360_Daemon_AddAutoTopupTransaction";
        public const string CurrentMonthAutoTopupAmount = "Pay360_THCC_CurrentMonthAutoTopupAmount_V2";
        #endregion

        #region ClassicCardConsumptionHistory-DB

        public const string GetClassicCardConsumptionHistory = "thcc_airship_get_usage_update";
        public const string UpdateClassicCardConsumptionItems = "thcc_airship_usage_update";

        public const string GetClassicCardCallingHistory = "thcc_airship_get_cdr_upload_v1";
        public const string UpdateClassicCardCallingItem = "thcc_airship_cdr_update";

      

        #endregion
    }

    public static class ConnectionStrings
    {
        public const string DefaultConnection = "DefaultConnection";
        public const string THCCLegacy = "THCCLegacy";
        public const string BackHome = "BackHome";
        public const string TalkHomeRechargeableCard = "TalkHomeRechargeableCard";
        public const string TalKHome = "TalKHome";
        public const string CentralizedPayment = "CentralizedPayment";
        public const string CallingCardConsumption = "CallingCardConsumption";
    }

    public static class UserRole
    {
        public static readonly string Admin = "Admin";
        public static readonly string Customer = "Customer";
        public static readonly string Guest = "Guest";
    }

    public static class CurrencySymbol
    {
        public const string GBP = "�";
    }

    public static class Currency
    {
        public const string GBP = "GBP";
    }

    public static class SupportedFileTypes
    {
        public static List<CommonFileTypes> FileTypeSupported()
        {
            return new List<CommonFileTypes>()
        {
            new CommonFileTypes("bin", "53 50 30 31"),
            new CommonFileTypes("bac", "42 41 43 4B 4D 49 4B 45 44 49 53 4B"),
            new CommonFileTypes("bz2", "42 5A 68"),
            new CommonFileTypes("tif tiff", "49 49 2A 00"),
            new CommonFileTypes("tif tiff", "4D 4D 00 2A"),
            new CommonFileTypes("cr2", "49 49 2A 00 10 00 00 00 43 52"),
            new CommonFileTypes("cin", "80 2A 5F D7"),
            new CommonFileTypes("exr", "76 2F 31 01"),
            new CommonFileTypes("dpx", "53 44 50 58"),
            new CommonFileTypes("dpx", "58 50 44 53"),
            new CommonFileTypes("bpg", "42 50 47 FB"),
            new CommonFileTypes("lz", "4C 5A 49 50"),
            new CommonFileTypes("ps", "25 21 50 53"),
            new CommonFileTypes("fits", "3D 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 20 2020 54"),
            new CommonFileTypes("doc xls ppt msg", "D0 CF 11 E0 A1 B1 1A E1"),
            new CommonFileTypes("dex", "64 65 78 0A 30 33 35 00"),
            new CommonFileTypes("vmdk", "4B 44 4D"),
            new CommonFileTypes("crx", "43 72 32 34"),
            new CommonFileTypes("cwk", "05 07 00 00 42 4F 42 4F 05 07 00 00 00 00 00 00 00 00 00 00 0001"),
            new CommonFileTypes("fh8", "41 47 44 33"),
            new CommonFileTypes("cwk", "06 07 E1 00 42 4F 42 4F 06 07 E1 00 00 00 00 00 00 00 00 00 0001"),
            new CommonFileTypes("toast", "45 52 02 00 00 00"),
            new CommonFileTypes("toast", "8B 45 52 02 00 00 00"),
            new CommonFileTypes("xar", "78 61 72 21"),
            new CommonFileTypes("dat", "50 4D 4F 43 43 4D 4F 43"),
            new CommonFileTypes("nes", "4E 45 53 1A"),
            new CommonFileTypes("tox", "74 6F 78 33"),
            new CommonFileTypes("MLV", "4D 4C 56 49"),
            new CommonFileTypes("lz4", "04 22 4D 18"),
            new CommonFileTypes("cab", "4D 53 43 46"),
            new CommonFileTypes("flif", "46 4C 49 46"),
            new CommonFileTypes("stg", "4D 49 4C 20"),
            new CommonFileTypes("der", "30 82"),
            new CommonFileTypes("wasm", "00 61 73 6d"),
            new CommonFileTypes("lep", "cf 84 01"),
            new CommonFileTypes("rtf", "7B 5C 72 74 66 31"),
            new CommonFileTypes("m2p vob", "00 00 01 BA"),
            new CommonFileTypes("zlib", "78 01"),
            new CommonFileTypes("zlib", "78 9c"),
            new CommonFileTypes("zlib", "78 da"),
            new CommonFileTypes("lzfse", "62 76 78 32"),
            new CommonFileTypes("orc", "4F 52 43"),
            new CommonFileTypes("avro", "4F 62 6A 01"),
            new CommonFileTypes("rc", "53 45 51 36"),
            new CommonFileTypes("tbi", "00 00 00 00 14 00 00 00"),
            new CommonFileTypes("ttf", "00 01 00 00 00"),
            new CommonFileTypes("mdf", "00 FF FF FF FF FF FF FF FF FF FF 00 00 02 00 01"),
            new CommonFileTypes("asf wma wmv", "30 26 B2 75 8E 66 CF 11 A6 D9 00 AA 00 62 CE 6C"),
            new CommonFileTypes("ogg oga ogv", "4F 67 67 53"),
            new CommonFileTypes("psd", "38 42 50 53"),
            new CommonFileTypes("mp3", "FF FB"),
            new CommonFileTypes("mp3", "49 44 33"),
            new CommonFileTypes("bmp dib", "42 4D"),
            new CommonFileTypes("jpg,jpeg", "ff,d8,ff,db"),
            new CommonFileTypes("png", "89,50,4e,47,0d,0a,1a,0a"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,03,04"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,07,08"),
            new CommonFileTypes("zip,jar,odt,ods,odp,docx,xlsx,pptx,vsdx,apk,aar", "50,4b,05,06"),
            new CommonFileTypes("rar", "52,61,72,21,1a,07,00"),
            new CommonFileTypes("rar", "52,61,72,21,1a,07,01,00"),
            new CommonFileTypes("class", "CA FE BA BE"),
            new CommonFileTypes("pdf", "25 50 44 46"),
            new CommonFileTypes("rpm", "ed ab ee db"),
            new CommonFileTypes("flac", "66 4C 61 43"),
            new CommonFileTypes("mid midi", "4D 54 68 64"),
            new CommonFileTypes("ico", "00 00 01 00"),
            new CommonFileTypes("z,tar.z", "1F 9D"),
            new CommonFileTypes("z,tar.z", "1F A0"),
            new CommonFileTypes("gif", "47 49 46 38 37 61"),
            new CommonFileTypes("gif", "47 49 46 38 39 61"),
            new CommonFileTypes("gif", "47 49 46 38 61"),    // "GIF8a"
            new CommonFileTypes("gif", "47 49 46 39 61"),    // "GIF9a"
            new CommonFileTypes("gif", "47 49 46 37 61"),    // "GIF7a"
            new CommonFileTypes("dmg", "78 01 73 0D 62 62 60"),
            new CommonFileTypes("exe", "4D 5A"),
            new CommonFileTypes("mkv mka mks mk3d webm", "1A 45 DF A3"),
            new CommonFileTypes("gz tar.gz", "1F 8B"),
            new CommonFileTypes("xz tar.xz", "FD 37 7A 58 5A 00 00"),
            new CommonFileTypes("7z", "37 7A BC AF 27 1C"),
            new CommonFileTypes("mpg mpeg", "00 00 01 BA"),
            new CommonFileTypes("mpg mpeg", "00 00 01 B3"),
            new CommonFileTypes("woff", "77 4F 46 46"),
            new CommonFileTypes("woff2", "77 4F 46 32"),
            new CommonFileTypes("XML", "3c 3f 78 6d 6c 20"),
            new CommonFileTypes("swf", "43 57 53"),
            new CommonFileTypes("swf", "46 57 53"),
            new CommonFileTypes("deb", "21 3C 61 72 63 68 3E"),
            new CommonFileTypes("jpg,jpeg","FF D8 FF E0 ?? ?? 4A 46 49 46 00 01"),
            new CommonFileTypes("jpg,jpeg","FF D8 FF E1 ?? ?? 45 78 69 66 00 00"),
        };
        }
    }

    public sealed class CommonFileTypes
    {
        public CommonFileTypes(string fileTypeName, string fileHeaderValue)
        {
            FileTypeName = fileTypeName;
            FileHeaderValue = fileHeaderValue;
        }

        public string FileTypeName { get; set; }
        public string FileHeaderValue { get; set; }
    }

    public static class TemplateNames
    {
        public const string EmailVerification = "EmailVerification";
        public const string ForgetPassword = "ForgotPassword";
        public const string SignUpSuccessEmail = "SignUp";
        public const string RedeemEmail = "RedeemEmail";
        public const string ContactUsEmail = "ContactUs";
        public const string Invoice = "Invoice";
        public const string THCCPurchase = "THCCPurchase";
        public const string THRCCPurchase = "THRCCPurchase";
        public const string THRCCRecharge = "THRCCRecharge";
        public const string THRCCFastRecharge = "THRCCFastRecharge";
        public const string ChangePasswordSuccess = "ChangePasswordSuccess";
    }

    public static class CustomStatusCode
    {
        public const int Success = 100200;
        public const int BadRequest = 100400;
        public const int Forbidden = 100403;
        public const int NotFound = 100404;
        public const int Unauthorized = 100401;
        public const int InternalServerError = 100500;
        public const int TooManyRequests = 100429;
        public const int EmailNotVerified = 100104;
        public const int AddressNotFound = 100108;
    }

    public static class CustomStatusKey
    {
        public const string BadRequest = "Whoops! Something went wrong with your request. Please try again.";
        public const string Forbidden = "Sorry, you don't have permission to access this resource.";
        public const string NotFound = "Hmmm, we couldn't find what you're looking for.";
        public const string Unauthorized = "Oops! You need to be authorized to access this resource.";
        public const string InternalServerError = "Something went wrong on our end. Please try again later.";
        public const string EmailNotVerified = "Oops! Your email is not verified. Please verify your email first.";
        public const string EmailAlreadyVerified = "Your email is already verified.";
        public const string EmailAlreadyRegistered = "Whoops! Your email is already registered. Please use a different email.";
        public const string CardNumberAlreadyRegistered = "Your card number is already registered.";
        public const string SignUpFailed = "There's been an error.Please try again.";
        public const string FileUploadedError = "Uh oh! There was an error uploading your file. Please try again.";
        public const string AccountLocked = "Oops! Your account has been locked. Please contact customer support.";
        public const string AccountNotRegistered = "Account doesn't exist, please try again.";
        public const string InvalidPin = "You entered an invalid PIN. Please try again.";
        public const string InvalidCardNumnber = "You entered an invalid card number. Please try again.";
        public const string InvalidCardorPinNumber = "Your card number or card pin is invalid. Please try again.";
        public const string ProductNotFound = "No products were found associated with this email address.";
        public const string AddressNotFound = "We couldn't find any address for your postal code.";
        public const string EmailNotSupported = "We're sorry - this email is not supported.";
        public const string LoginFailed = "There's been an error. Please try again.";
        public const string DailyPaymentLimitExceeded = "Sorry, you have hit your daily purchase limit. Please contact support for assistance.";
        public const string ProductAlreadyExist = "This product is already added to your account.";
        public const string InvalidCredentials = "You have input invalid credentials. Please try again.";
        public const string InvalidOtp = "Oops! Your OTP is invalid. Please try again.";
        public const string OrderNotCompleted = "Oops! We couldn't complete your order.";
        public const string FastTopupCardNumberRegistered = "We will send you an email confirmation on your registered email address.";
    }

    public static class OrderHistoryConstants
    {
        public const string PaymentSuccess = "Payment completed successfully";
        public const string PaymentFailed = "Payment failed";
        public const string Payment3dSecureCardPending = "Redirecting the user for 3d Secure to complete payment";
        public const string PaymentPaypalPending = "Redirecting the user to paypal to complete payment";
        public const string PaymentCaptureFailed = "Payment capture failed";
        public const string FulfillmentFailed = "Fulfillment failed";
        public const string FulfillmentSuccess = "Fulfillment success";
        public const string RedeemPointsFailed = "Redeem points failed";
        public const string RedeemPointsSuccess = "Redeem points success";
        public const string PaymentRefundSuccess = "Payment refund success";
        public const string PaymentRefundFailed = "Payment refund failed";
        public const string PaymentCancelSuccess = "Payment cancelled successfully";
        public const string PaymentCancelFailed = "Payment cancelled failed";
        public const string AddProductFailure = "Product add failed";
        public const string AddProductSuccess = "Product added successfully";
        public const string AutoTopupEnableSuccess = "Auto Topup enabled successfully";
        public const string AutoTopupDisabledSuccess = "Auto Topup disabled successfully";
        public const string EmailSentSuccess = "Email sent successfully";
        public const string EmailSentFailed = "Email sent failed";
        public const string InvoiceDownloaded = "User downloaded the invoice";
    }
}
