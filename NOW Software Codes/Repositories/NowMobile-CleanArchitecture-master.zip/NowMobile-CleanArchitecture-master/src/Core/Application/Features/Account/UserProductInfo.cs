﻿namespace Application.Features.Account;

public class UserProductInfo
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string Msisdn { get; set; } = default!;
    public SimStatus Status { get; set; }
    public bool IsDefault { get; set; }
    public float Balance { get; set; }
    public string CurrencySymbol { get; set; } = Common.Models.CurrencySymbol.GBP;
}
