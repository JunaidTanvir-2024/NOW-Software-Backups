using System.Text.Json.Serialization;
using System.Text.Json;

using JM.Core.Utilities.Behaviors;
using JM.Core.Utilities.DependencyResolver;

using Mediator;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http.Json;
using FluentValidation;
using System.Reflection;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Http.Features;

namespace JM.Core;

public static class ConfigureDependencies
{
	public static IServiceCollection AddCoreDependencies(this IServiceCollection services, IConfiguration configuration)
	{
		services.AutoResolve();
		services.RegisterMediatorBehaviors(configuration);
		services.Configure<JsonOptions>(opt =>
		{
			opt.SerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
			opt.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
			opt.SerializerOptions.PropertyNameCaseInsensitive = true;
			opt.SerializerOptions.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
			opt.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
			opt.SerializerOptions.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
		});
		services.Configure<FormOptions>(options =>
		{
			options.ValueLengthLimit = int.MaxValue;
			options.MultipartBodyLengthLimit = int.MaxValue;
		});
		return services;
	}
	private static IServiceCollection RegisterMediatorBehaviors(this IServiceCollection services, IConfiguration configuration)
	{
		services.AddMediator(cfg => cfg.ServiceLifetime = ServiceLifetime.Scoped);
		services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
		services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
		return services;
	}
}
