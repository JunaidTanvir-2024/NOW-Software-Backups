﻿using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services.Payment;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.Payment.Card.Topup.NewCard;

public class TopupNewCardPaymentRequestHandler : IRequestHandler<TopupNewCardPaymentRequest, object>
{
    private readonly IPaymentService _paymentService;
    private readonly IUserRepository _userRepository;
    private readonly ICurrentUser _currentUser;

    public TopupNewCardPaymentRequestHandler(
        IPaymentService paymentService,
        IUserRepository userRepository,
        ICurrentUser currentUser)
    {
        _paymentService = paymentService;
        _userRepository = userRepository;
        _currentUser = currentUser;
    }

    public async Task<object> Handle(TopupNewCardPaymentRequest request, CancellationToken cancellationToken)
    {
        #region Trim Request

        request.CardNumber = request.CardNumber.Trim();

        request.PaymentCardInfo.NameOnCard = request.PaymentCardInfo.NameOnCard.Trim();
        request.PaymentCardInfo.CardNumber = request.PaymentCardInfo.CardNumber.Trim();
        request.PaymentCardInfo.SecurityCode = request.PaymentCardInfo.SecurityCode.Trim();
        request.PaymentCardInfo.ExpiryMonth = request.PaymentCardInfo.ExpiryMonth.Trim();
        request.PaymentCardInfo.ExpiryYear = request.PaymentCardInfo.ExpiryYear.Trim();

        request.PaymentAddressInfo.AddressL1 = request.PaymentAddressInfo.AddressL1!.Trim();
        request.PaymentAddressInfo.City = request.PaymentAddressInfo.City!.Trim();
        request.PaymentAddressInfo.PostCode = request.PaymentAddressInfo.PostCode!.Trim();
        request.PaymentAddressInfo.CountryCode = request.PaymentAddressInfo.CountryCode!.Trim();

        #endregion

        var userProduct = await _userRepository.GetUserProducts(_currentUser.GetUserId());
        if (userProduct == null)
        {
            return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }
        if (!userProduct.Product.Trim().Equals(
            request.CardNumber, StringComparison.InvariantCultureIgnoreCase))
        {
            return ErrorResult.Failure(CustomStatusKey.ProductNotFound, CustomStatusCode.BadRequest);
        }

        return await _paymentService.HandleCardPaymentRequest(
            paymentNewCardInfo: request.PaymentCardInfo,
            paymentAddressInfo: request.PaymentAddressInfo,
            paymentExistingCardInfo: null!,
            autoTopupInfo: request.AutoTopupInfo,
            userInfo: new UserDto()
            {
                Id = _currentUser.GetUserId(),
                Email = _currentUser.GetUserEmail()
            },
            productType: ProductType.Topup,
            amount: request.Amount,
            cardNumber: request.CardNumber);
    }
}