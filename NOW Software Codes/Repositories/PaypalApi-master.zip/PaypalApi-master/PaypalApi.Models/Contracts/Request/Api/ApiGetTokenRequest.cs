﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Request.Api
{
    public class ApiGetTokenRequest
    {
        [JsonProperty("grant_type")]
        public string GrantType { get; set; }
    }
}
