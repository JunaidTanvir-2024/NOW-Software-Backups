namespace FH.Core.DTOs.Database;
public sealed record DatabasePaginationDto
{
    public int TotalRecords { get; set; }
    public int TotalPages { get; set; }
}
