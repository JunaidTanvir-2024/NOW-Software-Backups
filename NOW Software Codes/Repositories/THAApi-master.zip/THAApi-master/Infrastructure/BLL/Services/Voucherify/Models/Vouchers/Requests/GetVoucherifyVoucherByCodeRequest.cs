﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Requests
{
    public class GetVoucherifyVoucherByCodeRequest
    {
        public string VoucherCode { get; set; }
    }
}
