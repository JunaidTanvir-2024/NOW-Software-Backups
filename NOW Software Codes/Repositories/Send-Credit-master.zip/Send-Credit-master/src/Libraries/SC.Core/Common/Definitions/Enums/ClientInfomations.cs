﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppEnums
{
    public enum ClientInformations
    {
        ProductCode,
        ProductItemCode,
        UniqueReference
    }
}

