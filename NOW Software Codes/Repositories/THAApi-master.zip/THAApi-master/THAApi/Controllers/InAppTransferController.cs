﻿using Infrastructure.BLL.Interfaces;
using Infrastructure.Utilities;
using Microsoft.AspNetCore.Mvc;
using Models.Contracts.Request;
using System.Threading.Tasks;
using THAApi.Utilities;

namespace THAApi.Controllers
{
    [ApiController]
    public class InAppTransferController : ControllerBase
    {
        private readonly ITransfer_BL TransferBL;

        public InAppTransferController(ITransfer_BL transferBL)
        {
            TransferBL = transferBL;
        }

        [HttpPost]
        [Route("transfer/balance/confirm")]
        public async Task<IActionResult> TransferBalanceConfirmation([FromBody] TransferBalanceTransaction request)
        {
            request.advertiserID = HttpContext.GetAdvertiserID();
            return Ok(await TransferBL.ExecuteBalanceTransfer(request));
        }

        [HttpPost]
        [Route("transfer/balance/summary")]
        public async Task<IActionResult> TransferBalanceSummary([FromBody] TransferBalanceRequest request)
        {
            request.SourceMsisdn = User.Msisdn();
            return Ok(await TransferBL.SummariseBalanceTransfer(request));
        }
    }
    
}
