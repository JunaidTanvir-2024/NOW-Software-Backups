﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
    public class LocalAccessNumber2
    {
        public string Online { get; set; }

        public string Offline { get; set; }

    }
}
