﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TransferHome.Models.Contracts.Request
{
    public class SetCustomerDefaultCardRequestModel
    {
        [Required, StringLength(maximumLength: 4, MinimumLength = 3, ErrorMessage = "Length must be between (3-4)")]
        public string CardCV2 { get; set; }

        [Required]
        public string CardToken { get; set; }
    }
}
