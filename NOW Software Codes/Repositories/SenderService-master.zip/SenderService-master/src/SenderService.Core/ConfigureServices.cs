﻿using Mapster;
using MapsterMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SenderService.Core.Features.Domain;
using SenderService.Core.Features.Email;
using SenderService.Core.Features.EmailValidation;
using SenderService.Core.Features.ProductCode;
using SenderService.Core.Persistence;
using SenderService.Core.Persistence.Repository;
using SenderService.Core.Services.Mailing;
using SenderService.Core.Services.ZeroBounce;
using System.Reflection;

namespace SenderService.Core;
public static class ConfigureServices
{
    public static IServiceCollection AddCoreLayerServices(this IServiceCollection services, IConfiguration configuration)
    {

        services.AddDbContext<SenderServiceContext>(options => options.UseSqlServer(configuration.GetConnectionString("SenderServiceConnection")));
        services.AddHttpClient();

        #region Repositories
        services.AddScoped<IEmailRepository, EmailRepository>();
        services.AddScoped<IEmailRecipientRepository, EmailRecipientRepository>();
        services.AddScoped<IBlockedDomainRepository, BlockedDomainRepository>();
        services.AddScoped<IEmailValidationRepository, EmailValidationRepository>();
        services.AddScoped<IProductCodeRepository, ProductCodeRepository>();
        services.AddScoped<IZeroBounceImplementation, ZeroBounceImplementation>();
        #endregion

        #region Services
        services.AddScoped<IEmailValidationService, EmailValidationService>();
        services.AddScoped<IEmailService, EmailService>();
        services.AddScoped<IBlockedDomainService, BlockedDomainService>();
        services.AddScoped<IProductCodeService, ProductCodeService>();

        #endregion

        #region 
        var typeAdapterConfig = TypeAdapterConfig.GlobalSettings;
        // scans the assembly and gets the IRegister, adding the registration to the TypeAdapterConfig
        typeAdapterConfig.Scan(Assembly.GetExecutingAssembly());
        // register the mapper as Singleton service for my application
        var mapperConfig = new Mapper(typeAdapterConfig);
        services.AddSingleton<IMapper>(mapperConfig);
        #endregion

        services.AddSingleton<ISmtpMailService, SmtpMailService>();
        services.AddOptions<SmtpSettings>()
             .Bind(configuration.GetSection(SmtpSettings.SectionName));
        services.AddOptions<ZeroBounceSettings>()
            .Bind(configuration.GetSection(ZeroBounceSettings.SectionName));
        return services;
    }
}