﻿using ATT.Models.Contracts.Ding.Response;
using System.Threading.Tasks;

namespace ATT.Infrastructure.BLL.Ding
{
    public interface IDingAuth_BL
    {
        Task<DingAuthResponse> getAuthToken(string account);
    }
}
