using System.Linq.Expressions;

using JM.Core.Entities;

using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Database;

public interface ITravelerRepository : ResolveAs.IScoped
{
    Task<Traveler> AddTraveler(Traveler tripTraveler);
    Task<IEnumerable<Trip>> GetTravelerList(Expression<Func<Trip, bool>> expression = default!);
    void UpdateTraveler(Traveler tripTraveler);
    Task<Traveler?> GetTraveler(Expression<Func<Traveler, bool>> predicate);
}
