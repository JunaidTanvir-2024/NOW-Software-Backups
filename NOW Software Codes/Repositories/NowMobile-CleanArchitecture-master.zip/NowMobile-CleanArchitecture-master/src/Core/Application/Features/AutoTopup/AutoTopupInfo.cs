﻿namespace Application.Features.AutoTopup;

public class AutoTopupInfo
{
    public float ThresHoldAmount { get; set; }
    public float TopupAmount { get; set; }
    public string CurrencySymbol { get; set; } = Common.Models.CurrencySymbol.GBP;
    public bool Status { get; set; }
    public string? PaymentMethod { get; set; }
    public string? MaskedPan { get; set; }
}
