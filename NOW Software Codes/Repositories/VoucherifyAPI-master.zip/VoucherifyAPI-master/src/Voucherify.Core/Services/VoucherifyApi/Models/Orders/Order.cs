using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Definations;
using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Orders;

public class Order
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }
    [JsonPropertyName("source_id")]
    public string? SourceId { get; set; }

    [JsonPropertyName("status")]
    public VoucherifyEnums.OrderStatus Status { get; set; }

    [JsonPropertyName("customer")]
    public RelatedObject? Customer { get; set; }

    [JsonPropertyName("referrer")]
    public RelatedObject? Referrer { get; set; }

    [JsonPropertyName("amount")]
    public long? Amount { get; set; }

    [JsonPropertyName("discount_amount")]
    public long? DiscountAmount { get; set; }

    [JsonPropertyName("items_discount_amount")]
    public long? ItemsDiscountAmount { get; set; }

    [JsonPropertyName("total_discount_amount")]
    public long? TotalDiscountAmount { get; set; }

    [JsonPropertyName("total_amount")]
    public long? TotalAmount { get; set; }

    [JsonPropertyName("applied_discount_amount")]
    public long? AppliedDiscountAmount { get; set; }

    [JsonPropertyName("items_applied_discount_amount")]
    public long? ItemsAppliedDiscountAmount { get; set; }

    [JsonPropertyName("total_applied_discount_amount")]
    public long? TotalAppliedDiscountAmount { get; set; }

    [JsonPropertyName("items")]
    public List<OrderItem>? Items { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }

    [JsonPropertyName("redemptions")]
    public Dictionary<string, OrderRedemption>? Redemptions { get; set; }
}
