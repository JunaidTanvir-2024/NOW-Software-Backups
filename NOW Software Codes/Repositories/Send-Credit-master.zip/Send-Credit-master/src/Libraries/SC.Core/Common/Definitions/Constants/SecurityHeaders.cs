﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants
{
    public static class SecurityHeaders
    {
        public const string XFrameOptions = "X-FrameOptions";
        public const string XContentTypeOptions = "X-Content-Type-Options";
        public const string ReferrerPolicy = "Referrer-Policy";
        public const string PermissionsPolicy = "Permissions-Policy";
        public const string SameSite = "SameSite";
        public const string XXSSProtection = "X-XSS-Protection";
        public const string ContentPolicy = "ContentPolicy";
        public const string SALTKey = "SALTKEY46545";
        public const string RequestID = "Request_ID";
    }
}

