﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response.ApiContracts
{
    public class PortOutResponse
    {
        public string MSISDN { get; set; }
        public string Code { get; set; }
        public int CodeType { get; set; }
        public string Status { get; set; }
        public string StatusNote { get; set; }
        public string PortDate { get; set; }
        public string ExpiryDate { get; set; }
        public SwitchingInformation SwitchingInformation { get; set; }
    }

    public class SwitchingInformation
    {
        public decimal TerminationCharge { get; set; }
        public decimal Balance { get; set; }
        public string TerminateDate { get; set; }
        public string Url { get; set; }
        public bool IsPostPaid { get; set; }
        public decimal HandsetCharge { get; set; }
        public decimal AdditionalCharge { get; set; }
    }
}
