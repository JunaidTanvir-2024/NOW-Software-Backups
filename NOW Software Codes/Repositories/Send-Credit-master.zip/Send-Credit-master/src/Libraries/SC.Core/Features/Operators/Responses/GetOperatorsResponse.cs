﻿

using System.Text.Json.Serialization;

namespace SC.Core.Features.Operators;
public sealed class GetOperatorsResponse
{
    [JsonPropertyName("operator")]
    public OperatorInfo Operator { get; set; }
    public sealed record OperatorInfo
    {
        [JsonPropertyName("id")]
        public long Id { get; set; }
        [JsonPropertyName("operatorName")]
        public string? OperatorName { get; set; }
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        [JsonPropertyName("operatorLogo")]
        public string? OperatorLogo { get; set; }
        [JsonPropertyName("country")]
        public OperatorCountryInfo Country { get; set; }
    }
    public sealed record OperatorCountryInfo
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }
        [JsonPropertyName("isoCode")]
        public string? IsoCode { get; set; }
    }
}

