﻿using Application.Common.Extensions.DependencyResolver;
using Domain.Aggregate;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Interfaces.Repositories;
public interface ICreditSimFulfillmentRepository : IServicesType.IScopedService
{
    Task<IList<DbSimOrderPool>> GetActiveNumbersFromPool();
    Task<DbSimOrderPool> GetCreditSimFulfillmentFromSimPool(string msisdn);
    Task<DbResult<List<DbCreditSimOrderDetail>>> GetCreditSimOrderDetail(string msisdn);
    Task<DbResult<string>> UpdateCreditSimFullfilment(long id, bool isFullfilled, string fulfillment_error_message, string fulfillment_ref);
    Task<DbResult<DbAddBundleOrTopupResult>> AddBundleOrTopup(
        string transactionId, string bundleRef, string amount, string msisdn, PaymentType paymentType, string email);
    Task UpdateCreditSimFullfilmentInSimPool(int id, bool isFullfiled, string errorMessage);

    Task UpdateSimStatus(string msisdn);
    Task<(bool, OrderDetails, IEnumerable<OrderItemDetails>)> GetOrderDetails(string transactionId);
    Task<Bundle> GetBundleById(int bundleId);
    Task<MsisdnDetails> GetMsisdnDetail(string msisdn);
    Task UpdateCreditSimFullfilmentInSimPool(string account, bool isFullfiled, string errorMessage);
    //Task SetBundleAutoRenewal(bool isRenew, string msisdn, string accountId, string bundleUuid, string userEmail,
    //    PaymentType paymentMethod, string cardPanMasked = null, string cardInitialTransactionId = null);
    //Task SetAutoTopup(bool isAutoTopup, string msisdn, string userEmail, float topupAmount,
    //    string topupCurrency, float topupTheresholdAmount, PaymentType paymentMethod,
    //    string cardMaskedPan = default!, string cardInitialTransactionId = default!);
}
