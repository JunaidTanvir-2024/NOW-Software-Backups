using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Orders;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class StackableDiscountValidation
{
    [JsonPropertyName("valid")]
    public bool IsValid { get; set; }

    [JsonPropertyName("redeemables")]
    public Redeemable[]? Redeemables { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    [JsonPropertyName("tracking_id")]
    public string? TrackingId { get; set; }
}
