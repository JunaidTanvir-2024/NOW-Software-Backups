﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Configurations
{
    public class ATTConfig
    {
        public string ApiEndPoint { get; set; }
        public bool IsDToneEndpoint { get; set; }
        public Servicefee ServiceFee { get; set; }

        public class Servicefee
        {
            public string[] ExcludedOriginations { get; set; } = Array.Empty<string>();
            public string[] ExcludedDestinations { get; set; } = Array.Empty<string>();
            public FeeRule[] FeeRules { get; set; } = Array.Empty<FeeRule>();
            public FeeDiscountRule[] FeeDiscountRules { get; set; } = Array.Empty<FeeDiscountRule>();
            public class FeeRule
            {
                public string Currency { get; set; }
                public int Min { get; set; }
                public int Max { get; set; }
                public decimal FeePercentage { get; set; }
				public string Origination { set; get; }
				public string Destination { set; get; }
			}

            public class FeeDiscountRule
            {
                public string Currency { get; set; }
                public string Origination { get; set; }
                public string Destination { get; set; }
                public decimal DiscountPercentage { get; set; }
            }
        }
    }
}
