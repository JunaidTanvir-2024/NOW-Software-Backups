﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeAPI.Models.Configurations
{
    public class PayPalConfig
    {
        public string PayPalApiEndpoint { get; set; }
        public string PayPalByP630ApiEndpoint { get; set; }
        public bool IsPaypalByPay360 { get; set; }

        public bool IsDirectFullfilment { get; set; }
        
        public PayPalTransferSettings TransferSettings { get; set; }
        public TopupByPayPalReturnUrl TopupByPayPalReturnUrl { get; set; }
    }

    public class PayPalTransferSettings
    {
        public string PayPalReturnUrl { get; set; }
        public string PayPalByPay360ReturnUrl { get; set; }
        public string CancelUrl { get; set; }
    }
    public class TopupByPayPalReturnUrl
    {
        public string TopupPayPalReturnUrl { get; set; }
        public string TopupPayPalByPay360ReturnUrl { get; set; }
        public string TopupCancelUrl { get; set; }
    }

}
