﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models.ApiContracts.Request
{
    public class SaveUserSimOrderRequestModel
    {
        public RegisterUserRequestModel UserInfo { get; set; }
        public bool IsUserExists { get; set; }
        public UserAddressRequestModel UserAddressInfo { get; set; }
        public UserSIMOrderRequestModel UserSimInfo { get; set; }
    }
}
