﻿using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NowPayGApi.Infrastructure.BLL.Interfaces
{
    public interface IBL_User
    {
        Task<GenericApiResponse<LoginResponseModel>> Login(LoginRequestModel model);
        Task<GenericApiResponse<GetUserByEmailResponseModel>> GetUserByEmail(GetUserByEmailRequestModel model);
        Task<GenericApiResponse<bool>> IsUserExist(IsUserExistRequestModel model);
        Task<GenericApiResponse<bool>> RegisterUser(RegisterUserRequestModel model);
        Task<GenericApiResponse<bool>> VerifyEmailbyToken(VerifyEmailRequestModel model);
        Task<GenericApiResponse<LoginResponseModel>> RegisterSocialMediaUser(ExternalLoginRequestModel model);
        Task<GenericApiResponse<bool>> ResendVerificationEmail(ReSendTokenRequestModel model);
        Task<GenericApiResponse<bool>> ForgotPassword(ForgotPasswordRequestModel model);
        Task<GenericApiResponse<bool>> UpdatePassword(UpdateUserPasswordRequestModel model);
        Task<GenericApiResponse<int>> SaveUserSimOrder(SaveUserSimOrderRequestModel model);
        Task<GenericApiResponse<bool>> SaveUserProduct(SaveUserProductRequestModel model);
        Task<GenericApiResponse<GetAllProductsByUserIDResponseModel>> GetAllProductsByUserID(GetAllProductsByUserIDRequestModel model);
        Task<GenericApiResponse<GetUserSummaryResponseModel>> GetUserSummary(GetUserSummaryRequestModel model);
        Task<GenericApiResponse<bool>> UpdateMailSubscription(UpdateMailSubscriptionRequestModel model);
        Task<GenericApiResponse<bool>> ChangeAccountPassword(ChangePasswordRequestModel model);
        Task<GenericApiResponse<bool>> ValidateMsisdn(ValidateMsisdnRequestModel model);
        Task<GenericApiResponse<AddBundleViaSimCreditResponseModel>> AddBundleViaSimCredit(AddBundleViaSimCreditRequestModel model);
        Task<GenericApiResponse<string>> SetBundleAutoRenewal(BundleAutoRenewalRequestModel model);
        Task<GenericApiResponse<GetUserCallHistoryResponseModel>> GetUserCallHistory(GetUserCallHistoryRequestModel model);
        Task<GenericApiResponse<GetUserSmsHistoryResponseModel>> GetUserSmsHistory(GetUserSmsHistoryRequestModel model);
        Task<GenericApiResponse<GetUserDataHistoryResponseModel>> GetUserDataHistory(GetUserDataHistoryRequestModel model);
        Task<GenericApiResponse<GetUserPaymentHistoryResponseModel>> GetUserPaymentHistory(GetUserPaymentHistoryRequestModel model);
    }
}
