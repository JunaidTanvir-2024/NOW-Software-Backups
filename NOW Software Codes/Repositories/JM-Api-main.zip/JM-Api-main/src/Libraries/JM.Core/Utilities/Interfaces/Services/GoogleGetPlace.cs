using System.Text.Json.Serialization;

namespace JM.Core.Utilities.Interfaces.Services;

public abstract class GoogleGetPlace
{
    public sealed record Query
    {
        [JsonPropertyName("textQuery")]
        public required string SearchText { get; set; }
        public required string[] Filters { get; set; } = ["*"];
    }
    public sealed record Response
    {
        [JsonPropertyName("places")]
        public Place[] Places { get; set; } = [];
        public sealed class Place
        {
            [JsonPropertyName("name")]
            public string? Name { get; set; }

            [JsonPropertyName("id")]
            public string? Id { get; set; }

            [JsonPropertyName("types")]
            public string[]? Types { get; set; }

            [JsonPropertyName("formattedAddress")]
            public string? FormattedAddress { get; set; }

            [JsonPropertyName("addressComponents")]
            public AddressComponent[] AddressComponents { get; set; } = [];

            [JsonPropertyName("location")]
            public LocationInfo? Location { get; set; }

            [JsonPropertyName("viewport")]
            public ViewportInfo? Viewport { get; set; }

            [JsonPropertyName("googleMapsUri")]
            public string? GoogleMapsUri { get; set; }

            [JsonPropertyName("utcOffsetMinutes")]
            public long UtcOffsetMinutes { get; set; }

            [JsonPropertyName("adrFormatAddress")]
            public string? AdrFormatAddress { get; set; }

            [JsonPropertyName("businessStatus")]
            public string? BusinessStatus { get; set; }

            [JsonPropertyName("iconMaskBaseUri")]
            public string? IconMaskBaseUri { get; set; }

            [JsonPropertyName("iconBackgroundColor")]
            public string? IconBackgroundColor { get; set; }

            [JsonPropertyName("displayName")]
            public DisplayNameInfo? DisplayName { get; set; }

            [JsonPropertyName("shortFormattedAddress")]
            public string? ShortFormattedAddress { get; set; }

            [JsonPropertyName("nationalPhoneNumber")]
            public string? NationalPhoneNumber { get; set; }

            [JsonPropertyName("internationalPhoneNumber")]
            public string? InternationalPhoneNumber { get; set; }

            [JsonPropertyName("rating")]
            public double? Rating { get; set; }

            [JsonPropertyName("regularOpeningHours")]
            public RegularOpeningHoursInfo? RegularOpeningHours { get; set; }

            [JsonPropertyName("userRatingCount")]
            public long? UserRatingCount { get; set; }

            [JsonPropertyName("currentOpeningHours")]
            public CurrentOpeningHoursInfo? CurrentOpeningHours { get; set; }

            [JsonPropertyName("reviews")]
            public Review[]? Reviews { get; set; }

            [JsonPropertyName("photos")]
            public Photo[]? Photos { get; set; }

            [JsonPropertyName("primaryTypeDisplayName")]
            public DisplayNameInfo? PrimaryTypeDisplayName { get; set; }

            [JsonPropertyName("primaryType")]
            public string? PrimaryType { get; set; }

            [JsonPropertyName("plusCode")]
            public PlusCodeInfo? PlusCode { get; set; }

            [JsonPropertyName("websiteUri")]
            public string? WebsiteUri { get; set; }

            [JsonPropertyName("accessibilityOptions")]
            public AccessibilityOptionsInfo? AccessibilityOptions { get; set; }

            public sealed class AccessibilityOptionsInfo
            {
                [JsonPropertyName("wheelchairAccessibleParking")]
                public bool WheelchairAccessibleParking { get; set; }

                [JsonPropertyName("wheelchairAccessibleEntrance")]
                public bool WheelchairAccessibleEntrance { get; set; }
            }

            public sealed class AddressComponent
            {
                [JsonPropertyName("longText")]
                public string? LongText { get; set; }

                [JsonPropertyName("shortText")]
                public string? ShortText { get; set; }

                [JsonPropertyName("types")]
                public string[]? Types { get; set; }

                [JsonPropertyName("languageCode")]
                public string? LanguageCode { get; set; }
            }

            public sealed class CurrentOpeningHoursInfo
            {
                [JsonPropertyName("openNow")]
                public bool OpenNow { get; set; }

                [JsonPropertyName("periods")]
                public CurrentOpeningHoursPeriod[]? Periods { get; set; }

                [JsonPropertyName("weekdayDescriptions")]
                public string[]? WeekdayDescriptions { get; set; }
            }

            public sealed class CurrentOpeningHoursPeriod
            {
                [JsonPropertyName("open")]
                public PurpleClose? Open { get; set; }

                [JsonPropertyName("close")]
                public PurpleClose? Close { get; set; }
            }

            public sealed class PurpleClose
            {
                [JsonPropertyName("day")]
                public long Day { get; set; }

                [JsonPropertyName("hour")]
                public long Hour { get; set; }

                [JsonPropertyName("minute")]
                public long Minute { get; set; }

                [JsonPropertyName("truncated")]
                public bool? Truncated { get; set; }

                [JsonPropertyName("date")]
                public Date? Date { get; set; }
            }

            public sealed class Date
            {
                [JsonPropertyName("year")]
                public long Year { get; set; }

                [JsonPropertyName("month")]
                public long Month { get; set; }

                [JsonPropertyName("day")]
                public long Day { get; set; }
            }

            public sealed class DisplayNameInfo
            {
                [JsonPropertyName("text")]
                public string? Text { get; set; }

                [JsonPropertyName("languageCode")]
                public string? LanguageCode { get; set; }
            }

            public sealed class LocationInfo
            {
                [JsonPropertyName("latitude")]
                public double Latitude { get; set; }

                [JsonPropertyName("longitude")]
                public double Longitude { get; set; }
            }

            public sealed class Photo
            {
                [JsonPropertyName("name")]
                public string? Name { get; set; }

                [JsonPropertyName("widthPx")]
                public long WidthPx { get; set; }

                [JsonPropertyName("heightPx")]
                public long HeightPx { get; set; }

                [JsonPropertyName("authorAttributions")]
                public AuthorAttribution[]? AuthorAttributions { get; set; }
            }

            public sealed class AuthorAttribution
            {
                [JsonPropertyName("displayName")]
                public string? DisplayName { get; set; }

                [JsonPropertyName("uri")]
                public string? Uri { get; set; }

                [JsonPropertyName("photoUri")]
                public string? PhotoUri { get; set; }
            }

            public sealed class PlusCodeInfo
            {
                [JsonPropertyName("globalCode")]
                public string? GlobalCode { get; set; }

                [JsonPropertyName("compoundCode")]
                public string? CompoundCode { get; set; }
            }

            public sealed class RegularOpeningHoursInfo
            {
                [JsonPropertyName("openNow")]
                public bool OpenNow { get; set; }

                [JsonPropertyName("periods")]
                public RegularOpeningHoursPeriod[]? Periods { get; set; }

                [JsonPropertyName("weekdayDescriptions")]
                public string[]? WeekdayDescriptions { get; set; }
            }

            public sealed class RegularOpeningHoursPeriod
            {
                [JsonPropertyName("open")]
                public FluffyClose? Open { get; set; }

                [JsonPropertyName("close")]
                public FluffyClose? Close { get; set; }
            }

            public sealed class FluffyClose
            {
                [JsonPropertyName("day")]
                public long Day { get; set; }

                [JsonPropertyName("hour")]
                public long Hour { get; set; }

                [JsonPropertyName("minute")]
                public long Minute { get; set; }
            }
            public sealed class Review
            {
                [JsonPropertyName("name")]
                public string? Name { get; set; }

                [JsonPropertyName("relativePublishTimeDescription")]
                public string? RelativePublishTimeDescription { get; set; }

                [JsonPropertyName("rating")]
                public long Rating { get; set; }

                [JsonPropertyName("authorAttribution")]
                public AuthorAttribution? AuthorAttribution { get; set; }

                [JsonPropertyName("publishTime")]
                public DateTimeOffset PublishTime { get; set; }

                [JsonPropertyName("text")]
                public DisplayNameInfo? Text { get; set; }

                [JsonPropertyName("originalText")]
                public DisplayNameInfo? OriginalText { get; set; }
            }

            public sealed class ViewportInfo
            {
                [JsonPropertyName("low")]
                public LocationInfo? Low { get; set; }

                [JsonPropertyName("high")]
                public LocationInfo? High { get; set; }
            }
        }
    }
}

