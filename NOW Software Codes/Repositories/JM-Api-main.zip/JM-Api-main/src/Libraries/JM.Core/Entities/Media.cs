using JM.Core.Entities.Common;

namespace JM.Core.Entities;

public sealed class Media : IBaseEntity<long>, IAuditEntity
{
    public long Id { get; set; }
    public string Type { get; set; } = null!;
    public string Url { get; set; } = null!;
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public DateTime? DeletedAt { get; set; }
    public long TravelerId { get; set; }
    public Traveler Traveler { get; set; } = null!;
    public long TripId { get; set; }
    public Trip Trip { get; set; } = null!;
}
