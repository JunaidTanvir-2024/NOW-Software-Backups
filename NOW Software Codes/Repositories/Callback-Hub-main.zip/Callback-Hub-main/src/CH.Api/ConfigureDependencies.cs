using CH.Api.Common.Helpers;
using CH.Api.Common.Http;
using CH.Api.Common.Repositories;
using CH.Api.Common.Settings;
using CH.Api.Features.DTOne;

namespace CH.Api;

public static class ConfigureDependencies
{
    public static IServiceCollection AddApiDependencies(this IServiceCollection services, IConfiguration configuration)
    {
        services.RegisterJsonSettings(configuration);
        services.AddHttpClient();
        services.AddScoped<IHttpService, HttpService>();
        services.AddSingleton<ISecurityHelpers, SecurityHelpers>();
        services.AddTransient<ILoggerRepository, LoggerRepository>();
        services.AddScoped<IDTOneHandler, DTOneHandler>();
        return services;
    }
    private static IServiceCollection RegisterJsonSettings(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<SecuritySetting>(configuration.GetSection(SecuritySetting.SectionName));
        services.Configure<SecurityHeaderSetting>(configuration.GetSection(SecurityHeaderSetting.SectionName));
        services.Configure<FusionHubSetting>(configuration.GetSection(FusionHubSetting.SectionName));

        return services;
    }
}
