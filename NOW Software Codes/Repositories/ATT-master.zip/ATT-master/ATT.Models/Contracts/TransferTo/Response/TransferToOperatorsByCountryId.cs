﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.TransferTo.Response
{

    public class TransferToOperatorsByCountryId
    {        
        public string Country { get; set; }
        public List<OperatorsByCountry> Operators{ get; set; }
    }
    public class OperatorsByCountry
    {
        public string OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorImageUrl { get; set; }
    }
}
