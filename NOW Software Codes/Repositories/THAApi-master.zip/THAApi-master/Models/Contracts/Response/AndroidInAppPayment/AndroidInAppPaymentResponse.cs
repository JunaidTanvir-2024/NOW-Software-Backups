﻿using Models.Database;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response.AndroidInAppPayment
{
	public class AndroidInAppPaymentResponse
	{
		public AndroidInAppPaymentResponse()
		{
			inAppPurchase = new List<InAPPAndroidPaymentSettings>();
		}

		public IEnumerable<InAPPAndroidPaymentSettings> inAppPurchase { get; set; }
		public bool voucher { get; set; }
	}
}
