﻿namespace THCC.Domain.Entities
{
    public class AutoTopUpTransactions
    {
        public string Account { get; set; } = default!;
        public string BundleRef { get; set; } = default!;
        public int TopupAmount { get; set; }
        public string TopupCurrency { get; set; } = default!;
        public string ProductRef { get; set; } = default!;
        public int ReExecuteCount { get; set; }
        public bool IsSuccess { get; set; }
        public int ErrorCode { get; set; }
        public DateTime LastExecutionDate { get; set; }
        public decimal Balance { get; set; }
        public decimal Threshold { get; set; }
        public string Email { get; set; } = default!;
        public string ProductCode { get; set; } = default!;
        public string InitialTransactionId { get; set; } = default!;
        public string MaskedPan { get; set; } = default!;
    }
}
