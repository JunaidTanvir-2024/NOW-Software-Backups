﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TalkhomeWebApp.Models.ViewModels
{
    public class VerifyCodeViewModel
    {
        [Required(ErrorMessage = "Enter your phone number")]
        [MaxLength(length: 50, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumber { get; set; }
        [Required]
        [MaxLength(length: 5, ErrorMessage = "Maximum length exceeded")]
        public string PhoneNumberCountryCode { get; set; }
        public bool RememberMe { get; set; }
        public string ReturnUrl { get; set; }

        [Required(ErrorMessage = "Please enter 4-digit pin")]
        [StringLength(4, MinimumLength = 4, ErrorMessage = "Please enter 4-digit pin")]
        public string PinNumber { get; set; }
        public string Token { get; set; }
        public string AirShipChannelId { get; set; }
    }
}
