﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATT.Controllers
{
    [ApiController]
    public class HealthCheckController : Controller
    {

        [HttpGet]
        [Route("/healthCheck")]
        public async Task<IActionResult> healthCheck()
        {
            return Ok();
        }

    }
}
