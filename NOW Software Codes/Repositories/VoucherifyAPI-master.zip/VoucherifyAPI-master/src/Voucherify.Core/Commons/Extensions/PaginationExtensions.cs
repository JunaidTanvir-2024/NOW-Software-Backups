using RW;
using RW.Models;

namespace Voucherify.Core.Commons.Extensions;

public static class PaginationExtensions
{
    /// <summary>
    /// Includes pagination information in the service result by extending an existing service result.
    /// </summary>
    public static IResultWrapper<TPayload> IncludePagination<TPayload>(this IResultWrapper<TPayload> source, int currentPage, int totalRecordsPerPage, int? totalAvailableRecords, int? totalPages = null) where TPayload : class
    {
        int? pageCount = GetTotalRecored(currentPage, totalRecordsPerPage, totalAvailableRecords, totalPages);

        return !string.IsNullOrEmpty(source.Message)
                ? ResultWrapper.Success(source.Payload, new Pagination(totalAvailableRecords, pageCount, currentPage, totalRecordsPerPage), source.Message, code: source.Code)
                : ResultWrapper.Success(source.Payload, new Pagination(totalAvailableRecords, pageCount, currentPage, totalRecordsPerPage));
    }

    /// <summary>
    /// Includes pagination information in the service result by extending an existing service result.
    /// </summary>
    public static IResultWrapper IncludePagination(this IResultWrapper source, int currentPage, int totalRecordsPerPage, int? totalAvailableRecords, int? totalPages = null)
    {
        int? pageCount = GetTotalRecored(currentPage, totalRecordsPerPage, totalAvailableRecords, totalPages);

        return !string.IsNullOrEmpty(source.Message)
             ? ResultWrapper.Success(source.Payload, new Pagination(totalAvailableRecords, pageCount, currentPage, totalRecordsPerPage), source.Message, code: source.Code)
                : ResultWrapper.Success(source.Payload, new Pagination(totalAvailableRecords, pageCount, currentPage, totalRecordsPerPage));
    }

    private static int? GetTotalRecored(int currentPage, int totalRecordsPerPage, int? totalAvailableRecords, int? totalPages)
    {
        if (currentPage <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(currentPage), "Current page must be greater than zero.");
        }

        if (totalRecordsPerPage <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(totalRecordsPerPage), "Page size must be greater than zero.");
        }

        return totalPages ?? (totalAvailableRecords != null ? (int)Math.Ceiling((double)totalAvailableRecords / totalRecordsPerPage) : 0);
    }
}
