using CH.Api.Common.Definitions;

namespace CH.Api.Common.Middlewares;

public class AppExceptionMiddleware(RequestDelegate next, Serilog.ILogger logger)
{
    private readonly RequestDelegate _next = next;
    private readonly Serilog.ILogger _logger = logger;

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            // Handle the exception and generate an appropriate response
            context.Response.ContentType = AppConstants.ContentTypes.ApplicationJson;
            context.Response.StatusCode = AppConstants.StatusCodes.InternalServerError;

            _logger.Error(ex, ex.Message);

            await context.Response.WriteAsJsonAsync(new { ErrorMessage = ex.StackTrace!.ToString(), ErrorCode = AppConstants.StatusCodes.InternalServerError });
        }
    }
}
