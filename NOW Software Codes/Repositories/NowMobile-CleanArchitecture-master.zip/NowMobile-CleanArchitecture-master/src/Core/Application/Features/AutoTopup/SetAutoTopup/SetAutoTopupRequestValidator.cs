﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.SetAutoTopup;

public class SetAutoTopupRequestValidator : AbstractValidator<SetAutoTopupRequest>
{
    public SetAutoTopupRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        RuleFor(p => p.ThresholdAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.AutoTopupThresholdAmounts.Contains(p))
            .WithMessage("Invalid threshold amount");

        RuleFor(p => p.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .WithMessage("Invalid top-up amount");
    }
}