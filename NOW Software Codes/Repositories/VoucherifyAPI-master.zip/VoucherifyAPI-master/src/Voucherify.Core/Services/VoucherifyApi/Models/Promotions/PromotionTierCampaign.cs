using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Promotions;

public class PromotionTierCampaign
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("start_date")]
    public DateTime? StartDate { get; set; }

    [JsonPropertyName("expiration_date")]
    public DateTime? ExpirationDate { get; set; }

    [JsonPropertyName("active")]
    public bool Active { get; set; }
}