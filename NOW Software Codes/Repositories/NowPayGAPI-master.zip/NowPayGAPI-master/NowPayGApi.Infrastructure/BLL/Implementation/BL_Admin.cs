﻿using Microsoft.Extensions.Options;
using NowPayGApi.Infrastructure.BLL.Interfaces;
using NowPayGApi.Infrastructure.DAL.Interfaces;
using NowPayGApi.Models.Configurations;
using NowPayGApi.Models.Contracts;
using NowPayGApi.Models.Contracts.Request;
using NowPayGApi.Models.Contracts.Response;
using NowPayGApi.Models.DAOs;
using NowPayGApi.Models.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using Serilog;
using System.Threading.Tasks;
using System.Linq;
using System.IO;
using MimeKit;
using System.Net.Mail;
using Serilog;
using System.Net;

namespace NowPayGApi.Infrastructure.BLL.Implementation
{
    public class BL_Admin : IBL_Admin
    {
        private readonly IDL_Admin DL;
        private readonly SmtpConfig SmtpConfig;
        private readonly TokensConfig TokensConfig;
        private readonly OtpExpirationTimeConfig OtpConfig;
        private readonly ILogger Logger;

        public BL_Admin(ILogger logger, IDL_Admin dl, IOptions<SmtpConfig> smtpConfig, IOptions<TokensConfig> tokensConfig, IOptions<OtpExpirationTimeConfig> otpConfig)
        {
            Logger = logger;
            DL = dl;
            SmtpConfig = smtpConfig.Value;
            TokensConfig = tokensConfig.Value;
            OtpConfig = otpConfig.Value;
        }

        public async Task<LoginResponseModel> Login(LoginRequestModel model)
        {
            try
            {
                DBUser user = new DBUser()
                {
                    Email = model.Email,
                    Password = CryptoHelper.Hash(model.Password)
                };
                var result = await DL.Login(user);
                if (result != null)
                {
                    return new LoginResponseModel()
                    {
                        Id = result.Id,
                        FirstName = result.FirstName,
                        LastName = result.LastName,
                        Email = result.Email,
                        CountryId = result.CountryId,
                        Role = result.Role
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetUsersResponseModel>> GetAllUsers(GetUsersRequestModel request)
        {
            try
            {
                var result = await DL.GetAllUsers(request.CSVNumbers);
                if (result != null && result.Count() > 0)
                {
                    var UserList = new GetUsersResponseModel()
                    {
                        UserList = result.Select(UserData => new UserResponseModel()
                        {
                            Id = UserData.Id,
                            Firstname = UserData.Firstname,
                            Lastname = UserData.Lastname,
                            Email = UserData.Email,
                            IsEmailVerified = UserData.IsEmailVerified,
                            Address = UserData.Address,
                            CountryId = UserData.CountryId,
                            Role = UserData.Role,
                            CountryName = UserData.CountryName,
                            MailSubscription = UserData.MailSubscription,
                            IsActive = UserData.IsActive,
                            CreatedDatetime = UserData.CreatedDatetime,
                            SocialSignUpTypeId = UserData.SocialSignUpTypeId
                        }).AsEnumerable()
                    };
                    return GenericApiResponse<GetUsersResponseModel>.Success(UserList, "Found users data.");
                }
                return GenericApiResponse<GetUsersResponseModel>.Failure(new GetUsersResponseModel() { UserList = new List<UserResponseModel>() { } }, "No users found.", ApiStatusCodes.UserNotFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<GetUserByIDResponseModel>> GetUserByID(GetUserByIDRequestModel request)
        {
            try
            {
                var result = await DL.GetUserByID(request.userData);
                if (result != null)
                {
                    var userdetails = new GetUserByIDResponseModel()
                    {
                        userData = new UserResponseModel()
                        {
                            Id = result.userData.Id,
                            Firstname = result.userData.Firstname,
                            Lastname = result.userData.Lastname,
                            Email = result.userData.Email,
                            IsEmailVerified = result.userData.IsEmailVerified,
                            Address = result.userData.Address,
                            CountryId = result.userData.CountryId,
                            Role = result.userData.Role,
                            IsActive = result.userData.IsActive,
                            CreatedDatetime = result.userData.CreatedDatetime,
                            Password = result.userData.Password,
                            SocialSignUpTypeId = result.userData.SocialSignUpTypeId
                        },
                        userAddressList = result.userAddressList.Select(address => new UserAddressResponseModel()
                        {


                        }).AsEnumerable()
                    };
                    return GenericApiResponse<GetUserByIDResponseModel>.Success(userdetails, "Found user Data.");
                }
                return GenericApiResponse<GetUserByIDResponseModel>.Failure("User not found.", ApiStatusCodes.UserNotFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdateUserStatus(UpdateUserStatusModel request)
        {
            try
            {
                var result = await DL.UpdateUserStatus(request);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "User status successfully updated.");
                }
                return GenericApiResponse<bool>.Failure("Status update failed.", ApiStatusCodes.UserStatusNotChanged);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> SaveUpdateAdmin(SaveUpdateAdminRequestModel request)
        {
            try
            {
                request.adminData.Password = CryptoHelper.Hash(request.adminData.Password);

                var result = await DL.SaveUpdateAdmin(request.adminData);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Admin registered scuccessfully.");
                }
                return GenericApiResponse<bool>.Failure("Something went wrong on server.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<GenericApiResponse<GetAllAdminsResponse>> GetAllAdmins(GetAllAdminsRequestModel request)
        {
            try
            {
                var result = await DL.GetAllAdmins(request.adminData);
                if (result != null && result.Count() > 0)
                {
                    var adminsList = new GetAllAdminsResponse()
                    {
                        AdminsList = result
                    };
                    return GenericApiResponse<GetAllAdminsResponse>.Success(adminsList, "Found admins data.");
                }
                return GenericApiResponse<GetAllAdminsResponse>.Failure("admins record not found.", ApiStatusCodes.UserNotFound);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdateAdminStatus(UpdateAdminStatusRequestModel request)
        {
            try
            {
                var result = await DL.UpdateAdminStatus(request.adminData);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Status updated successfully.");
                }
                return GenericApiResponse<bool>.Success(true, "Status update failed.");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<GenericApiResponse<bool>> UpdatePlanStatus(UpdatePlanStatusModel modelId)
        {
            try
            {
                var result = await DL.UpdatePlanStatus(modelId);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Status updated successfully.");
                }
                return GenericApiResponse<bool>.Failure(false, "Status update failed.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> UpdatePlan(AddPlanRequestModel model)
        {
            try
            {
                var result = await DL.UpdatePlan(model);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Plan updated successfully.");
                }
                return GenericApiResponse<bool>.Failure("false", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> AddPlan(AddPlanRequestModel model)
        {
            try
            {
                var result = await DL.AddPlan(model);
                if (result > 0)
                {
                    return GenericApiResponse<bool>.Success(true, "Plan added successfully.");
                }
                return GenericApiResponse<bool>.Failure("Something went wrong while adding plan.", ApiStatusCodes.DBError);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericApiResponse<bool>> DispatchOrder(DispatchOrderRequestModel model, int userId)
        {
            var result = await DL.DispatchOrder(model.OrderId, userId);
            if (result > 0)
            {
                return GenericApiResponse<bool>.Success(true, "Order dispatched successfully");
            }
            else
            {
                return GenericApiResponse<bool>.Failure("Faliure", ApiStatusCodes.NoSimOrderFound);
            }
        }

        public async Task<GenericApiResponse<GetSpecificSimOrderDetailsResponseModel>> GetSpecificSimOrderDetails(GetSpecificSimOrderDetailsRequestModel model)
        {

            GetSpecificSimOrderDetailsResponseModel response = new GetSpecificSimOrderDetailsResponseModel();
            response.OrderDetails = await DL.GetSpecificSimOrderDetails(model.OrderId);

            return GenericApiResponse<GetSpecificSimOrderDetailsResponseModel>.Success(response, "found sim order details");
        }

        public async Task<GenericApiResponse<GetAllSimOrdersResponseModel>> GetAllSimOrders()
        {
            var result = await DL.GetAllSimOrders();
            if (result.Count() > 0)
            {
                var OrderList = new GetAllSimOrdersResponseModel()
                {
                    OrderList = result.Select(Order => new SimOrderResponseModel()
                    {
                        Id = Order.Id,
                        CustomerName = Order.FirstName + (string.IsNullOrEmpty(Order.LastName) ? "" : " " + Order.LastName),
                        IsDispatched = Order.IsDispatched,
                        City = Order.City,
                        OrderDateTime = Order.OrderDateTime,
                        DispatchDateTime = Order.DispatchDateTime,
                        DispatchedByName = Order.DispatchedByName,
                        IsReplacement = Order.IsReplacement
                    }).AsEnumerable()
                };
                return GenericApiResponse<GetAllSimOrdersResponseModel>.Success(OrderList, "found sim orders");
            }
            else
            {
                return GenericApiResponse<GetAllSimOrdersResponseModel>.Success(new GetAllSimOrdersResponseModel() { OrderList = new List<SimOrderResponseModel>() { } }, "sim orders not found");
            }
        }

        public async Task<GenericApiResponse<int>> Insertotp(InsertotpRequestModel model)
        {
            var result = await DL.Insertotp(model);
            if (result != null)
            {
                var builder = new BodyBuilder();

                using (StreamReader SourceReader = File.OpenText(string.Format(Path.GetFullPath(@"~\wwwroot\Templates\Otp.html").Replace("~\\", ""))))
                {
                    builder.HtmlBody = SourceReader.ReadToEnd();
                }
                string messageBody = string.Format(builder.HtmlBody, model.otpcode);

                 SendEmailToCustomer(model.Email, messageBody, "Sim Order & Registration Email");

                return GenericApiResponse<int>.Success("Otp saved sucessfully");
            }
            else
            {
                return GenericApiResponse<int>.Failure("Faliure", ApiStatusCodes.DBError);
            }
        }

        private async Task<bool> SendEmailToCustomer(string customerEmail, string Message, string Subject)
        {
            try
            {
                SmtpClient client = new SmtpClient(SmtpConfig.server);

                if (string.IsNullOrEmpty(Message))
                {
                    Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {""}, ErrorMessage: Empty Message");
                    return false;
                }

                if (SmtpConfig.userName != "" && SmtpConfig.password != "")
                {
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential(SmtpConfig.userName, SmtpConfig.password);
                }
                else
                {
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                }

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SmtpConfig.fromForNowPayGSignUp);
                mailMessage.To.Add(customerEmail);
                mailMessage.Body = Message;
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: BL_User, Method: SendEmailToCustomer, Parameters=> customerEmail: {customerEmail}, Message: {Message}, ErrorMessage: {ex.Message}");
                return false;
            }

        }

        public async Task<GenericApiResponse<int>> Verifyotp(VerifyotpRequestModel model)
        {
            model.ExpiryMinutes = int.Parse(OtpConfig.OTPExpiryMinutes.ToString());
            var result = await DL.Verifyotp(model);

            if (result == 1)
            {     
                return GenericApiResponse<int>.Success(result,"Otp verified sucessfully");
            }
            if (result == 2)
            {
                return GenericApiResponse<int>.Success(result, "Otp verification Failed");
            }
            else
            {
                return GenericApiResponse<int>.Failure("Faliure", ApiStatusCodes.DBError);
            }
        }

        public async Task<GenericApiResponse<int>> VerifyUserSimOrder(VerifyUserSimOrderRequestModel model)
        {
            
            var result = await DL.VerifyUserSimOrder(model);

            if (result == 6)
            {
                return GenericApiResponse<int>.Failure("Faliure", ApiStatusCodes.DBError);
            }
            else
            {
                return GenericApiResponse<int>.Success(result, "");
            }
        }

        public async Task<GenericApiResponse<int>> IsverifiedUser(string email)
        {
            var result = await DL.IsverifiedUser(email);

            if (result == 1)
            {
                return   GenericApiResponse<int>.Success(result, "User Exists and verified");
            }
            if (result == 2)
            {
                return GenericApiResponse<int>.Success(result, "User not verified");
            }
            else
            {
                return GenericApiResponse<int>.Failure("Faliure", ApiStatusCodes.DBError);
            }
        }
    }
}
