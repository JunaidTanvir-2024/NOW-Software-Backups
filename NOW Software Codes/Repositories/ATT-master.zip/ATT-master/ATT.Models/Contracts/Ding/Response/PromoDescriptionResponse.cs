﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATT.Models.Contracts.Ding.Response
{
    public class DingPromoDescriptionResponse
    {
        public List<DingPromoDescription> items { get; set; } = new List<DingPromoDescription>();
    }
    public class DingPromoDescription
    {
        public string Dates { get; set; }
        public string Headline { get; set; }
        public string TermsAndConditionsMarkDown { get; set; }
        public string BonusValidity { get; set; }
        public string PromotionType { get; set; }
        public Guid LocalizationKey { get; set; }
        public string LanguageCode { get; set; }
    }

    public class DingCountries
    {
        public List<CountryDetails> items { get; set; } = new List<CountryDetails>();
       
    }

    public class CountryDetails
    {
        public string CountryIso { get; set; }
        public string CountryName { get; set; }

    }

    public class DingProviders
    {
        public List<ProviderDetails> items { get; set; } = new List<ProviderDetails>();

    }

    public class ProviderDetails
    {
        public string ProviderCode { get; set; }
        public string Name { get; set; }
        public string CountryIso { get; set; }

    }
}
