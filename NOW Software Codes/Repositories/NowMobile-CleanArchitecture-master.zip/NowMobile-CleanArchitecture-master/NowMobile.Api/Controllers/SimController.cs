﻿using Application.Features.Payment.Card.ExistingCardPayment;
using Application.Features.Payment.Paypal.CreateSale;
using Application.Features.Sim.CreditSim.AuthOrder;
using Application.Features.Sim.CreditSim.Confirm;
using Application.Features.Sim.CreditSim.Order;
using Application.Features.Sim.CreditSim.Payment.NewCardPayment;
using Application.Features.Sim.CreditSim.Resend;
using Application.Features.Sim.FreeSim.AuthOrder;
using Application.Features.Sim.FreeSim.Confirm;
using Application.Features.Sim.FreeSim.Order;

namespace NowMobile.Api.Controllers;
public class SimController : VersionedApiController
{
    #region Credit Sim

    [HttpPost("credit"), AllowAnonymous, OpenApiOperation("order credit sim.", "")]
    public async Task<IActionResult> SignUpCreditSimAsync([FromBody] CreditSimOrderRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("credit/confirm"), AllowAnonymous, OpenApiOperation("confirm order credit sim.", "")]
    public async Task<IActionResult> SignUpCreditSimConfirmAsync([FromBody] CreditSimConfirmRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("credit/confirm/resend"), AllowAnonymous, OpenApiOperation("Resend Otp for credit sim order confirmation", "")]
    public async Task<IActionResult> SignUpCreditSimResendAsync([FromBody] CreditSimResendRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("credit/auth"), OpenApiOperation("Credit sim order with authenticated user.", "")]
    public async Task<IActionResult> SignUpAuthSimOrderAsync([FromBody] AuthCreditSimOrderRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("credit/payment/newcard"), Authorize, OpenApiOperation("Charge payment for credit sim from new card.", "")]
    public async Task<IActionResult> CreditSimNewCardAsync([FromBody] CreditSimNewCardPaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("credit/payment/existingcard"), Authorize, OpenApiOperation("Charge payment for credit sim from existing card.", "")]
    public async Task<IActionResult> CreditSimExistingCardAsync([FromBody] CreditSimExistingCardPaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }
    [HttpPost("credit/payment/paypal"), Authorize, OpenApiOperation("Charge payment for credit sim from paypal.", "")]
    public async Task<IActionResult> CreditSimPaypalAsync([FromBody] CreditSimPaypalCreateSalePaymentRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    #endregion

    #region Free Sim

    [HttpPost("free"), AllowAnonymous, OpenApiOperation("order free sim.", "")]
    public async Task<IActionResult> SignUpFreeSimAsync([FromBody] FreeSimOrderRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("free/confirm"), AllowAnonymous, OpenApiOperation("Confirm free sim order.", "")]
    public async Task<IActionResult> SignUpFreeSimConfirmAsync([FromBody] FreeSimConfirmRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("free/confirm/resend"), AllowAnonymous, OpenApiOperation("Resend Otp for free sim order confirmation.", "")]
    public async Task<IActionResult> SignUpFreeSimResendAsync([FromBody] FreeSimResendRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    [HttpPost("free/auth"), OpenApiOperation("Free sim order with authenticated user.", "")]
    public async Task<IActionResult> SignUpAuthSimOrderAsync([FromBody] AuthFreeSimOrderRequest request)
    {
        request.IpAddress = GetIpAddress();
        return Ok(await Mediator.Send(request));
    }

    #endregion

    private string GetIpAddress() =>
       Request.Headers.ContainsKey("X-Forwarded-For")
           ? Request.Headers["X-Forwarded-For"]
           : HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "N/A";
}
