﻿using NowPayGApi.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserDataHistoryResponseModel
    {
        public IEnumerable<DBDataHistory> DataHistory { get; set; }
        public int DataHisotryTotalRecords { get; set; }
    }
}
