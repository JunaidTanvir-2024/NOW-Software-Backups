namespace Application.Features.Rate.Model;

public class UkRate
{
    public string? ContentHeader { get; set; }
    public string? Content { get; set; }
    public string? Description { get; set; }
}
