﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NowPayG.Models;

namespace NowPayG.Controllers
{
    public class ErrorController : Controller
    {
        [HttpGet]
        [AllowAnonymous]
        [Route("SystemError")]
        public async Task<IActionResult> SystemError()
        {
            var model = new MessageViewModel()
            {
                Heading = "Error",
                Message = "Something went wrong on server."
            };

            await model.SetSharedDataAsync(User);
            return View("~/Views/Shared/Error.cshtml", model);
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("Error/{statuscode}")]
        [Route("Error")]
        public async Task<IActionResult> Error(int statuscode)
        {
            var model = new MessageViewModel();
            switch (statuscode)
            {
                case 404:
                    return View("~/Views/Shared/404.cshtml");
                    break;
                case 500:
                    model = new MessageViewModel()
                    {
                        Heading = "Error",
                        Message = "Something went wrong on server."
                    };

                    await model.SetSharedDataAsync(User);
                    return View("~/Views/Shared/Error.cshtml", model);
                    break;
            }
            model = new MessageViewModel()
            {
                Heading = (string)TempData["Heading"],
                Message = (string)TempData["Message"]
            };

            await model.SetSharedDataAsync(User);

            return View("~/Views/Shared/Error.cshtml", model);
        }

        //[HttpGet]
        //[AllowAnonymous]
        //[Route("Error")]
        //public async Task<IActionResult> Error()
        //{
        //    var model = new MessageViewModel();
        //    model = new MessageViewModel()
        //    {
        //        Heading = (string)TempData["Heading"],
        //        Message = (string)TempData["Message"]
        //    };

        //    await model.SetSharedDataAsync(User);

        //    return View("~/Views/Shared/Error.cshtml", model);
        //}
    }
}