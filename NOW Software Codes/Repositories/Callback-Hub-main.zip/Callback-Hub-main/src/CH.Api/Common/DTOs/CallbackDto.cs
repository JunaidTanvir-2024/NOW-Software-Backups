namespace CH.Api.Common.DTOs;

public record CallbackDto(string hash, object data);
