﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request
{
    public class UpdateMissingDetailsRequestModel
    {
        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid first name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Enter first name"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [RegularExpression(@"^[a-zA-Z0-9 .&-]*$", ErrorMessage = "Invalid last name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Enter email address"), MaxLength(length: 50, ErrorMessage = "Maximum 50 characters allowed")]
        [EmailAddress(ErrorMessage = "Email is invalid")]
        public string Email { get; set; }
        public bool EmailSubscription { get; set; }
    }
}
