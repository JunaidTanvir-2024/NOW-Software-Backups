﻿using SC.Core.Common.Definitions.Utilities;
using SC.Core.Models.OrderCheckout.Payment;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using static SC.Core.Common.Definitions.Constants.AppEnums;

namespace SC.Api.Model.CustomerOrder;
public record ProcessOrderPaymentModel
{
    public string? PromoCode { get; set; }
    [Required(ErrorMessage = "The {0} field is required.")]
    [EnumValidation(typeof(AppEnums.PaymentMethod), ErrorMessage = "The {0} field is required and must be a valid PaymentMethod value.")]
    public PaymentMethod paymentMethod { get; set; } = AppEnums.PaymentMethod.Pay360;
    public PaymentCardDto Card { get; set; } = default;
}

