﻿using THCC.Application.Features.User.Login;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Interfaces.Services;
using THCC.Application.Interfaces.Services.Tracking;
using THCC.Application.Models.Dtos;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Signup.SignupConfirm;

internal class SignupConfirmRequestHandler : IRequestHandler<SignupConfirmRequest, object>
{
    private readonly IMapper _mapper;
    private readonly IOtpService _otpService;
    private readonly IUserRepository _userRepository;
    private readonly IJwtService _jwtService;
    private readonly ICommonService _commonService;
    private readonly IMailService _mailService;
    private readonly IAirshipService _airshipService;

    public SignupConfirmRequestHandler(
        IMapper mapper,
        IOtpService otpService,
        IUserRepository userRepository,
        IJwtService jwtService,
        ICommonService commonService,
        IMailService mailService,
        IAirshipService airshipService)
    {
        _mapper = mapper;
        _otpService = otpService;
        _userRepository = userRepository;
        _jwtService = jwtService;
        _commonService = commonService;
        _mailService = mailService;
        _airshipService = airshipService;
    }

    public async Task<object> Handle(SignupConfirmRequest request, CancellationToken cancellationToken)
    {
        request.Email = request.Email.Trim();

        var user = await _userRepository.GetUserByEmailAsync(request.Email);
        if (user == null)
        {
            return ErrorResult.Failure(CustomStatusKey.AccountNotRegistered, CustomStatusCode.BadRequest);
        }

        if (user.EmailConfirmed)
        {
            return ErrorResult.Failure(CustomStatusKey.EmailAlreadyVerified, CustomStatusCode.BadRequest);
        }

        //get confirmation token
        var emailToken = await _otpService.GetTokenAgainstOtp(
                        request.Email, request.EmailOtp!, OtpType.SignUp);
        if (string.IsNullOrEmpty(emailToken))
        {
            return ErrorResult.Failure(CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }

        //token verification
        var response = await _userRepository.ConfirmEmailAsync(user!, emailToken);
        if (!response.Succeeded)
        {
            return ErrorResult.Failure(CustomStatusKey.InvalidOtp, CustomStatusCode.BadRequest);
        }
        else
        {
            await _airshipService.CreateEmailChannelAndAssociation(user.Email!, true);
            await _mailService.SendSignupSuccessEmail(user.Email!);
            var tokenInfo = await _jwtService.GetToken(user, _commonService.GetIpAddress());
            return new LoginResponse()
            {
                User = _mapper.Map<UserDto>(user!),
                RefreshToken = tokenInfo.RefreshToken!,
                Token = tokenInfo.Token!
            };
        }
    }
}