﻿
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TH.Infrastructure.DAL;
using TH.Models.Contracts.Response;
using TH.Models.Database;

namespace TH.Infrastructure.BLL
{
    public class TH_BL : ITH_BL
    {
        
        private ITHDb_DL Db;       
        private readonly ILogger Logger;
       

        public TH_BL(ILogger logger, ITHDb_DL db)
        {
            
            Db = db;           
            Logger = logger;           

        }

        public async Task<GenericApiResponse<Customer>> CustomerDetails(string msisdn)
        {

            try
            {

                Customer cust = await Db.CustomerDetails(msisdn);
                if(cust == null)
                {
                    return GenericApiResponse<Customer>.Failure("Invalid msisdn",2);
                }
                else
                {
                    return GenericApiResponse<Customer>.Success(cust, "Success");
                }

            }
            catch (Exception ex)
            {

                Logger.Error($"Class: TH_BL, Method: CustomerDetails, Parameters=> msisdn: {msisdn}, ErrorMessage: {ex.Message}");
                return GenericApiResponse<Customer>.Failure("Fatal error occurred", 10);
            }

        }

        public async Task<GenericApiResponse<List<AccountPlans>>> GetAccountPlans(string msisdn)
        {

            try
            {

                List<AccountPlans> plans = await Db.GetAccountPlans(msisdn);
                if (plans == null)
                {
                    return GenericApiResponse<List<AccountPlans>>.Failure("Error in data retrieval.");
                }
                else
                {
                    return GenericApiResponse<List<AccountPlans>>.Success(plans, "Success");
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: GetAccountPlans, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<List<AccountPlans>>.Failure(ex.Message);
            }

        }

        public async Task<GenericApiResponse<List<Plans>>> GetPlans()
        {

            try
            {

                List<Plans> plans = await Db.GetPlans();
                if (plans == null)
                {
                    return GenericApiResponse<List<Plans>>.Failure("Error in data retrieval.");
                }
                else
                {
                    return GenericApiResponse<List<Plans>>.Success(plans, "Success");
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: GetPlans, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<List<Plans>>.Failure(ex.Message);
            }

        }

        public async Task<GenericApiResponse<string>> SetPrimarySIMState(string msisdn, int state,string username)
        {

            try
            {

                DbResult<string> dbResult = await Db.SetPrimarySIMState(msisdn, state, username);
                if (dbResult.ErrorCode == 0)
                {
                    return GenericApiResponse<string>.Success(null, "Setting Primary SIM State is Successfull");
                    
                }else if (dbResult.ErrorCode == 1)
                {
                    return GenericApiResponse<string>.Failure("Invalid MSISDN",1);
                }
                else if (dbResult.ErrorCode == 2)
                {
                    return GenericApiResponse<string>.Failure("Invalid State on Request", 2);
                }else
                {
                    return GenericApiResponse<string>.Failure("Fatal error occurred", 10);
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: SetPrimarySIMState, Parameters => msisdn: {msisdn}, state: {state}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<string>.Failure("Fatal error occurred",10);
            }

        }

        public async Task<GenericApiResponse<string>> TopupVoucher(string msisdn, string pin)
        {

            try
            {

                DbResult<string> dbResult = await Db.TopupVoucher(msisdn, pin);
                if (dbResult.ErrorCode == 0)
                {
                    return GenericApiResponse<string>.Success("Topup Voucher successfull.", "Success");

                }
                else
                {
                    return GenericApiResponse<string>.Failure(dbResult.ErrorMsg.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: TopupVoucher, Parameters => msisdn: {msisdn}, pin: {pin}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<string>.Failure(ex.Message);
            }

        }


        public async Task<GenericApiResponse<PurchaseResult>> Purchase(string msisdn, string bundleref, decimal amount, string transactionid)
        {

            try
            {

               PurchaseResult dbResult = await Db.Purchase(msisdn, bundleref, amount, transactionid);
                if (dbResult.ErrorCode == 0)
                {
                    
                    return GenericApiResponse<PurchaseResult>.Success(dbResult, "Success");

                }
                else
                {
                    return GenericApiResponse<PurchaseResult>.Failure(dbResult.ErrorMsg.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: Purchase, Parameters => msisdn: {msisdn}, bundleref: {bundleref}, amount: {amount}, transactionid: {transactionid}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<PurchaseResult>.Failure(ex.Message);
            }

        }

        public async Task<GenericApiResponse<List<TopupHistory>>> GetTopupHistory(string msisdn)
        {

            try
            {

                List<TopupHistory> hist = await Db.GetTopupHistory(msisdn);
                if (hist == null)
                {
                    return GenericApiResponse<List<TopupHistory>>.Failure("Error in data retrieval.");
                }
                else
                {
                    return GenericApiResponse<List<TopupHistory>>.Success(hist, "Success");
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Class: TH_BL, Method: GetTopupHistory, Parameters=> msisdn: {msisdn}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return GenericApiResponse<List<TopupHistory>>.Failure(ex.Message);
            }

        }

    }
}
