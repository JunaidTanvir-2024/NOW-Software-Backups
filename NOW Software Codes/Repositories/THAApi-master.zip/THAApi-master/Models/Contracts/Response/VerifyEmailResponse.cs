﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    
    public class VerifyEmailReponse
    {
        public bool isAlreadyVerified { get; set; }
    }
}
