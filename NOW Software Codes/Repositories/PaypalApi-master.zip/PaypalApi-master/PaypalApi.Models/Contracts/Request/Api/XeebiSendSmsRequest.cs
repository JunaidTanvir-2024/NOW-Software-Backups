﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaypalApi.Models.Contracts.Request.Api
{
    public class XeebiSendSmsRequest
    {
        public string from { get; set; }
        public string to { get; set; }
        public string text { get; set; }

    }

    public class EmailTransactionModel
    {
        public string msisdn { get; set; }
        public string description { get; set; }
        public string status { get; set; }
        public string transactionId { get; set; }
        public string amount { get; set; }
        public string payerPaypalId { get; set; }
    }
}
