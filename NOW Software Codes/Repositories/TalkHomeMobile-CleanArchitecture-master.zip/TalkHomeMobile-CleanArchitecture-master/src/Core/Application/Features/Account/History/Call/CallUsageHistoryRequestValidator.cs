namespace Application.Features.Account.History.Call;
public class CallUsageHistoryRequestValidator : AbstractValidator<CallUsageHistoryRequest>
{
    public CallUsageHistoryRequestValidator(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull().Must(p => commonService.IsValidMsisdn(p)).WithMessage("Invalid Msisdn");
    }
}