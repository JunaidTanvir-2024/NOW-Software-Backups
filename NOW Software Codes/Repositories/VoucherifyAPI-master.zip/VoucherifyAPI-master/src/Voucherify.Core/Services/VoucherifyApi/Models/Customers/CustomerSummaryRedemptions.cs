using System.Text.Json.Serialization;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Customers;

public class CustomerSummaryRedemptions
{
    [JsonPropertyName("total_redeemed")]
    public int TotalRedeemed { get; set; }

    [JsonPropertyName("total_failed")]
    public int TotalFailed { get; set; }

    [JsonPropertyName("total_succeeded")]
    public int TotalSucceeded { get; set; }

    [JsonPropertyName("total_rolled_back")]
    public int TotalRolledBack { get; set; }

    [JsonPropertyName("total_rollback_failed")]
    public int TotalRollbackFailed { get; set; }

    [JsonPropertyName("total_rollback_succeeded")]
    public int TotalRollbackSucceeded { get; set; }

    [JsonPropertyName("gift")]
    public CustomerSummaryRedemptionsGift? Gift { get; set; }

    [JsonPropertyName("loyalty_card")]
    public CustomerLoyaltyCard? LoyaltyCard { get; set; }
}
