﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using TalkhomeWebApp.Models;

namespace TalkhomeWebApp.Services
{
    public interface IBundleService
    {
        public Task<List<Bundles>> GetBundleByCountry(string NaServiceId, string FromCoutry,string account, IPrincipal User);
        public Task<List<BundlesCountries>> GetBundlesCountries(IPrincipal User);
        Task<List<Bundles>> GetBundleByDestinationCountry(string NaServiceId, string FromCoutry, string toCountryCode, string account, IPrincipal User);
    }
}
