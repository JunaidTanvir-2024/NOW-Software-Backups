﻿using SenderService.Core.Common;
using SenderService.Core.Features.Email.Request;
using SenderService.Core.Features.Email.Response;

namespace SenderService.Core.Features.Email;
public interface IEmailService
{
    Task<ApiResult<bool>> AddEmailAsync(AddEmailRequest request);
    Task DeleteEmailAsync(RemoveEmailRequest request);
    Task<EmailResponse> GetSpecificEmailRecordAsync(GetSpecificEmailRecordRequest request);
    Task<ApiResult<IEnumerable<EmailResponse>>> GetEmailsAsync(GetEmailsRequest request);
    Task<bool> UpdateEmailAsync(UpdateEmailRequest request);
}