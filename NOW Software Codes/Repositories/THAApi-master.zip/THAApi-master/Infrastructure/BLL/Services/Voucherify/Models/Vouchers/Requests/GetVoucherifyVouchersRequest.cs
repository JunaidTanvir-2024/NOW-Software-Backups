﻿namespace Infrastructure.BLL.Services.Voucherify.Models.Vouchers.Requests
{
    public class GetVoucherifyVouchersRequest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
