﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts;
using TalkhomeAPI.Infrastructure.Common.Models.Contracts.Request;
using TalkhomeAPI.Infrastructure.Common.Models.DAOs;
using TalkhomeAPI.Infrastructure.Common.Services.Models.TalkHome;

namespace TalkhomeAPI.Infrastructure.Common.Services.Interfaces
{
    public interface ITalkHomeService 
    {
        Task<GenericApiResponse<SignUpResponse>> SignUp(SignUpRequest request);
        Task<GenericApiResponse<PreAuthResponseModel>> PreAuth(PreAuthRequestModel request);
        Task<GenericApiResponse<SignUpResponse>> SignUpWithPreAuth(SignUpWithPreAuthRequest request, string token);
        Task<GenericApiResponse<LoginApiResponseModel>> VerifyPin(LoginRequest request, string username, string password,string remoteIp);
        Task<GenericApiResponse<SignUpResponse>> SignUpOrSignInWithPreAuth(SignupWithPreAuthRequestV2 request,string remoteIp);               
    }
}
