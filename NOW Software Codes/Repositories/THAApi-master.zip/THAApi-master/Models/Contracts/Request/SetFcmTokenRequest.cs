﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models.Contracts.Request
{
    public class SetFcmTokenRequest
    {
        [JsonProperty("token")]
        [Required]
        public string Token { get; set; }
    }
}
