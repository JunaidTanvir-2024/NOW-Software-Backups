﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Request
{
  
    public class ReferralCode
    {
        public string referralCode { get; set; }
    }
}
