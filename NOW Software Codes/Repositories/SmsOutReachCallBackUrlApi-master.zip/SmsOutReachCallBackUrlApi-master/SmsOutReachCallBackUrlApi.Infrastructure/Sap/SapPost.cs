﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using SmsOutReachCallBackUrlApi.Contracts.Sap.Request;
using SmsOutReachCallBackUrlApi.Models;
using SmsOutReachCallBackUrlApi.Models.Configurations;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SmsOutReachCallBackUrlApi.Infrastructure.Sap
{
    public class SapPost : ISapPost
    {
        private readonly ILogger Logger;
        private ISapDb Db;

        public SapPost(ILogger logger, IOptions<ConnectionString> connectionConfig)
        {
            Logger = logger;
            string connectionString = connectionConfig.Value.SapDbConnection;
            Db = new SapDb(connectionString);
        }

        async public Task<DbResult> AddSmsCallBackUrlData(SapSmsCallBackRequest deliveryReport)
        {

            DbResult result = null;
            try
            {

                result = await Db.AddSmsCallBackData(deliveryReport);
                return result;
            }
            catch (Exception ex)
            {
                Logger.Error($"Database Insertion Error: - Class: SapPost, Method: AddSmsCallBackUrlData, Parameters --> SmsCallBackUrlJson: {JsonConvert.SerializeObject(deliveryReport)}, Exception: {ex.Message}");
                result = new DbResult();
                result.DBStatus = 2;
                result.DBErrorMessage = ex.Message;
                return result;
            }
        }
    }
}
