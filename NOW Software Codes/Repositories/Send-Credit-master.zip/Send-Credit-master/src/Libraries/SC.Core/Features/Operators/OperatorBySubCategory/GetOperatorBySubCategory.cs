﻿using MapsterMapper;

using RW.Models;

using SC.Core.Vendors.FusionHub;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SC.Core.Features.Operators.OperatorBySubCategory
{

    public sealed class GetOperatorBySubCategory
    {
        #region Query
        public sealed record Query : IRequest<IResultWrapper>
        {

            public string? CountryIsoCode { get; set; }
            public string? CurrencyCode { get; set; }
            public string? ProductCategoryAliasName { get; set; }
            public string? ProductSubCategoryAliasName { get; set; }
            public int Limit { get; set; }

        }
        #endregion

        #region Validator
        public sealed class Validator : AbstractValidator<Query>
        {
            public Validator()
            {

            }
        }
        #endregion

        #region Response
        public sealed record Response
        {


            [JsonPropertyName("subCategoryName")]
            public string? SubCategoryName { get; set; }

            [JsonPropertyName("operators")]
            public List<OperatorInfo> Operators { get; set; } = new List<OperatorInfo>();


            public sealed record OperatorInfo
            {

                [JsonPropertyName("operatorName")]
                public string? OperatorName { get; set; }

                [JsonPropertyName("operatorAliasName")]
                public string? OperatorAliasName { get; set; }

                [JsonPropertyName("operatorShortCode")]
                public string? OperatorShortCode { get; set; }

                [JsonPropertyName("operatorDescription")]
                public string? OperatorDescription { get; set; }

                [JsonPropertyName("logo")]
                public string? Logo { get; set; }

                [JsonPropertyName("countryIsoCode")]
                public string? CountryIsoCode { get; set; }

                [JsonPropertyName("currencyCode")]
                public string? CurrencyCode { get; set; }

                [JsonPropertyName("category")]
                public CategoryInfo Category { get; set; } = new CategoryInfo();

                public sealed record CategoryInfo
                {
                    [JsonPropertyName("categoryName")]
                    public string? CategoryName { get; set; }

                    [JsonPropertyName("subCategoryName")]
                    public string? SubCategoryName { get; set; }
                }
            }





        }
        #endregion

        #region Handler
        internal sealed class Handler(IMapper mapper, IFusionHubService _fusionHubService) : IRequestHandler<Query, IResultWrapper>
        {
            private readonly IMapper _mapper = mapper;
            private readonly IFusionHubService fusionHubService = _fusionHubService;

            public async Task<IResultWrapper> Handle(Query request, CancellationToken cancellationToken)
            {
                var response = await _fusionHubService.GetOperatorsBySubCategoryAsync(request);
                if (response?.Payload == null)
                {
                    return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
                }
                return ResultWrapper.Success(response.Payload);
            }

        }
        #endregion
    }
}



