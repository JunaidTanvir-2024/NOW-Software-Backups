﻿using THCC.Api.Controllers.Common;

namespace THCC.Api.Controllers
{
    public class ContactusController : BaseApiController
    {
        //[HttpPost, AllowAnonymous]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //public async Task<IActionResult> RefreshAsync([FromBody] ContactUsRequest request, CancellationToken cancellationToken)
        //{
        //    return HandleResponse(await Mediator.Send(request, cancellationToken));
        //}
    }
}
