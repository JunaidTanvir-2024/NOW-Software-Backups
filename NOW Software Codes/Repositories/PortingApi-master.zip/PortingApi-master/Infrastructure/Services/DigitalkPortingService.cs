﻿using Infrastructure.DAL;
using Infrastructure.Utilities;
using Microsoft.Extensions.Options;
using Models.Configurations;
using Models.Contracts.Request.ApiContracts;
using Models.Contracts.Response;
using Models.Contracts.Response.ApiContracts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class DigitalkPortingService : IDigitalkPortingService
    {
        private DigitalkConfig DigitalkConfigurations;
        private IApiCall ApiCall;
        private IDL_Porting Db;

        public DigitalkPortingService(IOptions<DigitalkConfig> digitalkConfig, IApiCall apiCall, IDL_Porting db)
        {
            DigitalkConfigurations = digitalkConfig.Value;
            ApiCall = apiCall;
            Db = db;
        }

        public async Task<HttpResponseMessage> GetSwitchingInformation(string SubscriberId)
        {
            try
            {
                string portApiEndPoint = $"{DigitalkConfigurations.ApiEndPoint}/subscribers/{SubscriberId}/sim/porting/gb/switching-information";
                HttpResponseMessage apiHttpResponse = null;
                string basicHeader = Utility.CreateBasicHeader(DigitalkConfigurations.Username, DigitalkConfigurations.Password);
                apiHttpResponse = await ApiCall.Get(portApiEndPoint, Models.Enums.TokenType.Basic, basicHeader);
                if (apiHttpResponse != null)
                {
                    return apiHttpResponse;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<HttpResponseMessage> PortOut(int subscriberId, int codeType)
        {
            try
            {
                string portApiEndPoint = $"{DigitalkConfigurations.ApiEndPoint}/subscribers/{subscriberId}/sim/porting/gb/port-out";
                HttpResponseMessage apiHttpResponse = null;
                PortOutRequest request = new PortOutRequest() { CodeType = codeType };
                string requestJson = JsonConvert.SerializeObject(request);
                try
                {
                    string basicHeader = Utility.CreateBasicHeader(DigitalkConfigurations.Username, DigitalkConfigurations.Password);
                    apiHttpResponse = await ApiCall.Post(portApiEndPoint, Models.Enums.TokenType.Basic, basicHeader, requestJson);
                    if(apiHttpResponse!=null)
                    {
                        return apiHttpResponse;
                    }
                    else
                    {
                        return null;
                    }

                }
                catch (Exception ex)  // Att Api Exception
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<HttpResponseMessage> CancelPortOut(int subscriberId, int codeType)
        {
            try
            {
                string portApiEndPoint = $"{DigitalkConfigurations.ApiEndPoint}/subscribers/{subscriberId}/sim/porting/gb/port-out";
                HttpResponseMessage apiHttpResponse = null;
                PortOutRequest request = new PortOutRequest() { CodeType = codeType };
                string requestJson = JsonConvert.SerializeObject(request);
                try
                {
                    string basicHeader = Utility.CreateBasicHeader(DigitalkConfigurations.Username, DigitalkConfigurations.Password);
                    apiHttpResponse = await ApiCall.Delete(portApiEndPoint, Models.Enums.TokenType.Basic, basicHeader, requestJson);
                    if (apiHttpResponse != null)
                    {
                        return apiHttpResponse;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (Exception ex)  // Att Api Exception
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
