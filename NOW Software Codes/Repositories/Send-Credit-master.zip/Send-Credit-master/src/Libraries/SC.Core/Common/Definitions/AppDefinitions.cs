﻿namespace SC.Core.Common.Definitions.Constants;
public static partial class AppConstants { }
public static partial class AppEnums { }

