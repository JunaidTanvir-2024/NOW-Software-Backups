﻿using NowPayGApi.Models.DAOs.Digitalk;
using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.Contracts.Response
{
    public class GetUserSummaryResponseModel
    {
        public MobileAccountResponseModel MobileAccount { get; set; }
        public IEnumerable<BundleResponseModel> BundleList { get; set; }
        public UserAccountLastTopupResponseModel LastTopUp { get; set; }
    }
}
