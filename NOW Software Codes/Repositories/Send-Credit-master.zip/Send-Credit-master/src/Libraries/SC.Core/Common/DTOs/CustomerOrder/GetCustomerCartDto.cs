﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Common.DTOs.CustomerOrder;
public record GetCustomerCartDto
{
    public long CustomerCartID { get; set; } = default!;
    public string UserID { get; set; } = default!;
    public int ProductId { get; set; } = default!;
    public string ProductName { get; set; } = default!;
    public decimal Price { get; set; } = default!;
    public int Quantity { get; set; } = default!;
    public string Currency { get; set; } = default!;
    public string DiscountType { get; set; } = default!;
    public decimal DiscountAmount { get; set; } = default!;
    public decimal TotalOrderPrice { get; set; } = default!;
    public string Status { get; set; } = default!;
    public string State { get; set; } = default!;
    public int CustomerOrderId { get; set; } = default!;

    public string ProductVendorCode { get; set; } = default!;
    public string ProductType { get; set; } = default!;
    public string ReceiverMobile { get; set; } = default!;
    public string SenderMobile { get; set; } = default!;
    public decimal ServiceFeeAmount { get; set; } = default!;
    public string ProductPriceType { get; set; } = default!;
    public decimal ProductPrice { get; set; } = default!;
    public string VendorFinalStatus { get; set; } = default!;
}

