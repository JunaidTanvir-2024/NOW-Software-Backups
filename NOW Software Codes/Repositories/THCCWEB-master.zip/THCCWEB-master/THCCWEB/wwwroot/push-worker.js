// 86acbd31cd7c09cf30acb66d2fbedc91daa48b86:1610606839.838443
importScripts('https://aswpsdkeu.com/notify/v1/ua-sdk.min.js')
uaSetup.worker(self, {
  defaultIcon: 'https://dl.asnapieu.com/binary/public/0cTHLU7uS0im9DNRQlrvvg/bd18d834\u002Dbe14\u002D490e\u002D8ba8\u002Dc0aa920167b8',
  defaultTitle: 'TalkHome Calling Cards',
  defaultActionURL: 'https://lab.talk\u002Dhome.co.uk',
  appKey: '0cTHLU7uS0im9DNRQlrvvg',
  token: 'MTowY1RITFU3dVMwaW05RE5SUWxydnZnOk5Ka1RsYUlJZGN5dzJNQnlhWHl6SWlIeFNtcVZ0b0FBaXMzcnN4XzRaWVk',
  vapidPublicKey: 'BAOAlbp_GUPjq4Zy35pRjBuXqQUHcjtugMWgHbm48XFrBo07bDiZnfCuOQj7_SnifdyFllPyB5lfTBUxf5_pvEA='
})
