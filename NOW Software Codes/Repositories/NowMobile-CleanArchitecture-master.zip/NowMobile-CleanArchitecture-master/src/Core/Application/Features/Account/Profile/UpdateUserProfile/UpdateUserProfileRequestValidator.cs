﻿namespace Application.Features.Account.Profile.UpdateUserProfile;
public class SetUserProfileRequestValidator : AbstractValidator<UpdateUserProfileRequest>
{
    public SetUserProfileRequestValidator()
    {
        RuleFor(p => p.FirstName).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
        RuleFor(p => p.LastName).Cascade(CascadeMode.Stop).NotEmpty().NotNull();
    }
}