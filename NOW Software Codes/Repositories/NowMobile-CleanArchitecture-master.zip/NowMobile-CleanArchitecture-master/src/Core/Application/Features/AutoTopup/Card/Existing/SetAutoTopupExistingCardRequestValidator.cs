using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.AutoTopup.Card.Existing;

public class SetAutoTopupExistingCardRequestValidator : AbstractValidator<SetAutoTopupExistingCardRequest>
{
    public SetAutoTopupExistingCardRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        // Payment Card properties validation
        RuleFor(p => p.PaymentCardInfo.CardToken).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MaximumLength(100);
        RuleFor(p => p.PaymentCardInfo.SecurityCode).Cascade(CascadeMode.Stop).NotEmpty().NotNull().MinimumLength(3).MaximumLength(4);

        // Auto Topup properties validation
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => commonService.IsValidMsisdn(p))
            .WithMessage("Invalid msisdn");

        //RuleFor(p => p.ThresHoldAmount).Cascade(CascadeMode.Stop)
        //    .NotEmpty()
        //    .NotNull()
        //    //.Must(p => options.Value.AutoTopupThresholdAmounts.Contains(p))
        //    .WithMessage("Invalid threshold amount");

        RuleFor(p => p.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .WithMessage("Invalid top-up amount");
    }
}