using FluentValidation;

using Voucherify.Api.Features.StackableDiscounts.Common;
using Voucherify.Core.Commons.Extensions;

namespace Voucherify.Api.Features.StackableDiscounts.Requests;

public class StackableDiscountRedemptionRequest
{
    public StackableDiscountCustomerInfo Customer { get; set; } = null!;
    public StackableDiscountOrderInfo Order { get; set; } = null!;
    public StackableDiscountRedemptionInfo Redemption { get; set; } = null!;
}

internal class StackableDiscountRedemptionRequestValidator : AbstractValidator<StackableDiscountRedemptionRequest>
{
    public StackableDiscountRedemptionRequestValidator()
    {
        RuleFor(p => p.Customer.SourceId)
            .NotNull()
            .NotEmpty()
            .WithMessage("Phone number is required")
            .FormatPhoneNumber((request, phoneNumber) => request.Customer.SourceId = phoneNumber);
        RuleFor(p => p.Redemption.DiscountCode).NotNull().NotEmpty();
        RuleFor(p => p.Redemption.DiscountType).NotNull().NotEmpty();
    }
}
