using FluentValidation;

using JM.Core.Utilities.Definitions;
using JM.Core.Utilities.Interfaces.Database;

using Mediator;

using RW;

namespace JM.Core.Features.Traveler;

public class GetTravelerList
{
    #region Query
    public sealed record Query : IRequest<IResultWrapper>
    {
        public long TripId { get; set; }
    }
    #endregion

    #region Validator
    public sealed class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.TripId).NotNull();
        }
    }
    #endregion

    #region Response
    public sealed record Response
    {
        public required TripInfo Trip { get; set; }
        public sealed record TripInfo
        {
            public long Id { get; set; }
            public string? Name { get; set; }
            public DateTime StartingDate { get; set; }
            public long CreatorId { get; set; }
            public IEnumerable<TravelerInfo>? Travelers { get; set; } = [];
        }
        public sealed record TravelerInfo
        {
            public required long Id { get; set; }
            public string? FullName { get; set; }
            public string? Email { get; set; }
        }
    }
    #endregion

    #region Handler
    internal sealed class Handler(IUnitOfWork unitOfWork) : IRequestHandler<Query, IResultWrapper>
    {
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async ValueTask<IResultWrapper> Handle(Query query, CancellationToken cancellationToken)
        {
            var travelers = query.TripId > 0 ? await _unitOfWork.TravelerRepository.GetTravelerList(x => x.Id.Equals(query.TripId))
            : await _unitOfWork.TravelerRepository.GetTravelerList();

            if (travelers is not null)
            {
                return ResultWrapper.Success(
                   travelers.Select(traveler => new Response()
                   {
                       Trip = new Response.TripInfo()
                       {
                           Id = traveler?.Id ?? default,
                           Name = traveler?.Name,
                           StartingDate = traveler?.StartingDate ?? default,
                           CreatorId = traveler?.CreatorId ?? default,
                           Travelers = traveler?.Travelers is not null ?
                           traveler?.Travelers.Select(
                            x => new Response.TravelerInfo()
                            {
                                Id = x?.User?.Id ?? default,
                                Email = x?.User?.Email,
                                FullName = x?.User?.UserDetail?.FullName,
                            }) : default!
                       }
                   }));
            }
            return ResultWrapper.Failure(AppConstant.StatusKey.NotFound, AppConstant.StatusCode.NotFound);
        }
    }
    #endregion
}
