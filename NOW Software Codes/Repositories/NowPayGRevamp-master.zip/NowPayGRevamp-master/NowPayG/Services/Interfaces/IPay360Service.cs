﻿using NowPayG.Models.Pay360ApiContracts;
using NowPayG.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Services.Interfaces
{
    public interface IPay360Service
    {
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Resume3DTransaction(Pay360Resume3DRequest request);
        Task<GenericPay360ApiResponse<Pay360CustomerModel>> GetCustomer(Pay360CustomerRequestModel model);
        Task<GenericPay360ApiResponse<Pay360CardsResponse>> Pay360GetCards(Pay360CustomerRequestModel request);
        Task<GenericPay360ApiResponse<Pay360PaymentResponse>> Pay360Payment(Pay360PaymentRequest request, Pay360PaymentType paymentType);
        Pay360PaymentRequestToken CreatePay360PaymentRequestToken(Pay360ViewModel model);
        Pay360PaymentBase CreatePay360PaymentBaseRequest(StartPay360ViewModel model);
        Pay360PaymentRequestExistingNew CreatePay360PaymentRequestExistingNew(Pay360ViewModel model);
        Pay360PaymentRequestNew CreatePay360PaymentRequestNew(Pay360ViewModel model);
        Task<GenericPay360ApiResponse<string>> SetAutoTopUp(Pay360SetAutoTopUpRequest model);
        Task<GenericPay360ApiResponse<Pay360GetAutoTopUpResponse>> GetAutoTopUp(Pay360GetAutoTopUpRequest model);
        Task<GenericPay360ApiResponse<paymentMethodResponse>> SetCustomerDefaultCard(SetCustomerDefaultCardRequest model);
        Task<GenericPay360ApiResponse<string>> RemoveCard(RemoveCardRequest model);
    }
}
