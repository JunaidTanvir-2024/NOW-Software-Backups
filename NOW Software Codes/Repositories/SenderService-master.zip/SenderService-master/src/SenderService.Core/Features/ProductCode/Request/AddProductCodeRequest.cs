﻿namespace SenderService.Core.Features.ProductCode.Request;
public class AddProductCodeRequest
{
    public string Code { get; set; } = null!;
    public string ItemCode { get; set; } = default!;
}
