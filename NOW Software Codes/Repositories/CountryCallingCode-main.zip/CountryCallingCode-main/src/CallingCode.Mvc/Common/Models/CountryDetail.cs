﻿namespace CallingCode.Mvc.Common.Models;

public class CountryDetail
{
    public Country? Country { get; set; }
    public WeatherForecastModel? Weather { get; set; }
    public CountryTimeZone? CountryTimeZone { get; set; }
    public CountryBundleInfoModel? BundleInfo { get; set; }
    public Variation ContentVariation { get; set; } = default!;
}
