﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BLL.Services.Interfaces
{
    public interface ITwillioService
    {
        Task<bool> Send(string to, string message, bool isSignupPinSms);
    }
}
