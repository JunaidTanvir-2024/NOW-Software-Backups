﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NowPayGApi.Models.DAOs
{
    public class DBResult<T>
    {
        public int DBStatus { get; set; }
        public string DBErrorMessage { get; set; }
        public T Data { get; set; }
    }
}
