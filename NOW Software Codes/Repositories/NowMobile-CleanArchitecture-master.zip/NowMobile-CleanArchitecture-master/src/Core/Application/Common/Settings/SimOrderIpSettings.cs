﻿
namespace Application.Common.Settings;
public class SimOrderIpSettings
{
    public const string SectionName = "SimOrderIpSettings";
    public static SimOrderIpSettings Bind = new SimOrderIpSettings();
    public int NumberOfHours { get; set; }
    public int NumberOfOrdersAllowed { get; set; }
}
