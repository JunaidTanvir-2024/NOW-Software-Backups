﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmsOutReachCallBackUrlApi.Models.Configurations
{
    public class SerilogConfig
    {
        public string FilePath { get; set; }
    }
}
