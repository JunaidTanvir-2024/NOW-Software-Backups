﻿namespace THCC.Domain.Entities
{
    public class Rate
    {
        public string? Country { get; set; }
        public string? ISOThreeCharacterCode { get; set; }
        public string? ISoTwoCharacterCode { get; set; }
        public float LandlineRatePerMin { get; set; }
        public float MobileRatePerMin { get; set; }
    }
}
