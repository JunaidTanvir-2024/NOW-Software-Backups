namespace DC.Core.Common.Setting;
public class SMSMarketingSetting
{
    public const string SectionName = nameof(SMSMarketingSetting);
    public static SMSMarketingSetting Instance { get; } = new SMSMarketingSetting();
    public string? Username { get; set; }
    public string? Password { get; set; }
    public string? From { get; set; }
    public string? IsAcitve { get; set; }
    public string? BaseUrl { get; set; }
}
