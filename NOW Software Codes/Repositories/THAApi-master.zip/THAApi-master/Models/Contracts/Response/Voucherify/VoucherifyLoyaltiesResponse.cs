﻿using System.Collections.Generic;

namespace Models.Contracts.Response.Voucherify
{
    public class VoucherifyLoyaltiesResponse
    {
        public long CustomerPoints { get; set; }
        public IEnumerable<LoyaltyRewardProducts> RewardProducts { get; set; }
        public class LoyaltyRewardProducts
        {
            public string SkuId { get; set; }
            public decimal Price { get; set; }
            public long Points { get; set; }
        }
        public IEnumerable<LoyaltyEarningCampaigns> LoyaltyCampaigns { get; set; }

        public LoyaltyTerms LoyaltyTermsInfo { get; set; } = new LoyaltyTerms();
        public class LoyaltyEarningCampaigns
        {
            public string LoyaltyName { get; set; }
            public long LoyaltyPoints { get; set; }
            public LoyaltyActionType LoyaltyType { get; set; }
        }
        public enum LoyaltyActionType
        {
            BuyBundle = 1,
            BuyTopup = 2,
            EnableAutoTopup = 3,
            ReferFriend = 4,
            MyAccount = 5
        }
        public class LoyaltyTerms
        {
            public string Heading { get; set; }
            public string Descripion { get; set; }
        }
    }
}