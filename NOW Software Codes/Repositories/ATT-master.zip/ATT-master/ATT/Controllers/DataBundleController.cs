﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ATT.Infrastructure.BLL.Sochitel;
using ATT.Infrastructure.BLL.TransferTo;
using ATT.Infrastructure.DAL;
using ATT.Models.Database;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace ATT.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class DataBundleController : ControllerBase
    {
    
        private ILogger loggerAPIAccess;
        private IDataBundlesDb_DL appDB;
        private ISochitelAutomation_BL sochiTelAutomation;
        private ITransfertoAutomation_BL transfertoAutomation;

        public DataBundleController(ILogger appLoggers, IDataBundlesDb_DL appDB, ITransfertoAutomation_BL transfertoAutomation, ISochitelAutomation_BL sochiTelAutomation)
        {
            loggerAPIAccess = appLoggers;
            this.appDB = appDB;
            this.transfertoAutomation = transfertoAutomation;
            this.sochiTelAutomation = sochiTelAutomation;
        }


        [HttpGet]
        [Route("getDataBundlesOperatorProductsMSISDN")]
        public async Task<IActionResult> getDataBundlesOperatorProductsMSISDN(int nsid, string destinationMSISDN, string account)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    ServiceProvider serviceProviderRecord = await appDB.GetDataBundleServiceProviderRecord(nsid, destinationMSISDN);
                    if (serviceProviderRecord != null)
                    {
                        if (serviceProviderRecord.DefaultServiceProviderDataBundles == 2) //transferto
                        {
                            var result = await transfertoAutomation.transferToGetDataBundlesOperatorProductsMSISDN(destinationMSISDN, account, serviceProviderRecord.OriginDestinationId);
                            return Ok(result);
                        }
                        else if (serviceProviderRecord.DefaultServiceProviderDataBundles == 1) // Sochitel
                        {
                            //var result = await sochiTelAutomation.sochitelGetOperatorProductsMSISDN(destinationMSISDN, account);
                            return Ok("Sochitel service is not available for DataBundle.");
                        }
                        else
                        {
                            loggerAPIAccess.Debug($"  \"GET /getDataBundlesOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                            var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                            return Ok(result2);
                        }
                    }
                    else
                    {
                        loggerAPIAccess.Debug($"  \"GET /getDataBundlesOperatorProductsMSISDN\"  Failed  Source:ATT API  Pasameters:      msisdn={destinationMSISDN}      currency-{account}  NSID--{nsid}     Reason=Service Not Found ");
                        var result2 = new { errorCode = 2, status = "Failure", message = "Service Not Found For this  MSISDN" };
                        return Ok(result2);
                    }
                }
                catch (Exception ex)
                {
                    loggerAPIAccess.Debug($"  \"GET /getDataBundlesOperatorProductsMSISDN\"  Failed  Source:General  Parameters-  currency:{account}    Message:{ex.ToString()}");
                    var errorResult = new { errorCode = 2, status = "Failure", message = "General API Access Error" };
                    return Ok(errorResult);
                }

            }

            return BadRequest(ModelState);


        }


    }
}