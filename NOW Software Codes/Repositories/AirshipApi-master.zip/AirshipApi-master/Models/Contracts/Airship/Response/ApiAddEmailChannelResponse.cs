﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Airship.Response
{
    public class ApiAddEmailChannelResponse
    {
        public bool ok { get; set; }
        public string channel_id { get; set; }
    }
}
