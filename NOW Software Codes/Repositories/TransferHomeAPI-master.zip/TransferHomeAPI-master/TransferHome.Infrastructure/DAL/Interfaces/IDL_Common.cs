﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TransferHome.Models.DAOs;

namespace TransferHome.Infrastructure.DAL.Interfaces
{
    public interface IDL_Common
    {
        Task<IEnumerable<DBTopAmounts>> TopUpAmounts();
    }
}
