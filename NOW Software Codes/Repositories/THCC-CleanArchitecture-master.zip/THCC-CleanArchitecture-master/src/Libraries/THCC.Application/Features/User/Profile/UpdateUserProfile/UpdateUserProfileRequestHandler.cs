﻿using Newtonsoft.Json;

using THCC.Application.Interfaces.Identity;
using THCC.Application.Interfaces.Repositories;
using THCC.Application.Models.ResponseWrappers;

namespace THCC.Application.Features.User.Profile.UpdateUserProfile;

public class UpdateUserProfileRequestHandler : IRequestHandler<UpdateUserProfileRequest,object>
{
    #region Fields

    private readonly IUserRepository _userRepository;
    private readonly ICurrentUser _currentUser;
    private readonly ILogger _logger;

    #endregion

    #region Ctor

    public UpdateUserProfileRequestHandler(
        IUserRepository userRepository,
        ICurrentUser currentUser,
        ILogger logger
        )
    {
        _userRepository = userRepository;
        _currentUser = currentUser;
        _logger = logger;
    }

    #endregion

    public async Task<object> Handle(UpdateUserProfileRequest request, CancellationToken cancellationToken)
    {
        var user = await _userRepository.GetUserByEmailAsync(_currentUser.GetUserEmail());
        user!.FirstName = request.FirstName;
        user.LastName = request.LastName;
        user.IsSubscribedToNewsletter= request.IsSubscribedToNewsletter;

        var response = await _userRepository.UpdatUserAsync(user!, request.FirstName, request.LastName);
        if (!response.Succeeded)
        {
            _logger.Debug($"Failed {user!.Email} update user info: {JsonConvert.SerializeObject(response?.Errors)}");
            ErrorResult.Failure(CustomStatusKey.InternalServerError, CustomStatusCode.InternalServerError);
        }

        return Unit.Value;
    }
}
