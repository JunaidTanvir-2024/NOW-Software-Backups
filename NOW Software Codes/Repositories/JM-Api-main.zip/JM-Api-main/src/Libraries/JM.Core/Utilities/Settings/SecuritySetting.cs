namespace JM.Core.Utilities.Settings;

public class SecuritySetting
{
    public const string SectionName = nameof(SecuritySetting);
    public required string Password { get; set; }
}
