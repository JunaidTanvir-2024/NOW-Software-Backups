using FH.Core.Interfaces.Services;

namespace FH.Infrastructure.Services.TimeWarp;

internal sealed class TimeWarpService : ITimeWarpService
{
    public DateTime UtcNow => DateTime.UtcNow;
}
