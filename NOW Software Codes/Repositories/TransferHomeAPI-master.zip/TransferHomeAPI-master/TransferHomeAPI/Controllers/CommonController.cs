﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TransferHome.Infrastructure.BLL.Interfaces;
using TransferHome.Models.Contracts.Request;
using Serilog;
using System.Net;
using TransferHome.Models.Configurations;
using Microsoft.Extensions.Options;
using TrasnferHome.Models.Contracts;
using System.Net.Http;
using System.Text;

namespace TransferHomeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly ILogger Logger;
        private readonly IBL_Common Bl;
        

        public CommonController(IBL_Common bl, ILogger logger)
        {
            Bl = bl;
            Logger = logger;
        }

        /// <summary>
        /// Required Basic Authentication
        /// </summary>
        [HttpGet]
        [Route("GetTopupAmounts")]
        [Authorize(Policy = "BasicAuth")]
        public async Task<IActionResult> GetTopupAmounts()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var response = await Bl.GetTopupAmounts();

                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: UserController, Method: FetchBalance, Parameters=> No Params, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer Authentication
        /// </summary>
        [HttpPost]
        [Route("GetInAppPurchaseOptions")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> GetInAppPurchaseOptions(GetInAppPurchaseOptionsRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var UserId = User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value;

                return Ok(await Bl.GetInAppPurchaseOptions(model,UserId));
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonController, Method: GetInAppPurchaseOptions, Parameters=> model: {model}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Required Bearer Authentication
        /// </summary>
        [HttpPost]
        [Route("ValidateAppleReciept")]
        [Authorize(Policy = "ActiveDevice")]
        public async Task<IActionResult> ValidateAppleReciept(ValidateAppleRecieptRequestModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                model.UserId = Convert.ToInt32(User.Claims.Where(x => x.Type == "Id").FirstOrDefault().Value);



                var response = await Bl.ValidateAppleReciept(model);




                //var options = await Bl.GetInAppPurchaseOptions(model, UserId);
                //Bl.ValidateAppleReciept(userId, )
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                Logger.Error($"Class: CommonController, Method: GetInAppPurchaseOptions, Parameters=> model: {model}, ErrorMessage: {(ex.InnerException == null ? ex.Message : ex.Message + " " + ex.InnerException.Message)}, StackTrace: {ex.StackTrace}");
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

    }
}