﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Configurations
{
    public class AirshipConfig
    {
        public string ApiEndPoint { get; set; }

        public string THA_AppKey { get; set; }
        public string THA_AppSecret { get; set; }
        public string THA_MasterSecret { get; set; }
        public string THA_BearerToken { get; set; }
        public AuthType THA_AuthType { get; set; }

        public string TRH_AppKey { get; set; }
        public string TRH_AppSecret { get; set; }
        public string TRH_MasterSecret { get; set; }
        public string TRH_BearerToken { get; set; }
        public AuthType TRH_AuthType { get; set; }

        public string THCC_AppKey { get; set; }
        public string THCC_AppSecret { get; set; }
        public string THCC_MasterSecret { get; set; }
        public string THCC_BearerToken { get; set; }
        public AuthType THCC_AuthType { get; set; }

        public string THM_AppKey { get; set; }
        public string THM_AppSecret { get; set; }
        public string THM_MasterSecret { get; set; }
        public string THM_BearerToken { get; set; }
        public AuthType THM_AuthType { get; set; }

    }
}
