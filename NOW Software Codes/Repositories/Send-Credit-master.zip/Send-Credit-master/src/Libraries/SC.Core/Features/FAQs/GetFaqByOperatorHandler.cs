﻿using MapsterMapper;

using RW.Models;

using SC.Core.Features.Countries.Requests;
using SC.Core.Features.FAQs.Requests;
using SC.Core.Features.FAQs.Response;
using SC.Core.Vendors.FusionHub;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Features.FAQs
{


    internal sealed class GetFaqByOperatorHandler : IRequestHandler<GetFaqByOperatorRequest, IResultWrapper>
    {
        private readonly IFaqRepository _faqRepository;
        private readonly IMapper _mapper;

        public GetFaqByOperatorHandler(IFaqRepository faqRepository, IMapper mapper)
        {
            
            _faqRepository = faqRepository;
            _mapper = mapper;
        }

        public async Task<IResultWrapper> Handle(GetFaqByOperatorRequest request, CancellationToken cancellationToken)
        {
            var requestdto = _mapper.Map<GetFaqsbyOperatorDto.Request>(request);


            // Assigning Default Values
            requestdto.IsActive = true;
            requestdto.IsDeleted = false;

            (IEnumerable<GetFaqsbyOperatorDto.Response> operatorFaqs, DatabasePaginationDto pagination)  = await _faqRepository.GetFaqsbyOperator(requestdto);
            
            if (operatorFaqs == null)
            {
                return ResultWrapper.Failure(AppConstants.StatusKeys.CommonFailureMessage, 404);
            }



            var result = operatorFaqs.Select(x => new GetFaqByOperatorResponse()
            {
                OperatorFaqId = x.OperatorFaqId,
                OperatorId = x.OperatorId,
                FaqId = x.FaqId,
                Question = x.Question,
                Answer = x.Answer,

            });


            return ResultWrapper.Success(result, new Pagination(pagination.TotalRecords, pagination.TotalPages, request.Page, request.RecordsPerPage));
        }
    }
}
