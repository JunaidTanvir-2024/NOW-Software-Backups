using Infrastructure.BLL.Services.Voucherify.Models.Customers.Requests;

namespace Infrastructure.BLL.Services.Voucherify.Models.Promotions.Requests
{
    public class RedeemPromotionTierRequest
    {
        public string PromotionTierId { get; set; } = null!;
        public CreateVoucherifyCustomerRequest Customer { get; set; } = null!;
    }
}
