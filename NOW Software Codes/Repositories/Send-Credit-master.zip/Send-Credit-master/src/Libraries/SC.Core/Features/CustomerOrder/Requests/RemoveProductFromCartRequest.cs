﻿

using SC.Core.Common.Interfaces.Services;
using System.Data.SqlTypes;
using System.Text.Json.Serialization;

namespace SC.Core.Features.CustomerOrder.Requests;
public sealed class RemoveProductFromCartRequest : IRequest<IResultWrapper>
{
    public long ProductID { get; set; } = default!;
    public long CustomerCartID { get; set; } = default!;
    public bool IsGuestUser { get; set; } = default!;
    public string? UserID { get; set; } = default!;

}
public sealed class RemoveProductFromCartRequestValidator : AbstractValidator<RemoveProductFromCartRequest>
{
    private readonly IHelperService _client;
    public RemoveProductFromCartRequestValidator(IHelperService client)
    {
        _client = client;
        RuleFor(x => x.ProductID).NotEmpty();
        RuleFor(x => x.CustomerCartID).NotEmpty();
        RuleFor(x => x.UserID).MustAsync(async (userId, cancellation) => await _client.IsValidUserID(userId)).WithMessage("User ID does not exist in system, must be a valid user").When(x => x.IsGuestUser);
    }
}

