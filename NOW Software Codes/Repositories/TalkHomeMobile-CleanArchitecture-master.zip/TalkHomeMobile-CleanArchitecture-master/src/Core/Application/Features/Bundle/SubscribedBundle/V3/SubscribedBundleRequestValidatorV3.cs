﻿namespace Application.Features.Bundle.SubscribedBundle.V3;
public class SubscribedBundleRequestValidatorV3 : AbstractValidator<SubscribedBundleRequestV3>
{
    public SubscribedBundleRequestValidatorV3(ICommonService commonService)
    {
        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop).NotEmpty().NotNull()
            .Must(p => commonService.IsValidMsisdn(p));
    }
}
