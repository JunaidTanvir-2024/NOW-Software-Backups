﻿
//import axios from 'axios';

//// GET method
//axios.get('/api/data')
//    .then(response => {
//        console.log(response.data);
//    })
//    .catch(error => {
//        console.error(error);
//    });

//// POST method with file upload
//const formData = new FormData();
//formData.append('name', 'John');
//formData.append('age', 30);
//formData.append('avatar', fileInput.files[0]); // assuming you have an input element with type="file" and id="fileInput"
//axios.post('/api/data', formData, {
//    headers: {
//        'Content-Type': 'multipart/form-data'
//    }
//})
//    .then(response => {
//        console.log(response.data);
//    })
//    .catch(error => {
//        console.error(error);
//    });

//// PUT method
//const data = {
//    name: 'Jane',
//    age: 25
//};
//axios.put('/api/data/123', data)
//    .then(response => {
//        console.log(response.data);
//    })
//    .catch(error => {
//        console.error(error);
//    });

//// DELETE method
//axios.delete('/api/data/123')
//    .then(response => {
//        console.log(response.data);
//    })
//    .catch(error => {
//        console.error(error);
//    });
