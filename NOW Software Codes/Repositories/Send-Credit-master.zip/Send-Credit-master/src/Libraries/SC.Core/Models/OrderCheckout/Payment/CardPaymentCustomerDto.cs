﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC.Core.Models.OrderCheckout.Payment;
public class CardPaymentCustomerDto
{
    public string Name { get; set; } = default!;
    public string? EmailAddress { get; set; } = default!;
    public string? Msisdn { get; set; } = default!;
    public string UniqueRef { get; set; } = default!;
    public BillingAddressDto? BillingAddress { get; set; } = default!;
}

