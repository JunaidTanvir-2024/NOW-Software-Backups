﻿using MassTransit;
using Microsoft.EntityFrameworkCore;
using SC.Core.MessageBroker;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using System.Reflection;
using SC.Core.Common.MessageEvents;
using MessageBrokerModel;

namespace SC.Infrastructure.Services.MessageBroker;
internal static class ConfigureMessageBroker
{
    internal static IServiceCollection AddRegisterMessageBrokerConfigurations(this IServiceCollection services, IConfiguration configuration)
    {
        var messageBrokerSetting = services.BuildServiceProvider().GetRequiredService<IOptions<MessageBrokerSetting>>().Value;

        services.AddDbContext<MessageBrokerDbContext>(options =>
        {
            options.UseNpgsql(configuration.GetConnectionString(AppConstants.DatabaseConnections.MessageBroker));
        });

        services.AddMassTransit(config =>
        {
            //config.AddConsumers(Assembly.GetExecutingAssembly());//  adding consumer here
            config.AddConsumer<OrderConsumer>();

            config.UsingRabbitMq((context, config) =>
            {
                config.Host(messageBrokerSetting.Host, messageBrokerSetting.Port, virtualHost: "/", configure: h =>
                {
                    h.Username(messageBrokerSetting.UserName);
                    h.Password(messageBrokerSetting.Password);
                });
                //config.MessageNameFormatting<TransactionMessageDto>(messageBrokerSetting.ShouldIncludeDTOPrefix);
                config.ReceiveEndpoint(messageBrokerSetting!.Queue, configureEndpoint: e =>
                {
                   
                    e.ConfigureConsumer<OrderConsumer>(context);
                });// Add Consumer EndPoint
                config.Publish<TransactionMessageDto>(x =>
                {
                    x.ExchangeType = ExchangeType.Fanout;
                    x.Durable = true;
                    x.AutoDelete = false;
                });
                config.UseMessageRetry(x => x.Interval(5, 5));
            });

            config.SetEndpointNameFormatter(new KebabCaseEndpointNameFormatter(messageBrokerSetting.MessagePrefix, false));

            config.AddEntityFrameworkOutbox<MessageBrokerDbContext>(config =>
            {
                config.QueryDelay = TimeSpan.FromSeconds(5);
                config.UsePostgres();
                config.UseBusOutbox();
            });
        });

        return services;
    }

    public static IRabbitMqBusFactoryConfigurator MessageNameFormatting<T>(this IRabbitMqBusFactoryConfigurator config, bool shouldIncludeDTOPrefix = false) where T : class
    {
        var input = typeof(T).Name;

        var parts = input.Split(':');

        if (parts.Length > 1)
        {
            input = string.Join(":", parts.Skip(1));
        }

        if (!shouldIncludeDTOPrefix)
        {
            input = input.Replace("Dto", "", StringComparison.InvariantCultureIgnoreCase);
        }

        var kebabCaseName = string.Concat(input.Select((x, i) =>
            i > 0 && char.IsUpper(x) ? "-" + x.ToString(CultureInfo.InvariantCulture) : x.ToString(CultureInfo.InvariantCulture)))
            .ToLowerInvariant();

        config.Message<T>(cfg => cfg.SetEntityName(kebabCaseName));

        return config;
    }
}

