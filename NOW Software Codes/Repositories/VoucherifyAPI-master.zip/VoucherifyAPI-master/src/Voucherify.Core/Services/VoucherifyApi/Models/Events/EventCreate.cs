using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;

namespace Voucherify.Core.Services.VoucherifyApi.Models.Events;

public class EventCreate
{
    [JsonPropertyName("event")]
    public string? Name { get; set; }

    [JsonPropertyName("customer")]
    public Customer? Customer { get; set; }

    [JsonPropertyName("referral")]
    public Referral? Referral { get; set; }

    [JsonPropertyName("metadata")]
    public Metadata? Metadata { get; set; }
}