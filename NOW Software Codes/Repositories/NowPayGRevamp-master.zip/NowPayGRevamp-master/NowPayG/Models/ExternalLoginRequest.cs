﻿using NowPayG.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NowPayG.Models
{
    public class ExternalLoginRequest
    {
        public string accessToken { get; set; }
        public LoginTypes socialLoginType { get; set; }
    }
}
