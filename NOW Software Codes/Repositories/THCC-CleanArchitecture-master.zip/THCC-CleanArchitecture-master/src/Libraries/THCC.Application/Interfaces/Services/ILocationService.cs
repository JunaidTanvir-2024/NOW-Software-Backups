﻿using THCC.Application.Extensions.DependencyResolver;
using THCC.Application.Models.Dtos;

namespace THCC.Application.Interfaces.Services
{
    public interface ILocationService : ServiceType.ITransient
    {
        Task<GeoLocationDto> GetLocationInfo();
    }
}
