using JM.Core.Utilities.DependencyResolver;

namespace JM.Core.Utilities.Interfaces.Services;

public interface IOtpService : ResolveAs.IScoped
{
    string GenerateOtp(int minValue = 111111, int maxValue = 999999);
}
