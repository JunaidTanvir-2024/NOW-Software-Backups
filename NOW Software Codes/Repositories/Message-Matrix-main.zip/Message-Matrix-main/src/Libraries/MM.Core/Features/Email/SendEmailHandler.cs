using MM.Core.Common.Definitions.Constants;
using MM.Core.Common.Interfaces.Services;
using MM.Core.Features.Email.Request;

namespace MM.Core.Features.Email;
internal class SendEmailHandler : IRequestHandler<SendEmailRequest, IResultWrapper>
{
    private readonly IEmailService _emailService;

    public SendEmailHandler(IEmailService emailService)
    {
        _emailService = emailService;
    }
    public async Task<IResultWrapper> Handle(SendEmailRequest request, CancellationToken cancellationToken)
    {
        await _emailService.SendEmailAsync(new SendEmailRequestDTO { To = request.To, Subject = request.Subject, EmailBody = request.EmailBody, ProductCode = request.ProductCode });
        return ResultWrapper.Success("Message send successfully", AppConstants.StatusCodes.Success);
    }
}
