﻿using FluentValidation;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;

namespace Voucherify.Api.Features.Promotions.Requests;

public class UpdatePromotionRequest
{
    public string? PromotionId { get; set; }

    public string? Name { get; set; }

    public string? Banner { get; set; }

    public long? AmountOff { get; private set; }

    public double? PercentOff { get; private set; }

    public double? UnitOff { get; private set; }

    public string? UnitType { get; private set; }

    public string? Category { get; set; }

    public string? CategoryId { get; set; }

    public Metadata? Metadata { get; set; }
}
internal class UpdatePromotionRequestValidator : AbstractValidator<UpdatePromotionRequest>
{
    public UpdatePromotionRequestValidator()
    {
        RuleFor(p => p.PromotionId).NotNull().NotEmpty();
    }
}