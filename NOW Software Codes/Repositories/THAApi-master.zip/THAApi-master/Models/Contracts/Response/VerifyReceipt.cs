﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Contracts.Response
{
    
    public class VerifyReceiptResponse
    {
        public string TransactionId { get; set; }

        public string Balance { get; set; }

        public string Credit { get; set; }
    }

    public class VerifyReceiptRequest
    {
        public string Msisdn { get; set; }

        public string Pin { get; set; }

        public string Receipt { get; set; }

        public string AppVersion { get; set; }
    }

    public class InAppPurchaseReceipt
    {
        public InAppPurchaseReceipt()
        {
            this.Receipt = new Receipt();
        }

        public Receipt Receipt { get; set; }

        public int Status { get; set; }
    }

    public class Receipt
    {
        [JsonProperty(PropertyName = "original_purchase_date_pst")]
        public string OriginalPurchaseDatePST { get; set; }

        [JsonProperty(PropertyName = "unique_identifier")]
        public string UniqueIdentifier { get; set; }

        [JsonProperty(PropertyName = "original_transaction_id")]
        public string OriginalTransactionID { get; set; }

        [JsonProperty(PropertyName = "bvrs")]
        public string BVRS { get; set; }

        [JsonProperty(PropertyName = "app_item_id")]
        public string AppItemId { get; set; }

        [JsonProperty(PropertyName = "quantity")]
        public string Quantity { get; set; }

        [JsonProperty(PropertyName = "unique_vendor_identifier")]
        public string UniqueVendorIdentifier { get; set; }

        //[JsonProperty(PropertyName = "product_id")]
        //public string ProductId { get; set; }

        [JsonProperty(PropertyName = "item_id")]
        public string ItemId { get; set; }

        [JsonProperty(PropertyName = "version_external_identifier")]
        public string VersionExternalIdentifier { get; set; }

        [JsonProperty(PropertyName = "bundle_id")]
        public string Bid { get; set; }

        [JsonProperty(PropertyName = "purchase_date_ms")]
        public string PurchaseDateMS { get; set; }

        [JsonProperty(PropertyName = "purchase_date")]
        public string PurchaseDate { get; set; }

        [JsonProperty(PropertyName = "purchase_date_pst")]
        public string PurchaseDatePST { get; set; }

        [JsonProperty(PropertyName = "original_purchase_date")]
        public string OriginalPurchaseDate { get; set; }

        [JsonProperty(PropertyName = "original_purchase_date_ms")]
        public string OriginalPurchaseDateMS { get; set; }

        [JsonProperty(PropertyName = "in_app")]
        public List<InAppReceipt> InAppData { get; set; }
    }

    public class InAppReceipt
    {
        [JsonProperty(PropertyName = "product_id")]
        public string ProductId { get; set; }

        [JsonProperty(PropertyName = "transaction_id")]
        public string TransactionId { get; set; }        
    }
}
