﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATT.Models.Contracts.TransferTo.Response
{
    public class TransferToMSISDNInfoResponse
    {
        public string country { get; set; }
        public int countryid { get; set; }
        public string @operator {get; set;}
        public int operatorid { get; set; }
    }
}
