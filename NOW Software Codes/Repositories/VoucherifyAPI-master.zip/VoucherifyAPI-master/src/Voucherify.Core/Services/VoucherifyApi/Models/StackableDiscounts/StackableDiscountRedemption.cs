using System.Text.Json.Serialization;

using Voucherify.Core.Services.VoucherifyApi.Models.Common;
using Voucherify.Core.Services.VoucherifyApi.Models.Customers;
using Voucherify.Core.Services.VoucherifyApi.Models.Orders;
using Voucherify.Core.Services.VoucherifyApi.Models.Vouchers;

namespace Voucherify.Core.Services.VoucherifyApi.Models.StackableDiscounts;

public class StackableDiscountRedemption
{
    [JsonPropertyName("redemptions")]
    public RedemptionInfo[]? Redemptions { get; set; }

    [JsonPropertyName("order")]
    public Order? Order { get; set; }

    public class RedemptionInfo
    {
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        [JsonPropertyName("object")]
        public string? Object { get; set; }

        [JsonPropertyName("date")]
        public DateTimeOffset Date { get; set; }

        [JsonPropertyName("customer_id")]
        public string? CustomerId { get; set; }

        [JsonPropertyName("tracking_id")]
        public string? TrackingId { get; set; }

        [JsonPropertyName("metadata")]
        public Metadata? Metadata { get; set; }

        [JsonPropertyName("result")]
        public string? Result { get; set; }

        [JsonPropertyName("order")]
        public Order? Order { get; set; }

        [JsonPropertyName("customer")]
        public Customer? Customer { get; set; }

        [JsonPropertyName("related_object_type")]
        public string? RelatedObjectType { get; set; }

        [JsonPropertyName("related_object_id")]
        public string? RelatedObjectId { get; set; }

        [JsonPropertyName("voucher")]
        public Voucher? Voucher { get; set; }
    }
}