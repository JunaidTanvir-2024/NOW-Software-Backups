﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Utilities
{    
    public static class PhoneNumberFixer
    {
        public static string Fix(string number)
        {
            var withoutPlus = StripPlus(number);
            var result = StripZeroes(withoutPlus);
            return result;
        }

        private static string StripPlus(string msisdn)
        {
            if (msisdn.StartsWith("+"))
            {
                return msisdn.Substring(1);
            }
            return msisdn;
        }

        private static string StripZeroes(string msisdn)
        {
            if (msisdn.StartsWith("00"))
            {
                return msisdn.Substring(2);
            }
            return msisdn;
        }
    }
}
