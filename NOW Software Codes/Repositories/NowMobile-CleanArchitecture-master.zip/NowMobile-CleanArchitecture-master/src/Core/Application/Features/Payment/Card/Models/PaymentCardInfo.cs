﻿namespace Application.Features.Payment.Card.Models;

public class PaymentNewCardInfo
{
    public string? NameOnCard { get; set; }
    public string? CardNumber { get; set; }
    public string? ExpiryMonth { get; set; }
    public string? ExpiryYear { get; set; }
    public string? SecurityCode { get; set; }
    public bool SaveCard { get; set; } = false;
    public bool MakeDefault { get; set; } = false;
}

public class PaymentExistingCardInfo
{
    public string? CardToken { get; set; }
    public string? SecurityCode { get; set; }
}