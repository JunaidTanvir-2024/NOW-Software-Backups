﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferHome.Models.Contracts.Service.SmsServiceModels
{
    public class SmsServiceModels
    {

    }

    public class XeebiSendSmsResponse
    {
        public string message { get; set; }
        public string status { get; set; }
        public int errorCode { get; set; }
        public Payload payload { get; set; }

    }
    public class Payload
    {
        public string message_id { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string submit_status { get; set; }
        public int sms_count { get; set; }
        public DateTime? created_date { get; set; }
        public string sent_date { get; set; }
        public string delivered_date { get; set; }
        public string delivery_status { get; set; }
    }

    public class XeebiSendSmsRequest
    {
        public string from { get; set; }
        public string to { get; set; }
        public string text { get; set; }

    }

    public class SendSAPSMSRequestModel
    {
        public string[] destination { get; set; }
        public string origination { get; set; }
        public string message { get; set; }
    }
}
