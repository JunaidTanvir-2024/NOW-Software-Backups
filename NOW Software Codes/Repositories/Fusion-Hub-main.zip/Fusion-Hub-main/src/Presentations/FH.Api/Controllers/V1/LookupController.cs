using Asp.Versioning;

using FH.Api.Controllers.Common;
using FH.UseCases.Lookups;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V1;

[ApiVersion(1.0)]
public sealed class LookupController : BaseApiController
{
    [HttpGet("mobile")]
    public async Task<ActionResult> MobileNumberLookup([FromQuery] MsisdnLookup.Query request)
    {
        var result = await Mediator.Send(request);
        if (result.IsSuccess)
        {
            return Ok(result);
        }
        return NotFound(result);
    }
}
