﻿using Application.Common.Settings;
using Microsoft.Extensions.Options;

namespace Application.Features.Discount;
public class DiscountRequestValidator : AbstractValidator<DiscountRequest>
{
    public DiscountRequestValidator(ICommonService commonService, IOptions<TopupSettings> options)
    {
        RuleFor(p => p.CheckoutType).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty();

        RuleFor(p => p.TopupAmount).Cascade(CascadeMode.Stop)
            .NotEmpty()
            .NotNull()
            .Must(p => options.Value.TopUpAmounts.Contains(p))
            .When(p => p.TopupAmount > 0 || p.BundleId <= 0)
            .WithMessage("Invalid top-up amount");

        RuleFor(p => p.Msisdn).Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Must(p => commonService.IsValidMsisdn(p!))
            .When(p => !string.IsNullOrEmpty(p.Msisdn))
            .WithMessage("Invalid Msisdn");
    }
}
