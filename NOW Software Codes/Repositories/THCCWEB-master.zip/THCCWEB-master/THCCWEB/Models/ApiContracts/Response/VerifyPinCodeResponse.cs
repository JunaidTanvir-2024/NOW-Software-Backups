﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Response
{
    public class VerifyPinCodeResponse
    {
        public int error_code { get; set; }
        public string error_msg { get; set; }
    }
}
