﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSOutReach.Modal.Configurations
{
    public class DBResult
    {

        public int DBStatus { get; set; }
        public string DBErrorMessage { get; set; }

    }
}
