using FH.Core.DependencyResolver;

namespace FH.Infrastructure.Services.Caching;

public interface ICacheManager : ServiceType.ISingleton
{
	Task StoreInCache(string? cacheKey, string? cacheValue, string? expiryInMinutes);
	Task<string?> RetrieveFromCache(string? cacheKey);
}
