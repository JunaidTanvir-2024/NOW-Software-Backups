using FH.Core.DependencyResolver;
using FH.Core.DTOs.Database;
using FH.Core.Entities;

namespace FH.Core.Interfaces.Database;
public interface IProductRepository : ServiceType.IScoped
{
	Task<ProductDetailDto.Response?> GetProductDetail(ProductDetailDto.Request request);
	Task<(IEnumerable<ProductDto.Response> products, DatabasePaginationDto pagination)> GetProducts(ProductDto.Request productRequestDto);
	Task<IEnumerable<ProductStatusDto.Response>?> CheckProductsAvailability(ProductStatusDto.Request productStatusRequestDto);
	Task<IEnumerable<ProductBenefitEntity>> ProductBenefitUpsert(IEnumerable<ProductBenefitEntity> productBenefitDto);
	Task<IEnumerable<ProductCategoryEntity>> ProductCategoryUpsert(IEnumerable<ProductCategoryEntity> productCategoryDto);
	Task<IEnumerable<ProductPriceEntity>> ProductPriceUpsert(IEnumerable<ProductPriceEntity> productPriceDto);
	Task<IEnumerable<ProductSubCategoryEntity>> ProductSubCategoryUpsert(IEnumerable<ProductSubCategoryEntity> productSubCategories);
	Task<IEnumerable<ProductEntity>> ProductUpsert(IEnumerable<ProductEntity> productDto);
	Task UpdateProductsAliases(IEnumerable<ProductAliasDto.Request> request);
    Task<(IEnumerable<ProductByOperatorDto.Response> products, DatabasePaginationDto pagination)> GetSingleProductByEachOperator(ProductByOperatorDto.Request productRequestDto);
    Task<IEnumerable<ProductByCategoryDto.Response>> GetProductSubCategoryByCategory(ProductByCategoryDto.Request request);
}
