﻿using Models.Contracts.Response;
using Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static THAApi.ViewModels.SuccessViewModel;

namespace THAApi.ViewModels
{
    public class ErrorViewModel
    {
        public CheckOutTypes Type { get; set; }
        public PaymentMehtods PaymentMethod { get; set; }
        public string Origination { get; set; }
        public string Message { get; set; }
        public ThemeMode ThemeMode { get; set; }
        public string Amount { get; set; }
        public BundlePurchaseInfo BundlePurchaseInfo { get; set; } = default;
    }
}
