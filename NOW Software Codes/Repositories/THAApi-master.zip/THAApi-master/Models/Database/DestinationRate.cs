﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Database
{
    
    public class DestinationRate
    {
        public string Number { get; set; }

        public string Zone { get; set; }

        public decimal CallRate { get; set; }

        public decimal SMSRate { get; set; }
    }

    public class DestinationMsisdn
    {
        public string destinationMsisdn { get; set; }
    }
}
