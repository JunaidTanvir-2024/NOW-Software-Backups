﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace THCCWEB.Models.ApiContracts.Request.Paypal
{
    public class CancelReturnPayPalViewModel
    {
        public string token { get; set; }
        public string ProductCode { get; set; }
        public int ErrorCode { get; set; }
        public string Message { get; set; }
    }
}
