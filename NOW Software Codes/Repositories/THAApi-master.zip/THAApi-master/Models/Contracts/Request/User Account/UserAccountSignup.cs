﻿namespace Models.Contracts.Request
{
    public class UserAccountSignup
    {
        public string Pin { get; set; }
    }
}
