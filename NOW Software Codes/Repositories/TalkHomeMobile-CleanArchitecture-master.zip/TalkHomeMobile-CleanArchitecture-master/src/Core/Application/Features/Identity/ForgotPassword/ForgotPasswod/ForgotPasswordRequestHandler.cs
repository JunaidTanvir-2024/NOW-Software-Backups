﻿using Application.Common.Interfaces.Infrastructure.Identity;
using Application.Common.Mailing;

namespace Application.Features.Identity.ForgotPassword.ForgotPasswod;

public class ForgotPasswordRequestHandler : IRequestHandler<ForgotPasswordRequest, Result<object>>
{
    private readonly IOtpService _otpService;
    private readonly IStringLocalizer<ForgotPasswordRequestHandler> _localizer;
    private readonly IMailService _mailService;
    private readonly IUnitOfWork _unitOfWork;

    public ForgotPasswordRequestHandler(
         IOtpService otpService,
         IStringLocalizer<ForgotPasswordRequestHandler> localizer,
         IMailService mailService,
         IUnitOfWork unitOfWork
       )
    {
        _otpService = otpService;
        _localizer = localizer;
        _mailService = mailService;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<object>> Handle(ForgotPasswordRequest request, CancellationToken cancellationToken)
    {
        //Validate user for any type of deactivation

        //get user by email
        var userReponse = await _unitOfWork.UserRepo.GetUserByEmail(request.EmailAddress);
        if (userReponse == null)
        {
            return Result<object>.Failure(null!, _localizer[CustomStatusKey.AccountNotRegistered], CustomStatusCode.AccountNotRegistered);
        }

        //Geneate Otp
        var (Otp, otpModel) = await _otpService.CreateOtp(request.EmailAddress, OtpType.ForgotPassword, true);
        if (otpModel.StatusCode != CustomStatusCode.OtpIsNotCreated)
        {
            //Send Email
            await _mailService.SendForgotPasswordEmailAsync(request.EmailAddress, Otp);
        }
        return Result<object>.Success(null!, _localizer[CustomStatusKey.Success]);
    }
}