using System.Data;

using CH.Api.Common.Definitions;
using CH.Api.Common.Repositories.DTOs;

using Dapper;

using Microsoft.Data.SqlClient;

namespace CH.Api.Common.Repositories;
public interface ILoggerRepository
{
    Task AppLogUpsertAsync(AppLogDto logDto);
    Task VendorLogInsertAsync(VendorLogDto vendorLogDto);
}

internal sealed class LoggerRepository(IConfiguration configuration) : ILoggerRepository
{
    private readonly IConfiguration? _configuration = configuration;
    private const string AppLogUpsert = "ch_app_log_upsert";
    private const string VendorLogInsert = "ch_vendor_log_insert";
    public async Task AppLogUpsertAsync(AppLogDto appLogDto)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.CallbackHub)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("@request_timestamp", appLogDto.Timestamp);
            parameters.Add("@request_path", appLogDto.RequestPath);
            parameters.Add("@request_method", appLogDto.RequestMethod);
            parameters.Add("@request_body", appLogDto.RequestBody);
            parameters.Add("@response_body", appLogDto.ResponseBody);
            parameters.Add("@status_code", appLogDto.StatusCode);
            parameters.Add("@duration", appLogDto.Duration);
            parameters.Add("@client_ip", appLogDto.ClientIP);
            parameters.Add("@user_agent", appLogDto.UserAgent);
            parameters.Add("@response_size", appLogDto.ResponseSize);
            parameters.Add("@error_reason", appLogDto.ErrorReason);
            parameters.Add("@correlation_id", appLogDto.CorrelationId);
            parameters.Add("@query_string", appLogDto.QueryString);
            await connection.ExecuteAsync(AppLogUpsert, parameters, commandType: CommandType.StoredProcedure);
        }
    }
    public async Task VendorLogInsertAsync(VendorLogDto vendorLogDto)
    {
        using (var connection = new SqlConnection(_configuration?.GetConnectionString(AppConstants.DatabaseConnections.CallbackHub)))
        {
            var parameters = new DynamicParameters();
            parameters.Add("request_timestamp", vendorLogDto.Timestamp);
            parameters.Add("request_path", vendorLogDto.RequestPath);
            parameters.Add("request_method", vendorLogDto.RequestMethod);
            parameters.Add("request_body", vendorLogDto.RequestBody);
            parameters.Add("response_body", vendorLogDto.ResponseBody);
            parameters.Add("status_code", vendorLogDto.StatusCode);
            parameters.Add("duration", vendorLogDto.Duration);
            parameters.Add("response_size", vendorLogDto.ResponseSize);
            parameters.Add("error_reason", vendorLogDto.ErrorReason);
            parameters.Add("correlation_id", vendorLogDto.CorrelationId ?? Guid.NewGuid().ToString());
            parameters.Add("headers", vendorLogDto.Headers);
            parameters.Add("query_string", vendorLogDto.QueryString);
            parameters.Add("vendor_id", vendorLogDto.VendorId);
            await connection.ExecuteAsync(VendorLogInsert, parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
