using Asp.Versioning;

using FH.Api.Controllers.Common;

using Microsoft.AspNetCore.Mvc;

namespace FH.Api.Controllers.V2;

[ApiVersion(2.0)]
public class WeatherForecastController : BaseApiController
{
    private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    public WeatherForecastController()
    {
    }
    [HttpGet(Name = "GetWeatherForecast")]
    public ActionResult Get()
    {
        var result = GetWeatherInfo();

        return Ok(result);
    }

    private static string[] GetWeatherInfo()
    {
        return Summaries;
    }

}
